import { Router, Response } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { db } from '../db.js';
import { AuthenticatedRequest, authenticate, JWT_SECRET } from '../middleware/auth.js';

const router = Router();

// Register new user
router.post('/register', (req, res) => {
  try {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({
        success: false,
        error: 'Name, email, and password are required.'
      });
    }

    if (password.length < 6) {
      return res.status(400).json({
        success: false,
        error: 'Password must be at least 6 characters long.'
      });
    }

    const existing = db.findUserByEmail(email);
    if (existing) {
      return res.status(400).json({
        success: false,
        error: 'An account with this email already exists.'
      });
    }

    const newUser = db.createUser({ name, email, password });
    const token = jwt.sign(
      { id: newUser.id, email: newUser.email, role: newUser.role },
      JWT_SECRET,
      { expiresIn: '30d' }
    );

    return res.status(201).json({
      success: true,
      message: 'Account created successfully',
      token,
      user: {
        id: newUser.id,
        name: newUser.name,
        email: newUser.email,
        role: newUser.role,
        apiKey: newUser.apiKey
      }
    });
  } catch (err: any) {
    console.error('Registration error:', err);
    return res.status(500).json({
      success: false,
      error: err.message || 'Server error during registration'
    });
  }
});

// Login
router.post('/login', (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        error: 'Email and password are required.'
      });
    }

    const user = db.findUserByEmail(email);
    if (!user) {
      return res.status(401).json({
        success: false,
        error: 'Invalid email or password.'
      });
    }

    const isMatch = bcrypt.compareSync(password, user.passwordHash);
    if (!isMatch) {
      return res.status(401).json({
        success: false,
        error: 'Invalid email or password.'
      });
    }

    const token = jwt.sign(
      { id: user.id, email: user.email, role: user.role },
      JWT_SECRET,
      { expiresIn: '30d' }
    );

    return res.json({
      success: true,
      message: 'Login successful',
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        apiKey: user.apiKey
      }
    });
  } catch (err: any) {
    console.error('Login error:', err);
    return res.status(500).json({
      success: false,
      error: err.message || 'Server error during login'
    });
  }
});

// Google Authentication Route (Instant one-click sync & login)
router.post('/google', (req, res) => {
  try {
    const { email, name, googleId } = req.body;

    if (!email) {
      return res.status(400).json({
        success: false,
        error: 'Google email is required.'
      });
    }

    let user = db.findUserByEmail(email);
    if (!user) {
      user = db.createUser({
        name: name || email.split('@')[0],
        email: email,
        authProvider: 'google',
        role: 'user'
      });
    }

    const token = jwt.sign(
      { id: user.id, email: user.email, role: user.role },
      JWT_SECRET,
      { expiresIn: '60d' }
    );

    return res.json({
      success: true,
      message: 'Google sign-in successful',
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        phoneNumber: user.phoneNumber,
        authProvider: user.authProvider || 'google',
        role: user.role,
        apiKey: user.apiKey,
        createdAt: user.createdAt
      }
    });
  } catch (err: any) {
    console.error('Google auth error:', err);
    return res.status(500).json({
      success: false,
      error: err.message || 'Server error during Google authentication'
    });
  }
});

// Phone Number Authentication Route (OTP/Phone Login)
router.post('/phone', (req, res) => {
  try {
    const { phone, otp, name } = req.body;

    if (!phone) {
      return res.status(400).json({
        success: false,
        error: 'Phone number is required.'
      });
    }

    // Clean phone number format
    const cleanPhone = phone.trim();
    const phoneEmail = `phone_${cleanPhone.replace(/\D/g, '')}@mastibash.local`;

    let user = db.findUserByPhone(cleanPhone) || db.findUserByEmail(phoneEmail);
    if (!user) {
      user = db.createUser({
        name: name || `User ${cleanPhone.slice(-4)}`,
        email: phoneEmail,
        phoneNumber: cleanPhone,
        authProvider: 'phone',
        role: 'user'
      });
    }

    const token = jwt.sign(
      { id: user.id, email: user.email, role: user.role },
      JWT_SECRET,
      { expiresIn: '60d' }
    );

    return res.json({
      success: true,
      message: 'Phone login successful',
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        phoneNumber: user.phoneNumber || cleanPhone,
        authProvider: 'phone',
        role: user.role,
        apiKey: user.apiKey,
        createdAt: user.createdAt
      }
    });
  } catch (err: any) {
    console.error('Phone auth error:', err);
    return res.status(500).json({
      success: false,
      error: err.message || 'Server error during phone authentication'
    });
  }
});

// Seamless Email Authentication & Sync for Masti Video App
router.post('/email-sync', (req, res) => {
  try {
    const { email, name, avatarUrl, userId, bio } = req.body;

    if (!email || typeof email !== 'string' || !email.includes('@')) {
      return res.status(400).json({
        success: false,
        error: 'Valid email address is required (e.g., user@gmail.com).'
      });
    }

    const cleanEmail = email.trim().toLowerCase();
    const displayName = name || cleanEmail.split('@')[0];
    const user = db.findOrCreateUserByEmail(cleanEmail, displayName, avatarUrl);

    // If userId was provided and different, link alias
    if (userId && userId !== user.id) {
      db.syncUserFromApp({
        userId: user.id,
        userName: displayName,
        userAvatar: avatarUrl,
        email: cleanEmail,
        bio
      });
    }

    const token = jwt.sign(
      { id: user.id, email: user.email, role: user.role },
      JWT_SECRET,
      { expiresIn: '90d' }
    );

    return res.json({
      success: true,
      message: 'User authenticated and synced by email with Masti Bash Cloud',
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        phoneNumber: user.phoneNumber,
        avatarUrl: (user as any).avatarUrl || `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(user.name)}`,
        bio: (user as any).bio,
        role: user.role,
        apiKey: user.apiKey,
        createdAt: user.createdAt
      }
    });
  } catch (err: any) {
    console.error('Email sync auth error:', err);
    return res.status(500).json({
      success: false,
      error: err.message || 'Server error during email authentication'
    });
  }
});

// Alias: /api/auth/masti-user
router.post('/masti-user', (req, res) => {
  const { email, name, avatarUrl, userId, bio } = req.body;
  if (!email && userId) {
    // If only userId sent, fallback
    const synced = db.syncUserFromApp({ userId, userName: name || 'Masti User', userAvatar: avatarUrl, email, bio });
    return res.json({ success: true, data: synced });
  }
  if (!email) {
    return res.status(400).json({ success: false, error: 'Email is required' });
  }
  const cleanEmail = String(email).trim().toLowerCase();
  const user = db.findOrCreateUserByEmail(cleanEmail, name, avatarUrl);
  const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: '90d' });
  return res.json({
    success: true,
    token,
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      avatarUrl: (user as any).avatarUrl,
      apiKey: user.apiKey
    }
  });
});

// Firebase Login & Sync Endpoint (Single Source of Truth for Masti Video)
router.post('/firebase-login', (req, res) => {
  try {
    const { firebaseIdToken, token, firebaseUid, email, name, avatarUrl, phoneNumber, username } = req.body;

    let targetUid = firebaseUid;
    let targetEmail = email;
    let targetName = name;
    let targetAvatar = avatarUrl;
    let targetPhone = phoneNumber;
    let targetUsername = username;

    const rawToken = firebaseIdToken || token;
    if (rawToken && typeof rawToken === 'string') {
      try {
        const decoded = jwt.decode(rawToken, { complete: true }) as any;
        if (decoded && decoded.payload) {
          const payload = decoded.payload;
          targetUid = targetUid || payload.user_id || payload.sub || payload.uid;
          targetEmail = targetEmail || payload.email;
          targetName = targetName || payload.name || payload.display_name;
          targetAvatar = targetAvatar || payload.picture || payload.avatar_url;
          targetPhone = targetPhone || payload.phone_number;
        }
      } catch {
        // Continue with body params
      }
    }

    if (!targetUid && !targetEmail) {
      return res.status(400).json({
        success: false,
        error: 'firebaseUid or email is required for Firebase login & MastiBase sync.'
      });
    }

    const effectiveUid = targetUid || `fb_${(targetEmail || '').replace(/[^a-zA-Z0-9]/g, '_')}`;

    const user = db.createUserWithFirebase({
      firebaseUid: effectiveUid,
      email: targetEmail,
      name: targetName,
      avatarUrl: targetAvatar,
      phoneNumber: targetPhone,
      username: targetUsername
    });

    const authToken = jwt.sign(
      { id: user.id, firebaseUid: user.firebaseUid, email: user.email, role: user.role },
      JWT_SECRET,
      { expiresIn: '90d' }
    );

    return res.json({
      success: true,
      message: 'Firebase user authenticated and mapped to permanent MastiBase identity',
      token: authToken,
      mastiBaseUserId: user.id,
      user: {
        id: user.id, // MastiBase permanent userId (single source of truth)
        firebaseUid: user.firebaseUid, // Firebase auth UID
        username: user.username,
        name: user.name,
        email: user.email,
        phoneNumber: user.phoneNumber,
        avatarUrl: (user as any).avatarUrl,
        bio: (user as any).bio,
        role: user.role,
        apiKey: user.apiKey,
        followersCount: user.followersCount || 0,
        followingCount: user.followingCount || 0,
        totalLikes: user.totalLikes || 0,
        totalVideos: user.totalVideos || 0,
        isVerified: user.isVerified || false,
        privacySettings: user.privacySettings,
        notificationSettings: user.notificationSettings,
        createdAt: user.createdAt
      }
    });
  } catch (err: any) {
    console.error('Firebase login error:', err);
    return res.status(500).json({ success: false, error: err.message || 'Failed to authenticate Firebase user' });
  }
});

// Alias: /api/auth/firebase-sync
router.post('/firebase-sync', (req, res) => {
  return (router as any).handle({ ...req, url: '/firebase-login' }, res);
});

// Get Quick API Key for Replit & APK Connect
router.get('/quick-key', (req, res) => {
  const allUsers = db.getUsers();
  const admin = allUsers.find(u => u.role === 'admin') || allUsers[0];
  const apiKey = admin?.apiKey || 'mb_live_master_rajkali_2026';
  const host = req.headers['x-forwarded-host'] || req.headers.host;
  const proto = req.headers['x-forwarded-proto'] || req.protocol || 'https';
  const baseUrl = host ? `${proto}://${host}` : '';

  return res.json({
    success: true,
    apiKey,
    baseUrl,
    headerName: 'x-api-key',
    replitSecret: {
      key: 'MASTI_API_KEY',
      value: apiKey
    },
    sampleCurl: `curl -H "x-api-key: ${apiKey}" "${baseUrl}/api/videos/feed"`
  });
});

// Get current user profile
router.get('/me', authenticate, (req: AuthenticatedRequest, res: Response) => {
  if (!req.user) {
    return res.status(401).json({ success: false, error: 'Unauthorized' });
  }

  return res.json({
    success: true,
    user: {
      id: req.user.id,
      firebaseUid: req.user.firebaseUid,
      username: req.user.username,
      name: req.user.name,
      email: req.user.email,
      phoneNumber: req.user.phoneNumber,
      authProvider: req.user.authProvider,
      avatarUrl: (req.user as any).avatarUrl,
      bio: (req.user as any).bio,
      role: req.user.role,
      apiKey: req.user.apiKey,
      followersCount: req.user.followersCount || 0,
      followingCount: req.user.followingCount || 0,
      isVerified: req.user.isVerified || false,
      privacySettings: req.user.privacySettings,
      notificationSettings: req.user.notificationSettings,
      createdAt: req.user.createdAt
    }
  });
});

export default router;
