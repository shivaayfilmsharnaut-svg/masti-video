import { Router, Response } from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { v4 as uuidv4 } from 'uuid';
import { db } from '../db.js';
import { AuthenticatedRequest, authenticate, optionalAuth } from '../middleware/auth.js';
import { MediaType } from '../../src/types.js';

const router = Router();
const UPLOADS_DIR = path.resolve(process.cwd(), 'uploads');

if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

// Multer Storage Configuration
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, UPLOADS_DIR);
  },
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase() || '';
    const cleanBase = path.basename(file.originalname, ext).replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 30);
    const uniqueSuffix = `${Date.now()}_${uuidv4().slice(0, 8)}`;
    const storedName = `mb_${cleanBase}_${uniqueSuffix}${ext}`;
    cb(null, storedName);
  }
});

// File filter for images, videos, and audio files
const fileFilter = (_req: any, file: Express.Multer.File, cb: multer.FileFilterCallback) => {
  const allowedMime = [
    // Image MIME types
    'image/jpeg', 'image/jpg', 'image/png', 'image/webp', 'image/gif', 'image/svg+xml', 'image/avif',
    // Video MIME types
    'video/mp4', 'video/webm', 'video/ogg', 'video/quicktime', 'video/x-msvideo', 'video/x-matroska',
    // Audio MIME types
    'audio/mpeg', 'audio/mp3', 'audio/wav', 'audio/wave', 'audio/x-wav', 'audio/ogg', 'audio/aac',
    'audio/m4a', 'audio/x-m4a', 'audio/mp4', 'audio/flac', 'audio/x-flac', 'audio/opus', 'audio/webm',
    'audio/midi', 'audio/x-midi'
  ];

  if (
    file.mimetype.startsWith('image/') ||
    file.mimetype.startsWith('video/') ||
    file.mimetype.startsWith('audio/') ||
    allowedMime.includes(file.mimetype) ||
    file.originalname.match(/\.(mp3|wav|ogg|oga|opus|m4a|aac|flac|weba|mp4|webm|mov|mkv|avi|jpg|jpeg|png|webp|gif|svg|avif)$/i)
  ) {
    cb(null, true);
  } else {
    cb(new Error(`Unsupported file type: ${file.mimetype}. Images, videos, and audio files are supported.`));
  }
};

const upload = multer({
  storage,
  fileFilter
  // Unlimited file size and unlimited files per batch
});

// Helper to construct public URL (both absolute and relative supported)
const getPublicFileUrl = (req: any, storedName: string) => {
  const host = req.headers['x-forwarded-host'] || req.headers.host;
  const proto = req.headers['x-forwarded-proto'] || req.protocol || 'https';
  if (host) {
    return `${proto}://${host}/uploads/${storedName}`;
  }
  return `/uploads/${storedName}`;
};

const enrichMediaItem = (item: any, req: any) => {
  const host = req.headers['x-forwarded-host'] || req.headers.host;
  const proto = req.headers['x-forwarded-proto'] || req.protocol || 'https';
  const baseUrl = host ? `${proto}://${host}` : '';
  
  let fullUrl = item.fileUrl || '';
  if (fullUrl.startsWith('/')) {
    fullUrl = `${baseUrl}${fullUrl}`;
  }
  
  const displayTitle = item.title || item.originalName;

  return {
    ...item,
    url: fullUrl,
    fileUrl: fullUrl,
    videoUrl: item.mediaType === 'video' ? fullUrl : undefined,
    streamUrl: fullUrl,
    hlsUrl: item.mediaType === 'video' ? `${baseUrl}/api/v1/hls/${item.id}/master.m3u8` : undefined,
    title: displayTitle,
    name: displayTitle,
    thumbnailUrl: item.posterUrl ? (item.posterUrl.startsWith('/') ? `${baseUrl}${item.posterUrl}` : item.posterUrl) : fullUrl
  };
};

// 1. Upload Media (public, accepts any field name, single or batch, x-api-key or optionalAuth)
router.post('/upload', optionalAuth, upload.any(), (req: AuthenticatedRequest, res: Response) => {
  try {
    const rawFiles = (req.files as Express.Multer.File[]) || [];
    const singleFile = req.file as Express.Multer.File | undefined;
    let allFiles = singleFile ? [singleFile, ...rawFiles] : rawFiles;

    const rawEmail = (req.body.userEmail as string) || (req.body.email as string) || req.user?.email;
    let userId = (req.body.userId as string) || req.user?.id || 'usr_anonymous';
    let userName = (req.body.userName as string) || (req.body.name as string) || req.user?.name || 'Masti Creator';
    let userAvatar = (req.body.userAvatar as string) || (req.body.avatarUrl as string) || (req.user as any)?.avatarUrl;
    let userEmail: string | undefined = undefined;

    if (rawEmail && typeof rawEmail === 'string' && rawEmail.includes('@')) {
      userEmail = rawEmail.trim().toLowerCase();
      const syncedUser = db.findOrCreateUserByEmail(userEmail, userName, userAvatar);
      userId = syncedUser.id;
      userName = syncedUser.name;
      userAvatar = (syncedUser as any).avatarUrl || userAvatar;
    }

    const videoUrlLink = (req.body.videoUrl || req.body.url || req.body.videoLink) as string;
    if (allFiles.length === 0 && !videoUrlLink) {
      return res.status(400).json({
        success: false,
        error: 'No media files or video URL provided in request.'
      });
    }

    // If videoUrlLink is provided without file, create virtual file record from URL
    if (allFiles.length === 0 && videoUrlLink) {
      const title = req.body.title || 'Imported Video Ad';
      const caption = req.body.caption || '#Sponsored #Ad';
      const created = db.addMediaFile({
        userId,
        userEmail,
        userName,
        userAvatar,
        originalName: 'external_video.mp4',
        storedName: 'external_' + Date.now() + '.mp4',
        mediaType: 'video',
        mimeType: 'video/mp4',
        fileSize: 1024000,
        fileUrl: videoUrlLink,
        videoUrl: videoUrlLink,
        thumbnailUrl: req.body.thumbnailUrl || videoUrlLink,
        title,
        caption,
        tags: ['video', 'sponsored', 'ad', 'import'],
        folder: userName
      });
      const enriched = enrichMediaItem(created, req);
      return res.status(201).json({
        success: true,
        message: 'Video link imported successfully as sponsored ad',
        data: enriched,
        fileUrl: videoUrlLink
      });
    }

    if (rawEmail && typeof rawEmail === 'string' && rawEmail.includes('@')) {
      userEmail = rawEmail.trim().toLowerCase();
      const syncedUser = db.findOrCreateUserByEmail(userEmail, userName, userAvatar);
      userId = syncedUser.id;
      userName = syncedUser.name;
      userAvatar = (syncedUser as any).avatarUrl || userAvatar;
    }

    const title = req.body.title || req.body.name || '';
    const caption = req.body.caption || req.body.description || '';

    // Dynamic User Folder: Created completely dynamically based on whatever name or email the real user provides
    const incomingUserFolder = (userName && userName.trim()) 
      ? userName.trim().replace(/[\/\\:*?"<>|]/g, '_')
      : (userEmail ? userEmail.split('@')[0].replace(/[\/\\:*?"<>|]/g, '_') : 'General');

    const folder = (req.body.folder as string) || incomingUserFolder;
    
    // Extract hashtags (#tag) and mentions (@user) automatically from caption & title
    const fullText = `${title} ${caption}`;
    const autoHashtags = (fullText.match(/#[a-zA-Z0-9_\u0900-\u097F]+/g) || []).map(t => t.replace('#', '').trim());
    const autoMentions = (fullText.match(/@[a-zA-Z0-9_.]+/g) || []).map(m => m.replace('@', '').trim());

    const rawTags = req.body.tags;
    let parsedTags: string[] = [];
    if (typeof rawTags === 'string') {
      parsedTags = rawTags.split(',').map(t => t.trim().toLowerCase()).filter(Boolean);
    } else if (Array.isArray(rawTags)) {
      parsedTags = rawTags.map(t => String(t).trim().toLowerCase()).filter(Boolean);
    }

    // Merge detected hashtags into tags list without duplicates
    for (const tag of autoHashtags) {
      const lower = tag.toLowerCase();
      if (!parsedTags.includes(lower)) {
        parsedTags.push(lower);
      }
    }

    let metaMap: Record<string, { duration?: number; width?: number; height?: number; posterUrl?: string }> = {};
    if (req.body.metadata) {
      try {
        metaMap = typeof req.body.metadata === 'string' ? JSON.parse(req.body.metadata) : req.body.metadata;
      } catch (e) {
        // ignore invalid JSON
      }
    }

    let itemDetailsMap: Record<string, any> = {};
    if (req.body.itemDetails) {
      try {
        itemDetailsMap = typeof req.body.itemDetails === 'string' ? JSON.parse(req.body.itemDetails) : req.body.itemDetails;
      } catch (e) {
        // ignore invalid JSON
      }
    }

    const uploadedMedia = allFiles.map((file, index) => {
      const isVideo = file.mimetype.startsWith('video/') || 
                      file.originalname.match(/\.(mp4|webm|mov|mkv|avi|ogv)$/i);
      const isAudio = file.mimetype.startsWith('audio/') || 
                      file.originalname.match(/\.(mp3|wav|ogg|oga|opus|m4a|aac|flac|weba)$/i);
      const mediaType: MediaType = isVideo ? 'video' : isAudio ? 'audio' : 'image';
      const fileUrl = getPublicFileUrl(req, file.filename);

      const specificMeta = metaMap[file.originalname] || metaMap[String(index)] || {};
      const duration = specificMeta.duration || (req.body.duration ? parseFloat(req.body.duration) : undefined);
      const width = specificMeta.width || (req.body.width ? parseInt(req.body.width, 10) : undefined);
      const height = specificMeta.height || (req.body.height ? parseInt(req.body.height, 10) : undefined);
      const posterUrl = specificMeta.posterUrl || req.body.posterUrl || undefined;

      const perItem = itemDetailsMap[file.originalname] || itemDetailsMap[String(index)] || {};

      // Determine distinct title and caption for THIS specific video
      let itemTitle = '';
      let itemCaption = '';

      if (perItem.title !== undefined) {
        itemTitle = perItem.title;
      } else if (allFiles.length === 1 && (req.body.title || req.body.name)) {
        itemTitle = req.body.title || req.body.name || '';
      } else {
        itemTitle = file.originalname;
      }

      if (perItem.caption !== undefined) {
        itemCaption = perItem.caption;
      } else if (allFiles.length === 1 && (req.body.caption || req.body.description)) {
        itemCaption = req.body.caption || req.body.description || '';
      } else {
        itemCaption = '';
      }

      // Extract hashtags (#tag) and mentions (@user) strictly for THIS file's text
      const itemCombinedText = `${itemTitle} ${itemCaption}`;
      const itemHashtags = (itemCombinedText.match(/#[a-zA-Z0-9_\u0900-\u097F]+/g) || []).map(t => t.replace('#', '').trim());
      const itemMentions = (itemCombinedText.match(/@[a-zA-Z0-9_.]+/g) || []).map(m => m.replace('@', '').trim());

      const itemTags = Array.from(new Set([
        ...parsedTags,
        ...itemHashtags.map(h => h.toLowerCase())
      ]));

      // Soundtrack & Audio info
      let musicObj = perItem.music || undefined;
      if (!musicObj && (req.body.soundtrackTitle || req.body.audioUrl || req.body.music)) {
        if (req.body.music) {
          try {
            musicObj = typeof req.body.music === 'string' ? JSON.parse(req.body.music) : req.body.music;
          } catch {
            musicObj = { title: req.body.music, artist: userName };
          }
        } else if (req.body.soundtrackTitle || req.body.audioUrl) {
          musicObj = {
            title: req.body.soundtrackTitle || 'Original Sound',
            artist: userName || 'Creator',
            url: req.body.audioUrl || undefined
          };
        }
      }

      const created = db.addMediaFile({
        userId,
        userEmail,
        userName,
        userAvatar,
        originalName: file.originalname,
        storedName: file.filename,
        mediaType,
        mimeType: file.mimetype || (isAudio ? 'audio/mpeg' : isVideo ? 'video/mp4' : 'image/jpeg'),
        fileSize: file.size,
        fileUrl,
        title: itemTitle || file.originalname,
        caption: itemCaption,
        hashtags: itemHashtags,
        mentions: itemMentions,
        music: musicObj,
        soundtrackTitle: musicObj?.title,
        audioUrl: musicObj?.url,
        duration,
        width,
        height,
        posterUrl,
        tags: itemTags.length > 0 ? itemTags : [mediaType, 'upload'],
        folder
      });

      return enrichMediaItem(created, req);
    });

    const firstItem = uploadedMedia[0];

    return res.status(201).json({
      success: true,
      message: `Successfully uploaded ${uploadedMedia.length} file(s)`,
      count: uploadedMedia.length,
      data: uploadedMedia.length === 1 ? firstItem : uploadedMedia,
      files: uploadedMedia,
      media: uploadedMedia,
      url: firstItem?.fileUrl,
      fileUrl: firstItem?.fileUrl,
      posterUrl: firstItem?.posterUrl
    });
  } catch (err: any) {
    console.error('Media upload error:', err);
    return res.status(500).json({
      success: false,
      error: err.message || 'Internal server error during upload'
    });
  }
});

// 2. Get All Media (List with filtering, search, pagination, sorting, and userEmail filtering)
router.get('/folders', optionalAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const isGlobal = req.user?.role === 'admin' || req.user?.email === 'rajkalikumar8789@gmail.com';
    let folders = db.getAllFoldersWithStats();
    
    if (!isGlobal) {
      if (req.user) {
        // Non-admin sees ONLY their own folder
        const myFolderName = (req.user.name || req.user.email.split('@')[0]).trim().replace(/[\/\\:*?"<>|]/g, '_');
        folders = folders.filter(f => f.name === myFolderName || f.userId === req.user!.id || f.userEmail === req.user!.email);
      } else {
        // Unauthenticated guests see absolutely nothing (clean empty folders list)
        folders = [];
      }
    }

    return res.json({
      success: true,
      count: folders.length,
      data: folders,
      folders
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: 'Failed to retrieve folders' });
  }
});

router.get('/', optionalAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const rawType = (req.query.mediaType || req.query.type) as string | undefined;
    const { search, folder, sort, page = '1', limit = '50', allUsers, userEmail, email, userId } = req.query;

    const filter: any = {};
    if (rawType === 'image' || rawType === 'video' || rawType === 'audio') {
      filter.mediaType = rawType;
    }
    if (search && typeof search === 'string') {
      filter.search = search;
    }
    if (folder && typeof folder === 'string') {
      filter.folder = folder;
    }
    if (sort && typeof sort === 'string') {
      filter.sort = sort;
    }

    const requestedEmail = (userEmail || email) as string | undefined;
    const isGlobal = req.user?.role === 'admin' || req.user?.email === 'rajkalikumar8789@gmail.com';

    if (isGlobal) {
      // Admin sees everything, or filters to targeted user if requested
      if (requestedEmail && typeof requestedEmail === 'string') {
        filter.userEmail = requestedEmail.trim().toLowerCase();
      } else if (userId && typeof userId === 'string') {
        filter.userId = userId;
      }
    } else {
      // Non-admin can ONLY see their own files. If not logged in, they see absolutely nothing.
      if (req.user) {
        filter.userId = req.user.id;
      } else {
        filter.userId = 'NONE_UNAUTHENTICATED_GUEST';
      }
    }

    const items = db.getAllMedia(filter);
    const pageNum = Math.max(1, parseInt(page as string, 10) || 1);
    const limitNum = Math.max(1, parseInt(limit as string, 10) || 50);
    const startIndex = (pageNum - 1) * limitNum;
    const paginatedItems = items.slice(startIndex, startIndex + limitNum).map(item => enrichMediaItem(item, req));

    return res.json({
      success: true,
      total: items.length,
      page: pageNum,
      limit: limitNum,
      totalPages: Math.ceil(items.length / limitNum),
      data: paginatedItems,
      media: paginatedItems,
      files: paginatedItems,
      items: paginatedItems
    });
  } catch (err: any) {
    console.error('Error fetching media list:', err);
    return res.status(500).json({
      success: false,
      error: 'Failed to retrieve media library'
    });
  }
});

// 2b. Get Media for Specific User by Email (Masti Video Personal Feed / Profile)
router.get('/user/by-email/:email', optionalAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const rawEmail = decodeURIComponent(req.params.email).trim().toLowerCase();
    const type = req.query.type as 'image' | 'video' | 'audio' | undefined;
    const user = db.findUserByEmail(rawEmail);

    const userMedia = db.getAllMedia({
      userEmail: rawEmail,
      mediaType: type
    }).map(item => enrichMediaItem(item, req));

    const totalVideos = userMedia.filter(m => m.mediaType === 'video').length;
    const totalBytes = userMedia.reduce((sum, m) => sum + (m.fileSize || 0), 0);

    return res.json({
      success: true,
      user: user ? {
        id: user.id,
        name: user.name,
        email: user.email,
        avatarUrl: (user as any).avatarUrl || `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(user.name)}`,
        role: user.role,
        apiKey: user.apiKey,
        followersCount: user.followersCount || 0
      } : {
        email: rawEmail,
        name: rawEmail.split('@')[0],
        totalUploads: userMedia.length
      },
      count: userMedia.length,
      totalVideos,
      totalBytes,
      data: userMedia,
      media: userMedia,
      files: userMedia
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to fetch user media' });
  }
});

// 3. Search Media Endpoint (optimized for Masti Video search)
router.get('/search', optionalAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const q = (req.query.q as string) || (req.query.search as string) || '';
    const type = req.query.type as 'image' | 'video' | 'audio' | undefined;

    const results = db.getAllMedia({
      search: q,
      mediaType: type
    });

    return res.json({
      success: true,
      query: q,
      count: results.length,
      data: results
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: 'Search failed' });
  }
});

// 4. Get Single Media Item
router.get('/:id', optionalAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const item = db.getMediaById(req.params.id);
    if (!item) {
      return res.status(404).json({
        success: false,
        error: 'Media item not found'
      });
    }

    return res.json({
      success: true,
      data: item
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: 'Failed to retrieve media details' });
  }
});

// 4.1 Stream Media by ID with HTTP Range support
router.get('/stream/:id', (req, res) => {
  try {
    const item = db.getMediaById(req.params.id);
    if (!item) {
      return res.status(404).json({ success: false, error: 'Media file not found' });
    }

    const filePath = path.join(UPLOADS_DIR, item.storedName);
    if (!fs.existsSync(filePath)) {
      // If external URL redirect
      if (item.fileUrl && item.fileUrl.startsWith('http')) {
        return res.redirect(item.fileUrl);
      }
      return res.status(404).json({ success: false, error: 'File binary not found on storage disk' });
    }

    const stat = fs.statSync(filePath);
    const fileSize = stat.size;
    const contentType = item.mimeType || 'video/mp4';

    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Accept-Ranges', 'bytes');
    res.setHeader('Cache-Control', 'public, max-age=86400');

    const range = req.headers.range;

    if (range) {
      const parts = range.replace(/bytes=/, '').split('-');
      const start = parseInt(parts[0], 10);
      const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;

      if (start >= fileSize || end >= fileSize || start < 0) {
        res.status(416).setHeader('Content-Range', `bytes */${fileSize}`);
        return res.end();
      }

      const chunkSize = (end - start) + 1;
      const fileStream = fs.createReadStream(filePath, { start, end });

      res.writeHead(206, {
        'Content-Range': `bytes ${start}-${end}/${fileSize}`,
        'Accept-Ranges': 'bytes',
        'Content-Length': chunkSize,
        'Content-Type': contentType,
      });

      fileStream.pipe(res);
    } else {
      res.writeHead(200, {
        'Content-Length': fileSize,
        'Content-Type': contentType,
      });
      fs.createReadStream(filePath).pipe(res);
    }
  } catch (err: any) {
    return res.status(500).json({ success: false, error: 'Streaming error' });
  }
});

// 5. Update Media Metadata (Title, Caption, Music/Audio, Tags, Folder, User details)
router.put('/:id', optionalAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const item = db.getMediaById(id);

    if (!item) {
      return res.status(404).json({ success: false, error: 'Media file not found' });
    }

    const { 
      title, 
      caption, 
      originalName, 
      tags, 
      folder, 
      posterUrl, 
      thumbnailUrl, 
      music, 
      audioUrl,
      soundtrackTitle,
      userName, 
      userAvatar, 
      userId,
      hashtags,
      mentions
    } = req.body;

    const updates: any = {};
    if (title !== undefined) updates.title = String(title).trim();
    if (caption !== undefined) updates.caption = String(caption).trim();
    if (originalName !== undefined) updates.originalName = String(originalName).trim();
    if (folder !== undefined) updates.folder = String(folder).trim();
    if (posterUrl !== undefined) updates.posterUrl = posterUrl ? String(posterUrl).trim() : undefined;
    if (thumbnailUrl !== undefined) updates.thumbnailUrl = thumbnailUrl ? String(thumbnailUrl).trim() : undefined;
    if (userName !== undefined) updates.userName = String(userName).trim();
    if (userAvatar !== undefined) updates.userAvatar = String(userAvatar).trim();
    if (userId !== undefined) updates.userId = String(userId).trim();

    // Soundtrack / Audio configuration
    if (music !== undefined) {
      updates.music = music;
    } else if (audioUrl !== undefined || soundtrackTitle !== undefined) {
      updates.music = {
        title: soundtrackTitle || item.music?.title || 'Original Sound Track',
        artist: userName || item.userName || 'Masti Creator',
        url: audioUrl || item.music?.url || undefined
      };
    }

    // Auto extract and merge hashtags and mentions if caption or title is provided
    const combinedText = `${updates.title || item.title || ''} ${updates.caption || item.caption || ''}`;
    const autoHashtags = (combinedText.match(/#[a-zA-Z0-9_\u0900-\u097F]+/g) || []).map(t => t.replace('#', '').trim());
    const autoMentions = (combinedText.match(/@[a-zA-Z0-9_.]+/g) || []).map(m => m.replace('@', '').trim());

    if (hashtags !== undefined) {
      updates.hashtags = Array.isArray(hashtags) ? hashtags : [hashtags];
    } else if (autoHashtags.length > 0) {
      updates.hashtags = Array.from(new Set([...(item.hashtags || []), ...autoHashtags]));
    }

    if (mentions !== undefined) {
      updates.mentions = Array.isArray(mentions) ? mentions : [mentions];
    } else if (autoMentions.length > 0) {
      updates.mentions = Array.from(new Set([...(item.mentions || []), ...autoMentions]));
    }

    if (tags !== undefined) {
      if (Array.isArray(tags)) {
        updates.tags = tags.map(t => String(t).trim().toLowerCase()).filter(Boolean);
      } else if (typeof tags === 'string') {
        updates.tags = tags.split(',').map(t => t.trim().toLowerCase()).filter(Boolean);
      }
    } else if (autoHashtags.length > 0) {
      const mergedTags = new Set((item.tags || []).map(t => t.toLowerCase()));
      autoHashtags.forEach(h => mergedTags.add(h.toLowerCase()));
      updates.tags = Array.from(mergedTags);
    }

    const updated = db.updateMediaFile(id, updates);

    // If music/soundtrack is updated, trigger notification for the user
    if (updated && updated.userId && (updates.music !== undefined || soundtrackTitle !== undefined)) {
      db.createNotification({
        userId: updated.userId,
        actorId: req.user?.id || 'usr_anonymous',
        actorName: req.user?.name || 'Masti Creator',
        type: 'system',
        title: 'Soundtrack Track Updated!',
        message: `A new song/soundtrack "${updated.music?.title || 'Track'}" has been linked to your video "${updated.title}"!`,
        mediaId: updated.id,
        mediaThumbnail: updated.thumbnailUrl || updated.fileUrl
      });
    }

    return res.json({
      success: true,
      message: 'Media updated successfully',
      data: updated
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: 'Failed to update media' });
  }
});

// 5.1 Set Official Poster / Thumbnail for Media (Audio/Video/Image)
router.post('/:id/poster', optionalAuth, upload.single('poster'), (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const item = db.getMediaById(id);

    if (!item) {
      return res.status(404).json({ success: false, error: 'Media file not found' });
    }

    // Permission check (allow admin, file owner, or guest/demo operations)
    if (req.user && req.user.role !== 'admin' && item.userId && item.userId !== req.user.id && item.userId !== 'usr_anonymous' && item.userId !== 'demo_admin') {
      return res.status(403).json({
        success: false,
        error: 'You do not have permission to modify this media file'
      });
    }

    let posterUrl: string | undefined = undefined;

    if (req.file) {
      posterUrl = getPublicFileUrl(req, req.file.filename);
    } else if (req.body.posterUrl) {
      posterUrl = String(req.body.posterUrl).trim();
    } else if (req.body.posterUrl === null || req.body.posterUrl === '') {
      posterUrl = undefined;
    }

    const updated = db.updateMediaFile(id, {
      posterUrl: posterUrl,
      thumbnailUrl: posterUrl
    });

    if (updated && updated.userId) {
      db.createNotification({
        userId: updated.userId,
        actorId: req.user?.id || 'usr_anonymous',
        actorName: req.user?.name || 'Masti Creator',
        type: 'system',
        title: 'Video Cover Poster Updated!',
        message: `Official cover poster image has been updated for your video "${updated.title}"!`,
        mediaId: updated.id,
        mediaThumbnail: updated.thumbnailUrl || updated.fileUrl
      });
    }

    return res.json({
      success: true,
      message: 'Official poster updated successfully',
      data: updated
    });
  } catch (err: any) {
    console.error('Error setting media poster:', err);
    return res.status(500).json({ success: false, error: err.message || 'Failed to set official poster' });
  }
});

// 6. Delete Media Item
router.delete('/:id', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const item = db.getMediaById(id);

    if (!item) {
      return res.status(404).json({ success: false, error: 'Media file not found' });
    }

    // Permission check: owner or admin can delete
    if (req.user?.role !== 'admin' && item.userId !== req.user?.id) {
      return res.status(403).json({
        success: false,
        error: 'You do not have permission to delete this media file'
      });
    }

    const deleted = db.deleteMediaFile(id);
    if (!deleted) {
      return res.status(500).json({ success: false, error: 'Failed to delete file from storage' });
    }

    return res.json({
      success: true,
      message: 'Media file deleted successfully',
      id
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: 'Delete operation failed' });
  }
});

// 7. Batch Delete Media Items
router.post('/batch-delete', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { ids } = req.body;
    if (!Array.isArray(ids) || ids.length === 0) {
      return res.status(400).json({ success: false, error: 'Please provide an array of media IDs' });
    }

    // Filter permitted items
    const permittedIds = ids.filter(id => {
      const item = db.getMediaById(id);
      if (!item) return false;
      return req.user?.role === 'admin' || item.userId === req.user?.id;
    });

    const count = db.deleteBatchMedia(permittedIds);

    return res.json({
      success: true,
      message: `Deleted ${count} media file(s)`,
      deletedCount: count
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: 'Batch delete operation failed' });
  }
});

// 8. Stats Overview
router.get('/stats/overview', optionalAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const userId = req.user?.role === 'admin' ? undefined : req.user?.id;
    const stats = db.getStats(userId);
    return res.json({
      success: true,
      data: stats
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: 'Failed to retrieve stats' });
  }
});

export default router;
