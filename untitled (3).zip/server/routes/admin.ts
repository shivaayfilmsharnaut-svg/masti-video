import { Router, Request, Response } from 'express';
import { db } from '../db.js';
import { AuthenticatedRequest, authenticate, requireAdmin } from '../middleware/auth.js';

const router = Router();

// Get Admin Overview & System Stats
router.get('/overview', authenticate, requireAdmin, (_req: AuthenticatedRequest, res: Response) => {
  try {
    const stats = db.getStats();
    const users = db.getUsers().map(u => ({
      id: u.id,
      name: u.name,
      email: u.email,
      role: u.role,
      avatarUrl: (u as any).avatarUrl,
      createdAt: u.createdAt,
      totalUploads: db.getAllMedia({ userId: u.id }).length,
      isVerified: Boolean(u.isVerified),
      monetization: db.getMonetizationData(u.id)
    }));

    const recentMedia = db.getAllMedia({ sort: 'newest' }).slice(0, 10);

    return res.json({
      success: true,
      data: {
        stats,
        users,
        recentMedia
      }
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: 'Failed to fetch admin overview' });
  }
});

// List all registered users
router.get('/users', authenticate, requireAdmin, (_req: AuthenticatedRequest, res: Response) => {
  try {
    const users = db.getUsers().map(u => ({
      id: u.id,
      name: u.name,
      email: u.email,
      role: u.role,
      avatarUrl: (u as any).avatarUrl,
      createdAt: u.createdAt,
      totalUploads: db.getAllMedia({ userId: u.id }).length,
      isVerified: Boolean(u.isVerified),
      monetization: db.getMonetizationData(u.id)
    }));

    return res.json({
      success: true,
      data: users
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: 'Failed to fetch users' });
  }
});

// Update User Verification (Blue Tick) Status
router.post('/users/:id/verification', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { isVerified } = req.body;
    const result = db.updateUserVerification(id, Boolean(isVerified));
    if (!result.success) {
      return res.status(404).json({ success: false, error: 'User not found' });
    }
    return res.json({
      success: true,
      message: `User verification updated to ${Boolean(isVerified)}`,
      data: result.user
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: 'Failed to update user verification' });
  }
});

// Update User Avatar
router.post('/users/:id/avatar', authenticate, requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { avatarUrl } = req.body;
    const result = db.updateUserAvatar(id, avatarUrl);
    if (!result.success) {
      return res.status(404).json({ success: false, error: 'User not found' });
    }
    return res.json({
      success: true,
      message: `User avatar updated successfully`,
      data: result.user
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: 'Failed to update user avatar' });
  }
});

// Update User Monetization Status & Balance
router.post('/users/:id/monetization', authenticate, requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const updated = db.updateUserMonetization(id, req.body);
    return res.json({
      success: true,
      message: `User ${id} monetization successfully updated`,
      data: updated
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: 'Failed to update user monetization' });
  }
});

// Delete user by ID
router.delete('/users/:id', authenticate, requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const requesterId = req.user?.id;
    if (requesterId === id) {
      return res.status(400).json({ success: false, error: 'Cannot delete your own active admin account.' });
    }

    const success = db.deleteUser(id);
    if (!success) {
      return res.status(404).json({ success: false, error: 'User not found' });
    }

    return res.json({
      success: true,
      message: 'User account removed successfully'
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: 'Failed to delete user' });
  }
});

// Purge all fake/seeded users with 1-click
router.post('/purge-fake-users', authenticate, requireAdmin, (_req: AuthenticatedRequest, res: Response) => {
  try {
    const result = db.purgeAllFakeUsers();
    return res.json({
      success: true,
      message: `Cleaned up ${result.removedUsers} fake/sample accounts. Only real users remain.`,
      data: result
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: 'Failed to purge fake users' });
  }
});

// Fetch withdrawal requests (Secured: Admin sees all, regular user sees only their own)
router.get('/payouts', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    if (!req.user) {
      return res.status(401).json({ success: false, error: 'Unauthorized' });
    }

    const isAdmin = req.user.role === 'admin';
    const allPayouts = db.getPayouts();
    
    // Filter payouts based on role
    const filteredPayouts = isAdmin 
      ? allPayouts 
      : allPayouts.filter(p => p.userId === req.user!.id || p.userId === req.user!.email);

    const payouts = filteredPayouts.map(p => {
      const user = db.findUserById(p.userId) || db.findUserByEmail(p.userId);
      return {
        ...p,
        userName: user?.name || 'Masti Creator',
        userEmail: user?.email || 'creator@masti.app',
        avatarUrl: (user as any)?.avatarUrl || ''
      };
    });

    return res.json({
      success: true,
      data: payouts
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to fetch payout requests' });
  }
});

// Update withdrawal request status (Approve / Reject) - Secured: Requires Admin role
router.post('/payouts/:id/status', authenticate, requireAdmin, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { status, transactionRef } = req.body; // status is 'completed' or 'rejected'

    if (!status || (status !== 'completed' && status !== 'rejected')) {
      return res.status(400).json({ success: false, error: "Status must be 'completed' or 'rejected'" });
    }

    const updated = db.updatePayoutStatus(id, status, transactionRef);
    const user = db.findUserById(updated.userId);

    return res.json({
      success: true,
      message: `Withdrawal request successfully ${status}`,
      data: {
        ...updated,
        userName: user?.name || 'Masti Creator',
        userEmail: user?.email || 'creator@masti.app',
        avatarUrl: (user as any)?.avatarUrl || ''
      }
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to update payout status' });
  }
});

export default router;
