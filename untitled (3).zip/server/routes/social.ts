import { Router, Request, Response } from 'express';
import { db } from '../db.js';
import { AuthenticatedRequest, optionalAuth } from '../middleware/auth.js';

const router = Router();

// Helper to extract authenticated user or fallback to query/body
function getRequester(req: Request) {
  const userId = (req.body?.userId || req.query?.userId || req.headers['x-user-id'] || 'usr_anonymous') as string;
  const userName = (req.body?.userName || req.query?.userName || req.headers['x-user-name'] || 'Masti User') as string;
  return { userId, userName };
}

// ---------------- TWO-WAY APP SYNC ENDPOINTS ---------------- //

// Sync user profile & data from Masti Video App to Masti Bash Cloud, and return full state
router.post('/user/sync', (req: Request, res: Response) => {
  try {
    let { userId, userName, userAvatar, email, followersCount, followingCount, bio, socialLinks } = req.body;

    if (!userId && email && email.includes('@')) {
      const user = db.findOrCreateUserByEmail(email, userName, userAvatar);
      userId = user.id;
      userName = userName || user.name;
    }

    if (!userId && !email) {
      return res.status(400).json({ success: false, error: 'userId or valid email is required for sync' });
    }

    const effectiveUserId = userId || `usr_${email.replace(/[^a-zA-Z0-9]/g, '_')}`;

    const syncedData = db.syncUserFromApp({
      userId: effectiveUserId,
      userName: userName || 'Masti App Creator',
      userAvatar,
      email,
      followersCount: Number(followersCount) || 0,
      followingCount: Number(followingCount) || 0,
      bio,
      socialLinks
    });

    return res.json({
      success: true,
      message: 'Masti Video App user synced with Masti Bash Cloud permanently by email/id',
      data: syncedData
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to sync user data' });
  }
});

// Get user profile & media back for Masti Video App (by userId or by email)
router.get(['/user/:identifier', '/user/:identifier/profile', '/users/:identifier', '/users/:identifier/profile', '/:identifier/profile', '/:identifier/synced'], (req: Request, res: Response) => {
  try {
    const { identifier } = req.params;
    let targetUserId = identifier;

    if (identifier.includes('@')) {
      const foundUser = db.findUserByEmail(identifier.toLowerCase());
      if (foundUser) {
        targetUserId = foundUser.id;
      }
    }

    const profile = db.getUserSyncedProfile(targetUserId);

    if (!profile.user) {
      // Check if user has uploaded media by email
      const userMedia = db.getAllMedia({ userEmail: identifier });
      if (userMedia.length > 0) {
        return res.json({
          success: true,
          data: {
            syncedAt: new Date().toISOString(),
            user: {
              id: targetUserId,
              name: identifier.split('@')[0],
              email: identifier,
              avatarUrl: `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(identifier)}`,
              bio: 'Masti Video Creator',
              followersCount: 0,
              followingCount: 0,
              totalUploads: userMedia.length,
              totalLikesReceived: 0,
              apiKey: `mb_live_${targetUserId}`
            },
            uploadedMedia: userMedia,
            likedMediaIds: [],
            followers: [],
            following: [],
            recentChatsCount: 0
          }
        });
      }
      return res.status(404).json({ success: false, error: 'User not found on Masti Bash Cloud' });
    }

    return res.json({
      success: true,
      data: profile
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to get user profile' });
  }
});

// Alias for /user/:identifier/synced-profile for SDK and Replit prompt
router.get('/user/:identifier/synced-profile', (req: Request, res: Response) => {
  try {
    const { identifier } = req.params;
    let targetUserId = identifier;

    if (identifier.includes('@')) {
      const foundUser = db.findUserByEmail(identifier.toLowerCase());
      if (foundUser) {
        targetUserId = foundUser.id;
      }
    }

    const profile = db.getUserSyncedProfile(targetUserId);
    return res.json({
      success: true,
      data: profile
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to get synced profile' });
  }
});

// Get user specific files and folders (Secured: Only Admin or Owner of those files can view them)
router.get('/user/:identifier/files', optionalAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { identifier } = req.params;
    const isGlobal = req.user?.role === 'admin' || req.user?.email === 'rajkalikumar8789@gmail.com';
    const isSelf = req.user && (req.user.id === identifier || req.user.email.toLowerCase() === identifier.toLowerCase());

    if (!isGlobal && !isSelf) {
      return res.json({
        success: true,
        user: null,
        folderName: 'Private',
        count: 0,
        data: []
      });
    }

    const media = db.getAllMedia({ userEmail: identifier });
    const user = db.findUserByEmail(identifier) || db.findUserById(identifier);
    const folderName = user?.name || identifier.split('@')[0];

    return res.json({
      success: true,
      user: {
        id: user?.id || identifier,
        name: folderName,
        email: user?.email || identifier
      },
      folderName,
      count: media.length,
      data: media
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ---------------- PUBLIC DIRECTORY & STATS ---------------- //

// Get all active Masti creators and network users (Secured: Admin gets all, other users see themselves, logged out sees empty)
router.get('/creators', optionalAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const isGlobal = req.user?.role === 'admin' || req.user?.email === 'rajkalikumar8789@gmail.com';
    let creators = [];
    if (isGlobal) {
      creators = db.getPublicCreators();
    } else if (req.user) {
      // Non-admin can only see themselves in the list
      creators = db.getPublicCreators().filter(c => c.id === req.user!.id || c.email === req.user!.email);
    }

    return res.json({
      success: true,
      count: creators.length,
      data: creators
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to get creators' });
  }
});

// Get global social statistics (Secured: Requires Admin role)
router.get('/stats', optionalAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const isGlobal = req.user?.role === 'admin' || req.user?.email === 'rajkalikumar8789@gmail.com';
    if (!isGlobal) {
      // Return empty stats for non-admins
      return res.json({
        success: true,
        data: {
          totalUsers: 0,
          totalMedia: 0,
          totalViews: 0,
          totalLikes: 0,
          totalComments: 0,
          totalFollows: 0
        }
      });
    }
    const stats = db.getSocialStats();
    return res.json({
      success: true,
      data: stats
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to get stats' });
  }
});

// ---------------- LIKES ENDPOINTS ---------------- //

// Toggle Like on Media
router.post('/like', (req: Request, res: Response) => {
  try {
    const { mediaId } = req.body;
    const { userId, userName } = getRequester(req);

    if (!mediaId) {
      return res.status(400).json({ success: false, error: 'mediaId is required' });
    }

    const result = db.toggleLike(mediaId, userId, userName);
    return res.json({
      success: true,
      data: result,
      message: result.isLiked ? 'Liked successfully' : 'Unliked successfully'
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to toggle like' });
  }
});

// Get Likes for a specific media item
router.get('/like/:mediaId', (req: Request, res: Response) => {
  try {
    const { mediaId } = req.params;
    const likes = db.getMediaLikes(mediaId);
    return res.json({
      success: true,
      mediaId,
      likesCount: likes.length,
      likes
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to get likes' });
  }
});

// Get Media IDs liked by a user
router.get('/likes/user/:userId', (req: Request, res: Response) => {
  try {
    const { userId } = req.params;
    const likedMediaIds = db.getUserLikedMediaIds(userId);
    return res.json({
      success: true,
      userId,
      likedMediaIds
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to get user likes' });
  }
});

// ---------------- COMMENTS ENDPOINTS ---------------- //

// Add comment to media
router.post('/comment', (req: Request, res: Response) => {
  try {
    const { mediaId, text, userAvatar } = req.body;
    const { userId, userName } = getRequester(req);

    if (!mediaId || !text || !text.trim()) {
      return res.status(400).json({ success: false, error: 'mediaId and comment text are required' });
    }

    const comment = db.addComment(mediaId, userId, userName, text, userAvatar);
    return res.status(201).json({
      success: true,
      data: comment,
      message: 'Comment posted successfully'
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to post comment' });
  }
});

// Get all comments for a media item
router.get('/comment/:mediaId', (req: Request, res: Response) => {
  try {
    const { mediaId } = req.params;
    const comments = db.getComments(mediaId);
    return res.json({
      success: true,
      mediaId,
      count: comments.length,
      data: comments
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to get comments' });
  }
});

// Delete a comment
router.delete('/comment/:commentId', (req: Request, res: Response) => {
  try {
    const { commentId } = req.params;
    const { userId } = getRequester(req);
    const isAdmin = req.body?.isAdmin === true;

    const deleted = db.deleteComment(commentId, userId, isAdmin);
    if (!deleted) {
      return res.status(404).json({ success: false, error: 'Comment not found or unauthorized' });
    }

    return res.json({ success: true, message: 'Comment deleted successfully' });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to delete comment' });
  }
});

// ---------------- SHARES ENDPOINTS ---------------- //

// Record a share
router.post('/share', (req: Request, res: Response) => {
  try {
    const { mediaId, platform, shareUrl } = req.body;
    const { userId } = getRequester(req);

    if (!mediaId) {
      return res.status(400).json({ success: false, error: 'mediaId is required' });
    }

    const result = db.recordShare(mediaId, userId, platform, shareUrl);
    return res.json({
      success: true,
      data: result,
      message: 'Share recorded successfully'
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to record share' });
  }
});

// Get shares for media
router.get('/share/:mediaId', (req: Request, res: Response) => {
  try {
    const { mediaId } = req.params;
    const shares = db.getShares(mediaId);
    return res.json({
      success: true,
      mediaId,
      sharesCount: shares.length,
      data: shares
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to get shares' });
  }
});

// ---------------- FOLLOWERS / FOLLOWING ENDPOINTS ---------------- //

// Toggle follow a user (supports both body and URL param)
router.post('/follow/:targetUserId?', (req: Request, res: Response) => {
  try {
    const followingId = req.params.targetUserId || req.body.followingId || req.body.userId || req.body.targetUserId;
    const followingName = req.body.followingName || req.body.userName;
    const { userId: followerId, userName: followerName } = getRequester(req);

    if (!followingId) {
      return res.status(400).json({ success: false, error: 'followingId or targetUserId is required' });
    }

    const result = db.toggleFollow(followerId, followingId, followerName, followingName);
    return res.json({
      success: true,
      data: result,
      message: result.isFollowing ? 'Followed successfully' : 'Unfollowed successfully'
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to toggle follow' });
  }
});

// Get followers of a user
router.get('/followers/:userId', (req: Request, res: Response) => {
  try {
    const { userId } = req.params;
    const followers = db.getFollowers(userId);
    return res.json({
      success: true,
      userId,
      followersCount: followers.length,
      data: followers
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to get followers' });
  }
});

// Get users followed by a user
router.get('/following/:userId', (req: Request, res: Response) => {
  try {
    const { userId } = req.params;
    const following = db.getFollowing(userId);
    return res.json({
      success: true,
      userId,
      followingCount: following.length,
      data: following
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to get following' });
  }
});

// ---------------- CHAT & MESSAGING ENDPOINTS ---------------- //

// Send a chat message
router.post('/chat', (req: Request, res: Response) => {
  try {
    const { receiverId, receiverName, message, mediaUrl, mediaType } = req.body;
    const { userId: senderId, userName: senderName } = getRequester(req);

    if (!receiverId || (!message && !mediaUrl)) {
      return res.status(400).json({ success: false, error: 'receiverId and message or mediaUrl are required' });
    }

    const chat = db.sendChatMessage({
      senderId,
      senderName,
      receiverId,
      receiverName,
      message: message || '',
      mediaUrl,
      mediaType
    });

    return res.status(201).json({
      success: true,
      data: chat,
      message: 'Message sent successfully'
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to send chat message' });
  }
});

// Get conversation between two users
router.get('/chat/conversation', (req: Request, res: Response) => {
  try {
    const user1 = req.query.user1 as string;
    const user2 = req.query.user2 as string;

    if (!user1 || !user2) {
      return res.status(400).json({ success: false, error: 'user1 and user2 query parameters are required' });
    }

    const messages = db.getChatConversation(user1, user2);
    return res.json({
      success: true,
      count: messages.length,
      data: messages
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to get conversation' });
  }
});

// Get user chat threads list
router.get('/chat/threads/:userId', (req: Request, res: Response) => {
  try {
    const { userId } = req.params;
    const threads = db.getUserChatThreads(userId);
    return res.json({
      success: true,
      userId,
      count: threads.length,
      data: threads
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to get chat threads' });
  }
});

// Mark chat message as read
router.post('/chat/read/:messageId', (req: Request, res: Response) => {
  try {
    const { messageId } = req.params;
    const { userId } = getRequester(req);
    const updated = db.markChatRead(messageId, userId);
    return res.json({ success: updated });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to mark message read' });
  }
});

// ---------------- NOTIFICATIONS ENDPOINTS ---------------- //

// Get notifications for a user
router.get('/notifications/:userId', (req: Request, res: Response) => {
  try {
    const { userId } = req.params;
    const notifications = db.getUserNotifications(userId);
    const unreadCount = db.getUnreadNotificationsCount(userId);

    return res.json({
      success: true,
      userId,
      unreadCount,
      count: notifications.length,
      data: notifications
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to get notifications' });
  }
});

// Mark single notification as read
router.post('/notifications/read/:notificationId', (req: Request, res: Response) => {
  try {
    const { notificationId } = req.params;
    const { userId } = getRequester(req);
    const updated = db.markNotificationRead(notificationId, userId);
    return res.json({ success: updated, message: updated ? 'Marked read' : 'Notification not found' });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to mark notification read' });
  }
});

// Mark all notifications read for a user
router.post('/notifications/read-all/:userId', (req: Request, res: Response) => {
  try {
    const { userId } = req.params;
    const updated = db.markAllNotificationsRead(userId);
    return res.json({ success: true, updated });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to mark all notifications read' });
  }
});

// Clear / Delete all notifications for a user
router.delete('/notifications/:userId', (req: Request, res: Response) => {
  try {
    const { userId } = req.params;
    db.clearNotifications(userId);
    return res.json({ success: true, message: 'Notifications cleared successfully' });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to clear notifications' });
  }
});

// Trigger a custom notification
router.post('/notifications/create', (req: Request, res: Response) => {
  try {
    const { userId, type, title, message, mediaId, mediaThumbnail } = req.body;
    const { userId: actorId, userName: actorName } = getRequester(req);

    if (!userId || !title || !message) {
      return res.status(400).json({ success: false, error: 'userId, title and message are required' });
    }

    const notif = db.createNotification({
      userId,
      actorId,
      actorName,
      type: type || 'system',
      title,
      message,
      mediaId,
      mediaThumbnail
    });

    return res.status(201).json({ success: true, data: notif });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to create notification' });
  }
});

// ---------------- MONETIZATION & CREATOR WALLET ENDPOINTS ---------------- //

// Get creator monetization status & wallet balance
router.get('/monetization/:identifier', (req: Request, res: Response) => {
  try {
    const { identifier } = req.params;

    if (identifier === 'config') {
      const admob = db.getAdMobConfig();
      if (!admob || !admob.appId || !admob.bannerAdUnitId || !admob.interstitialAdUnitId || !admob.rewardedAdUnitId) {
        return res.status(404).json({
          success: false,
          error: 'Google AdMob settings are missing. Please configure them in the admin panel.'
        });
      }
      return res.json({
        success: true,
        data: {
          userId: 'config',
          monetizationStatus: 'eligible',
          isEnabled: admob.isMonetizationEnabled !== undefined ? Boolean(admob.isMonetizationEnabled) : true,
          ads: {
            globalAdsEnabled: Boolean(admob.isAdMobEnabled),
            testAdsEnabled: Boolean(admob.testMode),
            appId: admob.appId,
            bannerAdUnitId: admob.bannerAdUnitId,
            interstitialAdUnitId: admob.interstitialAdUnitId,
            rewardedAdUnitId: admob.rewardedAdUnitId
          }
        }
      });
    }

    const monetization = db.getMonetizationData(identifier);
    return res.json({
      success: true,
      data: monetization
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to get monetization data' });
  }
});

// Control / Toggle / Update Monetization for a user
router.post('/monetization/control/:identifier', (req: Request, res: Response) => {
  try {
    const { identifier } = req.params;
    const updated = db.updateUserMonetization(identifier, req.body);
    return res.json({
      success: true,
      message: `Monetization updated for ${identifier}`,
      data: updated
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to update monetization' });
  }
});

// Request withdrawal / payout
router.post('/monetization/payout', (req: Request, res: Response) => {
  try {
    const { userId, amount, method, accountInfo } = req.body;

    if (!userId || !amount || !accountInfo) {
      return res.status(400).json({ success: false, error: 'userId, amount, and accountInfo (UPI ID/Bank Details) are required' });
    }

    if (Number(amount) <= 0) {
      return res.status(400).json({ success: false, error: 'Payout amount must be greater than 0' });
    }

    const payout = db.requestPayout(userId, Number(amount), method || 'upi', accountInfo);
    const updatedMonetization = db.getMonetizationData(userId);
    return res.status(201).json({
      success: true,
      message: `Withdrawal of ₹${Number(amount).toFixed(2)} processed successfully via ${method || 'UPI'}!`,
      data: payout,
      monetization: updatedMonetization
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to process payout' });
  }
});

// Record video view & monetize
router.post('/view', (req: Request, res: Response) => {
  try {
    const { mediaId, viewerId } = req.body;
    if (!mediaId) {
      return res.status(400).json({ success: false, error: 'mediaId is required' });
    }

    const result = db.recordMediaView(mediaId, viewerId);
    return res.json({
      success: true,
      data: result
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to record view' });
  }
});

// Log, initiate or start a video or audio call with WebRTC support
router.post('/call', (req: Request, res: Response) => {
  try {
    const { receiverId, receiverName, callType } = req.body;
    const { userId: callerId, userName: callerName } = getRequester(req);
    if (!receiverId || !callType) {
      return res.status(400).json({ success: false, error: 'receiverId and callType (video/audio) are required' });
    }
    const call = db.initiateCall(callerId, callerName, receiverId, receiverName || 'User', callType);
    return res.status(201).json({
      success: true,
      message: `${callType} call initiated and notification sent successfully`,
      data: call
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to log call' });
  }
});

// Send WebRTC Signaling payload (SDP Offer, SDP Answer, ICE Candidate)
router.post('/call/signal', (req: Request, res: Response) => {
  try {
    const { senderId, receiverId, type, payload } = req.body;
    if (!senderId || !receiverId || !type || !payload) {
      return res.status(400).json({ success: false, error: 'senderId, receiverId, type, and payload are required' });
    }
    const signal = db.addCallSignal(senderId, receiverId, type, payload);
    return res.json({
      success: true,
      message: 'Signaling message sent successfully',
      data: signal
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Receive pending WebRTC signals for a user (Long-polling / Polling method)
router.get('/call/signals/:receiverId', (req: Request, res: Response) => {
  try {
    const { receiverId } = req.params;
    if (!receiverId) {
      return res.status(400).json({ success: false, error: 'receiverId is required' });
    }
    const signals = db.getCallSignals(receiverId);
    return res.json({
      success: true,
      count: signals.length,
      data: signals
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Update Call status (e.g. connected, ended)
router.post('/call/status', (req: Request, res: Response) => {
  try {
    const { callId, status } = req.body;
    if (!callId || !status) {
      return res.status(400).json({ success: false, error: 'callId and status are required' });
    }
    const updated = db.updateCallStatus(callId, status);
    return res.json({
      success: true,
      message: `Call status updated to ${status}`,
      data: updated
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ---------------- SUPPORT & HELP TICKETS ENDPOINTS ---------------- //

// Submit a help/support ticket from user
router.post('/support/ticket', (req: Request, res: Response) => {
  try {
    const { subject, message, userName, userEmail } = req.body;
    const { userId, userName: reqUserName } = getRequester(req);
    if (!subject || !message) {
      return res.status(400).json({ success: false, error: 'subject and message are required' });
    }
    const ticket = db.createSupportTicket({
      userId,
      userName: userName || reqUserName || 'User',
      userEmail,
      subject,
      message
    });
    return res.status(201).json({
      success: true,
      message: 'Support ticket submitted and saved successfully. Admin (Rajkali) will review and reply soon.',
      data: ticket
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to submit support ticket' });
  }
});

// Get all support tickets (for Admin / Rajkali)
router.get('/support/tickets', (req: Request, res: Response) => {
  try {
    const tickets = db.getSupportTickets();
    return res.json({
      success: true,
      count: tickets.length,
      data: tickets
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to get support tickets' });
  }
});

// Admin resolve / reply to support ticket
router.post('/support/resolve/:ticketId', (req: Request, res: Response) => {
  try {
    const { ticketId } = req.params;
    const { adminReply } = req.body;
    if (!adminReply) {
      return res.status(400).json({ success: false, error: 'adminReply is required' });
    }
    const updated = db.resolveSupportTicket(ticketId, adminReply);
    if (!updated) {
      return res.status(404).json({ success: false, error: 'Support ticket not found' });
    }
    return res.json({
      success: true,
      message: 'Support ticket resolved and reply sent to user successfully',
      data: updated
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to resolve support ticket' });
  }
});

export default router;
