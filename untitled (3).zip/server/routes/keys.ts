import { Router, Response } from 'express';
import { db } from '../db.js';
import { AuthenticatedRequest, authenticate } from '../middleware/auth.js';

const router = Router();

// Get API Keys for current user
router.get('/', authenticate, (req: AuthenticatedRequest, res: Response) => {
  if (!req.user) return res.status(401).json({ success: false, error: 'Unauthorized' });

  const keys = db.getUserApiKeys(req.user.id);
  return res.json({
    success: true,
    data: keys
  });
});

// Generate new API Key
router.post('/', authenticate, (req: AuthenticatedRequest, res: Response) => {
  if (!req.user) return res.status(401).json({ success: false, error: 'Unauthorized' });

  const { name } = req.body;
  const keyName = (name && typeof name === 'string') ? name.trim() : 'Masti Video Client Key';
  const newKey = db.createApiKey(req.user.id, keyName);

  return res.status(201).json({
    success: true,
    message: 'API Key generated successfully',
    data: newKey
  });
});

// Revoke API Key
router.delete('/:id', authenticate, (req: AuthenticatedRequest, res: Response) => {
  if (!req.user) return res.status(401).json({ success: false, error: 'Unauthorized' });

  const { id } = req.params;
  const deleted = db.deleteApiKey(id, req.user.id);

  if (!deleted) {
    return res.status(404).json({ success: false, error: 'API Key not found or already deleted' });
  }

  return res.json({
    success: true,
    message: 'API Key revoked successfully',
    id
  });
});

export default router;
