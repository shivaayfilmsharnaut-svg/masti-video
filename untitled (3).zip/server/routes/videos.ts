import { Router, Request, Response } from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { v4 as uuidv4 } from 'uuid';
import { db } from '../db.js';
import { AuthenticatedRequest, authenticate, optionalAuth } from '../middleware/auth.js';

const router = Router();
const UPLOADS_DIR = path.resolve(process.cwd(), 'uploads');

if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

// Multer storage configuration for video files and thumbnails
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, UPLOADS_DIR);
  },
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase() || '.mp4';
    const cleanBase = path.basename(file.originalname, ext).replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 30);
    const uniqueSuffix = `${Date.now()}_${uuidv4().slice(0, 8)}`;
    const storedName = `mv_${cleanBase}_${uniqueSuffix}${ext}`;
    cb(null, storedName);
  }
});

const upload = multer({
  storage
  // Unlimited file size and batch uploads
});

const getBaseUrl = (req: any) => {
  const host = req.headers['x-forwarded-host'] || req.headers.host;
  const proto = req.headers['x-forwarded-proto'] || req.protocol || 'https';
  return host ? `${proto}://${host}` : '';
};

// ==========================================
// 1. VIDEO FEED & UPLOADS
// ==========================================

// GET /api/videos/feed - Primary feed for Masti Video app
router.get('/feed', optionalAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const page = parseInt(req.query.page as string, 10) || 1;
    const limitQuery = req.query.limit ? parseInt(req.query.limit as string, 10) : 0; // 0 = unlimited
    const currentUserId = req.user?.id;
    const baseUrl = getBaseUrl(req);

    const feed = db.getVideoFeed(currentUserId, limitQuery, page, baseUrl);
    const admob = db.getAdMobConfig();

    return res.json({
      success: true,
      page,
      limit: limitQuery || 'unlimited',
      count: feed.length,
      data: feed,
      feed: feed,
      admob
    });
  } catch (err: any) {
    console.error('Error fetching video feed:', err);
    return res.status(500).json({ success: false, error: err.message || 'Failed to fetch video feed' });
  }
});

// GET /api/videos/admob - Get Google AdMob config for Masti Video App
router.get('/admob', (_req: Request, res: Response) => {
  try {
    const admob = db.getAdMobConfig();
    return res.json({
      success: true,
      data: admob
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to get AdMob config' });
  }
});

// POST /api/videos/admob - Update Google AdMob config from MastiBase
router.post('/admob', optionalAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const updated = db.updateAdMobConfig(req.body);
    return res.json({
      success: true,
      message: 'Google AdMob settings updated successfully! Changes will reflect live in Masti Video App.',
      data: updated
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message || 'Failed to update AdMob config' });
  }
});

// POST /api/videos/upload - Upload video with Bearer Token (Firebase Auth / MastiBase Auth)
router.post('/upload', authenticate, upload.any(), (req: AuthenticatedRequest, res: Response) => {
  try {
    const rawFiles = (req.files as Express.Multer.File[]) || [];
    const singleFile = req.file as Express.Multer.File | undefined;
    const allFiles = singleFile ? [singleFile, ...rawFiles] : rawFiles;

    if (allFiles.length === 0) {
      return res.status(400).json({
        success: false,
        error: 'No video file provided. Please upload a valid video file.'
      });
    }

    const user = req.user!;
    const baseUrl = getBaseUrl(req);
    const videoFile = allFiles.find(f => f.mimetype.startsWith('video/') || f.originalname.match(/\.(mp4|webm|mov|mkv|avi|ogv)$/i)) || allFiles[0];
    const thumbFile = allFiles.find(f => f !== videoFile && f.mimetype.startsWith('image/'));

    const title = req.body.title || req.body.name || path.basename(videoFile.originalname, path.extname(videoFile.originalname));
    const caption = req.body.caption || req.body.description || '';
    const duration = req.body.duration ? parseFloat(req.body.duration) : undefined;
    const width = req.body.width ? parseInt(req.body.width, 10) : undefined;
    const height = req.body.height ? parseInt(req.body.height, 10) : undefined;
    const visibility = (req.body.visibility as 'public' | 'private' | 'unlisted') || 'public';
    const commentsEnabled = req.body.commentsEnabled !== 'false' && req.body.commentsEnabled !== false;
    const duetEnabled = req.body.duetEnabled !== 'false' && req.body.duetEnabled !== false;

    // Extract hashtags (#tag) and mentions (@user) automatically from caption & title while preserving raw text
    const fullText = `${title} ${caption}`;
    const autoHashtags = (fullText.match(/#[a-zA-Z0-9_\u0900-\u097F]+/g) || []).map(t => t.replace('#', '').trim());
    const autoMentions = (fullText.match(/@[a-zA-Z0-9_.]+/g) || []).map(m => m.replace('@', '').trim());

    let parsedTags: string[] = ['mastivideo', 'short'];
    if (typeof req.body.tags === 'string') {
      parsedTags = req.body.tags.split(',').map((t: string) => t.trim().toLowerCase()).filter(Boolean);
    } else if (Array.isArray(req.body.tags)) {
      parsedTags = req.body.tags.map((t: any) => String(t).trim().toLowerCase()).filter(Boolean);
    }

    // Merge detected hashtags into tags list without duplicates
    for (const tag of autoHashtags) {
      const lower = tag.toLowerCase();
      if (!parsedTags.includes(lower)) {
        parsedTags.push(lower);
      }
    }

    let musicObj = undefined;
    if (req.body.music) {
      try {
        musicObj = typeof req.body.music === 'string' ? JSON.parse(req.body.music) : req.body.music;
      } catch {
        musicObj = { title: req.body.music, artist: user.name };
      }
    }

    const fileUrl = `${baseUrl}/uploads/${videoFile.filename}`;
    const posterUrl = thumbFile ? `${baseUrl}/uploads/${thumbFile.filename}` : (req.body.posterUrl || req.body.thumbnailUrl || undefined);

    const createdMedia = db.addMediaFile({
      userId: user.id,
      userEmail: user.email,
      userName: user.name,
      userAvatar: (user as any).avatarUrl,
      originalName: videoFile.originalname,
      storedName: videoFile.filename,
      mediaType: 'video',
      mimeType: videoFile.mimetype || 'video/mp4',
      fileSize: videoFile.size,
      fileUrl,
      videoUrl: fileUrl,
      thumbnailUrl: posterUrl || fileUrl,
      posterUrl,
      title,
      caption,
      duration,
      width,
      height,
      visibility,
      commentsEnabled,
      duetEnabled,
      music: musicObj,
      tags: parsedTags,
      folder: (req.body.folder as string) || (user.name ? user.name.trim().replace(/[\/\\:*?"<>|]/g, '_') : 'Videos'),
      viewsCount: 1,
      likesCount: 0,
      commentsCount: 0,
      sharesCount: 0,
      savesCount: 0
    });

    // Award initial creator monetization event
    db.recordMediaView(createdMedia.id, user.id);

    return res.status(201).json({
      success: true,
      message: 'Video uploaded and published to MastiBase successfully',
      data: {
        id: createdMedia.id,
        videoId: createdMedia.id,
        userId: user.id,
        title: createdMedia.title,
        caption: createdMedia.caption,
        videoUrl: createdMedia.fileUrl,
        thumbnailUrl: createdMedia.thumbnailUrl,
        posterUrl: createdMedia.posterUrl,
        duration: createdMedia.duration,
        createdAt: createdMedia.createdAt,
        visibility: createdMedia.visibility,
        owner: {
          id: user.id,
          firebaseUid: user.firebaseUid,
          name: user.name,
          username: user.username,
          avatarUrl: (user as any).avatarUrl
        }
      }
    });
  } catch (err: any) {
    console.error('Video upload error:', err);
    return res.status(500).json({ success: false, error: err.message || 'Server error during video upload' });
  }
});

// GET /api/videos - List all videos
router.get('/', optionalAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const filter: any = { mediaType: 'video' };
    if (req.query.userId) filter.userId = req.query.userId as string;
    if (req.query.search) filter.search = req.query.search as string;

    const items = db.getAllMedia(filter);
    const baseUrl = getBaseUrl(req);

    const enriched = items.map(item => ({
      ...item,
      url: item.fileUrl.startsWith('/') ? `${baseUrl}${item.fileUrl}` : item.fileUrl,
      videoUrl: item.fileUrl.startsWith('/') ? `${baseUrl}${item.fileUrl}` : item.fileUrl,
      thumbnailUrl: item.posterUrl ? (item.posterUrl.startsWith('/') ? `${baseUrl}${item.posterUrl}` : item.posterUrl) : item.fileUrl
    }));

    return res.json({ success: true, count: enriched.length, data: enriched });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/videos/:id - Single video details
router.get('/:id', optionalAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const video = db.getMediaById(req.params.id);
    if (!video) {
      return res.status(404).json({ success: false, error: 'Video not found' });
    }

    const creator = db.findUserById(video.userId);
    const baseUrl = getBaseUrl(req);

    return res.json({
      success: true,
      data: {
        ...video,
        videoUrl: video.fileUrl.startsWith('/') ? `${baseUrl}${video.fileUrl}` : video.fileUrl,
        thumbnailUrl: video.posterUrl ? (video.posterUrl.startsWith('/') ? `${baseUrl}${video.posterUrl}` : video.posterUrl) : video.fileUrl,
        profile: {
          id: creator?.id || video.userId,
          firebaseUid: creator?.firebaseUid,
          name: creator?.name || video.userName,
          username: creator?.username,
          avatarUrl: (creator as any)?.avatarUrl || video.userAvatar
        }
      }
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// PUT /api/videos/:id - Update video details (Title, Caption, Hashtags, Soundtrack)
router.put('/:id', optionalAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const video = db.getMediaById(req.params.id);
    if (!video) {
      return res.status(404).json({ success: false, error: 'Video not found' });
    }

    if (req.user && req.user.role !== 'admin' && video.userId && video.userId !== req.user.id && video.userId !== 'usr_anonymous') {
      return res.status(403).json({ success: false, error: 'Permission denied. Only video owner or admin can edit.' });
    }

    const { title, caption, hashtags, mentions, tags, music, soundtrackTitle, audioUrl, visibility } = req.body;
    const updates: any = {};

    if (title !== undefined) updates.title = title;
    if (caption !== undefined) updates.caption = caption;
    if (visibility !== undefined) updates.visibility = visibility;

    const combinedText = `${updates.title || video.title || ''} ${updates.caption || video.caption || ''}`;
    const autoHashtags = (combinedText.match(/#[a-zA-Z0-9_\u0900-\u097F]+/g) || []).map(t => t.replace('#', '').trim());
    const autoMentions = (combinedText.match(/@[a-zA-Z0-9_.]+/g) || []).map(m => m.replace('@', '').trim());

    if (hashtags !== undefined) {
      updates.hashtags = Array.isArray(hashtags) ? hashtags : [hashtags];
    } else if (caption !== undefined || title !== undefined) {
      updates.hashtags = autoHashtags;
    }

    if (mentions !== undefined) {
      updates.mentions = Array.isArray(mentions) ? mentions : [mentions];
    } else if (caption !== undefined || title !== undefined) {
      updates.mentions = autoMentions;
    }

    if (music !== undefined) {
      updates.music = typeof music === 'string' ? { title: music, url: audioUrl } : music;
    } else if (soundtrackTitle !== undefined || audioUrl !== undefined) {
      updates.music = {
        title: soundtrackTitle || video.music?.title || 'Original Soundtrack',
        artist: video.userName || 'Creator',
        url: audioUrl || video.music?.url || undefined
      };
    }

    if (tags !== undefined) {
      updates.tags = Array.isArray(tags) ? tags : String(tags).split(',').map(t => t.trim().toLowerCase()).filter(Boolean);
    }

    const updated = db.updateMediaFile(req.params.id, updates);
    return res.json({ success: true, message: 'Video updated successfully', data: updated });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// DELETE /api/videos/:id - Delete video
router.delete('/:id', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const video = db.getMediaById(req.params.id);
    if (!video) {
      return res.status(404).json({ success: false, error: 'Video not found' });
    }

    if (req.user?.role !== 'admin' && video.userId !== req.user?.id) {
      return res.status(403).json({ success: false, error: 'Permission denied. Only video owner can delete.' });
    }

    db.deleteMediaFile(req.params.id);
    return res.json({ success: true, message: 'Video deleted successfully' });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// 2. SOCIAL PROFILE APIs (/api/videos/social/profile/...)
// ==========================================

// GET /api/videos/social/profile/me - Authenticated user complete profile
router.get('/social/profile/me', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const profile = db.getUserSyncedProfile(req.user!.id);
    return res.json({
      success: true,
      data: profile,
      profile: profile.user
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// PUT /api/videos/social/profile/me - Update user profile
router.put('/social/profile/me', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { name, username, avatarUrl, bio, phoneNumber, privacySettings, notificationSettings } = req.body;

    const updated = db.updateUserProfile(req.user!.id, {
      name,
      username,
      avatarUrl,
      bio,
      phoneNumber,
      privacySettings,
      notificationSettings
    });

    if (!updated) {
      return res.status(404).json({ success: false, error: 'User not found' });
    }

    return res.json({
      success: true,
      message: 'Profile updated successfully',
      user: {
        id: updated.id,
        firebaseUid: updated.firebaseUid,
        username: updated.username,
        name: updated.name,
        email: updated.email,
        avatarUrl: (updated as any).avatarUrl,
        bio: (updated as any).bio,
        privacySettings: updated.privacySettings,
        notificationSettings: updated.notificationSettings
      }
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/videos/social/profile/:userId - Public creator profile
router.get('/social/profile/:userId', optionalAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const profile = db.getUserSyncedProfile(req.params.userId);
    return res.json({
      success: true,
      data: profile
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// 3. SOCIAL INTERACTIONS: LIKES, SAVES, VIEWS, SHARES
// ==========================================

// POST /api/videos/social/videos/:videoId/like - Toggle like
router.post('/social/videos/:videoId/like', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { videoId } = req.params;
    const result = db.toggleLike(videoId, req.user!.id, req.user!.name);
    return res.json({
      success: true,
      data: result,
      message: result.isLiked ? 'Liked' : 'Unliked'
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/videos/social/videos/:videoId/save - Toggle save/favorite
router.post('/social/videos/:videoId/save', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { videoId } = req.params;
    const result = db.toggleSave(videoId, req.user!.id);
    return res.json({
      success: true,
      data: result,
      message: result.isSaved ? 'Saved to bookmarks' : 'Removed from bookmarks'
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/videos/social/saves - Get saved videos of current user
router.get('/social/saves', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const saves = db.getUserSaves(req.user!.id);
    return res.json({
      success: true,
      count: saves.length,
      data: saves
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/videos/social/videos/:videoId/view - Record video view & monetize
router.post('/social/videos/:videoId/view', optionalAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { videoId } = req.params;
    const viewerId = req.user?.id || req.body.viewerId;
    const result = db.recordMediaView(videoId, viewerId);
    return res.json({ success: true, data: result });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/videos/social/videos/:videoId/share - Record video share
router.post('/social/videos/:videoId/share', optionalAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { videoId } = req.params;
    const { platform, shareUrl } = req.body;
    const result = db.recordShare(videoId, req.user?.id, platform, shareUrl);
    return res.json({ success: true, data: result });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// 4. COMMENTS
// ==========================================

// GET /api/videos/social/videos/:videoId/comments - Get comments for video
router.get('/social/videos/:videoId/comments', (req: Request, res: Response) => {
  try {
    const comments = db.getComments(req.params.videoId);
    return res.json({ success: true, count: comments.length, data: comments });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/videos/social/videos/:videoId/comments - Post a comment
router.post('/social/videos/:videoId/comments', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { videoId } = req.params;
    const { text, replyToCommentId } = req.body;

    if (!text || !text.trim()) {
      return res.status(400).json({ success: false, error: 'Comment text is required' });
    }

    const comment = db.addComment(
      videoId,
      req.user!.id,
      req.user!.name,
      text.trim(),
      (req.user as any).avatarUrl
    );

    return res.status(201).json({ success: true, data: comment });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// DELETE /api/videos/social/comments/:commentId - Delete a comment
router.delete('/social/comments/:commentId', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const deleted = db.deleteComment(req.params.commentId, req.user!.id, req.user!.role === 'admin');
    if (!deleted) {
      return res.status(404).json({ success: false, error: 'Comment not found or unauthorized' });
    }
    return res.json({ success: true, message: 'Comment deleted' });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// 5. FOLLOW SYSTEM
// ==========================================

// GET /api/videos/social/users/:userId/follow-state
router.get('/social/users/:userId/follow-state', optionalAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const targetUserId = req.params.userId;
    const currentUserId = req.user?.id;
    const followers = db.getFollowers(targetUserId);
    const following = db.getFollowing(targetUserId);
    const isFollowing = currentUserId ? followers.some(f => f.followerId === currentUserId) : false;

    return res.json({
      success: true,
      userId: targetUserId,
      isFollowing,
      followersCount: followers.length,
      followingCount: following.length
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/videos/social/users/:userId/follow - Toggle follow
router.post('/social/users/:userId/follow', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const targetUserId = req.params.userId;
    const targetUser = db.findUserById(targetUserId);
    const result = db.toggleFollow(req.user!.id, targetUserId, req.user!.name, targetUser?.name || req.body.followingName);

    return res.json({
      success: true,
      data: result,
      message: result.isFollowing ? 'Followed successfully' : 'Unfollowed successfully'
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/videos/social/users/:userId/followers
router.get('/social/users/:userId/followers', (req: Request, res: Response) => {
  try {
    const followers = db.getFollowers(req.params.userId);
    return res.json({ success: true, count: followers.length, data: followers });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/videos/social/users/:userId/following
router.get('/social/users/:userId/following', (req: Request, res: Response) => {
  try {
    const following = db.getFollowing(req.params.userId);
    return res.json({ success: true, count: following.length, data: following });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// 6. CHAT & MESSAGING
// ==========================================

// GET /api/videos/social/chat/messages
router.get('/social/chat/messages', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const withUser = (req.query.withUser || req.query.receiverId || req.query.user2) as string;
    if (!withUser) {
      return res.status(400).json({ success: false, error: 'withUser query parameter is required' });
    }

    const messages = db.getChatConversation(req.user!.id, withUser);
    return res.json({ success: true, count: messages.length, data: messages });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/videos/social/chat/messages - Send chat message
router.post('/social/chat/messages', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { receiverId, receiverName, message, mediaUrl, mediaType } = req.body;

    if (!receiverId || (!message && !mediaUrl)) {
      return res.status(400).json({ success: false, error: 'receiverId and message/mediaUrl are required' });
    }

    const chat = db.sendChatMessage({
      senderId: req.user!.id,
      senderName: req.user!.name,
      receiverId,
      receiverName,
      message: message || '',
      mediaUrl,
      mediaType
    });

    return res.status(201).json({ success: true, data: chat });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/videos/social/chat/threads - List user chat threads
router.get('/social/chat/threads', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const threads = db.getUserChatThreads(req.user!.id);
    return res.json({ success: true, count: threads.length, data: threads });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// 7. SEARCH & SEARCH HISTORY
// ==========================================

// GET or POST /api/videos/social/search
router.all('/social/search', optionalAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const q = ((req.query.q || req.query.query || req.body?.q || req.body?.query) as string) || '';
    if (q && req.user?.id) {
      db.addSearchHistory(req.user.id, q);
    }

    const videos = db.getAllMedia({ search: q, mediaType: 'video' });
    const creators = db.getPublicCreators().filter(c => c.name.toLowerCase().includes(q.toLowerCase()) || c.email.toLowerCase().includes(q.toLowerCase()));

    return res.json({
      success: true,
      query: q,
      videosCount: videos.length,
      creatorsCount: creators.length,
      data: {
        videos,
        creators
      }
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/videos/social/search/history
router.get('/social/search/history', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const history = db.getSearchHistory(req.user!.id);
    return res.json({ success: true, data: history });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// DELETE /api/videos/social/search/history
router.delete('/social/search/history', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    db.clearSearchHistory(req.user!.id);
    return res.json({ success: true, message: 'Search history cleared' });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// 8. LIVE STREAM COUNT
// ==========================================

router.get('/social/live/:videoId', (req: Request, res: Response) => {
  try {
    const result = db.getLiveVideoViewerCount(req.params.videoId);
    return res.json({ success: true, data: result });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

router.post('/social/live/:videoId/count', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const count = parseInt(req.body.count, 10) || 0;
    const result = db.setLiveVideoViewerCount(req.params.videoId, count);
    return res.json({ success: true, data: result });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// 9. NOTIFICATIONS
// ==========================================

router.get('/social/notifications', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const notifs = db.getUserNotifications(req.user!.id);
    const unreadCount = db.getUnreadNotificationsCount(req.user!.id);
    return res.json({ success: true, unreadCount, count: notifs.length, data: notifs });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

router.post('/social/notifications/read/:id', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const updated = db.markNotificationRead(req.params.id, req.user!.id);
    return res.json({ success: updated });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

router.post('/social/notifications/read-all', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const updated = db.markAllNotificationsRead(req.user!.id);
    return res.json({ success: true, updated });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// 10. BLOCK, MUTE & REPORT
// ==========================================

router.post('/social/users/:userId/block', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const result = db.blockUser(req.user!.id, req.params.userId);
    return res.json({ success: true, data: result });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

router.post('/social/users/:userId/mute', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const result = db.muteUser(req.user!.id, req.params.userId);
    return res.json({ success: true, data: result });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

router.post('/social/videos/:videoId/report', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { reason } = req.body;
    const report = db.reportContent(req.user!.id, 'video', req.params.videoId, reason || 'Inappropriate content');
    return res.status(201).json({ success: true, message: 'Report submitted successfully', data: report });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// 11. CREATOR STATS & MONETIZATION
// ==========================================

router.get('/social/creator/stats', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const profile = db.getUserSyncedProfile(req.user!.id);
    return res.json({
      success: true,
      data: {
        totalUploads: profile.user.totalUploads,
        totalLikesReceived: profile.user.totalLikesReceived,
        totalCommentsReceived: profile.user.totalCommentsReceived,
        totalSharesReceived: profile.user.totalSharesReceived,
        totalViewsReceived: profile.user.totalViewsReceived,
        followersCount: profile.user.followersCount,
        followingCount: profile.user.followingCount,
        monetization: profile.monetization
      }
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

router.get('/social/monetization', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const monetization = db.getMonetizationData(req.user!.id);
    return res.json({ success: true, data: monetization });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

router.post('/social/monetization/payout', authenticate, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { amount, method, accountInfo } = req.body;
    if (!amount || !accountInfo) {
      return res.status(400).json({ success: false, error: 'amount and accountInfo (UPI / Bank Details) are required' });
    }

    const payout = db.requestPayout(req.user!.id, Number(amount), method || 'upi', accountInfo);
    return res.status(201).json({ success: true, message: 'Payout requested successfully', data: payout });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

export default router;
