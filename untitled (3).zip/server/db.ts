import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';
import { User, MediaFile, ApiKey, Like, Save, Comment, Share, Follow, ChatMessage, Notification, SearchHistoryItem, ReportItem, SupportTicket, PayoutTransaction, MonetizationData, VideoFeedItem, AdMobConfig } from '../src/types.js';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const UPLOADS_DIR = path.resolve(process.cwd(), 'uploads');
const DB_FILE = path.join(DATA_DIR, 'mastibash_db.json');

// Ensure directories exist
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

interface DatabaseSchema {
  users: User[];
  media_files: MediaFile[];
  api_keys: ApiKey[];
  likes: Like[];
  saves: Save[];
  comments: Comment[];
  shares: Share[];
  follows: Follow[];
  chats: ChatMessage[];
  notifications: Notification[];
  search_history: SearchHistoryItem[];
  reports: ReportItem[];
  support_tickets: SupportTicket[];
  payouts: PayoutTransaction[];
  admob_config?: AdMobConfig;
}

class Database {
  private data: DatabaseSchema = {
    users: [],
    media_files: [],
    api_keys: [],
    likes: [],
    saves: [],
    comments: [],
    shares: [],
    follows: [],
    chats: [],
    notifications: [],
    search_history: [],
    reports: [],
    support_tickets: [],
    payouts: [],
    admob_config: {
      appId: 'ca-app-pub-3940256099942544~3347511713',
      bannerAdUnitId: 'ca-app-pub-3940256099942544/6300978111',
      interstitialAdUnitId: 'ca-app-pub-3940256099942544/1033173712',
      rewardedAdUnitId: 'ca-app-pub-3940256099942544/5224354917',
      nativeAdUnitId: 'ca-app-pub-3940256099942544/2247696110',
      isAdMobEnabled: true,
      isMonetizationEnabled: true,
      testMode: true,
      adFrequency: 4,
      isVideoCallingEnabled: true,
      isAudioCallingEnabled: true,
      isVirtualGiftingEnabled: false,
      isBadgesEnabled: false,
      isSubscriptionsEnabled: false,
      isStarsEnabled: false,
      isPremiumGoldEnabled: false,
      isUploadAllowed: true,
      appVersion: '1.0.0',
      forceUpdate: false,
      updateUrl: 'https://play.google.com/store',
      theme: {
        primaryColor: '#6366f1', // Indigo
        secondaryColor: '#db2777', // Pink
        fontFamily: 'modern',
        borderRadius: 16,
        layoutType: 'reels',
        isDarkMode: true,
        cameraEngine: 'expo'
      },
      updatedAt: new Date().toISOString()
    }
  };
  private liveViewers: Map<string, number> = new Map();
  private callSignals: Array<{ id: string; senderId: string; receiverId: string; type: string; payload: any; createdAt: string }> = [];
  private activeCallsList: Array<{ callId: string; callerId: string; receiverId: string; status: 'ringing' | 'connected' | 'ended'; callType: 'audio' | 'video'; createdAt: string }> = [];
  private isLoaded = false;

  constructor() {
    this.init();
  }

  private init() {
    if (fs.existsSync(DB_FILE)) {
      try {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        this.data = {
          users: parsed.users || [],
          media_files: parsed.media_files || [],
          api_keys: parsed.api_keys || [],
          likes: parsed.likes || [],
          saves: parsed.saves || [],
          comments: parsed.comments || [],
          shares: parsed.shares || [],
          follows: parsed.follows || [],
          chats: parsed.chats || [],
          notifications: parsed.notifications || [],
          search_history: parsed.search_history || [],
          reports: parsed.reports || [],
          support_tickets: parsed.support_tickets || [],
          payouts: parsed.payouts || [],
          admob_config: parsed.admob_config
        };
        this.purgeAllFakeUsersAndMedia();
        this.isLoaded = true;
      } catch (err) {
        console.error('Error reading database file, re-initializing:', err);
        this.seedInitialData();
      }
    } else {
      this.seedInitialData();
    }
    this.purgeAllFakeUsersAndMedia();
  }

  private seedInitialPayouts() {
    const defaultUsers: User[] = [
      {
        id: 'usr_rohit_masti',
        name: 'Rohit Kumar',
        email: 'rohit@mastiapp.io',
        role: 'user' as any,
        isVerified: false,
        passwordHash: 'seeded',
        apiKey: 'mb_live_rohit_masti',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=150'
      } as any,
      {
        id: 'usr_priya_dance',
        name: 'Priya Sharma',
        email: 'priya@mastiapp.io',
        role: 'user' as any,
        isVerified: false,
        passwordHash: 'seeded',
        apiKey: 'mb_live_priya_dance',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=150'
      } as any,
      {
        id: 'usr_deepak_vlogs',
        name: 'Deepak Verma',
        email: 'deepak@mastiapp.io',
        role: 'user' as any,
        isVerified: false,
        passwordHash: 'seeded',
        apiKey: 'mb_live_deepak_vlogs',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=150'
      } as any,
      {
        id: 'usr_amit_comedy',
        name: 'Amit Desi Comedy',
        email: 'amit@mastiapp.io',
        role: 'user' as any,
        isVerified: false,
        passwordHash: 'seeded',
        apiKey: 'mb_live_amit_comedy',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        avatarUrl: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&q=80&w=150'
      } as any
    ];

    for (const u of defaultUsers) {
      const existingUser = this.data.users.find(existing => existing.id === u.id);
      if (!existingUser) {
        this.data.users.push(u);
      } else {
        // Force the seeded demo users to be unverified by default so they match the rule
        existingUser.isVerified = false;
      }
    }

    this.data.payouts = [
      {
        id: 'pay_rohit1',
        userId: 'usr_rohit_masti',
        amount: 1500,
        currency: 'INR',
        status: 'pending',
        method: 'upi',
        accountInfo: 'rohitkumar@ybl',
        transactionRef: 'MB_UPI_' + Math.floor(100000000 + Math.random() * 900000000),
        createdAt: new Date().toISOString()
      },
      {
        id: 'pay_priya1',
        userId: 'usr_priya_dance',
        amount: 3200,
        currency: 'INR',
        status: 'pending',
        method: 'bank_transfer',
        accountInfo: 'SBI Bank, A/C: 39402560911, IFSC: SBIN0007892, Holder: Priya Sharma',
        transactionRef: 'MB_BANK_' + Math.floor(100000000 + Math.random() * 900000000),
        createdAt: new Date(Date.now() - 3600000).toISOString()
      },
      {
        id: 'pay_deepak1',
        userId: 'usr_deepak_vlogs',
        amount: 850,
        currency: 'INR',
        status: 'pending',
        method: 'paytm',
        accountInfo: '9876543210@paytm',
        transactionRef: 'MB_PAYTM_' + Math.floor(100000000 + Math.random() * 900000000),
        createdAt: new Date(Date.now() - 7200000).toISOString()
      },
      {
        id: 'pay_amit1',
        userId: 'usr_amit_comedy',
        amount: 5000,
        currency: 'INR',
        status: 'completed',
        method: 'upi',
        accountInfo: 'amitcomedy@oksbi',
        transactionRef: 'MB_UPI_938472918',
        createdAt: new Date(Date.now() - 86400000).toISOString()
      }
    ];

    this.persist();
  }

  private seedInitialData() {
    const salt = bcrypt.genSaltSync(10);
    const primaryPasswordHash = bcrypt.hashSync('admin123', salt);

    const ownerEmail = 'rajkalikumar8789@gmail.com';
    const ownerId = 'usr_rajkali_owner';
    const ownerApiKey = 'mb_live_rajkali_8789_' + uuidv4().replace(/-/g, '').slice(0, 16);

    const ownerUser: User = {
      id: ownerId,
      name: 'Raj Kali Kumar',
      email: ownerEmail,
      passwordHash: primaryPasswordHash,
      role: 'admin',
      isVerified: true,
      apiKey: ownerApiKey,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    this.data.users = [ownerUser];

    this.data.api_keys = [
      {
        id: 'key_' + uuidv4().slice(0, 8),
        userId: ownerId,
        keyName: 'Masti Video Primary Production Key',
        key: ownerApiKey,
        createdAt: new Date().toISOString(),
        lastUsedAt: new Date().toISOString()
      }
    ];

    // Clean initial media files: only real user media
    this.data.media_files = [];
    this.data.chats = [];
    this.data.comments = [];
    this.data.likes = [];
    this.data.saves = [];
    this.data.follows = [];

    this.persist();
    this.isLoaded = true;
  }

  purgeAllFakeUsersAndMedia(): { removedUsers: number; remainingUsers: number; removedMedia: number } {
    const fakeEmailSuffix = '@mastibash.io';
    const fakeEmailSuffix2 = '@mastiapp.io';
    const fakeIds = [
      'usr_admin',
      'usr_creator',
      'usr_masti_cinema',
      'usr_dj_rohit',
      'usr_pawan_music',
      'usr_desi_comedy',
      'usr_tech_masti',
      'usr_rohit_masti',
      'usr_priya_dance',
      'usr_deepak_vlogs',
      'usr_amit_comedy'
    ];

    const initialUserCount = this.data.users.length;
    const initialMediaCount = this.data.media_files.length;

    // Filter out fake users
    this.data.users = this.data.users.filter(u => {
      if (fakeIds.some(id => u.id === id || u.id.startsWith(id))) return false;
      if (u.email && u.email.toLowerCase().endsWith(fakeEmailSuffix)) return false;
      if (u.email && u.email.toLowerCase().endsWith(fakeEmailSuffix2)) return false;
      return true;
    });

    // Ensure primary owner exists
    const ownerExists = this.data.users.find(u => u.email.toLowerCase() === 'rajkalikumar8789@gmail.com');
    if (!ownerExists) {
      const salt = bcrypt.genSaltSync(10);
      const primaryPasswordHash = bcrypt.hashSync('admin123', salt);
      const ownerId = 'usr_rajkali_owner';
      const ownerApiKey = 'mb_live_rajkali_8789_' + uuidv4().replace(/-/g, '').slice(0, 16);

      this.data.users.unshift({
        id: ownerId,
        name: 'Raj Kali Kumar',
        email: 'rajkalikumar8789@gmail.com',
        passwordHash: primaryPasswordHash,
        role: 'admin',
        apiKey: ownerApiKey,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });

      this.data.api_keys.push({
        id: 'key_' + uuidv4().slice(0, 8),
        userId: ownerId,
        keyName: 'Masti Video Primary Production Key',
        key: ownerApiKey,
        createdAt: new Date().toISOString(),
        lastUsedAt: new Date().toISOString()
      });
    }

    const validUserIds = new Set(this.data.users.map(u => u.id));

    // Filter out sample media or media belonging to deleted fake users
    this.data.media_files = this.data.media_files.filter(m => {
      if (m.storedName && m.storedName.startsWith('sample_')) return false;
      if (m.originalName && (
        m.originalName.includes('sample_') || 
        m.originalName.includes('masti_cinema_intro_4k') ||
        m.originalName.includes('nature_wildlife_teaser') ||
        m.originalName.includes('cyberpunk_neon_banner') ||
        m.originalName.includes('mountain_sunset_backdrop') ||
        m.originalName.includes('mobile_app_hero_poster')
      )) {
        return false;
      }
      if (m.userId && !validUserIds.has(m.userId) && m.userId.startsWith('usr_')) {
        return false;
      }
      return true;
    });

    // Clean related artifacts
    this.data.payouts = (this.data.payouts || []).filter(p => validUserIds.has(p.userId));
    this.data.api_keys = this.data.api_keys.filter(k => validUserIds.has(k.userId));
    this.data.chats = this.data.chats.filter(c => validUserIds.has(c.senderId) && (!c.receiverId || validUserIds.has(c.receiverId)));
    this.data.likes = this.data.likes.filter(l => validUserIds.has(l.userId));
    this.data.follows = this.data.follows.filter(f => validUserIds.has(f.followerId) && validUserIds.has(f.followingId));

    const removedUsers = initialUserCount - this.data.users.length;
    const removedMedia = initialMediaCount - this.data.media_files.length;

    this.persist();

    return {
      removedUsers,
      remainingUsers: this.data.users.length,
      removedMedia
    };
  }

  private persist() {
    try {
      fs.writeFileSync(DB_FILE, JSON.stringify(this.data, null, 2), 'utf-8');
    } catch (err) {
      console.error('Failed to write database to disk:', err);
    }
  }

  // User Operations
  getUsers(): User[] {
    return this.data.users;
  }

  findUserByEmail(email: string): User | undefined {
    return this.data.users.find(u => u.email.toLowerCase() === email.toLowerCase());
  }

  findUserById(id: string): User | undefined {
    return this.data.users.find(u => u.id === id);
  }

  findUserByFirebaseUid(firebaseUid: string): User | undefined {
    if (!firebaseUid) return undefined;
    return this.data.users.find(u => u.firebaseUid === firebaseUid);
  }

  linkFirebaseUid(userId: string, firebaseUid: string): User | undefined {
    const user = this.data.users.find(u => u.id === userId);
    if (user) {
      user.firebaseUid = firebaseUid;
      user.updatedAt = new Date().toISOString();
      this.persist();
    }
    return user;
  }

  // Update Blue Tick / Verification Badge for a single user
  updateUserVerification(identifier: string, isVerified: boolean): { user?: User; success: boolean } {
    const cleanId = String(identifier || '').trim().toLowerCase();
    const user = this.data.users.find(
      u => u.id.toLowerCase() === cleanId || 
           u.email.toLowerCase() === cleanId || 
           (u.username && u.username.toLowerCase() === cleanId)
    );

    if (!user) {
      return { success: false };
    }

    user.isVerified = Boolean(isVerified);
    user.updatedAt = new Date().toISOString();
    this.persist();
    return { user, success: true };
  }

  // Update Avatar URL for a user
  updateUserAvatar(identifier: string, avatarUrl: string): { user?: User; success: boolean } {
    const cleanId = String(identifier || '').trim().toLowerCase();
    const user = this.data.users.find(
      u => u.id.toLowerCase() === cleanId || 
           u.email.toLowerCase() === cleanId || 
           (u.username && u.username.toLowerCase() === cleanId)
    );

    if (!user) {
      return { success: false };
    }

    user.avatarUrl = avatarUrl;
    user.updatedAt = new Date().toISOString();
    this.persist();
    return { user, success: true };
  }

  // Bulk update Blue Tick for multiple users at once
  bulkSetVerification(userIds: string[], isVerified: boolean): { updatedCount: number; success: boolean } {
    if (!Array.isArray(userIds) || userIds.length === 0) {
      return { updatedCount: 0, success: true };
    }

    const idSet = new Set(userIds.map(id => String(id || '').trim().toLowerCase()));
    let updatedCount = 0;

    for (const u of this.data.users) {
      if (idSet.has(u.id.toLowerCase()) || (u.email && idSet.has(u.email.toLowerCase()))) {
        u.isVerified = Boolean(isVerified);
        u.updatedAt = new Date().toISOString();
        updatedCount++;
      }
    }

    if (updatedCount > 0) {
      this.persist();
    }

    return { updatedCount, success: true };
  }

  createUserWithFirebase(params: {
    firebaseUid: string;
    email?: string;
    name?: string;
    avatarUrl?: string;
    phoneNumber?: string;
    username?: string;
  }): User {
    // Check if user already exists by firebaseUid
    const existingByUid = this.findUserByFirebaseUid(params.firebaseUid);
    if (existingByUid) {
      return existingByUid;
    }

    // Check if user exists by email
    if (params.email) {
      const existingByEmail = this.findUserByEmail(params.email);
      if (existingByEmail) {
        existingByEmail.firebaseUid = params.firebaseUid;
        if (params.name && !existingByEmail.name) existingByEmail.name = params.name;
        if (params.avatarUrl && !(existingByEmail as any).avatarUrl) (existingByEmail as any).avatarUrl = params.avatarUrl;
        if (params.phoneNumber && !existingByEmail.phoneNumber) existingByEmail.phoneNumber = params.phoneNumber;
        existingByEmail.updatedAt = new Date().toISOString();
        this.persist();
        return existingByEmail;
      }
    }

    const id = 'usr_' + uuidv4().slice(0, 8);
    const apiKey = 'mb_live_' + uuidv4().replace(/-/g, '').slice(0, 24);
    const email = (params.email || `${params.firebaseUid}@firebase.mastibash.io`).toLowerCase();
    const displayName = params.name || params.email?.split('@')[0] || `Masti Creator ${params.firebaseUid.slice(0, 5)}`;
    const username = params.username || (params.email ? params.email.split('@')[0].replace(/[^a-zA-Z0-9_]/g, '') : `user_${params.firebaseUid.slice(0, 6)}`);

    const newUser: User = {
      id,
      firebaseUid: params.firebaseUid,
      username,
      name: displayName,
      email,
      phoneNumber: params.phoneNumber,
      authProvider: 'firebase',
      avatarUrl: params.avatarUrl || `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(displayName)}`,
      bio: 'Masti Video Creator',
      followersCount: 0,
      followingCount: 0,
      totalLikes: 0,
      totalVideos: 0,
      isVerified: false,
      passwordHash: '',
      role: 'user',
      apiKey,
      privacySettings: {
        isPrivate: false,
        allowComments: true,
        allowDuet: true,
        allowDirectMessages: true
      },
      notificationSettings: {
        likes: true,
        comments: true,
        follows: true,
        directMessages: true,
        monetization: true
      },
      blockedUsers: [],
      mutedUsers: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    this.data.users.push(newUser);
    this.data.api_keys.push({
      id: 'key_' + uuidv4().slice(0, 8),
      userId: id,
      keyName: `Firebase API Key (${email})`,
      key: apiKey,
      createdAt: new Date().toISOString()
    });

    this.persist();
    return newUser;
  }

  updateUserProfile(userId: string, updates: Partial<User>): User | null {
    const user = this.data.users.find(u => u.id === userId);
    if (!user) return null;

    if (updates.name !== undefined) user.name = String(updates.name).trim();
    if (updates.username !== undefined) user.username = String(updates.username).trim().toLowerCase().replace(/[^a-z0-9_]/g, '');
    if (updates.avatarUrl !== undefined) user.avatarUrl = updates.avatarUrl ? String(updates.avatarUrl).trim() : user.avatarUrl;
    if (updates.bio !== undefined) user.bio = String(updates.bio).trim();
    if (updates.phoneNumber !== undefined) user.phoneNumber = String(updates.phoneNumber).trim();
    if (updates.privacySettings !== undefined) user.privacySettings = { ...user.privacySettings, ...updates.privacySettings };
    if (updates.notificationSettings !== undefined) user.notificationSettings = { ...user.notificationSettings, ...updates.notificationSettings };
    if (updates.blockedUsers !== undefined) user.blockedUsers = updates.blockedUsers;
    if (updates.mutedUsers !== undefined) user.mutedUsers = updates.mutedUsers;
    
    user.updatedAt = new Date().toISOString();
    this.persist();
    return user;
  }

  findUserByApiKey(apiKey: string): User | undefined {
    // Check primary user key
    const directUser = this.data.users.find(u => u.apiKey === apiKey);
    if (directUser) return directUser;

    // Check registered api_keys table
    const keyRecord = this.data.api_keys.find(k => k.key === apiKey);
    if (keyRecord) {
      keyRecord.lastUsedAt = new Date().toISOString();
      this.persist();
      return this.findUserById(keyRecord.userId);
    }
    return undefined;
  }

  findUserByPhone(phone: string): User | undefined {
    return this.data.users.find(u => u.phoneNumber === phone || (u.email && u.email.startsWith(`phone_${phone.replace(/\D/g, '')}`)));
  }

  createUser(userData: { 
    name: string; 
    email: string; 
    password?: string; 
    phoneNumber?: string; 
    authProvider?: 'email' | 'google' | 'phone';
    role?: 'admin' | 'user' 
  }): User {
    const salt = bcrypt.genSaltSync(10);
    const passwordHash = userData.password ? bcrypt.hashSync(userData.password, salt) : '';
    const id = 'usr_' + uuidv4().slice(0, 8);
    const apiKey = 'mb_live_' + uuidv4().replace(/-/g, '').slice(0, 24);

    const newUser: User = {
      id,
      name: userData.name,
      email: userData.email.toLowerCase(),
      phoneNumber: userData.phoneNumber,
      authProvider: userData.authProvider || 'email',
      passwordHash,
      role: userData.role || 'user',
      apiKey,
      isVerified: false,
      monetizationStatus: 'disabled',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    this.data.users.push(newUser);

    // Also register default API key
    this.data.api_keys.push({
      id: 'key_' + uuidv4().slice(0, 8),
      userId: id,
      keyName: 'Default API Key',
      key: apiKey,
      createdAt: new Date().toISOString()
    });

    this.persist();
    return newUser;
  }

  findOrCreateUserByEmail(email: string, name?: string, avatarUrl?: string, role: 'admin' | 'user' = 'user'): User {
    const cleanEmail = email.trim().toLowerCase();
    let user = this.data.users.find(u => u.email.toLowerCase() === cleanEmail);
    if (!user) {
      const id = 'usr_' + uuidv4().slice(0, 8);
      const apiKey = 'mb_live_' + uuidv4().replace(/-/g, '').slice(0, 24);
      user = {
        id,
        name: name || cleanEmail.split('@')[0],
        email: cleanEmail,
        authProvider: 'email',
        passwordHash: '',
        role,
        apiKey,
        followersCount: 0,
        followingCount: 0,
        isVerified: false,
        monetizationStatus: 'disabled',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      if (avatarUrl) (user as any).avatarUrl = avatarUrl;
      this.data.users.push(user);
      this.data.api_keys.push({
        id: 'key_' + uuidv4().slice(0, 8),
        userId: id,
        keyName: 'Default API Key (' + cleanEmail + ')',
        key: apiKey,
        createdAt: new Date().toISOString()
      });
      this.persist();
    } else {
      let updated = false;
      if (name && user.name !== name && name !== cleanEmail.split('@')[0]) {
        user.name = name;
        updated = true;
      }
      if (avatarUrl && (user as any).avatarUrl !== avatarUrl) {
        (user as any).avatarUrl = avatarUrl;
        updated = true;
      }
      if (updated) {
        user.updatedAt = new Date().toISOString();
        this.persist();
      }
    }
    return user;
  }

  deleteUser(userId: string): boolean {
    const initialLen = this.data.users.length;
    this.data.users = this.data.users.filter(u => u.id !== userId);
    this.data.api_keys = this.data.api_keys.filter(k => k.userId !== userId);
    this.data.chats = this.data.chats.filter(c => c.senderId !== userId && c.receiverId !== userId);
    this.data.notifications = this.data.notifications.filter(n => n.userId !== userId);
    this.data.likes = this.data.likes.filter(l => l.userId !== userId);
    this.data.follows = this.data.follows.filter(f => f.followerId !== userId && f.followingId !== userId);
    
    if (this.data.users.length !== initialLen) {
      this.persist();
      return true;
    }
    return false;
  }

  purgeAllFakeUsers(): { removedUsers: number; remainingUsers: number; removedMedia?: number } {
    return this.purgeAllFakeUsersAndMedia();
  }

  getUserFolderName(userIdOrEmail: string): string {
    const user = this.findUserById(userIdOrEmail) || this.findUserByEmail(userIdOrEmail);
    if (user && user.name) {
      return user.name.trim().replace(/[\/\\:*?"<>|]/g, '_');
    }
    if (userIdOrEmail.includes('@')) {
      return userIdOrEmail.split('@')[0].replace(/[\/\\:*?"<>|]/g, '_');
    }
    return 'General';
  }

  getAllFoldersWithStats(): Array<{ 
    name: string; 
    isUserFolder: boolean; 
    userId?: string; 
    userName?: string;
    userEmail?: string; 
    userAvatar?: string; 
    count: number; 
    totalSize: number;
    videoCount: number;
    audioCount: number;
    imageCount: number;
  }> {
    const folderMap = new Map<string, {
      name: string;
      isUserFolder: boolean;
      userId?: string;
      userName?: string;
      userEmail?: string;
      userAvatar?: string;
      count: number;
      totalSize: number;
      videoCount: number;
      audioCount: number;
      imageCount: number;
    }>();

    // 1. Initialize user dedicated folders for all registered users
    for (const u of this.data.users) {
      const folderName = (u.name || u.email.split('@')[0]).trim().replace(/[\/\\:*?"<>|]/g, '_');
      if (!folderMap.has(folderName)) {
        folderMap.set(folderName, {
          name: folderName,
          isUserFolder: true,
          userId: u.id,
          userName: u.name,
          userEmail: u.email,
          userAvatar: (u as any).avatarUrl || `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(u.name || u.email)}`,
          count: 0,
          totalSize: 0,
          videoCount: 0,
          audioCount: 0,
          imageCount: 0
        });
      }
    }

    // 2. Tally all media files into their respective folders
    for (const m of this.data.media_files) {
      let fName = (m.folder || '').trim().replace(/[\/\\:*?"<>|]/g, '_');
      if (!fName || fName === 'general' || fName === 'all') {
        if (m.userName) {
          fName = m.userName.trim().replace(/[\/\\:*?"<>|]/g, '_');
        } else if (m.userEmail) {
          fName = m.userEmail.split('@')[0].replace(/[\/\\:*?"<>|]/g, '_');
        } else {
          fName = 'General';
        }
      }

      let entry = folderMap.get(fName);
      if (!entry) {
        // Check if matching user exists
        const matchedUser = this.data.users.find(u => u.name?.toLowerCase() === fName.toLowerCase() || u.id === m.userId);
        entry = {
          name: fName,
          isUserFolder: Boolean(matchedUser || m.userId),
          userId: matchedUser?.id || m.userId,
          userName: matchedUser?.name || m.userName || fName,
          userEmail: matchedUser?.email || m.userEmail,
          userAvatar: (matchedUser as any)?.avatarUrl || m.userAvatar,
          count: 0,
          totalSize: 0,
          videoCount: 0,
          audioCount: 0,
          imageCount: 0
        };
        folderMap.set(fName, entry);
      }

      entry.count += 1;
      entry.totalSize += (m.fileSize || 0);
      if (m.mediaType === 'video') entry.videoCount += 1;
      else if (m.mediaType === 'audio') entry.audioCount += 1;
      else if (m.mediaType === 'image') entry.imageCount += 1;
    }

    return Array.from(folderMap.values());
  }

  // Media Operations
  getAllMedia(filter?: { userId?: string; userEmail?: string; mediaType?: 'image' | 'video' | 'audio'; search?: string; folder?: string; sort?: string }): MediaFile[] {
    let result = [...this.data.media_files];

    if (filter?.userEmail) {
      const targetEmail = filter.userEmail.toLowerCase().trim();
      result = result.filter(m => {
        if (m.userEmail && m.userEmail.toLowerCase() === targetEmail) return true;
        const creator = this.findUserById(m.userId);
        return creator && creator.email.toLowerCase() === targetEmail;
      });
    }

    if (filter?.userId) {
      result = result.filter(m => m.userId === filter.userId);
    }

    if (filter?.mediaType) {
      result = result.filter(m => m.mediaType === filter.mediaType);
    }

    if (filter?.folder && filter.folder !== 'all') {
      result = result.filter(m => m.folder?.toLowerCase() === filter.folder?.toLowerCase());
    }

    if (filter?.search) {
      const q = filter.search.toLowerCase().trim();
      result = result.filter(m => 
        m.originalName.toLowerCase().includes(q) ||
        m.storedName.toLowerCase().includes(q) ||
        m.tags?.some(t => t.toLowerCase().includes(q)) ||
        m.mimeType.toLowerCase().includes(q)
      );
    }

    // Sort
    const sortMode = filter?.sort || 'newest';
    if (sortMode === 'newest') {
      result.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    } else if (sortMode === 'oldest') {
      result.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
    } else if (sortMode === 'name_asc') {
      result.sort((a, b) => a.originalName.localeCompare(b.originalName));
    } else if (sortMode === 'name_desc') {
      result.sort((a, b) => b.originalName.localeCompare(a.originalName));
    } else if (sortMode === 'size_desc') {
      result.sort((a, b) => b.fileSize - a.fileSize);
    } else if (sortMode === 'size_asc') {
      result.sort((a, b) => a.fileSize - b.fileSize);
    }

    return result;
  }

  getMediaById(id: string): MediaFile | undefined {
    return this.data.media_files.find(m => m.id === id);
  }

  addMediaFile(media: Omit<MediaFile, 'id' | 'createdAt' | 'updatedAt'>): MediaFile {
    const id = 'med_' + uuidv4().slice(0, 10);
    const now = new Date().toISOString();

    // Auto-resolve user folder if not explicitly provided or generic
    let resolvedFolder = (media.folder || '').trim().replace(/[\/\\:*?"<>|]/g, '_');
    if (!resolvedFolder || resolvedFolder.toLowerCase() === 'general' || resolvedFolder.toLowerCase() === 'all') {
      if (media.userName) {
        resolvedFolder = media.userName.trim().replace(/[\/\\:*?"<>|]/g, '_');
      } else if (media.userEmail) {
        resolvedFolder = media.userEmail.split('@')[0].replace(/[\/\\:*?"<>|]/g, '_');
      } else if (media.userId) {
        const found = this.findUserById(media.userId);
        if (found) {
          resolvedFolder = (found.name || found.email.split('@')[0]).trim().replace(/[\/\\:*?"<>|]/g, '_');
        }
      }
    }
    if (!resolvedFolder) {
      resolvedFolder = 'General';
    }

    const newMedia: MediaFile = {
      ...media,
      folder: resolvedFolder,
      id,
      createdAt: now,
      updatedAt: now
    };
    this.data.media_files.unshift(newMedia);
    this.persist();
    return newMedia;
  }

  updateMediaFile(id: string, updates: Partial<MediaFile>): MediaFile | undefined {
    const index = this.data.media_files.findIndex(m => m.id === id);
    if (index === -1) return undefined;

    this.data.media_files[index] = {
      ...this.data.media_files[index],
      ...updates,
      updatedAt: new Date().toISOString()
    };
    this.persist();
    return this.data.media_files[index];
  }

  deleteMediaFile(id: string): boolean {
    const media = this.getMediaById(id);
    if (!media) return false;

    // If file is stored locally in /uploads, delete it from disk
    if (media.storedName && !media.fileUrl.startsWith('http://') && !media.fileUrl.startsWith('https://')) {
      const localPath = path.join(UPLOADS_DIR, media.storedName);
      if (fs.existsSync(localPath)) {
        try {
          fs.unlinkSync(localPath);
        } catch (err) {
          console.warn('Could not delete local file:', err);
        }
      }
    } else if (media.fileUrl.includes('/uploads/')) {
      const parts = media.fileUrl.split('/uploads/');
      if (parts[1]) {
        const localPath = path.join(UPLOADS_DIR, parts[1]);
        if (fs.existsSync(localPath)) {
          try {
            fs.unlinkSync(localPath);
          } catch (err) {
            console.warn('Could not delete local file:', err);
          }
        }
      }
    }

    this.data.media_files = this.data.media_files.filter(m => m.id !== id);
    this.persist();
    return true;
  }

  deleteBatchMedia(ids: string[]): number {
    let count = 0;
    for (const id of ids) {
      if (this.deleteMediaFile(id)) {
        count++;
      }
    }
    return count;
  }

  // API Key operations
  getUserApiKeys(userId: string): ApiKey[] {
    return this.data.api_keys.filter(k => k.userId === userId);
  }

  createApiKey(userId: string, keyName: string): ApiKey {
    const newKey: ApiKey = {
      id: 'key_' + uuidv4().slice(0, 8),
      userId,
      keyName: keyName || 'API Key',
      key: 'mb_live_' + uuidv4().replace(/-/g, '').slice(0, 24),
      createdAt: new Date().toISOString()
    };
    this.data.api_keys.push(newKey);
    this.persist();
    return newKey;
  }

  deleteApiKey(id: string, userId: string): boolean {
    const initialLen = this.data.api_keys.length;
    this.data.api_keys = this.data.api_keys.filter(k => !(k.id === id && k.userId === userId));
    if (this.data.api_keys.length !== initialLen) {
      this.persist();
      return true;
    }
    return false;
  }

  // Stats
  getStats(userId?: string) {
    const files = userId ? this.data.media_files.filter(m => m.userId === userId) : this.data.media_files;
    const totalFiles = files.length;
    const totalVideos = files.filter(f => f.mediaType === 'video').length;
    const totalImages = files.filter(f => f.mediaType === 'image').length;
    const totalBytes = files.reduce((acc, f) => acc + (f.fileSize || 0), 0);

    const folders = Array.from(new Set(files.map(f => f.folder || 'general'))).filter(Boolean);
    const tags = Array.from(new Set(files.flatMap(f => f.tags || []))).filter(Boolean);

    return {
      totalFiles,
      totalVideos,
      totalImages,
      totalBytes,
      totalUsers: this.data.users.length,
      totalLikes: this.data.likes.length,
      totalComments: this.data.comments.length,
      totalShares: this.data.shares.length,
      totalChats: this.data.chats.length,
      folders,
      tags
    };
  }

  // ---------------- Social & Interactive Operations ---------------- //

  // Notifications System
  createNotification(params: {
    userId: string;
    actorId: string;
    actorName: string;
    actorAvatar?: string;
    type: 'like' | 'comment' | 'follow' | 'share' | 'chat' | 'monetization' | 'system' | 'save' | 'video_call' | 'audio_call';
    title: string;
    message: string;
    mediaId?: string;
    mediaThumbnail?: string;
  }): Notification {
    // Avoid self-notifications
    if (params.userId === params.actorId && params.type !== 'monetization' && params.type !== 'system') {
      return null as any;
    }

    const notif: Notification = {
      id: 'notif_' + uuidv4().slice(0, 8),
      userId: params.userId,
      actorId: params.actorId,
      actorName: params.actorName,
      actorAvatar: params.actorAvatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(params.actorName)}`,
      type: params.type,
      title: params.title,
      message: params.message,
      mediaId: params.mediaId,
      mediaThumbnail: params.mediaThumbnail,
      isRead: false,
      createdAt: new Date().toISOString()
    };

    this.data.notifications.unshift(notif);
    this.persist();
    return notif;
  }

  getUserNotifications(userId: string): Notification[] {
    return this.data.notifications
      .filter(n => n.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  markNotificationRead(notificationId: string, userId: string): boolean {
    const notif = this.data.notifications.find(n => n.id === notificationId && n.userId === userId);
    if (notif) {
      notif.isRead = true;
      this.persist();
      return true;
    }
    return false;
  }

  markAllNotificationsRead(userId: string): boolean {
    let changed = false;
    for (const notif of this.data.notifications) {
      if (notif.userId === userId && !notif.isRead) {
        notif.isRead = true;
        changed = true;
      }
    }
    if (changed) this.persist();
    return changed;
  }

  getUnreadNotificationsCount(userId: string): number {
    return this.data.notifications.filter(n => n.userId === userId && !n.isRead).length;
  }

  clearNotifications(userId: string): boolean {
    const initialLen = this.data.notifications.length;
    this.data.notifications = this.data.notifications.filter(n => n.userId !== userId);
    if (this.data.notifications.length !== initialLen) {
      this.persist();
      return true;
    }
    return false;
  }

  // Likes System
  toggleLike(mediaId: string, userId: string, userName?: string): { isLiked: boolean; likesCount: number; userIds: string[] } {
    const existingIndex = this.data.likes.findIndex(l => l.mediaId === mediaId && l.userId === userId);
    let isLiked = false;
    const media = this.getMediaById(mediaId);
    const actorName = userName || this.findUserById(userId)?.name || 'Masti User';

    if (existingIndex >= 0) {
      // Remove like
      this.data.likes.splice(existingIndex, 1);
      isLiked = false;
    } else {
      // Add like
      this.data.likes.push({
        id: 'like_' + uuidv4().slice(0, 8),
        mediaId,
        userId,
        userName: actorName,
        createdAt: new Date().toISOString()
      });
      isLiked = true;

      // Trigger Notification for creator
      if (media && media.userId && media.userId !== userId) {
        this.createNotification({
          userId: media.userId,
          actorId: userId,
          actorName,
          actorAvatar: (this.findUserById(userId) as any)?.avatarUrl,
          type: 'like',
          title: 'New Like on your Video!',
          message: `${actorName} liked your video "${media.originalName}".`,
          mediaId: media.id,
          mediaThumbnail: media.thumbnailUrl || media.fileUrl
        });
      }
    }

    const likesForMedia = this.data.likes.filter(l => l.mediaId === mediaId);
    const likesCount = likesForMedia.length;
    const userIds = likesForMedia.map(l => l.userId);

    // Sync media item likesCount
    if (media) {
      media.likesCount = likesCount;
      media.likedBy = userIds;
    }

    this.persist();
    return { isLiked, likesCount, userIds };
  }

  getMediaLikes(mediaId: string): Like[] {
    return this.data.likes.filter(l => l.mediaId === mediaId);
  }

  getUserLikedMediaIds(userId: string): string[] {
    return this.data.likes.filter(l => l.userId === userId).map(l => l.mediaId);
  }

  // Comments System
  addComment(mediaId: string, userId: string, userName: string, text: string, userAvatar?: string): Comment {
    const actorName = userName || this.findUserById(userId)?.name || 'Masti User';
    const comment: Comment = {
      id: 'cmt_' + uuidv4().slice(0, 8),
      mediaId,
      userId,
      userName: actorName,
      userAvatar: userAvatar || (this.findUserById(userId) as any)?.avatarUrl,
      text: text.trim(),
      createdAt: new Date().toISOString()
    };

    this.data.comments.push(comment);

    // Update media commentsCount
    const media = this.getMediaById(mediaId);
    if (media) {
      media.commentsCount = this.data.comments.filter(c => c.mediaId === mediaId).length;

      // Trigger Notification for creator
      if (media.userId && media.userId !== userId) {
        this.createNotification({
          userId: media.userId,
          actorId: userId,
          actorName,
          actorAvatar: comment.userAvatar,
          type: 'comment',
          title: 'New Comment on your Video',
          message: `${actorName}: "${text.length > 50 ? text.substring(0, 47) + '...' : text}"`,
          mediaId: media.id,
          mediaThumbnail: media.thumbnailUrl || media.fileUrl
        });
      }
    }

    this.persist();
    return comment;
  }

  getComments(mediaId?: string): Comment[] {
    if (mediaId) {
      return this.data.comments
        .filter(c => c.mediaId === mediaId)
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    }
    return this.data.comments.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  deleteComment(commentId: string, userId?: string, isAdmin: boolean = false): boolean {
    const idx = this.data.comments.findIndex(c => c.id === commentId);
    if (idx === -1) return false;

    const comment = this.data.comments[idx];
    if (!isAdmin && userId && comment.userId !== userId) {
      return false;
    }

    const mediaId = comment.mediaId;
    this.data.comments.splice(idx, 1);

    const media = this.getMediaById(mediaId);
    if (media) {
      media.commentsCount = this.data.comments.filter(c => c.mediaId === mediaId).length;
    }

    this.persist();
    return true;
  }

  // Shares System
  recordShare(mediaId: string, userId?: string, platform?: string, shareUrl?: string): { share: Share; totalShares: number } {
    const share: Share = {
      id: 'shr_' + uuidv4().slice(0, 8),
      mediaId,
      userId: userId || 'anonymous',
      platform: platform || 'direct',
      shareUrl,
      createdAt: new Date().toISOString()
    };

    this.data.shares.push(share);

    const totalShares = this.data.shares.filter(s => s.mediaId === mediaId).length;
    const media = this.getMediaById(mediaId);
    if (media) {
      media.sharesCount = totalShares;

      // Trigger Notification for creator
      if (media.userId && userId && media.userId !== userId) {
        const actor = this.findUserById(userId);
        this.createNotification({
          userId: media.userId,
          actorId: userId,
          actorName: actor?.name || 'A Fan',
          actorAvatar: (actor as any)?.avatarUrl,
          type: 'share',
          title: 'Video Shared!',
          message: `${actor?.name || 'Someone'} shared your video on ${platform || 'Masti Social'}.`,
          mediaId: media.id,
          mediaThumbnail: media.thumbnailUrl || media.fileUrl
        });
      }
    }

    this.persist();
    return { share, totalShares };
  }

  getShares(mediaId?: string): Share[] {
    if (mediaId) {
      return this.data.shares.filter(s => s.mediaId === mediaId);
    }
    return this.data.shares;
  }

  // Followers & Following System
  toggleFollow(followerId: string, followingId: string, followerName?: string, followingName?: string): { isFollowing: boolean; followersCount: number; followingCount: number } {
    if (followerId === followingId) {
      const followersCount = this.data.follows.filter(f => f.followingId === followingId).length;
      const followingCount = this.data.follows.filter(f => f.followerId === followerId).length;
      return { isFollowing: false, followersCount, followingCount };
    }

    const existingIdx = this.data.follows.findIndex(f => f.followerId === followerId && f.followingId === followingId);
    let isFollowing = false;
    const actorName = followerName || this.findUserById(followerId)?.name || 'Masti Creator';

    if (existingIdx >= 0) {
      this.data.follows.splice(existingIdx, 1);
      isFollowing = false;
    } else {
      this.data.follows.push({
        id: 'fol_' + uuidv4().slice(0, 8),
        followerId,
        followerName: actorName,
        followingId,
        followingName: followingName || this.findUserById(followingId)?.name || 'Creator',
        createdAt: new Date().toISOString()
      });
      isFollowing = true;

      // Trigger Notification for followed creator
      this.createNotification({
        userId: followingId,
        actorId: followerId,
        actorName,
        actorAvatar: (this.findUserById(followerId) as any)?.avatarUrl,
        type: 'follow',
        title: 'New Follower Alert!',
        message: `${actorName} started following your Masti profile.`,
      });
    }

    const followersCount = this.data.follows.filter(f => f.followingId === followingId).length;
    const followingCount = this.data.follows.filter(f => f.followerId === followerId).length;

    // Update user caches
    const followingUser = this.findUserById(followingId);
    if (followingUser) {
      followingUser.followersCount = followersCount;
    }
    const followerUser = this.findUserById(followerId);
    if (followerUser) {
      followerUser.followingCount = followingCount;
    }

    this.persist();
    return { isFollowing, followersCount, followingCount };
  }

  getFollowers(userId: string): Follow[] {
    return this.data.follows.filter(f => f.followingId === userId);
  }

  getFollowing(userId: string): Follow[] {
    return this.data.follows.filter(f => f.followerId === userId);
  }

  isUserFollowing(followerId: string, followingId: string): boolean {
    return this.data.follows.some(f => f.followerId === followerId && f.followingId === followingId);
  }

  // Realtime Live Chat Messages System
  sendChatMessage(params: {
    senderId: string;
    senderName: string;
    receiverId: string;
    receiverName?: string;
    message: string;
    mediaUrl?: string;
    mediaType?: 'image' | 'video' | 'audio';
  }): ChatMessage {
    const senderName = params.senderName || this.findUserById(params.senderId)?.name || 'User';
    const chat: ChatMessage = {
      id: 'msg_' + uuidv4().slice(0, 8),
      senderId: params.senderId,
      senderName,
      receiverId: params.receiverId,
      receiverName: params.receiverName || this.findUserById(params.receiverId)?.name || 'Contact',
      message: params.message.trim(),
      mediaUrl: params.mediaUrl,
      mediaType: params.mediaType,
      isRead: false,
      createdAt: new Date().toISOString()
    };

    this.data.chats.push(chat);

    // Trigger Notification for receiver
    if (params.receiverId && params.receiverId !== params.senderId) {
      this.createNotification({
        userId: params.receiverId,
        actorId: params.senderId,
        actorName: senderName,
        actorAvatar: (this.findUserById(params.senderId) as any)?.avatarUrl,
        type: 'chat',
        title: `New message from ${senderName}`,
        message: params.message.length > 50 ? params.message.substring(0, 47) + '...' : params.message
      });
    }

    this.persist();
    return chat;
  }

  getChatConversation(user1Id: string, user2Id: string): ChatMessage[] {
    return this.data.chats
      .filter(c => (c.senderId === user1Id && c.receiverId === user2Id) || (c.senderId === user2Id && c.receiverId === user1Id))
      .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
  }

  getUserChatThreads(userId: string): { contactId: string; contactName: string; lastMessage: ChatMessage; unreadCount: number }[] {
    const userMessages = this.data.chats.filter(c => c.senderId === userId || c.receiverId === userId);
    const contactMap = new Map<string, { contactName: string; lastMessage: ChatMessage; unreadCount: number }>();

    for (const msg of userMessages) {
      const contactId = msg.senderId === userId ? msg.receiverId : msg.senderId;
      const contactName = msg.senderId === userId 
        ? (msg.receiverName || this.findUserById(contactId)?.name || 'User') 
        : (msg.senderName || this.findUserById(contactId)?.name || 'User');

      const existing = contactMap.get(contactId);
      const isUnread = msg.receiverId === userId && !msg.isRead;

      if (!existing || new Date(msg.createdAt).getTime() > new Date(existing.lastMessage.createdAt).getTime()) {
        contactMap.set(contactId, {
          contactName,
          lastMessage: msg,
          unreadCount: (existing?.unreadCount || 0) + (isUnread ? 1 : 0)
        });
      } else if (isUnread && existing) {
        existing.unreadCount++;
      }
    }

    return Array.from(contactMap.entries()).map(([contactId, data]) => ({
      contactId,
      contactName: data.contactName,
      lastMessage: data.lastMessage,
      unreadCount: data.unreadCount
    })).sort((a, b) => new Date(b.lastMessage.createdAt).getTime() - new Date(a.lastMessage.createdAt).getTime());
  }

  markChatRead(messageId: string, userId: string): boolean {
    const msg = this.data.chats.find(c => c.id === messageId && c.receiverId === userId);
    if (msg) {
      msg.isRead = true;
      this.persist();
      return true;
    }
    return false;
  }

  // ---------------- Monetization & Creator Revenue Engine ---------------- //
  recordMediaView(mediaId: string, viewerId?: string): { viewsCount: number; earningsEarned: number } {
    const media = this.getMediaById(mediaId);
    if (!media) return { viewsCount: 0, earningsEarned: 0 };

    media.viewsCount = (media.viewsCount || 0) + 1;

    // Check if media creator's monetization is active
    let isOwnerMonetized = false;
    if (media.userId || (media as any).userEmail) {
      const ownerMonetization = this.getMonetizationData(media.userId || (media as any).userEmail);
      isOwnerMonetized = ownerMonetization.isEnabled && ownerMonetization.monetizationStatus === 'active';
    }

    // Base RPM: ₹35 per 1,000 views = ₹0.035 per view ONLY if monetization is active!
    const earningsEarned = isOwnerMonetized ? 0.035 : 0;

    this.persist();
    return { viewsCount: media.viewsCount, earningsEarned };
  }

  getMonetizationData(userIdOrEmail: string): MonetizationData {
    let user = this.findUserById(userIdOrEmail);
    if (!user && userIdOrEmail.includes('@')) {
      user = this.findUserByEmail(userIdOrEmail);
    }
    const userId = user?.id || userIdOrEmail;

    const userMedia = this.data.media_files.filter(m => m.userId === userId || (user?.email && m.userEmail === user.email));
    const totalViews = userMedia.reduce((sum, m) => sum + (m.viewsCount || 0), 0);
    const monetizedViews = Math.floor(totalViews * 0.85);

    // Custom admin overrides if configured
    const custom = (user as any)?.monetizationSettings || {};
    const isExplicitlyDisabled = (user as any)?.monetizationStatus === 'disabled' || custom.isEnabled === false;

    // RPM ₹1.00 per 1k views by default
    const rpm = custom.rpm !== undefined ? Number(custom.rpm) : 1.0;
    const cpm = custom.cpm !== undefined ? Number(custom.cpm) : 1.0;

    const calculatedGross = Number(((monetizedViews / 1000) * rpm).toFixed(2));
    const baseBonus = 0.0;
    const totalEarnings = (custom.totalEarnings !== undefined && custom.totalEarnings !== null)
      ? Number(custom.totalEarnings)
      : (calculatedGross + baseBonus);

    const userPayouts = this.data.payouts.filter(p =>
      p.userId === userId ||
      (user && (p.userId === user.id || (user.email && p.userId === user.email)))
    );
    const totalPaidOut = userPayouts.filter(p => p.status === 'completed').reduce((sum, p) => sum + p.amount, 0);
    const walletBalance = (custom.walletBalance !== undefined && custom.walletBalance !== null)
      ? Number(custom.walletBalance)
      : Math.max(0, Number((totalEarnings - totalPaidOut).toFixed(2)));

    // Monetization status: eligible / active / disabled
    let monetizationStatus: 'eligible' | 'approved' | 'active' | 'in_review' | 'disabled' | 'suspended' = 'disabled';
    if ((user as any)?.monetizationStatus) {
      monetizationStatus = (user as any).monetizationStatus;
    } else if (isExplicitlyDisabled) {
      monetizationStatus = 'disabled';
    }

    const isEnabled = monetizationStatus === 'active' || monetizationStatus === 'approved';

    const statusMessage = isEnabled
      ? 'Monetization is ACTIVE on Masti Video App. Earnings from views and payouts are enabled.'
      : 'Monetization is DISABLED on Masti Video App by Admin. Views will NOT earn revenue and payouts are blocked.';

    return {
      userId,
      userName: user?.name,
      userEmail: user?.email,
      monetizationStatus,
      isEnabled,
      statusMessage,
      appSyncStatus: isEnabled ? 'MONETIZED_ACTIVE' : 'MONETIZED_DISABLED',
      totalEarnings,
      walletBalance,
      hasWalletOverride: custom.walletBalance !== undefined && custom.walletBalance !== null,
      hasEarningsOverride: custom.totalEarnings !== undefined && custom.totalEarnings !== null,
      estimatedMonthlyRevenue: Number((totalEarnings * 1.4).toFixed(2)),
      rpm,
      cpm,
      totalViews,
      monetizedViews,
      currency: 'INR',
      bankDetails: {
        upiId: custom.upiId || (user as any)?.upiId || `${user?.email ? user.email.split('@')[0] : 'creator'}@oksbi`,
        accountHolderName: custom.accountHolderName || user?.name || 'Masti Creator'
      },
      payouts: userPayouts
    };
  }

  updateUserMonetization(userIdOrEmail: string, update: {
    isEnabled?: boolean;
    monetizationStatus?: 'active' | 'disabled' | 'in_review' | 'eligible' | 'suspended';
    walletBalance?: number | null;
    totalEarnings?: number | null;
    rpm?: number;
    cpm?: number;
    upiId?: string;
    accountHolderName?: string;
    note?: string;
  }): MonetizationData {
    let user = this.findUserById(userIdOrEmail);
    if (!user && userIdOrEmail.includes('@')) {
      user = this.findUserByEmail(userIdOrEmail);
    }
    if (!user) {
      user = {
        id: userIdOrEmail,
        name: userIdOrEmail.includes('@') ? userIdOrEmail.split('@')[0] : 'Masti User',
        email: userIdOrEmail.includes('@') ? userIdOrEmail : `${userIdOrEmail}@mastiapp.io`,
        role: 'user',
        passwordHash: 'synced_user',
        apiKey: `mb_live_${userIdOrEmail}`,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      this.data.users.push(user);
    }

    const currentSettings = { ...((user as any).monetizationSettings || {}) };
    if (update.walletBalance === null) {
      delete currentSettings.walletBalance;
    }
    if (update.totalEarnings === null) {
      delete currentSettings.totalEarnings;
    }

    let newStatus: 'active' | 'disabled' | 'in_review' | 'eligible' | 'suspended' = 'active';

    if (update.monetizationStatus) {
      newStatus = update.monetizationStatus;
    } else if (update.isEnabled === false) {
      newStatus = 'disabled';
    } else if (update.isEnabled === true) {
      newStatus = 'active';
    } else {
      newStatus = (user as any).monetizationStatus || 'active';
    }

    (user as any).monetizationStatus = newStatus;
    (user as any).monetizationSettings = {
      ...currentSettings,
      isEnabled: newStatus !== 'disabled',
      ...(update.walletBalance !== undefined && update.walletBalance !== null ? { walletBalance: Math.max(0, Number(update.walletBalance)) } : {}),
      ...(update.totalEarnings !== undefined && update.totalEarnings !== null ? { totalEarnings: Math.max(0, Number(update.totalEarnings)) } : {}),
      ...(update.rpm !== undefined ? { rpm: Number(update.rpm) } : {}),
      ...(update.cpm !== undefined ? { cpm: Number(update.cpm) } : {}),
      ...(update.upiId ? { upiId: update.upiId } : {}),
      ...(update.accountHolderName ? { accountHolderName: update.accountHolderName } : {}),
      ...(update.note ? { note: update.note } : {})
    };
    user.updatedAt = new Date().toISOString();

    // Create a real-time in-app notification for the user
    this.createNotification({
      userId: user.id,
      actorId: 'masti_admin',
      actorName: 'Masti Bash Admin',
      type: 'monetization',
      title: newStatus === 'active' ? '💰 Monetization Activated!' : '⚠️ Monetization Status Changed',
      message: newStatus === 'active'
        ? 'Admin has approved & enabled your monetization! Earnings from video views and payouts are active.'
        : `Your creator monetization status has been set to: ${newStatus.toUpperCase()} by Admin.`
    });

    this.persist();
    return this.getMonetizationData(user.id);
  }

  requestPayout(userId: string, amount: number, method: 'upi' | 'bank_transfer' | 'paytm', accountInfo: string): PayoutTransaction {
    const numericAmount = Number(amount);
    if (isNaN(numericAmount) || numericAmount < 1) {
      throw new Error('Minimum withdrawal amount is ₹1.00.');
    }

    const monetization = this.getMonetizationData(userId);
    if (!monetization.isEnabled || monetization.monetizationStatus === 'disabled') {
      throw new Error('Monetization is disabled for this account on Masti Video App by Admin. Payouts and withdrawals are suspended.');
    }

    if (numericAmount > monetization.walletBalance) {
      throw new Error(`Insufficient wallet balance! Available: ₹${monetization.walletBalance.toFixed(2)}, Requested: ₹${numericAmount.toFixed(2)}`);
    }

    let user = this.findUserById(userId);
    if (!user && userId.includes('@')) {
      user = this.findUserByEmail(userId);
    }
    const canonicalUserId = user ? user.id : userId;

    const cleanAccountInfo = (accountInfo && accountInfo.trim().length > 0)
      ? accountInfo.trim()
      : (monetization.bankDetails?.upiId || (user?.email ? `${user.email.split('@')[0]}@oksbi` : 'creator@oksbi'));

    const payout: PayoutTransaction = {
      id: 'pay_' + uuidv4().slice(0, 8),
      userId: canonicalUserId,
      amount: numericAmount,
      currency: 'INR',
      status: 'pending',
      method,
      accountInfo: cleanAccountInfo,
      transactionRef: 'MB_UPI_' + Math.floor(100000000 + Math.random() * 900000000),
      createdAt: new Date().toISOString()
    };

    // Deduct from wallet balance in user's monetization settings
    if (user) {
      if (!(user as any).monetizationSettings) {
        (user as any).monetizationSettings = {};
      }
      const updatedBalance = Math.max(0, Number((monetization.walletBalance - numericAmount).toFixed(2)));
      (user as any).monetizationSettings.walletBalance = updatedBalance;
      user.updatedAt = new Date().toISOString();
    }

    this.data.payouts.unshift(payout);

    // Send notification to creator
    this.createNotification({
      userId: canonicalUserId,
      actorId: 'masti_payout_bot',
      actorName: 'Masti Bash Payouts',
      type: 'monetization',
      title: '⏳ Withdrawal Request Submitted!',
      message: `₹${numericAmount.toFixed(2)} withdrawal request to ${cleanAccountInfo} (${method.toUpperCase()}) has been received and is under review. Ref: ${payout.transactionRef}`,
    });

    this.persist();
    return payout;
  }

  updatePayoutStatus(payoutId: string, status: 'completed' | 'rejected', transactionRef?: string): PayoutTransaction {
    const payout = this.data.payouts.find(p => p.id === payoutId);
    if (!payout) {
      throw new Error('Payout request not found.');
    }
    if (payout.status !== 'pending') {
      throw new Error(`Payout request already ${payout.status}.`);
    }

    payout.status = status;
    if (transactionRef) {
      payout.transactionRef = transactionRef;
    }

    const user = this.findUserById(payout.userId);

    if (status === 'completed') {
      // Create success notification
      this.createNotification({
        userId: payout.userId,
        actorId: 'masti_payout_bot',
        actorName: 'Masti Bash Payouts',
        type: 'monetization',
        title: '🎉 Withdrawal Successful!',
        message: `Your withdrawal of ₹${payout.amount.toFixed(2)} to ${payout.accountInfo} (${payout.method.toUpperCase()}) has been APPROVED and processed. Ref: ${payout.transactionRef}`,
      });
    } else if (status === 'rejected') {
      // Refund user's balance
      if (user) {
        if (!(user as any).monetizationSettings) {
          (user as any).monetizationSettings = {};
        }
        const currentBal = (user as any).monetizationSettings.walletBalance || 0;
        (user as any).monetizationSettings.walletBalance = Number((currentBal + payout.amount).toFixed(2));
        user.updatedAt = new Date().toISOString();
      }

      // Create failure notification
      this.createNotification({
        userId: payout.userId,
        actorId: 'masti_payout_bot',
        actorName: 'Masti Bash Payouts',
        type: 'monetization',
        title: '❌ Withdrawal Rejected',
        message: `Your withdrawal of ₹${payout.amount.toFixed(2)} to ${payout.accountInfo} was rejected. The amount has been refunded back to your wallet.`,
      });
    }

    this.persist();
    return payout;
  }

  getPayouts(): PayoutTransaction[] {
    return this.data.payouts || [];
  }

  // Two-Way App Sync: Save and return real comprehensive data for Masti Video App users
  syncUserFromApp(userData: {
    userId: string;
    userName: string;
    userAvatar?: string;
    email?: string;
    followersCount?: number;
    followingCount?: number;
    bio?: string;
    socialLinks?: {
      instagram?: string;
      youtube?: string;
      facebook?: string;
      twitter?: string;
      website?: string;
      whatsapp?: string;
      telegram?: string;
    };
  }) {
    let user = this.data.users.find(u => u.id === userData.userId || (userData.email && u.email.toLowerCase() === userData.email.toLowerCase()));
    if (!user) {
      user = {
        id: userData.userId,
        name: userData.userName,
        email: userData.email || `${userData.userId}@mastiapp.io`,
        role: 'user',
        passwordHash: 'masti_video_app_synced',
        apiKey: `mb_live_${userData.userId}`,
        followersCount: userData.followersCount || 0,
        followingCount: userData.followingCount || 0,
        isVerified: false,
        monetizationStatus: 'disabled',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      (user as any).avatarUrl = userData.userAvatar;
      (user as any).bio = userData.bio;
      if (userData.socialLinks) {
        (user as any).socialLinks = userData.socialLinks;
      }
      this.data.users.push(user);
    } else {
      user.name = userData.userName || user.name;
      if (userData.userAvatar) (user as any).avatarUrl = userData.userAvatar;
      if (userData.bio) (user as any).bio = userData.bio;
      if (userData.socialLinks) {
        (user as any).socialLinks = {
          ...((user as any).socialLinks || {}),
          ...userData.socialLinks
        };
      }
      if (userData.followersCount !== undefined) user.followersCount = userData.followersCount;
      if (userData.followingCount !== undefined) user.followingCount = userData.followingCount;
      user.updatedAt = new Date().toISOString();
    }

    this.persist();
    return this.getUserSyncedProfile(user.id);
  }

  getUserSyncedProfile(userIdOrEmail: string) {
    let user = this.data.users.find(u => u.id === userIdOrEmail);
    if (!user && userIdOrEmail.includes('@')) {
      user = this.data.users.find(u => u.email.toLowerCase() === userIdOrEmail.toLowerCase());
    }

    const targetUserId = user?.id || userIdOrEmail;
    const targetEmail = user?.email || (userIdOrEmail.includes('@') ? userIdOrEmail.toLowerCase() : undefined);

    const userMedia = this.data.media_files.filter(m => m.userId === targetUserId || (targetEmail && m.userEmail?.toLowerCase() === targetEmail));
    const likedMediaIds = this.data.likes.filter(l => l.userId === targetUserId).map(l => l.mediaId);
    const followers = this.data.follows.filter(f => f.followingId === targetUserId);
    const following = this.data.follows.filter(f => f.followerId === targetUserId);
    const chatThreads = this.getUserChatThreads(targetUserId);
    const notifications = this.getUserNotifications(targetUserId);
    const monetization = this.getMonetizationData(targetUserId);

    const totalLikesReceived = this.data.likes.filter(l => userMedia.some(m => m.id === l.mediaId)).length;
    const totalCommentsReceived = this.data.comments.filter(c => userMedia.some(m => m.id === c.mediaId)).length;
    const totalSharesReceived = this.data.shares.filter(s => userMedia.some(m => m.id === s.mediaId)).length;
    const totalViewsReceived = userMedia.reduce((acc, m) => acc + (m.viewsCount || 0), 0);

    const defaultAvatar = `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(user?.name || targetUserId)}`;

    return {
      syncedAt: new Date().toISOString(),
      user: {
        id: targetUserId,
        name: user?.name || (targetEmail ? targetEmail.split('@')[0] : 'Masti Creator'),
        email: user?.email || targetEmail || `${targetUserId}@mastiapp.io`,
        avatarUrl: (user as any)?.avatarUrl || defaultAvatar,
        bio: (user as any)?.bio || 'Masti Video Creator & Content Publisher',
        socialLinks: (user as any)?.socialLinks || {
          instagram: `https://instagram.com/${(user?.name || 'masticreator').toLowerCase().replace(/\s+/g, '')}`,
          youtube: '',
          facebook: '',
          twitter: '',
          website: '',
          whatsapp: ''
        },
        followersCount: (user?.followersCount || 0) + followers.length,
        followingCount: (user?.followingCount || 0) + following.length,
        totalUploads: userMedia.length,
        totalLikesReceived,
        totalCommentsReceived,
        totalSharesReceived,
        totalViewsReceived,
        isMonetized: monetization.isEnabled,
        monetizationEnabled: monetization.isEnabled,
        monetizationStatus: monetization.monetizationStatus,
        isVerified: user ? Boolean(user.isVerified) : false,
        apiKey: user?.apiKey || `mb_live_${targetUserId}`
      },
      uploadedMedia: userMedia,
      notifications,
      unreadNotificationsCount: notifications.filter(n => !n.isRead).length,
      monetization,
      followers,
      following,
      chatThreads,
      unreadChatsCount: chatThreads.reduce((sum, t) => sum + t.unreadCount, 0),
      likedMediaIds
    };
  }

  getPublicCreators(): Array<{
    id: string;
    name: string;
    username: string;
    email: string;
    role: string;
    avatarUrl?: string;
    followersCount: number;
    followingCount: number;
    mediaCount: number;
    likesCount: number;
    badge?: string;
    bio?: string;
    socialLinks?: any;
    monetization?: MonetizationData;
    isVerified?: boolean;
    createdAt: string;
  }> {
    const seenIds = new Set<string>();
    const uniqueUsers = this.data.users.filter(u => {
      if (!u.id || seenIds.has(u.id)) return false;
      seenIds.add(u.id);
      return true;
    });

    return uniqueUsers.map(u => {
      const userMedia = this.data.media_files.filter(m => m.userId === u.id || (u.email && m.userEmail === u.email));
      const userLikes = this.data.likes.filter(l => userMedia.some(m => m.id === l.mediaId)).length;
      const followers = this.data.follows.filter(f => f.followingId === u.id || (u.email && f.followingId === u.email)).length;
      const following = this.data.follows.filter(f => f.followerId === u.id || (u.email && f.followerId === u.email)).length;

      let badge = 'Creator';
      if (u.role === 'admin') badge = 'Official Admin';
      else if (u.name.includes('DJ')) badge = 'Top DJ';
      else if (u.name.includes('Music') || u.name.includes('Star')) badge = 'Star Artist';
      else if (u.name.includes('Comedy')) badge = 'Popular Comedy';
      else if (u.name.includes('Tech')) badge = 'Developer Studio';

      const username = u.username || (u.email ? u.email.split('@')[0] : `user_${u.id.slice(0, 6)}`);

      return {
        id: u.id,
        name: u.name,
        username,
        email: u.email,
        role: u.role,
        avatarUrl: (u as any).avatarUrl || `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(u.name || u.email || u.id)}`,
        followersCount: (u.followersCount || 0) + followers,
        followingCount: (u.followingCount || 0) + following,
        mediaCount: userMedia.length,
        likesCount: userLikes,
        badge,
        isVerified: Boolean(u.isVerified),
        bio: (u as any).bio || `Masti creator with ${userMedia.length} uploads and active community followers.`,
        monetization: this.getMonetizationData(u.id),
        socialLinks: (u as any).socialLinks || {
          instagram: `https://instagram.com/${username.toLowerCase().replace(/[^a-z0-9_]/g, '')}`,
          youtube: '',
          facebook: '',
          twitter: '',
          website: '',
          whatsapp: ''
        },
        createdAt: u.createdAt
      };
    });
  }

  getSocialStats() {
    return {
      totalUsers: this.data.users.length,
      totalMedia: this.data.media_files.length,
      totalLikes: this.data.likes.length,
      totalSaves: this.data.saves.length,
      totalComments: this.data.comments.length,
      totalShares: this.data.shares.length,
      totalFollows: this.data.follows.length,
      totalChats: this.data.chats.length
    };
  }

  // ---------------- SAVES / BOOKMARKS / FAVORITES ---------------- //
  toggleSave(mediaId: string, userId: string): { isSaved: boolean; savesCount: number } {
    const existingIndex = this.data.saves.findIndex(s => s.mediaId === mediaId && s.userId === userId);
    let isSaved = false;

    if (existingIndex >= 0) {
      this.data.saves.splice(existingIndex, 1);
      isSaved = false;
    } else {
      this.data.saves.push({
        id: 'save_' + uuidv4().slice(0, 8),
        mediaId,
        userId,
        createdAt: new Date().toISOString()
      });
      isSaved = true;
    }

    const savesCount = this.data.saves.filter(s => s.mediaId === mediaId).length;
    const media = this.getMediaById(mediaId);
    if (media) {
      media.savesCount = savesCount;
      media.updatedAt = new Date().toISOString();
    }

    this.persist();

    if (isSaved && media && media.userId !== userId) {
      const user = this.findUserById(userId);
      this.createNotification({
        userId: media.userId,
        actorId: userId,
        actorName: user?.name || 'Someone',
        type: 'save',
        title: 'Video Saved',
        message: `${user?.name || 'Someone'} saved your video to their bookmarks!`,
        mediaId: media.id,
        mediaThumbnail: media.thumbnailUrl || media.fileUrl
      });
    }

    return { isSaved, savesCount };
  }

  logCall(params: { callerId: string; callerName: string; receiverId: string; receiverName: string; callType: 'video' | 'audio' }): Notification {
    const caller = this.findUserById(params.callerId);
    const notif = this.createNotification({
      userId: params.receiverId,
      actorId: params.callerId,
      actorName: params.callerName || caller?.name || 'Someone',
      type: params.callType === 'video' ? 'video_call' : 'audio_call',
      title: params.callType === 'video' ? 'Incoming Video Call 📹' : 'Incoming Audio Call 📞',
      message: `initiated a ${params.callType} call with you.`
    });
    return notif;
  }

  initiateCall(callerId: string, callerName: string, receiverId: string, receiverName: string, callType: 'audio' | 'video') {
    const callId = 'call_' + uuidv4().slice(0, 8);
    const newCall = {
      callId,
      callerId,
      receiverId,
      status: 'ringing' as const,
      callType,
      createdAt: new Date().toISOString()
    };
    this.activeCallsList.push(newCall);

    // Also trigger logCall notification
    this.logCall({
      callerId,
      callerName,
      receiverId,
      receiverName,
      callType
    });

    return newCall;
  }

  addCallSignal(senderId: string, receiverId: string, type: string, payload: any) {
    const signal = {
      id: 'sig_' + uuidv4().slice(0, 8),
      senderId,
      receiverId,
      type,
      payload,
      createdAt: new Date().toISOString()
    };
    this.callSignals.push(signal);
    return signal;
  }

  getCallSignals(receiverId: string) {
    // Get and clear signals for this receiver
    const filtered = this.callSignals.filter(s => s.receiverId === receiverId);
    this.callSignals = this.callSignals.filter(s => s.receiverId !== receiverId);
    return filtered;
  }

  updateCallStatus(callId: string, status: 'connected' | 'ended') {
    const call = this.activeCallsList.find(c => c.callId === callId);
    if (call) {
      call.status = status;
    }
    return call;
  }

  getUserSaves(userId: string): MediaFile[] {
    const savedMediaIds = this.data.saves.filter(s => s.userId === userId).map(s => s.mediaId);
    return this.data.media_files.filter(m => savedMediaIds.includes(m.id));
  }

  // ---------------- SEARCH HISTORY ---------------- //
  addSearchHistory(userId: string, query: string): SearchHistoryItem {
    const cleanQuery = query.trim();
    if (!cleanQuery) return null as any;

    // Remove duplicates for this user
    this.data.search_history = this.data.search_history.filter(s => !(s.userId === userId && s.query.toLowerCase() === cleanQuery.toLowerCase()));

    const item: SearchHistoryItem = {
      id: 'sh_' + uuidv4().slice(0, 8),
      userId,
      query: cleanQuery,
      createdAt: new Date().toISOString()
    };

    this.data.search_history.unshift(item);
    if (this.data.search_history.length > 500) {
      this.data.search_history = this.data.search_history.slice(0, 500);
    }
    this.persist();
    return item;
  }

  getSearchHistory(userId: string): SearchHistoryItem[] {
    return this.data.search_history.filter(s => s.userId === userId).slice(0, 20);
  }

  clearSearchHistory(userId: string): boolean {
    this.data.search_history = this.data.search_history.filter(s => s.userId !== userId);
    this.persist();
    return true;
  }

  // ---------------- BLOCK / MUTE / REPORT ---------------- //
  blockUser(userId: string, targetUserId: string): { isBlocked: boolean; blockedUsers: string[] } {
    const user = this.findUserById(userId);
    if (!user) return { isBlocked: false, blockedUsers: [] };

    user.blockedUsers = user.blockedUsers || [];
    const index = user.blockedUsers.indexOf(targetUserId);
    let isBlocked = false;

    if (index >= 0) {
      user.blockedUsers.splice(index, 1);
      isBlocked = false;
    } else {
      user.blockedUsers.push(targetUserId);
      isBlocked = true;
    }

    user.updatedAt = new Date().toISOString();
    this.persist();
    return { isBlocked, blockedUsers: user.blockedUsers };
  }

  muteUser(userId: string, targetUserId: string): { isMuted: boolean; mutedUsers: string[] } {
    const user = this.findUserById(userId);
    if (!user) return { isMuted: false, mutedUsers: [] };

    user.mutedUsers = user.mutedUsers || [];
    const index = user.mutedUsers.indexOf(targetUserId);
    let isMuted = false;

    if (index >= 0) {
      user.mutedUsers.splice(index, 1);
      isMuted = false;
    } else {
      user.mutedUsers.push(targetUserId);
      isMuted = true;
    }

    user.updatedAt = new Date().toISOString();
    this.persist();
    return { isMuted, mutedUsers: user.mutedUsers };
  }

  reportContent(reporterId: string, targetType: 'video' | 'user' | 'comment', targetId: string, reason: string): ReportItem {
    const report: ReportItem = {
      id: 'rep_' + uuidv4().slice(0, 8),
      reporterId,
      targetType,
      targetId,
      reason,
      createdAt: new Date().toISOString()
    };

    this.data.reports.push(report);
    this.persist();
    return report;
  }

  createSupportTicket(params: { userId: string; userName: string; userEmail?: string; subject: string; message: string }): SupportTicket {
    const user = this.findUserById(params.userId);
    const ticket: SupportTicket = {
      id: 'tkt_' + uuidv4().slice(0, 8),
      userId: params.userId,
      userName: params.userName || user?.name || 'User',
      userEmail: params.userEmail || user?.email,
      subject: params.subject,
      message: params.message,
      status: 'open',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    this.data.support_tickets.unshift(ticket);

    this.createNotification({
      userId: 'usr_rajkali_owner',
      actorId: params.userId,
      actorName: ticket.userName,
      type: 'system',
      title: '🆘 New Help / Support Ticket',
      message: `sent a support request: "${params.subject}"`
    });

    this.persist();
    return ticket;
  }

  getSupportTickets(): SupportTicket[] {
    return this.data.support_tickets.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  resolveSupportTicket(ticketId: string, adminReply: string): SupportTicket | null {
    const ticket = this.data.support_tickets.find(t => t.id === ticketId);
    if (ticket) {
      ticket.status = 'resolved';
      ticket.adminReply = adminReply;
      ticket.updatedAt = new Date().toISOString();

      this.createNotification({
        userId: ticket.userId,
        actorId: 'usr_rajkali_owner',
        actorName: 'Rajkali (Admin)',
        type: 'system',
        title: '✅ Support Ticket Resolved',
        message: `Admin replied: "${adminReply}"`
      });

      this.persist();
      return ticket;
    }
    return null;
  }

  // ---------------- LIVE STREAM VIEWER COUNT ---------------- //
  getLiveVideoViewerCount(videoId: string): { count: number; videoId: string } {
    const count = this.liveViewers.get(videoId) || 0;
    return { count, videoId };
  }

  setLiveVideoViewerCount(videoId: string, count: number): { count: number; videoId: string } {
    this.liveViewers.set(videoId, Math.max(0, count));
    return { count: this.liveViewers.get(videoId)!, videoId };
  }

  // ---------------- VIDEO FEED WITH DYNAMIC LIVE PROFILE & SOCIAL DATA ---------------- //
  getVideoFeed(currentUserId?: string, limit: number = 0, page: number = 1, baseUrl: string = ''): VideoFeedItem[] {
    const videos = this.data.media_files
      .filter(m => m.mediaType === 'video' && m.visibility !== 'private')
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    // If limit <= 0, return all videos (unlimited)
    const paginated = limit > 0
      ? videos.slice((Math.max(1, page) - 1) * limit, (Math.max(1, page) - 1) * limit + limit)
      : videos;

    return paginated.map(video => {
      // Resolve latest user profile dynamically from users table (Single Source of Truth)
      const creator = this.findUserById(video.userId) || this.findUserByEmail(video.userEmail || '');
      const creatorName = creator?.name || video.userName || 'Masti Creator';
      const creatorUsername = creator?.username || (creator?.email ? creator.email.split('@')[0] : `user_${(video.userId || 'guest').slice(0, 6)}`);
      const creatorAvatar = (creator as any)?.avatarUrl || video.userAvatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(creatorName)}`;
      const followersCount = (creator?.followersCount || 0) + this.data.follows.filter(f => f.followingId === (creator?.id || video.userId)).length;
      const followingCount = (creator?.followingCount || 0) + this.data.follows.filter(f => f.followerId === (creator?.id || video.userId)).length;

      // Resolve real-time social metrics
      const likesCount = this.data.likes.filter(l => l.mediaId === video.id).length;
      const commentsCount = this.data.comments.filter(c => c.mediaId === video.id).length;
      const sharesCount = this.data.shares.filter(s => s.mediaId === video.id).length;
      const savesCount = this.data.saves.filter(s => s.mediaId === video.id).length;
      const viewsCount = video.viewsCount || 0;

      const isLiked = currentUserId ? this.data.likes.some(l => l.mediaId === video.id && l.userId === currentUserId) : false;
      const isSaved = currentUserId ? this.data.saves.some(s => s.mediaId === video.id && s.userId === currentUserId) : false;
      const isFollowing = currentUserId && creator ? this.data.follows.some(f => f.followerId === currentUserId && f.followingId === creator.id) : false;

      let fullVideoUrl = video.fileUrl || '';
      if (fullVideoUrl.startsWith('/') && baseUrl) {
        fullVideoUrl = `${baseUrl}${fullVideoUrl}`;
      }

      let fullThumbnailUrl = video.posterUrl || video.thumbnailUrl || video.fileUrl || '';
      if (fullThumbnailUrl.startsWith('/') && baseUrl) {
        fullThumbnailUrl = `${baseUrl}${fullThumbnailUrl}`;
      }

      return {
        id: video.id,
        userId: creator?.id || video.userId,
        videoUrl: fullVideoUrl,
        thumbnailUrl: fullThumbnailUrl,
        title: video.title || video.originalName,
        caption: video.caption || video.tags?.join(' ') || video.originalName,
        hashtags: video.tags || [],
        mentions: video.mentions || [],
        music: video.music || { title: 'Original Sound', artist: creatorName },
        duration: video.duration || 15,
        createdAt: video.createdAt,
        visibility: video.visibility || 'public',
        commentsEnabled: video.commentsEnabled !== false,
        duetEnabled: video.duetEnabled !== false,
        profile: {
          id: creator?.id || video.userId,
          firebaseUid: creator?.firebaseUid,
          name: creatorName,
          username: creatorUsername,
          avatarUrl: creatorAvatar,
          bio: (creator as any)?.bio || 'Masti Video Creator',
          socialLinks: (creator as any)?.socialLinks || {
            instagram: `https://instagram.com/${creatorUsername}`,
            youtube: '',
            facebook: '',
            twitter: '',
            website: '',
            whatsapp: ''
          },
          followersCount,
          followingCount,
          isVerified: Boolean(creator?.isVerified)
        },
        social: {
          likes: likesCount,
          comments: commentsCount,
          views: viewsCount,
          shares: sharesCount,
          saves: savesCount,
          isLiked,
          isSaved,
          isFollowing
        }
      };
    });
  }

  // ---------------- GOOGLE ADMOB REVENUE & ADS ENGINE ---------------- //
  getAdMobConfig(): AdMobConfig {
    if (!this.data.admob_config) {
      this.data.admob_config = {
        appId: 'ca-app-pub-3940256099942544~3347511713',
        bannerAdUnitId: 'ca-app-pub-3940256099942544/6300978111',
        interstitialAdUnitId: 'ca-app-pub-3940256099942544/1033173712',
        rewardedAdUnitId: 'ca-app-pub-3940256099942544/5224354917',
        nativeAdUnitId: 'ca-app-pub-3940256099942544/2247696110',
        isAdMobEnabled: true,
        isMonetizationEnabled: true,
        testMode: true,
        adFrequency: 4,
        isVideoCallingEnabled: true,
        isAudioCallingEnabled: true,
        isVirtualGiftingEnabled: false,
        isBadgesEnabled: false,
        isSubscriptionsEnabled: false,
        isStarsEnabled: false,
        isPremiumGoldEnabled: false,
        isUploadAllowed: true,
        appVersion: '1.0.0',
        forceUpdate: false,
        updateUrl: 'https://play.google.com/store',
        theme: {
          primaryColor: '#6366f1',
          secondaryColor: '#db2777',
          fontFamily: 'modern',
          borderRadius: 16,
          layoutType: 'reels',
          isDarkMode: true,
          cameraEngine: 'expo'
        },
        updatedAt: new Date().toISOString()
      };
      this.persist();
    }
    return this.data.admob_config;
  }

  updateAdMobConfig(updates: Partial<AdMobConfig>): AdMobConfig {
    const current = this.getAdMobConfig();
    this.data.admob_config = {
      ...current,
      ...updates,
      updatedAt: new Date().toISOString()
    };
    this.persist();
    return this.data.admob_config;
  }
}

export const db = new Database();

