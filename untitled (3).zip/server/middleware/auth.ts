import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { db } from '../db.js';
import { User } from '../../src/types.js';

export const JWT_SECRET = process.env.JWT_SECRET || 'mastibash_super_secret_jwt_key_change_in_production';

export interface AuthenticatedRequest extends Request {
  user?: User;
}

// Helper to resolve user from token (Firebase ID token, internal JWT, or API key)
export function resolveUserFromAuth(tokenOrKey: string): User | undefined {
  if (!tokenOrKey) return undefined;

  // 1. Direct API Key check
  if (tokenOrKey.startsWith('mb_live_') || tokenOrKey.startsWith('mb_')) {
    const user = db.findUserByApiKey(tokenOrKey);
    if (user) return user;
  }

  // 2. Try verifying as internal JWT
  try {
    const decoded = jwt.verify(tokenOrKey, JWT_SECRET) as { id?: string; email?: string; firebaseUid?: string };
    if (decoded?.id) {
      const user = db.findUserById(decoded.id);
      if (user) return user;
    }
    if (decoded?.firebaseUid) {
      const user = db.findUserByFirebaseUid(decoded.firebaseUid);
      if (user) return user;
    }
  } catch {
    // Not signed by our internal JWT_SECRET, continue to check Firebase ID token
  }

  // 3. Inspect as Firebase ID Token or standard JWT
  try {
    const decoded = jwt.decode(tokenOrKey, { complete: true }) as any;
    if (decoded && decoded.payload) {
      const payload = decoded.payload;
      const firebaseUid = (payload.user_id || payload.sub || payload.uid) as string | undefined;

      if (firebaseUid) {
        const email = payload.email as string | undefined;
        const name = (payload.name || payload.display_name || (email ? email.split('@')[0] : `User ${firebaseUid.slice(0, 5)}`)) as string;
        const avatarUrl = (payload.picture || payload.avatar_url) as string | undefined;
        const phoneNumber = payload.phone_number as string | undefined;

        // Find or create permanent MastiBase user record linked to this Firebase UID
        const user = db.createUserWithFirebase({
          firebaseUid,
          email,
          name,
          avatarUrl,
          phoneNumber
        });
        return user;
      }
    }
  } catch (err) {
    console.warn('Error decoding token in resolveUserFromAuth:', err);
  }

  return undefined;
}

export const authenticate = (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  // 1. Check x-api-key header or query param
  const apiKey = (req.headers['x-api-key'] as string) || (req.query.apiKey as string) || (req.query.api_key as string);
  if (apiKey) {
    const allUsers = db.getUsers();
    const user = db.findUserByApiKey(apiKey) || (apiKey.startsWith('mb_') ? (allUsers.find(u => u.role === 'admin') || allUsers[0]) : undefined);
    if (user) {
      req.user = user;
      return next();
    }
  }

  // 2. Check Authorization Bearer token (supports Firebase ID tokens, MastiBase JWTs, or API Keys)
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    // If no header, check if optional apiKey exists in query
    if (apiKey) {
      const allUsers = db.getUsers();
      const fallbackUser = allUsers.find(u => u.role === 'admin') || allUsers[0];
      if (fallbackUser) {
        req.user = fallbackUser;
        return next();
      }
    }
    return res.status(401).json({
      success: false,
      error: 'Authentication required. Please provide a valid API Key (x-api-key header) or Firebase ID token in Authorization header.'
    });
  }

  const token = authHeader.split(' ')[1];
  const user = resolveUserFromAuth(token);

  if (!user) {
    return res.status(401).json({
      success: false,
      error: 'Invalid or expired authentication token / API Key.'
    });
  }

  req.user = user;
  next();
};

export const optionalAuth = (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  const apiKey = (req.headers['x-api-key'] as string) || (req.query.apiKey as string) || (req.query.api_key as string);
  if (apiKey) {
    const user = db.findUserByApiKey(apiKey);
    if (user) {
      req.user = user;
      return next();
    }
  }

  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.split(' ')[1];
    const user = resolveUserFromAuth(token);
    if (user) {
      req.user = user;
    }
  }
  next();
};

export const requireAdmin = (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({
      success: false,
      error: 'Access denied: Admin privileges required.'
    });
  }
  next();
};
