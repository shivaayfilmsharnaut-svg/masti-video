import { db } from './db.js';

async function runTest() {
  console.log('🧪 Starting Monetization Config Route Integration Test...');
  
  try {
    // 1. Verify db config directly first
    const dbConfig = db.getAdMobConfig();
    if (!dbConfig) {
      throw new Error('Database AdMob config is missing.');
    }
    console.log('✅ Step 1: Database AdMob Config is present.');

    // 2. Query the live endpoint
    const url = 'http://localhost:3000/api/v1/social/monetization/config';
    console.log(`📡 Fetching endpoint: ${url}`);
    
    const res = await fetch(url);
    if (!res.ok) {
      throw new Error(`HTTP Error: ${res.status} ${res.statusText}`);
    }
    
    const body: any = await res.json();
    
    // 3. Assertions
    if (!body.success) {
      throw new Error('Response success is false.');
    }
    
    const data = body.data;
    if (!data) {
      throw new Error('Response data is missing.');
    }
    
    if (data.userId !== 'config') {
      throw new Error(`Expected userId "config", got "${data.userId}"`);
    }
    
    if (data.monetizationStatus !== 'eligible') {
      throw new Error(`Expected monetizationStatus "eligible", got "${data.monetizationStatus}"`);
    }
    
    const expectedIsEnabled = dbConfig.isMonetizationEnabled !== undefined ? Boolean(dbConfig.isMonetizationEnabled) : true;
    if (data.isEnabled !== expectedIsEnabled) {
      throw new Error(`Expected isEnabled ${expectedIsEnabled}, got "${data.isEnabled}"`);
    }
    
    const ads = data.ads;
    if (!ads) {
      throw new Error('Response data.ads is missing.');
    }
    
    const expectedKeys = [
      'globalAdsEnabled',
      'testAdsEnabled',
      'appId',
      'bannerAdUnitId',
      'interstitialAdUnitId',
      'rewardedAdUnitId'
    ];
    
    for (const key of expectedKeys) {
      if (ads[key] === undefined) {
        throw new Error(`Response data.ads is missing key: ${key}`);
      }
    }
    
    console.log('✅ Step 2: Response matches exact shape requested.');
    console.log('Response JSON:', JSON.stringify(body, null, 2));
    console.log('🎉 Integration Test PASSED successfully!');
    process.exit(0);
  } catch (err: any) {
    console.error('❌ Integration Test FAILED:', err.message);
    process.exit(1);
  }
}

runTest();
