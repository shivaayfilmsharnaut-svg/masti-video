const fs = require('fs');
const dbPath = 'data/mastibash_db.json';

if (fs.existsSync(dbPath)) {
  const data = JSON.parse(fs.readFileSync(dbPath, 'utf8'));

  // Keep ONLY the real user: rajkalikumar8789@gmail.com or id usr_rajkali_owner
  const realUsers = data.users.filter(u => 
    u.email === 'rajkalikumar8789@gmail.com' || 
    u.id === 'usr_rajkali_owner' ||
    u.name?.toLowerCase().includes('rajkali')
  );

  if (realUsers.length === 0 && data.users.length > 0) {
    // If exact match not found, keep the first user or create Rajkali
    realUsers.push(data.users[0]);
  }

  // Ensure Rajkali's email & name are correct
  if (realUsers.length > 0) {
    realUsers[0].email = 'rajkalikumar8789@gmail.com';
    realUsers[0].name = 'Rajkali Kumar';
    realUsers[0].followersCount = 0;
    realUsers[0].followingCount = 0;
    realUsers[0].totalLikes = 0;
  }

  data.users = realUsers;
  const validUserIds = new Set(data.users.map(u => u.id));

  // Filter media files belonging ONLY to real users
  data.media_files = data.media_files.filter(m => validUserIds.has(m.userId) || m.userEmail === 'rajkalikumar8789@gmail.com');
  data.media_files.forEach(m => {
    m.viewsCount = 0;
    m.likesCount = 0;
    m.commentsCount = 0;
    m.sharesCount = 0;
    m.savesCount = 0;
  });

  // Clear all fake/dummy interactions, notifications, chats, earnings
  data.likes = [];
  data.comments = [];
  data.saves = [];
  data.shares = [];
  data.follows = [];
  data.chats = [];
  data.notifications = [];
  data.payouts = [];

  // Reset API keys to only Rajkali's key
  data.api_keys = data.api_keys.filter(k => validUserIds.has(k.userId));

  fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
  console.log('Thoroughly cleaned DB: Only Rajkali remains, all fake earnings, notifications and metrics wiped to 0.');
} else {
  console.log('No DB file found');
}
