import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.js';
import { ToastProvider, useToast } from './components/Toast.js';
import { Navbar } from './components/Navbar.js';
import { Sidebar, ActiveTab } from './components/Sidebar.js';
import { DashboardOverview } from './components/DashboardOverview.js';
import { MediaLibrary } from './components/MediaLibrary.js';
import { UploadHub } from './components/UploadHub.js';
import { ConnectHub } from './components/ConnectHub.js';
import { AdminConsole } from './components/AdminConsole.js';
import { UserLoginDisplay } from './components/UserLoginDisplay.js';
import { WalletAndPayoutsHub } from './components/WalletAndPayoutsHub.js';
import { AdMobManager } from './components/AdMobManager.js';
import { WithdrawalRequests } from './components/WithdrawalRequests.js';
import { SocialChatModal } from './components/SocialChatModal.js';
import { VideoPlayerModal } from './components/VideoPlayerModal.js';
import { ImagePreviewModal } from './components/ImagePreviewModal.js';
import { AudioPlayerModal } from './components/AudioPlayerModal.js';
import { AuthModal } from './components/AuthModal.js';
import { PullToRefresh } from './components/PullToRefresh.js';
import { MediaFile } from './types.js';
import { api } from './services/api.js';

function MainLayout() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('overview');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'register'>('login');
  const [socialModalOpen, setSocialModalOpen] = useState(false);

  // Media Data State
  const [media, setMedia] = useState<MediaFile[]>([]);
  const [loadingMedia, setLoadingMedia] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Active Modals
  const [selectedVideo, setSelectedVideo] = useState<MediaFile | null>(null);
  const [selectedImage, setSelectedImage] = useState<MediaFile | null>(null);
  const [selectedAudio, setSelectedAudio] = useState<MediaFile | null>(null);

  const { isAuthenticated, user, isAdmin } = useAuth();
  const { showToast } = useToast();

  const fetchMedia = async (showSuccessToast = false) => {
    setLoadingMedia(true);
    setIsRefreshing(true);
    try {
      const res = await api.getMedia({ limit: 100, sort: 'newest' });
      if (res.success && res.data) {
        setMedia(res.data);
        if (showSuccessToast) {
          showToast('Media library refreshed successfully', 'success');
        }
      }
    } catch (err) {
      console.error('Error loading media:', err);
      if (showSuccessToast) {
        showToast('Failed to refresh media', 'error');
      }
    }
    setLoadingMedia(false);
    setIsRefreshing(false);
  };

  useEffect(() => {
    fetchMedia();
  }, [isAuthenticated]);

  const handleOpenAuth = (mode: 'login' | 'register' = 'login') => {
    setAuthModalMode(mode);
    setAuthModalOpen(true);
  };

  const handlePullRefresh = async () => {
    await fetchMedia(true);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Sidebar Navigation */}
      <Sidebar
        activeTab={activeTab}
        onTabChange={setActiveTab}
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        totalMediaCount={media.length}
      />

      {/* Main Workspace (Offset for desktop sidebar) */}
      <div className="lg:pl-64 flex flex-col min-h-screen">
        {/* Top Navbar */}
        <Navbar
          onOpenUpload={() => setActiveTab('upload')}
          onOpenAuth={handleOpenAuth}
          onToggleSidebar={() => setSidebarOpen(prev => !prev)}
          onNavigateToConnect={() => setActiveTab('connect')}
          onOpenSocial={() => setSocialModalOpen(true)}
          onRefresh={() => fetchMedia(true)}
          isRefreshing={isRefreshing}
        />


        {/* Dynamic Page Views Wrapped in Gesture-Based PullToRefresh */}
        <PullToRefresh onRefresh={handlePullRefresh}>
          <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto animate-in fade-in duration-150">
            {activeTab === 'overview' && (
              <DashboardOverview
                media={media}
                loading={loadingMedia}
                onNavigateToUpload={() => setActiveTab('upload')}
                onNavigateToLibrary={() => setActiveTab('library')}
                onNavigateToConnect={() => setActiveTab('connect')}
                onSelectVideo={(item) => setSelectedVideo(item)}
                onSelectImage={(item) => setSelectedImage(item)}
                onSelectAudio={(item) => setSelectedAudio(item)}
              />
            )}

            {(activeTab === 'connect' || activeTab === 'easyconnect' || activeTab === 'api') && <ConnectHub />}

            {activeTab === 'library' && (
              <MediaLibrary
                media={media}
                loading={loadingMedia}
                onRefresh={fetchMedia}
                onSelectVideo={(item) => setSelectedVideo(item)}
                onSelectImage={(item) => setSelectedImage(item)}
                onSelectAudio={(item) => setSelectedAudio(item)}
                onNavigateToUpload={() => setActiveTab('upload')}
              />
            )}

            {activeTab === 'upload' && (
              <UploadHub
                onUploadComplete={fetchMedia}
                onNavigateToLibrary={() => setActiveTab('library')}
              />
            )}

            {activeTab === 'social' && (
              <div className="space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-2xl bg-gradient-to-r from-indigo-950/60 via-slate-900 to-purple-950/40 border border-indigo-500/20 shadow-xl">
                  <div>
                    <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2.5">
                      <span>Masti Community & Live Chat</span>
                    </h2>
                    <p className="text-xs sm:text-sm text-slate-300 mt-1">
                      Real-time chats, followers, creator interactions, and live social network in Masti Bash.
                    </p>
                  </div>
                  <button
                    onClick={() => setSocialModalOpen(true)}
                    className="px-4 py-2.5 bg-gradient-to-r from-indigo-600 to-pink-600 hover:from-indigo-500 hover:to-pink-500 text-white text-xs font-bold rounded-xl shadow-lg transition-all"
                  >
                    Open Fullscreen Hub
                  </button>
                </div>

                {/* Inline preview or quick launcher */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div
                    onClick={() => setSocialModalOpen(true)}
                    className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-indigo-500/50 cursor-pointer transition-all hover:scale-[1.01]"
                  >
                    <div className="w-10 h-10 rounded-xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center font-bold mb-3">
                      💬
                    </div>
                    <h4 className="text-sm font-bold text-white">Live Realtime Chat</h4>
                    <p className="text-xs text-slate-400 mt-1">
                      Chat in real-time with creators and friends. All messages are securely saved.
                    </p>
                  </div>

                  <div
                    onClick={() => setSocialModalOpen(true)}
                    className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-pink-500/50 cursor-pointer transition-all hover:scale-[1.01]"
                  >
                    <div className="w-10 h-10 rounded-xl bg-pink-600/20 text-pink-400 flex items-center justify-center font-bold mb-3">
                      👥
                    </div>
                    <h4 className="text-sm font-bold text-white">Followers & Following</h4>
                    <p className="text-xs text-slate-400 mt-1">
                      Build your creator network, follow favorite channels and gain subscribers.
                    </p>
                  </div>

                  <div
                    onClick={() => setSocialModalOpen(true)}
                    className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-rose-500/50 cursor-pointer transition-all hover:scale-[1.01]"
                  >
                    <div className="w-10 h-10 rounded-xl bg-rose-600/20 text-rose-400 flex items-center justify-center font-bold mb-3">
                      ❤️
                    </div>
                    <h4 className="text-sm font-bold text-white">Likes, Comments & Shares</h4>
                    <p className="text-xs text-slate-400 mt-1">
                      Track your social engagement across all media uploads and files.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'wallet' && <WalletAndPayoutsHub />}

            {activeTab === 'admob' && <AdMobManager />}

            {activeTab === 'payouts' && <WithdrawalRequests />}

            {activeTab === 'account' && <UserLoginDisplay />}

            {activeTab === 'admin' && isAdmin && <AdminConsole />}
          </main>
        </PullToRefresh>
      </div>

      {/* Modals */}
      <SocialChatModal
        isOpen={socialModalOpen || activeTab === 'social'}
        onClose={() => {
          setSocialModalOpen(false);
          if (activeTab === 'social') {
            setActiveTab('library');
          }
        }}
      />

      <VideoPlayerModal
        media={selectedVideo}
        onClose={() => setSelectedVideo(null)}
        onMediaUpdated={(updated) => {
          setMedia(prev => prev.map(m => m.id === updated.id ? updated : m));
          if (selectedVideo?.id === updated.id) {
            setSelectedVideo(updated);
          }
        }}
      />

      <ImagePreviewModal
        media={selectedImage}
        onClose={() => setSelectedImage(null)}
      />

      <AudioPlayerModal
        media={selectedAudio}
        onClose={() => setSelectedAudio(null)}
        availableImages={media.filter(m => m.mediaType === 'image')}
        onMediaUpdated={(updated) => {
          setMedia(prev => prev.map(m => m.id === updated.id ? updated : m));
          if (selectedAudio?.id === updated.id) {
            setSelectedAudio(updated);
          }
        }}
      />

      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        initialMode={authModalMode}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <ToastProvider>
        <MainLayout />
      </ToastProvider>
    </AuthProvider>
  );
}
