import React, { useState, useRef } from 'react';
import { MediaFile } from '../types.js';
import { api, resolveMediaUrl, formatBytes } from '../services/api.js';
import { useToast } from './Toast.js';
import {
  X,
  Image as ImageIcon,
  UploadCloud,
  Check,
  Sparkles,
  Trash2,
  ExternalLink,
  Plus,
  Disc,
  Music,
  Film
} from 'lucide-react';

interface PosterSelectorModalProps {
  media: MediaFile | null;
  isOpen: boolean;
  onClose: () => void;
  onPosterUpdated: (updatedMedia: MediaFile) => void;
  availableImages: MediaFile[];
}

export const PosterSelectorModal: React.FC<PosterSelectorModalProps> = ({
  media,
  isOpen,
  onClose,
  onPosterUpdated,
  availableImages
}) => {
  const [selectedPosterUrl, setSelectedPosterUrl] = useState<string>(media?.posterUrl || '');
  const [activeTab, setActiveTab] = useState<'library' | 'upload' | 'url'>('library');
  const [customUrl, setCustomUrl] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [uploadPreview, setUploadPreview] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const { showToast } = useToast();

  React.useEffect(() => {
    if (media) {
      setSelectedPosterUrl(media.posterUrl || '');
      setCustomUrl(media.posterUrl || '');
      setUploadedFile(null);
      setUploadPreview(null);
    }
  }, [media, isOpen]);

  if (!isOpen || !media) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        showToast('error', 'Invalid File', 'Please select an image file (PNG, JPG, WEBP, AVIF).');
        return;
      }
      if (file.size > 25 * 1024 * 1024) {
        showToast('error', 'File Too Large', 'Poster image size must be under 25 MB.');
        return;
      }
      setUploadedFile(file);
      const url = URL.createObjectURL(file);
      setUploadPreview(url);
      setSelectedPosterUrl(url);
    }
  };

  const handleSelectLibraryImage = (img: MediaFile) => {
    setSelectedPosterUrl(img.fileUrl);
    setUploadedFile(null);
    setUploadPreview(null);
  };

  const handleApplyUrl = () => {
    if (customUrl.trim()) {
      setSelectedPosterUrl(customUrl.trim());
      setUploadedFile(null);
      setUploadPreview(null);
      showToast('info', 'Poster URL Selected', 'Click "Save Official Poster" to apply.');
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      let res;
      if (uploadedFile) {
        // Upload poster file and attach
        res = await api.setMediaPoster(media.id, uploadedFile);
      } else if (selectedPosterUrl) {
        // Set selected URL (from library or custom URL)
        res = await api.setMediaPoster(media.id, selectedPosterUrl);
      } else {
        // Clear poster
        res = await api.setMediaPoster(media.id, null);
      }

      if (res.success && res.data) {
        showToast('success', 'Official Poster Updated', `Cover poster set for "${media.originalName}".`);
        onPosterUpdated(res.data);
        onClose();
      } else {
        showToast('error', 'Update Failed', res.error || 'Could not save official poster.');
      }
    } catch (err: any) {
      showToast('error', 'Update Error', err.message || 'Failed to update poster.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleRemovePoster = async () => {
    setIsSaving(true);
    try {
      const res = await api.setMediaPoster(media.id, null);
      if (res.success && res.data) {
        showToast('info', 'Poster Removed', 'Official poster removed from this track.');
        setSelectedPosterUrl('');
        onPosterUpdated(res.data);
        onClose();
      }
    } catch (err: any) {
      showToast('error', 'Error', err.message);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-xl animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-2xl flex flex-col shadow-2xl overflow-hidden max-h-[90vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-rose-500 flex items-center justify-center text-white shrink-0 shadow-lg shadow-amber-500/20">
              {media.mediaType === 'audio' ? <Music className="w-5 h-5" /> : <Film className="w-5 h-5" />}
            </div>
            <div className="min-w-0">
              <h2 className="text-sm sm:text-base font-bold text-white truncate">
                Official Terminal Poster & Cover Art
              </h2>
              <p className="text-xs text-slate-400 truncate">
                Select or upload official cover image for <span className="text-slate-200 font-medium">{media.originalName}</span>
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5">
          {/* Active Preview Banner */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row items-center gap-4">
            <div className="relative w-24 h-24 sm:w-28 sm:h-28 rounded-xl overflow-hidden bg-slate-900 border border-slate-700 flex items-center justify-center shrink-0 shadow-md">
              {selectedPosterUrl ? (
                <img
                  src={resolveMediaUrl(selectedPosterUrl)}
                  alt="Poster Preview"
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="flex flex-col items-center justify-center text-slate-500 p-2 text-center">
                  <ImageIcon className="w-8 h-8 mb-1 text-slate-600" />
                  <span className="text-[10px]">No Poster Set</span>
                </div>
              )}
              {selectedPosterUrl && (
                <span className="absolute bottom-1 right-1 px-1.5 py-0.5 rounded bg-emerald-600 text-white text-[9px] font-bold uppercase shadow-sm">
                  Active
                </span>
              )}
            </div>

            <div className="flex-1 min-w-0 text-center sm:text-left space-y-1">
              <div className="flex items-center justify-center sm:justify-start gap-2">
                <span className="text-xs font-bold text-white uppercase tracking-wide">
                  {selectedPosterUrl ? 'Selected Official Poster' : 'Default Generic Artwork'}
                </span>
                <span className="px-2 py-0.5 rounded-full bg-amber-500/20 border border-amber-500/30 text-amber-300 text-[10px] font-mono font-semibold">
                  {media.mediaType.toUpperCase()}
                </span>
              </div>
              <p className="text-xs text-slate-400">
                {selectedPosterUrl
                  ? 'This image will be displayed in the player, feed cards, thumbnails, and HTML embeds.'
                  : 'No custom thumbnail attached yet. Pick one from your library or upload an official poster.'}
              </p>
              {selectedPosterUrl && (
                <div className="pt-1 flex items-center justify-center sm:justify-start gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedPosterUrl('');
                      setUploadedFile(null);
                      setUploadPreview(null);
                    }}
                    className="text-xs text-rose-400 hover:text-rose-300 flex items-center gap-1 font-medium"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Clear Selection</span>
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Tab Navigation */}
          <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
            <button
              type="button"
              onClick={() => setActiveTab('library')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 ${
                activeTab === 'library'
                  ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <ImageIcon className="w-3.5 h-3.5" />
              <span>Choose from Library ({availableImages.length})</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('upload')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 ${
                activeTab === 'upload'
                  ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <UploadCloud className="w-3.5 h-3.5" />
              <span>Upload New Poster</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('url')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 ${
                activeTab === 'url'
                  ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>Direct URL</span>
            </button>
          </div>

          {/* Tab 1: Library Images Grid */}
          {activeTab === 'library' && (
            <div className="space-y-2">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                Select an image from your Cloud Media Library
              </span>
              {availableImages.length === 0 ? (
                <div className="p-8 text-center rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                  <ImageIcon className="w-8 h-8 text-slate-600 mx-auto" />
                  <p className="text-xs text-slate-400">No images found in your media library.</p>
                  <button
                    type="button"
                    onClick={() => setActiveTab('upload')}
                    className="text-xs text-amber-400 hover:text-amber-300 font-semibold underline"
                  >
                    Upload a new poster image instead
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-3 sm:grid-cols-4 gap-2.5 max-h-64 overflow-y-auto p-1">
                  {availableImages.map((img) => {
                    const isChosen = selectedPosterUrl === img.fileUrl;
                    return (
                      <button
                        key={img.id}
                        type="button"
                        onClick={() => handleSelectLibraryImage(img)}
                        className={`relative group aspect-square rounded-xl overflow-hidden border transition-all text-left ${
                          isChosen
                            ? 'border-amber-500 ring-2 ring-amber-500/50 shadow-lg'
                            : 'border-slate-800 hover:border-slate-700'
                        }`}
                      >
                        <img
                          src={resolveMediaUrl(img.fileUrl)}
                          alt={img.originalName}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                        />
                        {isChosen && (
                          <div className="absolute inset-0 bg-amber-500/20 flex items-center justify-center">
                            <div className="w-6 h-6 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center shadow">
                              <Check className="w-3.5 h-3.5 stroke-[3]" />
                            </div>
                          </div>
                        )}
                        <div className="absolute bottom-0 inset-x-0 bg-slate-950/80 p-1 truncate text-[9px] text-slate-300">
                          {img.originalName}
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* Tab 2: Upload New Poster */}
          {activeTab === 'upload' && (
            <div className="space-y-3">
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileChange}
                className="hidden"
              />
              <div
                onClick={() => fileInputRef.current?.click()}
                className="p-8 border-2 border-dashed border-slate-700 hover:border-amber-500 rounded-xl bg-slate-950/50 hover:bg-slate-950 cursor-pointer text-center space-y-3 transition-colors"
              >
                <div className="w-12 h-12 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20 flex items-center justify-center mx-auto">
                  <UploadCloud className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-xs font-semibold text-white block">
                    Click to browse poster image from your device
                  </span>
                  <span className="text-[11px] text-slate-400 mt-0.5 block">
                    Supports JPG, PNG, WEBP, AVIF up to 25 MB (recommended 1:1 or 16:9 ratio)
                  </span>
                </div>
              </div>

              {uploadedFile && (
                <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-amber-500/40">
                  <div className="flex items-center gap-3 min-w-0">
                    {uploadPreview && (
                      <img src={uploadPreview} alt="Preview" className="w-10 h-10 rounded-lg object-cover" />
                    )}
                    <div className="min-w-0">
                      <span className="text-xs font-semibold text-white truncate block">{uploadedFile.name}</span>
                      <span className="text-[10px] text-slate-400 font-mono">{formatBytes(uploadedFile.size)}</span>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 text-[10px] font-bold uppercase">
                    Ready to Attach
                  </span>
                </div>
              )}
            </div>
          )}

          {/* Tab 3: Direct URL */}
          {activeTab === 'url' && (
            <div className="space-y-3">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                Paste Image Web Address
              </span>
              <div className="flex items-center gap-2">
                <input
                  type="url"
                  placeholder="https://example.com/poster_cover.jpg"
                  value={customUrl}
                  onChange={(e) => setCustomUrl(e.target.value)}
                  className="flex-1 px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                />
                <button
                  type="button"
                  onClick={handleApplyUrl}
                  className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-xl transition-colors"
                >
                  Apply
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/80 flex items-center justify-between gap-3">
          {media.posterUrl ? (
            <button
              type="button"
              onClick={handleRemovePoster}
              disabled={isSaving}
              className="px-3.5 py-2 rounded-xl text-xs font-semibold text-rose-400 hover:bg-rose-950/40 border border-rose-900/40 transition-colors"
            >
              Remove Poster
            </button>
          ) : (
            <div />
          )}

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              disabled={isSaving}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              Cancel
            </button>

            <button
              type="button"
              onClick={handleSave}
              disabled={isSaving}
              className="px-5 py-2 bg-gradient-to-r from-amber-500 to-rose-500 hover:from-amber-400 hover:to-rose-400 text-slate-950 font-bold text-xs rounded-xl shadow-lg shadow-amber-500/20 transition-all flex items-center gap-2 disabled:opacity-50"
            >
              {isSaving ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-slate-950/40 border-t-slate-950 rounded-full animate-spin" />
                  <span>Saving Poster...</span>
                </>
              ) : (
                <>
                  <Check className="w-4 h-4" />
                  <span>Save Official Poster</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
