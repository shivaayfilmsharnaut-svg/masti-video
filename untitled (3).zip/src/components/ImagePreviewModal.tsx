import React, { useState } from 'react';
import { MediaFile } from '../types.js';
import { useToast } from './Toast.js';
import { formatBytes, formatDate, resolveMediaUrl } from '../services/api.js';
import { X, Copy, Download, Code, Check, ImageIcon, Layers, Sparkles, ZoomIn, ZoomOut, RotateCcw } from 'lucide-react';

interface ImagePreviewModalProps {
  media: MediaFile | null;
  onClose: () => void;
}

export const ImagePreviewModal: React.FC<ImagePreviewModalProps> = ({ media, onClose }) => {
  const [zoom, setZoom] = useState(1);
  const [copiedType, setCopiedType] = useState<string | null>(null);
  const { showToast } = useToast();

  if (!media) return null;

  const handleZoomIn = () => setZoom(prev => Math.min(prev + 0.25, 3));
  const handleZoomOut = () => setZoom(prev => Math.max(prev - 0.25, 0.5));
  const handleResetZoom = () => setZoom(1);

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedType(label);
    showToast('success', 'Copied to Clipboard', label);
    setTimeout(() => setCopiedType(null), 2000);
  };

  const resolvedUrl = resolveMediaUrl(media.fileUrl);
  const absolutePublicUrl = typeof window !== 'undefined' 
    ? `${window.location.origin}${resolvedUrl}` 
    : resolvedUrl;

  const embedHtml = `<img src="${absolutePublicUrl}" alt="${media.originalName}" loading="lazy" />`;
  const markdownEmbed = `![${media.originalName}](${absolutePublicUrl})`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/90 backdrop-blur-xl animate-in fade-in duration-200">
      <div className="relative w-full max-w-5xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/90 shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <div className="p-2 rounded-xl bg-cyan-600/20 text-cyan-400 border border-cyan-500/30 shrink-0">
              <ImageIcon className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <h3 className="text-base font-semibold text-white truncate">{media.originalName}</h3>
              <p className="text-xs text-slate-400">
                {formatBytes(media.fileSize)} • Uploaded {formatDate(media.createdAt)}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto grid grid-cols-1 lg:grid-cols-3 gap-6 p-6">
          {/* Image Canvas Column */}
          <div className="lg:col-span-2 flex flex-col items-center justify-center bg-slate-950 rounded-xl overflow-hidden border border-slate-800 relative min-h-[350px] p-4">
            {/* Zoom Controls */}
            <div className="absolute top-4 right-4 z-10 flex items-center gap-1.5 p-1 bg-slate-900/90 backdrop-blur-md rounded-xl border border-slate-800 shadow-lg">
              <button
                onClick={handleZoomOut}
                className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
                title="Zoom Out"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <span className="text-[11px] font-mono font-medium text-slate-300 px-1">
                {Math.round(zoom * 100)}%
              </span>
              <button
                onClick={handleZoomIn}
                className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
                title="Zoom In"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
              <button
                onClick={handleResetZoom}
                className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
                title="Reset Zoom"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="overflow-auto max-h-[480px] w-full flex items-center justify-center">
              <img
                src={resolvedUrl}
                alt={media.originalName}
                style={{ transform: `scale(${zoom})`, transformOrigin: 'center' }}
                className="max-h-[450px] max-w-full object-contain rounded-lg transition-transform duration-150"
              />
            </div>
          </div>

          {/* Details & Delivery Sidebar */}
          <div className="flex flex-col gap-4">
            {/* Direct URL Box */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span className="font-semibold uppercase tracking-wider text-[11px] text-cyan-400 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" /> Public CDN Image URL
                </span>
                <span className="text-slate-500">Masti CDN</span>
              </div>
              <div className="flex items-center gap-2 bg-slate-900 p-2 rounded-lg border border-slate-800 font-mono text-xs text-slate-300 break-all">
                <span className="truncate flex-1">{absolutePublicUrl}</span>
                <button
                  onClick={() => handleCopy(absolutePublicUrl, 'Direct Image URL')}
                  className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-md transition-colors shrink-0"
                  title="Copy Direct URL"
                >
                  {copiedType === 'Direct Image URL' ? (
                    <Check className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                </button>
              </div>
            </div>

            {/* Quick Embed Actions */}
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => handleCopy(embedHtml, 'HTML Image Tag')}
                className="flex items-center justify-center gap-2 p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold border border-slate-700 transition-all"
              >
                <Code className="w-3.5 h-3.5 text-cyan-400" />
                <span>Copy HTML</span>
              </button>

              <button
                onClick={() => handleCopy(markdownEmbed, 'Markdown Tag')}
                className="flex items-center justify-center gap-2 p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold border border-slate-700 transition-all"
              >
                <Code className="w-3.5 h-3.5 text-indigo-400" />
                <span>Markdown</span>
              </button>
            </div>

            <a
              href={media.fileUrl}
              download={media.originalName}
              target="_blank"
              rel="noreferrer"
              className="w-full flex items-center justify-center gap-2 p-2.5 bg-cyan-600/20 hover:bg-cyan-600/30 text-cyan-300 border border-cyan-500/30 rounded-xl text-xs font-semibold transition-all"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download Image</span>
            </a>

            {/* Metadata Table */}
            <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800/80 space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5" /> Asset Specs
              </h4>
              <div className="grid grid-cols-2 gap-2.5 text-xs">
                <div className="p-2 bg-slate-900 rounded-lg border border-slate-800/80">
                  <span className="text-slate-500 block text-[10px] uppercase">Format</span>
                  <span className="font-semibold text-slate-200">{media.mimeType || 'image/jpeg'}</span>
                </div>
                <div className="p-2 bg-slate-900 rounded-lg border border-slate-800/80">
                  <span className="text-slate-500 block text-[10px] uppercase">File Size</span>
                  <span className="font-semibold text-slate-200">{formatBytes(media.fileSize)}</span>
                </div>
                <div className="p-2 bg-slate-900 rounded-lg border border-slate-800/80">
                  <span className="text-slate-500 block text-[10px] uppercase">Folder</span>
                  <span className="font-semibold text-slate-200 capitalize">{media.folder || 'general'}</span>
                </div>
                <div className="p-2 bg-slate-900 rounded-lg border border-slate-800/80">
                  <span className="text-slate-500 block text-[10px] uppercase">Asset ID</span>
                  <span className="font-mono text-[11px] text-slate-300 truncate block">{media.id}</span>
                </div>
              </div>

              {/* Tags */}
              {media.tags && media.tags.length > 0 && (
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase mb-1.5">Tags</span>
                  <div className="flex flex-wrap gap-1.5">
                    {media.tags.map((t, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-0.5 rounded-md bg-cyan-950/80 text-cyan-300 border border-cyan-800/50 text-[11px]"
                      >
                        #{t}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
