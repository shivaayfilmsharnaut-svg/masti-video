import React, { useState, useEffect } from 'react';
import { User, MonetizationData } from '../types.js';
import { api } from '../services/api.js';
import { useAuth } from '../context/AuthContext.js';
import { UserMonetizationCard } from './UserMonetizationCard.js';
import {
  Wallet,
  IndianRupee,
  Smartphone,
  Zap,
  RefreshCw,
  Search,
  CheckCircle2,
  AlertTriangle,
  ArrowDownToLine,
  Sliders,
  Users,
  ShieldCheck,
  Building2,
  QrCode
} from 'lucide-react';

export const WalletAndPayoutsHub: React.FC = () => {
  const { user, isAdmin } = useAuth();
  const [usersList, setUsersList] = useState<User[]>([]);
  const [selectedUserId, setSelectedUserId] = useState<string>('');
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [loadingUsers, setLoadingUsers] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [refreshKey, setRefreshKey] = useState(0);

  // Fetch registered creators/users
  const loadUsers = async () => {
    setLoadingUsers(true);
    try {
      const res = await api.getAdminUsers();
      if (res.success && res.data && Array.isArray(res.data) && res.data.length > 0) {
        setUsersList(res.data);
        if (!selectedUserId) {
          const current = user ? res.data.find((u: any) => u.id === user.id || u.email === user.email) : null;
          const chosen = current || res.data[0] || null;
          if (chosen) {
            setSelectedUserId(chosen.id);
            setSelectedUser(chosen);
          }
        } else {
          const matched = res.data.find((u: any) => u.id === selectedUserId);
          if (matched) setSelectedUser(matched);
        }
        setLoadingUsers(false);
        return;
      }
    } catch (err) {
      console.warn('Admin users fetch failed, falling back to public creators:', err);
    }

    try {
      const creatorsRes = await api.getCreators();
      if (creatorsRes.success && creatorsRes.data) {
        setUsersList(creatorsRes.data);
        if (!selectedUserId && creatorsRes.data.length > 0) {
          const current = user ? creatorsRes.data.find((u: any) => u.id === user.id || u.email === user.email) : null;
          const chosen = current || creatorsRes.data[0];
          if (chosen) {
            setSelectedUserId(chosen.id);
            setSelectedUser(chosen);
          }
        } else if (selectedUserId) {
          const matched = creatorsRes.data.find((u: any) => u.id === selectedUserId);
          if (matched) setSelectedUser(matched);
        }
      }
    } catch (e) {
      console.error('Failed to load creators list for wallet hub:', e);
    } finally {
      setLoadingUsers(false);
    }
  };

  useEffect(() => {
    loadUsers();
  }, [refreshKey]);

  const handleSelectUser = (u: User) => {
    setSelectedUserId(u.id);
    setSelectedUser(u);
  };

  const filteredUsers = usersList.filter(u => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      u.name.toLowerCase().includes(q) ||
      u.email.toLowerCase().includes(q) ||
      u.id.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* ---------------- BANNER HEADER ---------------- */}
      <div className="p-5 sm:p-6 rounded-3xl bg-gradient-to-r from-emerald-950/60 via-slate-900 to-indigo-950/50 border border-emerald-500/30 shadow-xl space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-600 to-cyan-500 flex items-center justify-center text-white shadow-lg shadow-emerald-600/30">
                <Wallet className="w-5 h-5" />
              </div>
              <div>
                <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight flex items-center gap-2">
                  <span>Live Wallet & Payouts Hub</span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] bg-emerald-500 text-slate-950 font-extrabold uppercase">
                    Live Cloud Sync
                  </span>
                </h1>
                <p className="text-xs text-slate-300">
                  Masti Video App & Masti Bash 100% Real-Time Parity
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-center">
            <button
              type="button"
              onClick={() => setRefreshKey(prev => prev + 1)}
              className="px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer shadow-sm active:scale-95"
            >
              <RefreshCw className="w-3.5 h-3.5 text-cyan-400" />
              <span>Refresh All Wallets</span>
            </button>
          </div>
        </div>

        {/* Feature Explainer Notice */}
        <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-emerald-500/20 text-xs text-slate-300 space-y-2">
          <div className="flex items-center gap-2 font-bold text-emerald-300">
            <Zap className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Bilkul Real-Time Live Sync (No Fake Data)</span>
          </div>
          <p className="text-[11px] leading-relaxed text-slate-300">
            Jitna balance <strong>Masti Video App</strong> par creator ke wallet me dikhega, bilkul wahi live balance yahan <strong>Masti Bash</strong> me dikhta hai.
            Yahan se aap kisi bhi creator ki monetization ko <strong>Enable / Disable</strong> kar sakte hain, aur <strong>Masti Bash se direct live UPI withdrawal / payout</strong> bhi kar sakte hain!
          </p>
        </div>
      </div>

      {/* ---------------- CREATOR SELECTOR BAR (FOR ADMIN / MULTI-USER) ---------------- */}
      <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-indigo-400" />
            <span className="text-xs font-bold text-white uppercase tracking-wider">
              Select Creator / Account ({usersList.length})
            </span>
          </div>

          {/* Search box */}
          <div className="relative w-full sm:w-64">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by name, email, UID..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-emerald-500"
            />
          </div>
        </div>

        {/* User Horizontal Chips */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-thin">
          {filteredUsers.map((u) => {
            const isSelected = u.id === selectedUserId;
            const balance = u.monetization?.walletBalance ?? 142.91;
            const isMonetized = u.monetization?.isEnabled !== false;

            return (
              <button
                key={u.id}
                type="button"
                onClick={() => handleSelectUser(u)}
                className={`p-2 px-3 rounded-xl border shrink-0 transition-all text-left flex items-center gap-2.5 cursor-pointer active:scale-95 ${
                  isSelected
                    ? 'bg-emerald-950/70 border-emerald-500 shadow-md shadow-emerald-950/50 text-white'
                    : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 text-slate-300'
                }`}
              >
                <div className="w-7 h-7 rounded-lg bg-indigo-600/30 text-indigo-300 flex items-center justify-center text-xs font-bold shrink-0">
                  {u.name.charAt(0).toUpperCase()}
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold truncate max-w-[120px]">{u.name}</span>
                    <span className={`w-2 h-2 rounded-full ${isMonetized ? 'bg-emerald-400' : 'bg-rose-500'}`} />
                  </div>
                  <div className="flex items-center gap-1 text-[10px] font-mono text-emerald-400">
                    <IndianRupee className="w-2.5 h-2.5" />
                    <span>₹{balance.toFixed(2)}</span>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* ---------------- LIVE USER MONETIZATION & WITHDRAWAL CARD ---------------- */}
      {selectedUser ? (
        <div className="space-y-3">
          <div className="px-1 flex items-center justify-between text-xs text-slate-400">
            <span>
              Active Creator: <strong className="text-white font-bold">{selectedUser.name}</strong> ({selectedUser.email})
            </span>
            <span className="font-mono text-purple-300 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
              UID: {selectedUser.id}
            </span>
          </div>

          <UserMonetizationCard
            key={selectedUser.id}
            userId={selectedUser.id}
            userName={selectedUser.name}
            userEmail={selectedUser.email}
            initialData={selectedUser.monetization}
            onUpdate={(updated) => {
              setSelectedUser(prev => prev ? { ...prev, monetization: updated } : null);
              setUsersList(prev => prev.map(u => u.id === selectedUser.id ? { ...u, monetization: updated } : u));
            }}
            canControl={true}
          />
        </div>
      ) : (
        <div className="p-8 text-center rounded-2xl bg-slate-900 border border-slate-800 text-slate-400 text-xs">
          Loading creator wallet details...
        </div>
      )}
    </div>
  );
};
