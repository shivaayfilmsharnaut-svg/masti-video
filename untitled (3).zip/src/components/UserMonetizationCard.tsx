import React, { useState, useEffect, useRef } from 'react';
import { MonetizationData, PayoutTransaction } from '../types.js';
import { api, formatDate } from '../services/api.js';
import { useToast } from './Toast.js';
import {
  Wallet,
  TrendingUp,
  Sparkles,
  IndianRupee,
  CheckCircle2,
  XCircle,
  Sliders,
  Save,
  ShieldCheck,
  AlertTriangle,
  RefreshCw,
  Smartphone,
  Lock,
  Unlock,
  ArrowDownToLine,
  Check,
  History,
  Send,
  Zap,
  Building2,
  QrCode
} from 'lucide-react';

interface UserMonetizationCardProps {
  userId: string;
  userName?: string;
  userEmail?: string;
  initialData?: MonetizationData | null;
  onUpdate?: (updated: MonetizationData) => void;
  canControl?: boolean;
}

export const UserMonetizationCard: React.FC<UserMonetizationCardProps> = ({
  userId,
  userName = 'Creator',
  userEmail,
  initialData,
  onUpdate,
  canControl = true
}) => {
  const [data, setData] = useState<MonetizationData | null>(initialData || null);
  const [loading, setLoading] = useState(!initialData);
  const [refreshing, setRefreshing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [withdrawing, setWithdrawing] = useState(false);
  const [showWithdrawDrawer, setShowWithdrawDrawer] = useState(false);
  const [lastSyncedTime, setLastSyncedTime] = useState<string>('Just now');

  // Withdrawal form state
  const [withdrawAmount, setWithdrawAmount] = useState<string>('');
  const [withdrawMethod, setWithdrawMethod] = useState<'upi' | 'bank_transfer' | 'paytm'>('upi');
  const [withdrawAccountInfo, setWithdrawAccountInfo] = useState<string>('');
  const [withdrawSuccessInfo, setWithdrawSuccessInfo] = useState<PayoutTransaction | null>(null);

  // Editable fields for rates/balance adjuster
  const [showEditForm, setShowEditForm] = useState(false);
  const [editBalance, setEditBalance] = useState<string>('');
  const [editEarnings, setEditEarnings] = useState<string>('');
  const [editRpm, setEditRpm] = useState<string>('1.00');
  const [editCpm, setEditCpm] = useState<string>('1.00');
  const [editUpiId, setEditUpiId] = useState<string>('');
  const [autoCalc, setAutoCalc] = useState<boolean>(true);

  const { showToast } = useToast();
  const pollTimerRef = useRef<any>(null);

  // Sync edit fields when data changes (only when form is closed)
  useEffect(() => {
    if (data && !showEditForm) {
      setEditBalance(String(data.walletBalance || 0));
      setEditEarnings(String(data.totalEarnings || 0));
      setEditRpm(String(data.rpm || '1.00'));
      setEditCpm(String(data.cpm || '1.00'));
      setEditUpiId(data.bankDetails?.upiId || '');
      setAutoCalc(!data.hasWalletOverride && !data.hasEarningsOverride);
    }
  }, [data, showEditForm]);

  const populateFields = (item: MonetizationData) => {
    const fallbackUpi = item.bankDetails?.upiId || (userEmail ? `${userEmail.split('@')[0]}@oksbi` : 'creator@oksbi');
    if (!withdrawAccountInfo) {
      setWithdrawAccountInfo(fallbackUpi);
    }
  };

  // Real-time fetch from Masti Video / Masti Bash shared backend
  const fetchLiveMonetization = async (silent: boolean = false) => {
    if (!userId) return;
    if (!silent) setRefreshing(true);
    try {
      const res = await api.getMonetization(userId);
      if (res.success && res.data) {
        setData(res.data);
        populateFields(res.data);
        setLastSyncedTime(new Date().toLocaleTimeString());
        if (onUpdate) onUpdate(res.data);
      }
    } catch (err) {
      console.error('Failed to load live monetization:', err);
    } finally {
      if (!silent) {
        setRefreshing(false);
        setLoading(false);
      }
    }
  };

  // Initial load + periodic polling for real-time live wallet sync
  useEffect(() => {
    if (initialData) {
      setData(initialData);
      populateFields(initialData);
      setLoading(false);
    } else {
      fetchLiveMonetization(false);
    }

    // Auto-poll every 6 seconds to keep wallet balance 100% in sync with Masti Video app
    pollTimerRef.current = setInterval(() => {
      fetchLiveMonetization(true);
    }, 6000);

    return () => {
      if (pollTimerRef.current) clearInterval(pollTimerRef.current);
    };
  }, [userId]);

  // Handle Save Custom Settings
  const handleSaveCustomSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const res = await api.updateMonetizationControl(userId, {
        walletBalance: autoCalc ? null : (parseFloat(editBalance) || 0),
        totalEarnings: autoCalc ? null : (parseFloat(editEarnings) || 0),
        rpm: parseFloat(editRpm) || 0,
        cpm: parseFloat(editCpm) || 0,
        upiId: editUpiId
      } as any);

      if (res.success && res.data) {
        setData(res.data);
        showToast('success', 'Settings Saved', 'Monetization settings updated successfully.');
        setShowEditForm(false);
        if (onUpdate) onUpdate(res.data);
      } else {
        showToast('error', 'Update Failed', res.error || 'Could not update.');
      }
    } catch (err: any) {
      showToast('error', 'Error', err.message || 'Something went wrong.');
    } finally {
      setSaving(false);
    }
  };

  // Handle Enable / Disable Toggle
  const handleToggleMonetization = async (enable: boolean) => {
    setSaving(true);
    try {
      const res = await api.updateMonetizationControl(userId, {
        isEnabled: enable,
        monetizationStatus: enable ? 'active' : 'disabled'
      });

      if (res.success && res.data) {
        setData(res.data);
        populateFields(res.data);
        showToast(
          'success',
          enable ? 'Monetization Activated' : 'Monetization Disabled',
          enable
            ? `Monetization for ${userName} is now ACTIVE on Masti Video App.`
            : `Monetization for ${userName} is now DISABLED on Masti Video App.`
        );
        if (onUpdate) onUpdate(res.data);
      } else {
        showToast('error', 'Update Failed', res.error || 'Could not update monetization status.');
      }
    } catch (err: any) {
      showToast('error', 'Error', err.message || 'Something went wrong.');
    } finally {
      setSaving(false);
    }
  };

  // Handle Withdrawal Request from Masti Bash
  const handleProcessWithdrawal = async (e: React.FormEvent) => {
    e.preventDefault();
    const amountNum = parseFloat(withdrawAmount);

    if (isNaN(amountNum) || amountNum < 1) {
      showToast('error', 'Invalid Amount', 'Please enter a valid withdrawal amount (minimum ₹1.00).');
      return;
    }

    const currentBalance = data?.walletBalance || 0;
    if (amountNum > currentBalance) {
      showToast('error', 'Insufficient Balance', `Available wallet balance is ₹${currentBalance.toFixed(2)}.`);
      return;
    }

    if (!withdrawAccountInfo.trim()) {
      showToast('error', 'Account Required', 'Please provide a valid UPI ID (e.g. name@oksbi) or Bank Account.');
      return;
    }

    setWithdrawing(true);
    setWithdrawSuccessInfo(null);
    try {
      const res = await api.requestPayout({
        userId,
        amount: amountNum,
        method: withdrawMethod,
        accountInfo: withdrawAccountInfo.trim()
      });

      if (res.success && res.data) {
        setWithdrawSuccessInfo(res.data);
        setWithdrawAmount('');
        showToast('success', 'Withdrawal Processed', `₹${amountNum.toFixed(2)} successfully sent to ${withdrawAccountInfo}!`);

        // If backend returned updated monetization data, use it; otherwise refresh
        if (res.monetization) {
          setData(res.monetization);
          populateFields(res.monetization);
          if (onUpdate) onUpdate(res.monetization);
        } else {
          await fetchLiveMonetization(false);
        }
      } else {
        showToast('error', 'Withdrawal Failed', res.error || 'Could not process payout.');
      }
    } catch (err: any) {
      showToast('error', 'Error', err.message || 'Withdrawal processing failed.');
    } finally {
      setWithdrawing(false);
    }
  };

  const isMonetizationActive = data ? (data.isEnabled !== false && data.monetizationStatus !== 'disabled') : true;
  const currentWalletBalance = data?.walletBalance ?? 0;

  if (loading) {
    return (
      <div className="p-6 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-center gap-3 text-xs text-slate-400">
        <div className="w-5 h-5 border-2 border-emerald-500/40 border-t-emerald-400 rounded-full animate-spin" />
        <span>Syncing live monetization data from Masti Video App...</span>
      </div>
    );
  }

  return (
    <div id={`monetize-card-${userId}`} className="space-y-3.5">
      {/* ---------------- LIVE STATUS & SYNC HEADER BAR ---------------- */}
      <div className="flex items-center justify-between px-3 py-2 rounded-xl bg-slate-950/90 border border-slate-800 text-[11px]">
        <div className="flex items-center gap-2">
          <span className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
          </span>
          <span className="font-bold text-white uppercase tracking-wider flex items-center gap-1">
            <Smartphone className="w-3.5 h-3.5 text-cyan-400" />
            <span>Masti Video App • Live Sync Active</span>
          </span>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[10px] text-slate-400 hidden sm:inline">
            Synced: <span className="font-mono text-slate-300">{lastSyncedTime}</span>
          </span>
          <button
            type="button"
            onClick={() => fetchLiveMonetization(false)}
            disabled={refreshing}
            className="p-1 px-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700/60 text-slate-300 hover:text-white transition-all flex items-center gap-1 text-[10px] font-semibold cursor-pointer active:scale-95"
            title="Fetch latest wallet balance from server"
          >
            <RefreshCw className={`w-3 h-3 text-cyan-400 ${refreshing ? 'animate-spin' : ''}`} />
            <span>{refreshing ? 'Syncing...' : 'Sync Now'}</span>
          </button>
        </div>
      </div>

      {/* ---------------- PRIMARY CONTROL CARD ---------------- */}
      <div className={`p-4 rounded-2xl border transition-all space-y-3.5 ${
        isMonetizationActive
          ? 'bg-gradient-to-br from-emerald-950/40 via-slate-950 to-slate-900 border-emerald-500/40 shadow-lg shadow-emerald-950/20'
          : 'bg-gradient-to-br from-rose-950/40 via-slate-950 to-slate-900 border-rose-500/40 shadow-lg shadow-rose-950/20'
      }`}>
        {/* Title & Status Badge */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
              isMonetizationActive
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                : 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
            }`}>
              {isMonetizationActive ? <Unlock className="w-5 h-5" /> : <Lock className="w-5 h-5" />}
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-sm sm:text-base font-bold text-white tracking-wide">
                  Creator Monetization
                </span>
                <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-extrabold uppercase tracking-wider ${
                  isMonetizationActive
                    ? 'bg-emerald-500 text-slate-950 shadow-sm'
                    : 'bg-rose-500 text-white shadow-sm'
                }`}>
                  {isMonetizationActive ? 'Active' : 'Disabled'}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-mono mt-0.5">
                User ID: {userId}
              </p>
            </div>
          </div>
        </div>

        {/* Informative Status Message */}
        <div className={`p-3 rounded-xl text-xs flex items-start gap-2.5 ${
          isMonetizationActive
            ? 'bg-emerald-950/60 border border-emerald-800/40 text-emerald-200'
            : 'bg-rose-950/60 border border-rose-800/40 text-rose-200'
        }`}>
          {isMonetizationActive ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
          ) : (
            <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
          )}
          <div className="text-[11px] leading-relaxed">
            {isMonetizationActive ? (
              <span>
                <strong className="font-bold text-emerald-300">Live Monetization Active:</strong> Video views on Masti Video App earn real ad revenue. Payouts can be withdrawn anytime to UPI.
              </span>
            ) : (
              <span>
                <strong className="font-bold text-rose-300">Monetization Disabled:</strong> Creator will <strong className="underline">NOT</strong> earn revenue from views. Withdrawals and payouts are locked on Masti Video App until enabled.
              </span>
            )}
          </div>
        </div>

        {/* Display Bank/UPI Details for Admin */}
        {canControl && data?.bankDetails && (
          <div className="p-3 rounded-xl bg-indigo-950/30 border border-indigo-500/20 text-xs">
            <h5 className="text-[10px] uppercase font-bold text-indigo-300 mb-1.5 flex items-center gap-1.5">
              <Building2 className="w-3 h-3" /> Registered Payment Details
            </h5>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] font-mono text-slate-300">
              {data.bankDetails.upiId && <p>UPI: {data.bankDetails.upiId}</p>}
              {data.bankDetails.accountNumber && <p>A/C: {data.bankDetails.accountNumber}</p>}
              {data.bankDetails.ifsc && <p>IFSC: {data.bankDetails.ifsc}</p>}
              {data.bankDetails.accountHolderName && <p>Holder: {data.bankDetails.accountHolderName}</p>}
            </div>
          </div>
        )}

        {/* Action Buttons Row */}
        {canControl && (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
            {/* Toggle Enable / Disable */}
            <button
              type="button"
              disabled={saving}
              onClick={() => handleToggleMonetization(!isMonetizationActive)}
              className={`px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 shadow-md active:scale-98 cursor-pointer ${
                isMonetizationActive
                  ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-rose-950/50'
                  : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-950/50'
              }`}
            >
              {saving ? (
                <RefreshCw className="w-4 h-4 animate-spin" />
              ) : isMonetizationActive ? (
                <XCircle className="w-4 h-4" />
              ) : (
                <CheckCircle2 className="w-4 h-4" />
              )}
              <span>{saving ? 'Updating...' : isMonetizationActive ? 'Disable Monetization' : 'Enable Monetization'}</span>
            </button>

            {/* Withdraw Money from Masti Bash */}
            <button
              type="button"
              onClick={() => {
                setShowWithdrawDrawer(!showWithdrawDrawer);
                if (!withdrawAmount && currentWalletBalance > 0) {
                  setWithdrawAmount(String(currentWalletBalance));
                }
              }}
              className="px-3.5 py-2.5 rounded-xl bg-gradient-to-r from-amber-600 to-emerald-600 hover:from-amber-500 hover:to-emerald-500 text-white text-xs font-bold transition-all flex items-center justify-center gap-2 shadow-md shadow-emerald-950/30 active:scale-98 cursor-pointer"
            >
              <ArrowDownToLine className="w-4 h-4" />
              <span>{showWithdrawDrawer ? 'Hide Withdrawal' : 'Withdraw Funds (₹)'}</span>
            </button>

            {/* Adjust Rates & Balance */}
            <button
              type="button"
              onClick={() => {
                if (!showEditForm && data) {
                  setEditBalance(String(data.walletBalance || 0));
                  setEditEarnings(String(data.totalEarnings || 0));
                  setEditRpm(String(data.rpm || '1.00'));
                  setEditCpm(String(data.cpm || '1.00'));
                  setEditUpiId(data.bankDetails?.upiId || '');
                  setAutoCalc(!data.hasWalletOverride && !data.hasEarningsOverride);
                }
                setShowEditForm(!showEditForm);
              }}
              className="px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-all flex items-center justify-center gap-1.5 active:scale-98 cursor-pointer"
            >
              <Sliders className="w-3.5 h-3.5 text-indigo-400" />
              <span>{showEditForm ? 'Hide Rates' : 'Adjust Rates'}</span>
            </button>
          </div>
        )}
      </div>

      {/* ---------------- ADMIN CUSTOM ADJUSTER DRAWER ---------------- */}
      {showEditForm && canControl && (
        <form onSubmit={handleSaveCustomSettings} className="p-4 rounded-xl bg-slate-950 border border-indigo-500/30 space-y-3.5 animate-in fade-in duration-150">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
              <Sliders className="w-4 h-4 text-indigo-400" />
              <span>Admin Monetization Controls & Rates Adjuster</span>
            </h4>
            <span className="text-[10px] text-slate-400">Direct Live Sync</span>
          </div>

          {/* Toggle Calculation Mode */}
          <div className="p-3 rounded-lg bg-indigo-950/20 border border-indigo-500/20 flex items-center justify-between text-xs gap-4">
            <div className="flex flex-col gap-0.5">
              <span className="font-semibold text-slate-200">View-Based Auto Earnings (हज़ार व्यूज़ का पैसा)</span>
              <span className="text-[10px] text-slate-400">इसे चालू रखें ताकि यूज़र्स की कमाई व्यूज़ और RPM के हिसाब से खुद-ब-खुद बढ़े।</span>
            </div>
            <label className="relative inline-flex items-center cursor-pointer shrink-0">
              <input 
                type="checkbox" 
                checked={autoCalc} 
                onChange={(e) => setAutoCalc(e.target.checked)} 
                className="sr-only peer"
              />
              <div className="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-slate-300 after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-600 peer-checked:after:bg-white peer-checked:after:border-white"></div>
            </label>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
            <div>
              <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
                Wallet Balance (₹)
              </label>
              <input
                type="number"
                step="0.01"
                disabled={autoCalc}
                value={autoCalc ? (data?.walletBalance ?? 0).toFixed(2) : editBalance}
                onChange={(e) => setEditBalance(e.target.value)}
                className={`w-full px-2.5 py-1.5 border rounded-lg font-mono text-xs focus:outline-none ${
                  autoCalc 
                    ? 'bg-slate-950/80 border-slate-800 text-slate-500 cursor-not-allowed opacity-60' 
                    : 'bg-slate-900 border-slate-700 text-white focus:border-emerald-500'
                }`}
              />
            </div>

            <div>
              <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
                Total Earnings (₹)
              </label>
              <input
                type="number"
                step="0.01"
                disabled={autoCalc}
                value={autoCalc ? (data?.totalEarnings ?? 0).toFixed(2) : editEarnings}
                onChange={(e) => setEditEarnings(e.target.value)}
                className={`w-full px-2.5 py-1.5 border rounded-lg font-mono text-xs focus:outline-none ${
                  autoCalc 
                    ? 'bg-slate-950/80 border-slate-800 text-slate-500 cursor-not-allowed opacity-60' 
                    : 'bg-slate-900 border-slate-700 text-white focus:border-indigo-500'
                }`}
              />
            </div>

            <div>
              <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
                RPM (₹/1k views)
              </label>
              <input
                type="number"
                step="0.05"
                value={editRpm}
                onChange={(e) => setEditRpm(e.target.value)}
                className="w-full px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono text-xs focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
                CPM (₹/1k ad views)
              </label>
              <input
                type="number"
                step="0.05"
                value={editCpm}
                onChange={(e) => setEditCpm(e.target.value)}
                className="w-full px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono text-xs focus:outline-none focus:border-cyan-500"
              />
            </div>
          </div>

          {autoCalc && (
            <div className="text-[10px] text-indigo-400 italic font-medium">
              * Auto-calculated using {data?.monetizedViews ?? 0} views at ₹{editRpm}/1K views.
            </div>
          )}

          <div>
            <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
              Registered UPI ID (e.g. name@oksbi)
            </label>
            <input
              type="text"
              value={editUpiId}
              onChange={(e) => setEditUpiId(e.target.value)}
              className="w-full px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono text-xs focus:outline-none focus:border-indigo-500"
              placeholder="creator@oksbi"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-1">
            <button
              type="button"
              onClick={() => setShowEditForm(false)}
              className="px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-bold transition-all flex items-center gap-1.5 shadow-sm cursor-pointer"
            >
              <Save className="w-3.5 h-3.5" />
              <span>{saving ? 'Saving...' : 'Save Monetize Settings'}</span>
            </button>
          </div>
        </form>
      )}

      {/* ---------------- REAL-TIME BENTO METRICS ---------------- */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
        {/* Card 1: Live Available Wallet Balance */}
        <div className={`p-4 rounded-xl border space-y-1.5 transition-all ${
          isMonetizationActive
            ? 'bg-gradient-to-br from-emerald-950/50 via-slate-950 to-slate-900 border-emerald-500/40 shadow-md'
            : 'bg-slate-950 border-slate-800 opacity-85'
        }`}>
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-emerald-400 flex items-center gap-1">
              <Wallet className="w-3.5 h-3.5" /> Live Wallet Balance
            </span>
            <span className={`px-2 py-0.5 rounded-md text-[9px] font-extrabold uppercase ${
              isMonetizationActive
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
            }`}>
              {isMonetizationActive ? 'Ready to Withdraw' : 'Locked'}
            </span>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-white font-mono tracking-tight flex items-center gap-0.5">
            <IndianRupee className="w-6 h-6 text-emerald-400 shrink-0" />
            <span>{currentWalletBalance.toFixed(2)}</span>
          </div>
          <p className="text-[10px] text-slate-400 truncate">
            {data?.bankDetails?.upiId ? `Registered UPI: ${data.bankDetails.upiId}` : 'Instant UPI Payouts Supported'}
          </p>
        </div>

        {/* Card 2: Total Lifetime Earnings */}
        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-400 flex items-center gap-1">
              <TrendingUp className="w-3.5 h-3.5 text-indigo-400" /> Total Earnings
            </span>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-indigo-300 font-mono tracking-tight flex items-center gap-0.5">
            <IndianRupee className="w-6 h-6 text-indigo-400 shrink-0" />
            <span>{(data?.totalEarnings ?? 0).toFixed(2)}</span>
          </div>
          <div className="flex items-center gap-1.5 text-[10px] text-slate-400 font-mono">
            <span>RPM: ₹{data?.rpm || '1.00'}/1k</span>
            <span>•</span>
            <span>CPM: ₹{data?.cpm || '1.00'}</span>
          </div>
        </div>

        {/* Card 3: Monetized Views */}
        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-400 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" /> Monetized Views
            </span>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-cyan-300 font-mono tracking-tight">
            {data?.monetizedViews?.toLocaleString() || '0'}
          </div>
          <p className="text-[10px] text-slate-400 truncate">
            Total Views: {data?.totalViews?.toLocaleString() || '0'} (85% Monetized)
          </p>
        </div>
      </div>

      {/* ---------------- WITHDRAW FUNDS DRAWER / FORM ---------------- */}
      {showWithdrawDrawer && (
        <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 border border-emerald-500/40 shadow-xl space-y-4 animate-in fade-in duration-200">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                <ArrowDownToLine className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs sm:text-sm font-bold text-white">
                  Withdraw Funds from Masti Bash
                </h4>
                <p className="text-[10px] text-slate-400">
                  Transfers directly to creator UPI or bank account
                </p>
              </div>
            </div>

            <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-950/60 px-2.5 py-1 rounded-lg border border-emerald-800/40">
              Available: ₹{currentWalletBalance.toFixed(2)}
            </span>
          </div>

          {!isMonetizationActive && (
            <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-800/50 text-rose-200 text-xs flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>
                Monetization is currently disabled. Please click <strong>"Enable Monetization"</strong> above before withdrawing funds.
              </span>
            </div>
          )}

          {withdrawSuccessInfo && (
            <div className="p-3.5 rounded-xl bg-emerald-950/80 border border-emerald-600/50 text-emerald-200 text-xs space-y-1.5 animate-in fade-in">
              <div className="flex items-center gap-2 font-bold text-emerald-300">
                <Check className="w-4 h-4 text-emerald-400" />
                <span>Withdrawal Completed Successfully!</span>
              </div>
              <p className="text-[11px] text-emerald-200/90 font-mono">
                Amount: ₹{withdrawSuccessInfo.amount.toFixed(2)} | Ref: {withdrawSuccessInfo.transactionRef}
              </p>
              <p className="text-[10px] text-slate-300">
                Account: {withdrawSuccessInfo.accountInfo} ({withdrawSuccessInfo.method.toUpperCase()})
              </p>
            </div>
          )}

          <form onSubmit={handleProcessWithdrawal} className="space-y-3.5">
            {/* Amount Input with Quick Presets */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-[11px] font-bold text-slate-300 uppercase">
                  Withdrawal Amount (₹)
                </label>
                <span className="text-[10px] text-slate-400">Minimum: ₹1.00</span>
              </div>

              <div className="relative">
                <IndianRupee className="w-4 h-4 text-emerald-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="number"
                  step="0.01"
                  min="1"
                  max={currentWalletBalance}
                  disabled={!isMonetizationActive || withdrawing}
                  value={withdrawAmount}
                  onChange={(e) => setWithdrawAmount(e.target.value)}
                  placeholder={`Max: ${currentWalletBalance.toFixed(2)}`}
                  className="w-full pl-9 pr-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white font-mono text-sm focus:outline-none focus:border-emerald-500 disabled:opacity-50"
                  required
                />
              </div>

              {/* Quick Preset Buttons */}
              <div className="flex items-center gap-1.5 flex-wrap mt-2">
                {[10, 50, 100, 200].map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    disabled={!isMonetizationActive || currentWalletBalance < preset}
                    onClick={() => setWithdrawAmount(String(preset))}
                    className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 disabled:opacity-40 border border-slate-700 text-slate-300 text-[11px] font-mono cursor-pointer"
                  >
                    ₹{preset}
                  </button>
                ))}
                <button
                  type="button"
                  disabled={!isMonetizationActive || currentWalletBalance <= 0}
                  onClick={() => setWithdrawAmount(String(currentWalletBalance))}
                  className="px-2.5 py-1 rounded-lg bg-emerald-950/70 hover:bg-emerald-900 border border-emerald-700/60 text-emerald-300 text-[11px] font-bold font-mono cursor-pointer"
                >
                  Withdraw All (₹{currentWalletBalance.toFixed(2)})
                </button>
              </div>
            </div>

            {/* Payout Method */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <div>
                <label className="text-[11px] font-bold text-slate-300 uppercase block mb-1">
                  Payout Method
                </label>
                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    type="button"
                    onClick={() => setWithdrawMethod('upi')}
                    className={`px-3 py-2 rounded-xl text-xs font-bold border transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                      withdrawMethod === 'upi'
                        ? 'bg-emerald-600 text-white border-emerald-500 shadow-sm'
                        : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                    }`}
                  >
                    <QrCode className="w-3.5 h-3.5" />
                    <span>UPI / QR</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setWithdrawMethod('bank_transfer')}
                    className={`px-3 py-2 rounded-xl text-xs font-bold border transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                      withdrawMethod === 'bank_transfer'
                        ? 'bg-emerald-600 text-white border-emerald-500 shadow-sm'
                        : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                    }`}
                  >
                    <Building2 className="w-3.5 h-3.5" />
                    <span>Bank / NEFT</span>
                  </button>
                </div>
              </div>

              {/* UPI ID / Account Details */}
              <div>
                <label className="text-[11px] font-bold text-slate-300 uppercase block mb-1">
                  {withdrawMethod === 'upi' ? 'UPI ID (GPay / PhonePe / Paytm)' : 'Account Number & IFSC'}
                </label>
                <input
                  type="text"
                  disabled={!isMonetizationActive || withdrawing}
                  value={withdrawAccountInfo}
                  onChange={(e) => setWithdrawAccountInfo(e.target.value)}
                  placeholder={withdrawMethod === 'upi' ? 'e.g. rajkali@oksbi' : 'A/C: 123456789, IFSC: SBIN0001234'}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white font-mono text-xs focus:outline-none focus:border-emerald-500 disabled:opacity-50"
                  required
                />
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800/80">
              <button
                type="button"
                onClick={() => setShowWithdrawDrawer(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              >
                Close
              </button>

              <button
                type="submit"
                disabled={!isMonetizationActive || withdrawing || currentWalletBalance < 1}
                className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-bold transition-all flex items-center gap-2 shadow-lg shadow-emerald-950/50 cursor-pointer"
              >
                {withdrawing ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Processing Payout...</span>
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    <span>Confirm & Withdraw Funds</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      )}


      {/* ---------------- LIVE PAYOUT & WITHDRAWAL HISTORY ---------------- */}
      <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-xs font-bold text-white">
            <History className="w-4 h-4 text-cyan-400" />
            <span>Withdrawal & Payout History</span>
          </div>
          <span className="text-[10px] text-slate-400 font-mono">
            {data?.payouts?.length || 0} Transactions
          </span>
        </div>

        {data?.payouts && data.payouts.length > 0 ? (
          <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
            {data.payouts.map((p) => (
              <div
                key={p.id}
                className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between gap-2 text-xs hover:border-slate-700 transition-colors"
              >
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-emerald-400">
                      ₹{p.amount.toFixed(2)}
                    </span>
                    <span className="px-1.5 py-0.2 text-[9px] font-bold uppercase rounded bg-emerald-500/20 text-emerald-300">
                      {p.status}
                    </span>
                    <span className="text-[10px] font-mono text-slate-400 truncate">
                      Ref: {p.transactionRef}
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-400 truncate mt-0.5">
                    To: {p.accountInfo} • {formatDate(p.createdAt)}
                  </p>
                </div>
                <div className="shrink-0 text-right">
                  <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono uppercase">
                    {p.method}
                  </span>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="py-3 px-2 rounded-lg bg-slate-900/50 border border-dashed border-slate-800 text-center">
            <p className="text-xs text-slate-400">
              No previous withdrawals yet.
            </p>
            <p className="text-[10px] text-slate-500 mt-0.5">
              Available wallet balance (₹{currentWalletBalance.toFixed(2)}) is ready for instant withdrawal.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
