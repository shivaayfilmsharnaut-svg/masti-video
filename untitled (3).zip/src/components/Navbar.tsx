import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext.js';
import { useToast } from './Toast.js';
import {
  Sparkles,
  UploadCloud,
  User as UserIcon,
  LogOut,
  Shield,
  Search,
  Menu,
  Key,
  LogIn,
  RefreshCw,
  Zap,
  MessageCircle,
  Globe,
  Copy,
  Check
} from 'lucide-react';

interface NavbarProps {
  onOpenUpload: () => void;
  onOpenAuth: (mode?: 'login' | 'register') => void;
  onToggleSidebar: () => void;
  onNavigateToConnect: () => void;
  onOpenSocial?: () => void;
  onRefresh?: () => void;
  isRefreshing?: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenUpload,
  onOpenAuth,
  onToggleSidebar,
  onNavigateToConnect,
  onOpenSocial,
  onRefresh,
  isRefreshing = false
}) => {
  const { user, isAuthenticated, logout, isAdmin } = useAuth();
  const { showToast } = useToast();
  const [copiedUrl, setCopiedUrl] = useState(false);

  const currentPublicUrl = typeof window !== 'undefined' ? window.location.origin : 'https://ais-dev-vqsmp4cogfojsrm6tre6zu-18143192690.asia-east1.run.app';

  const handleCopyPublicUrl = () => {
    navigator.clipboard.writeText(currentPublicUrl);
    setCopiedUrl(true);
    showToast('success', 'Public URL Copied!', 'Masti Bash server URL is ready to paste into Masti Video app.');
    setTimeout(() => setCopiedUrl(false), 2500);
  };

  return (
    <header className="sticky top-0 z-40 h-16 bg-slate-950/85 backdrop-blur-xl border-b border-slate-800/80 px-4 sm:px-6 flex items-center justify-between gap-4">
      {/* Left: Mobile Sidebar Toggle + Brand */}
      <div className="flex items-center gap-3">
        <button
          onClick={onToggleSidebar}
          className="lg:hidden p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-900 transition-colors"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-cyan-400 flex items-center justify-center text-white shadow-lg shadow-indigo-600/30">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <span className="text-base font-extrabold tracking-tight text-white flex items-center gap-1.5 font-['Outfit']">
              MASTI BASH
            </span>
            <span className="hidden sm:inline-block text-[10px] font-semibold uppercase tracking-widest text-indigo-400">
              Cloud Media Storage
            </span>
          </div>
        </div>
      </div>

      {/* Center / Left: Live Public Server URL Badge */}
      <div className="hidden lg:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900/90 border border-slate-800 text-xs">
        <div className="flex items-center gap-1.5 text-slate-400">
          <Globe className="w-3.5 h-3.5 text-cyan-400" />
          <span className="font-semibold text-slate-300">Public Server URL:</span>
        </div>
        <code className="text-cyan-300 font-mono text-[11px] max-w-[280px] truncate">
          {currentPublicUrl}
        </code>
        <button
          onClick={handleCopyPublicUrl}
          className="p-1 px-2 rounded-lg bg-indigo-600/30 hover:bg-indigo-600/50 border border-indigo-500/40 text-indigo-200 text-[10px] font-bold flex items-center gap-1 transition-all"
          title="Copy Public Server URL"
        >
          {copiedUrl ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
          <span>{copiedUrl ? 'Copied' : 'Copy'}</span>
        </button>
      </div>

      {/* Right Actions */}
      <div className="flex items-center gap-2 sm:gap-2.5">
        {/* Mobile / Compact Public URL Copy Button */}
        <button
          onClick={handleCopyPublicUrl}
          className="lg:hidden flex items-center gap-1 px-2.5 py-1.5 bg-cyan-950/60 border border-cyan-500/40 text-cyan-300 rounded-xl text-xs font-bold transition-all shadow-sm"
          title="Copy Public Server URL"
        >
          {copiedUrl ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Globe className="w-3.5 h-3.5 text-cyan-400" />}
          <span className="text-[11px]">{copiedUrl ? 'Copied!' : 'Server URL'}</span>
        </button>

        {/* Connect Masti Video Hub Button */}
        <button
          onClick={onNavigateToConnect}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-amber-500/10 to-indigo-500/10 hover:from-amber-500/20 hover:to-indigo-500/20 border border-amber-500/30 hover:border-amber-500/60 rounded-xl text-xs font-semibold text-amber-300 transition-all shadow-sm"
          title="Connect to Masti Video App"
        >
          <Zap className="w-4 h-4 text-amber-400" />
          <span className="hidden sm:inline">Connect App</span>
        </button>

        {/* Quick Refresh Button */}
        {onRefresh && (
          <button
            onClick={onRefresh}
            disabled={isRefreshing}
            className={`p-2 rounded-xl border border-slate-800 bg-slate-900/90 text-slate-300 hover:text-white hover:bg-slate-800 transition-all ${
              isRefreshing ? 'opacity-75 cursor-not-allowed' : ''
            }`}
            title="Refresh Media Library (Pull down or click)"
          >
            <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-indigo-400' : ''}`} />
          </button>
        )}

        {/* Social & Chat Shortcut */}
        {onOpenSocial && (
          <button
            onClick={onOpenSocial}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-950/60 hover:bg-indigo-900/60 border border-indigo-500/30 hover:border-indigo-500/60 text-indigo-300 hover:text-white rounded-xl text-xs font-semibold transition-all shadow-sm"
            title="Open Masti Community Chat & Followers"
          >
            <MessageCircle className="w-4 h-4 text-indigo-400" />
            <span className="hidden md:inline">Chat</span>
          </button>
        )}

        {/* Quick Upload Button */}
        <button
          onClick={onOpenUpload}
          className="flex items-center gap-1.5 px-3.5 py-1.5 bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 text-white text-xs font-bold rounded-xl shadow-md shadow-indigo-600/20 transition-all"
        >
          <UploadCloud className="w-4 h-4" />
          <span className="hidden sm:inline">Upload</span>
        </button>

        {/* User Account / Auth Buttons */}
        {isAuthenticated && user ? (
          <div className="flex items-center gap-2 pl-2 border-l border-slate-800">
            <div className="flex items-center gap-2 px-2.5 py-1 rounded-xl bg-slate-900 border border-slate-800">
              <div className="w-6 h-6 rounded-lg bg-indigo-600/30 text-indigo-300 flex items-center justify-center text-xs font-bold">
                {user.name.charAt(0).toUpperCase()}
              </div>
              <div className="hidden md:flex flex-col text-left">
                <span className="text-xs font-bold text-white leading-none">{user.name}</span>
                <span className="text-[9px] text-slate-400 uppercase font-semibold mt-0.5">{user.role}</span>
              </div>
            </div>

            <button
              onClick={logout}
              className="p-2 text-slate-400 hover:text-rose-400 rounded-xl hover:bg-slate-900 transition-colors"
              title="Sign Out"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <button
              onClick={() => onOpenAuth('login')}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-300 hover:text-white transition-colors"
            >
              <LogIn className="w-3.5 h-3.5" />
              <span>Sign In</span>
            </button>
            <button
              onClick={() => onOpenAuth('register')}
              className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-xl border border-slate-700 transition-all"
            >
              Sign Up
            </button>
          </div>
        )}
      </div>
    </header>
  );
};
