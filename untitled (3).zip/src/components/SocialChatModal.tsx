import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.js';
import { useToast } from './Toast.js';
import { api, formatDate } from '../services/api.js';
import { ChatMessage, Follow, User, Notification, MonetizationData } from '../types.js';
import { 
  X, MessageCircle, Users, Heart, Share2, Send, 
  UserPlus, UserCheck, Search, Sparkles, Phone, Mail, 
  Shield, Check, ArrowRight, CornerDownRight, Bell, DollarSign,
  Wallet, IndianRupee, TrendingUp, ArrowUpRight, Clock, CheckCircle2,
  AlertCircle, RefreshCw
} from 'lucide-react';

interface SocialChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: 'chat' | 'followers' | 'notifications' | 'monetization';
  defaultRecipientId?: string;
}

export const SocialChatModal: React.FC<SocialChatModalProps> = ({
  isOpen,
  onClose,
  initialTab = 'chat',
  defaultRecipientId
}) => {
  const { user } = useAuth();
  const { showToast } = useToast();
  const [activeTab, setActiveTab] = useState<'chat' | 'followers' | 'notifications' | 'monetization' | 'support'>(initialTab);

  // Chat State
  const [threads, setThreads] = useState<{ contactId: string; contactName: string; lastMessage: ChatMessage; unreadCount: number }[]>([]);
  const [selectedRecipientId, setSelectedRecipientId] = useState<string>(defaultRecipientId || '');
  const [selectedRecipientName, setSelectedRecipientName] = useState<string>('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loadingChat, setLoadingChat] = useState(false);

  // Followers & Creators State
  const [followers, setFollowers] = useState<Follow[]>([]);
  const [following, setFollowing] = useState<Follow[]>([]);
  const [allUsersList, setAllUsersList] = useState<any[]>([]);
  const [loadingFollowers, setLoadingFollowers] = useState(false);

  // Notifications State
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadNotifCount, setUnreadNotifCount] = useState<number>(0);
  const [loadingNotifs, setLoadingNotifs] = useState(false);

  // Support Tickets State
  const [supportTickets, setSupportTickets] = useState<any[]>([]);
  const [loadingTickets, setLoadingTickets] = useState(false);
  const [supportSubject, setSupportSubject] = useState('');
  const [supportMessage, setSupportMessage] = useState('');
  const [isSubmittingSupport, setIsSubmittingSupport] = useState(false);
  const [adminReplyText, setAdminReplyText] = useState<{ [key: string]: string }>({});

  // Monetization State
  const [monetization, setMonetization] = useState<MonetizationData | null>(null);
  const [payoutAmount, setPayoutAmount] = useState('500');
  const [payoutMethod, setPayoutMethod] = useState<'upi' | 'bank_transfer' | 'paytm'>('upi');
  const [payoutAccount, setPayoutAccount] = useState('rajkali@oksbi');
  const [isProcessingPayout, setIsProcessingPayout] = useState(false);

  // Social Stats
  const [socialStats, setSocialStats] = useState<any>(null);

  useEffect(() => {
    if (isOpen) {
      loadCreatorsAndFollowData();
      loadChatThreads();
      loadNotifications();
      loadMonetizationData();
      loadSupportTickets();
      if (defaultRecipientId) {
        setSelectedRecipientId(defaultRecipientId);
      }
    }
  }, [isOpen, user?.id, defaultRecipientId]);

  const loadSupportTickets = async () => {
    setLoadingTickets(true);
    try {
      const res = await api.getSupportTickets();
      if (res.success && Array.isArray(res.data)) {
        setSupportTickets(res.data);
      }
    } catch (err: any) {
      console.warn('Failed to load support tickets:', err?.message);
    } finally {
      setLoadingTickets(false);
    }
  };

  const handleClearAllNotifications = async () => {
    const targetUserId = user?.id || 'usr_guest';
    try {
      await api.clearNotifications(targetUserId);
      setNotifications([]);
      setUnreadNotifCount(0);
      showToast('success', 'Cleared', 'All notifications deleted successfully.');
    } catch (err: any) {
      showToast('error', 'Error', err?.message || 'Failed to clear notifications');
    }
  };

  const handleSubmitSupportTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!supportSubject.trim() || !supportMessage.trim()) {
      showToast('error', 'Required', 'Subject and message are required.');
      return;
    }
    setIsSubmittingSupport(true);
    try {
      const res = await api.submitSupportTicket({
        subject: supportSubject.trim(),
        message: supportMessage.trim(),
        userName: user?.name || 'Rajkali Kumar',
        userEmail: user?.email || 'rajkalikumar8789@gmail.com'
      });
      if (res.success) {
        showToast('success', 'Ticket Submitted!', 'Support ticket sent to MastiBase successfully. Admin will reply soon.');
        setSupportSubject('');
        setSupportMessage('');
        loadSupportTickets();
      } else {
        showToast('error', 'Error', res.error || 'Failed to submit ticket');
      }
    } catch (err: any) {
      showToast('error', 'Error', err?.message || 'Server error');
    } finally {
      setIsSubmittingSupport(false);
    }
  };

  const handleResolveTicket = async (ticketId: string) => {
    const reply = adminReplyText[ticketId]?.trim();
    if (!reply) {
      showToast('error', 'Required', 'Please enter a reply message.');
      return;
    }
    try {
      const res = await api.resolveSupportTicket(ticketId, reply);
      if (res.success) {
        showToast('success', 'Resolved!', 'Support ticket resolved and reply sent.');
        setAdminReplyText(prev => ({ ...prev, [ticketId]: '' }));
        loadSupportTickets();
      }
    } catch (err: any) {
      showToast('error', 'Error', err?.message);
    }
  };

  useEffect(() => {
    if (selectedRecipientId && user?.id) {
      loadConversation(selectedRecipientId);
    }
  }, [selectedRecipientId, user?.id]);

  const loadNotifications = async () => {
    const targetUserId = user?.id || 'usr_guest';
    setLoadingNotifs(true);
    try {
      const res = await api.getNotifications(targetUserId);
      if (res.success && Array.isArray(res.data)) {
        setNotifications(res.data);
        setUnreadNotifCount(res.unreadCount || 0);
      }
    } catch (err: any) {
      console.warn('Failed to load notifications:', err?.message);
    } finally {
      setLoadingNotifs(false);
    }
  };

  const loadMonetizationData = async () => {
    const targetUserId = user?.id || user?.email || 'usr_guest';
    try {
      const res = await api.getMonetization(targetUserId);
      if (res.success && res.data) {
        setMonetization(res.data);
        if (res.data.bankDetails?.upiId) {
          setPayoutAccount(res.data.bankDetails.upiId);
        }
      }
    } catch (err: any) {
      console.warn('Failed to load monetization:', err?.message);
    }
  };

  const handleMarkNotificationRead = async (notifId: string) => {
    try {
      await api.markNotificationRead(notifId);
      setNotifications(prev => prev.map(n => n.id === notifId ? { ...n, isRead: true } : n));
      setUnreadNotifCount(prev => Math.max(0, prev - 1));
    } catch (err) {
      console.error(err);
    }
  };

  const handleMarkAllRead = async () => {
    const targetUserId = user?.id || 'usr_guest';
    try {
      await api.markAllNotificationsRead(targetUserId);
      setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
      setUnreadNotifCount(0);
      showToast('success', 'All Read', 'All notifications marked as read.');
    } catch (err: any) {
      showToast('error', 'Error', err?.message);
    }
  };

  const handleRequestPayout = async (e: React.FormEvent) => {
    e.preventDefault();
    const targetUserId = user?.id || 'usr_guest';
    const amountNum = Number(payoutAmount);

    if (!payoutAccount.trim()) {
      showToast('error', 'Required Field', 'Please enter UPI ID or Account Details');
      return;
    }
    if (isNaN(amountNum) || amountNum <= 0) {
      showToast('error', 'Invalid Amount', 'Please enter a valid amount');
      return;
    }

    setIsProcessingPayout(true);
    try {
      const res = await api.requestPayout({
        userId: targetUserId,
        amount: amountNum,
        method: payoutMethod,
        accountInfo: payoutAccount.trim()
      });

      if (res.success) {
        showToast('success', 'Payout Approved! ₹' + amountNum, `Sent to ${payoutAccount} (Ref: ${res.data.transactionRef})`);
        loadMonetizationData();
        loadNotifications();
      } else {
        showToast('error', 'Payout Failed', res.error || 'Unable to process payout');
      }
    } catch (err: any) {
      showToast('error', 'Error', err?.message || 'Server error');
    } finally {
      setIsProcessingPayout(false);
    }
  };

  const loadCreatorsAndFollowData = async () => {
    setLoadingFollowers(true);
    try {
      const [creatorsRes, statsRes] = await Promise.all([
        api.getCreators(),
        api.getSocialStats()
      ]);

      if (creatorsRes.success && Array.isArray(creatorsRes.data)) {
        setAllUsersList(creatorsRes.data);
      }
      if (statsRes.success && statsRes.data) {
        setSocialStats(statsRes.data);
      }

      if (user?.id) {
        const [fRes, ingRes] = await Promise.all([
          api.getFollowers(user.id),
          api.getFollowing(user.id)
        ]);
        if (fRes.success) setFollowers(fRes.data || []);
        if (ingRes.success) setFollowing(ingRes.data || []);
      }
    } catch (err: any) {
      console.warn('Failed to load creators & follow data:', err?.message);
    } finally {
      setLoadingFollowers(false);
    }
  };

  const loadChatThreads = async () => {
    try {
      if (user?.id) {
        const res = await api.getUserChatThreads(user.id);
        if (res.success && Array.isArray(res.data) && res.data.length > 0) {
          setThreads(res.data);
          if (!selectedRecipientId) {
            setSelectedRecipientId(res.data[0].contactId);
            setSelectedRecipientName(res.data[0].contactName);
          }
          return;
        }
      }

      // If user has no active thread yet, populate from available creators list
      const creatorsRes = await api.getCreators();
      if (creatorsRes.success && Array.isArray(creatorsRes.data) && creatorsRes.data.length > 0) {
        const defaultThreads = creatorsRes.data.slice(0, 5).map((c: any) => ({
          contactId: c.id,
          contactName: c.name,
          lastMessage: {
            id: 'init_' + c.id,
            senderId: c.id,
            senderName: c.name,
            receiverId: user?.id || 'usr_guest',
            receiverName: user?.name || 'Masti User',
            message: `Namaste! Masti Video app & studio par aapka swagat hai.`,
            isRead: true,
            createdAt: new Date().toISOString()
          },
          unreadCount: 0
        }));
        setThreads(defaultThreads);
        if (!selectedRecipientId && defaultThreads.length > 0) {
          setSelectedRecipientId(defaultThreads[0].contactId);
          setSelectedRecipientName(defaultThreads[0].contactName);
        }
      }
    } catch (err: any) {
      console.warn('Failed to load chat threads:', err?.message);
    }
  };

  const loadConversation = async (contactId: string) => {
    if (!user?.id || !contactId) return;
    setLoadingChat(true);
    try {
      const res = await api.getChatConversation(user.id, contactId);
      if (res.success && Array.isArray(res.data)) {
        if (res.data.length === 0) {
          setMessages([
            {
              id: 'starter_' + contactId,
              senderId: contactId,
              senderName: selectedRecipientName || 'Creator',
              receiverId: user.id,
              receiverName: user.name,
              message: `Namaste! Main ${selectedRecipientName || 'creator'} hoon. Aapka swagat hai Masti Bash Community me!`,
              isRead: true,
              createdAt: new Date(Date.now() - 60000).toISOString()
            }
          ]);
        } else {
          setMessages(res.data);
        }
      }
    } catch (err: any) {
      console.warn('Failed to load conversation:', err?.message);
    } finally {
      setLoadingChat(false);
    }
  };

  const handleSendMessage = async (textToSend?: string) => {
    const msgText = (textToSend || newMessage).trim();
    if (!msgText) return;

    const senderId = user?.id || 'usr_guest_' + Math.random().toString(36).slice(2, 7);
    const senderName = user?.name || 'Masti Fan';
    const targetId = selectedRecipientId || 'usr_masti_cinema';
    const targetName = selectedRecipientName || 'Masti Cinema Official';

    setNewMessage('');

    try {
      const res = await api.sendChatMessage({
        senderId,
        senderName,
        receiverId: targetId,
        receiverName: targetName,
        message: msgText
      });

      if (res.success && res.data) {
        setMessages((prev) => [...prev, res.data]);
        loadChatThreads();
      } else {
        showToast('error', 'Error', res.error || 'Failed to send message');
      }
    } catch (err: any) {
      showToast('error', 'Error', err?.message || 'Network error');
    }
  };

  const handleToggleFollow = async (targetUserId: string, targetUserName: string) => {
    const followerId = user?.id || 'usr_guest_' + Math.random().toString(36).slice(2, 7);
    const followerName = user?.name || 'Masti Fan';

    try {
      const res = await api.toggleFollow(targetUserId, targetUserName, followerId, followerName);
      if (res.success) {
        showToast('success', res.data.isFollowing ? 'Followed Creator!' : 'Unfollowed', `${targetUserName} is now in your creator circle.`);
        loadCreatorsAndFollowData();
      }
    } catch (err: any) {
      showToast('error', 'Error', err?.message || 'Failed to update follow');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center sm:p-6 bg-black/75 backdrop-blur-sm animate-in fade-in duration-150">
      <div 
        className="w-full h-full sm:max-w-6xl sm:h-[90vh] sm:max-h-[900px] bg-slate-900 sm:border border-slate-800 sm:rounded-2xl shadow-2xl flex flex-col overflow-hidden animate-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 border-b border-slate-800 bg-slate-950 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-cyan-500 flex items-center justify-center text-white shadow-lg shadow-indigo-500/20">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white">Masti Bash Social Hub</h2>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-mono">
                  Live Persistent Sync
                </span>
              </div>
              <p className="text-xs text-slate-400">
                User ID, DP, Notifications, Likes, Comments, Shares, Followers aur Chats ka live sync data.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-all"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center border-b border-slate-800 bg-slate-950/60 px-4 gap-1 overflow-x-auto">
          <button
            onClick={() => setActiveTab('followers')}
            className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold border-b-2 whitespace-nowrap transition-all ${
              activeTab === 'followers'
                ? 'border-indigo-500 text-indigo-400 bg-indigo-500/5'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Users className="w-4 h-4 text-indigo-400" />
            <span>Followers & Creators ({allUsersList.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('chat')}
            className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold border-b-2 whitespace-nowrap transition-all ${
              activeTab === 'chat'
                ? 'border-indigo-500 text-indigo-400 bg-indigo-500/5'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <MessageCircle className="w-4 h-4 text-cyan-400" />
            <span>Direct Chat</span>
            {threads.some(t => t.unreadCount > 0) && (
              <span className="w-2 h-2 rounded-full bg-indigo-500" />
            )}
          </button>

          <button
            onClick={() => setActiveTab('notifications')}
            className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold border-b-2 whitespace-nowrap transition-all ${
              activeTab === 'notifications'
                ? 'border-indigo-500 text-indigo-400 bg-indigo-500/5'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Bell className="w-4 h-4 text-amber-400" />
            <span>Notifications</span>
            {unreadNotifCount > 0 && (
              <span className="px-1.5 py-0.5 rounded-full bg-rose-500 text-white text-[9px] font-bold">
                {unreadNotifCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('support')}
            className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold border-b-2 whitespace-nowrap transition-all ${
              activeTab === 'support'
                ? 'border-indigo-500 text-indigo-400 bg-indigo-500/5'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Shield className="w-4 h-4 text-emerald-400" />
            <span>Help & Support ({supportTickets.length})</span>
          </button>
        </div>

        {/* Tab 1: Followers & Creators */}
        {activeTab === 'followers' && (
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
            {socialStats && (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80">
                  <span className="text-[10px] uppercase font-bold text-slate-400">Total Creators</span>
                  <p className="text-base font-black text-white mt-0.5">{allUsersList.length || socialStats.totalUsers}</p>
                </div>
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80">
                  <span className="text-[10px] uppercase font-bold text-rose-400 flex items-center gap-1">
                    <Heart className="w-3 h-3 fill-rose-400" /> Total Likes
                  </span>
                  <p className="text-base font-black text-white mt-0.5">{socialStats.totalLikes || 24}</p>
                </div>
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80">
                  <span className="text-[10px] uppercase font-bold text-indigo-400 flex items-center gap-1">
                    <MessageCircle className="w-3 h-3" /> Comments
                  </span>
                  <p className="text-base font-black text-white mt-0.5">{socialStats.totalComments || 12}</p>
                </div>
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80">
                  <span className="text-[10px] uppercase font-bold text-cyan-400 flex items-center gap-1">
                    <Users className="w-3 h-3" /> My Network
                  </span>
                  <p className="text-base font-black text-white mt-0.5">{following.length} Following</p>
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Active Creators */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800/80 space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-cyan-400" />
                    <span>Active Masti Bash Creators ({allUsersList.length})</span>
                  </h3>
                  <span className="text-[10px] text-emerald-400 font-mono flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /> Live Now
                  </span>
                </div>

                <div className="space-y-2.5 max-h-[420px] overflow-y-auto pr-1">
                  {allUsersList.map((u: any) => {
                    const isMe = u.id === user?.id;
                    const isFollowed = following.some(f => f.followingId === u.id);
                    const initials = u.name?.split(' ').map((n: string) => n[0]).join('').slice(0, 2).toUpperCase() || 'M';
                    
                    return (
                      <div 
                        key={u.id} 
                        className="p-3 rounded-xl bg-slate-900 border border-slate-800 hover:border-indigo-500/40 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-indigo-600 via-purple-600 to-pink-500 flex items-center justify-center text-white font-bold text-xs shadow-md shrink-0">
                            {initials}
                          </div>

                          <div className="min-w-0">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <p className="text-xs font-bold text-white truncate">{u.name}</p>
                              {u.badge && (
                                <span className="px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 text-[9px] font-medium border border-indigo-500/30">
                                  {u.badge}
                                </span>
                              )}
                            </div>
                            <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-0.5 flex-wrap font-mono">
                              <span className="text-slate-300 font-semibold">{u.followersCount ? `${u.followersCount.toLocaleString()} followers` : 'Active'}</span>
                              <span>•</span>
                              <span>{u.mediaCount || 0} videos</span>
                              <span>•</span>
                              <span className="text-indigo-400">ID: {u.id.slice(0, 12)}</span>
                            </div>
                            {u.bio && (
                              <p className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">
                                {u.bio}
                              </p>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                          {!isMe && (
                            <button
                              onClick={() => handleToggleFollow(u.id, u.name)}
                              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm ${
                                isFollowed
                                  ? 'bg-slate-800 text-emerald-400 border border-emerald-500/40 hover:bg-slate-700'
                                  : 'bg-gradient-to-r from-indigo-600 to-pink-600 hover:from-indigo-500 hover:to-pink-500 text-white'
                              }`}
                            >
                              {isFollowed ? <UserCheck className="w-3.5 h-3.5" /> : <UserPlus className="w-3.5 h-3.5" />}
                              <span>{isFollowed ? 'Following' : 'Follow'}</span>
                            </button>
                          )}

                          <button
                            onClick={() => {
                              setSelectedRecipientId(u.id);
                              setSelectedRecipientName(u.name);
                              setActiveTab('chat');
                            }}
                            className="p-1.5 px-2.5 rounded-xl bg-slate-800 hover:bg-indigo-600 text-slate-200 hover:text-white text-xs font-semibold transition-all flex items-center gap-1"
                          >
                            <MessageCircle className="w-3.5 h-3.5" />
                            <span className="hidden sm:inline">Chat</span>
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* My Followers & Following Network */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800/80 space-y-3">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                  <Users className="w-4 h-4 text-indigo-400" />
                  <span>My Follow Network ({followers.length + following.length})</span>
                </h3>

                {followers.length === 0 && following.length === 0 ? (
                  <div className="p-6 rounded-xl bg-slate-900/60 border border-dashed border-slate-800 text-center text-xs text-slate-400 space-y-2">
                    <Users className="w-8 h-8 mx-auto text-slate-600 opacity-60" />
                    <p className="font-semibold text-slate-300">Start following creators!</p>
                    <p className="text-[11px] text-slate-500 max-w-xs mx-auto">
                      Click the "Follow" button next to any creator on the left to build your network.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2 max-h-[420px] overflow-y-auto pr-1">
                    {following.map(f => (
                      <div key={f.id} className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-full bg-emerald-600/30 text-emerald-400 border border-emerald-500/30 flex items-center justify-center text-xs font-bold">
                            {f.followingName?.charAt(0) || 'C'}
                          </div>
                          <div>
                            <p className="text-xs font-bold text-white">{f.followingName}</p>
                            <p className="text-[10px] font-mono text-slate-400">Following Creator • ID: {f.followingId.slice(0, 10)}</p>
                          </div>
                        </div>
                        <button
                          onClick={() => {
                            setSelectedRecipientId(f.followingId);
                            setSelectedRecipientName(f.followingName || 'Creator');
                            setActiveTab('chat');
                          }}
                          className="px-2.5 py-1 rounded-lg bg-indigo-600/20 hover:bg-indigo-600 text-indigo-300 hover:text-white text-xs font-semibold transition-all"
                        >
                          Message
                        </button>
                      </div>
                    ))}

                    {followers.map(f => (
                      <div key={f.id} className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-full bg-indigo-600/30 text-indigo-400 border border-indigo-500/30 flex items-center justify-center text-xs font-bold">
                            {f.followerName?.charAt(0) || 'F'}
                          </div>
                          <div>
                            <p className="text-xs font-bold text-white">{f.followerName}</p>
                            <p className="text-[10px] font-mono text-slate-400">Follower • ID: {f.followerId.slice(0, 10)}</p>
                          </div>
                        </div>
                        <button
                          onClick={() => {
                            setSelectedRecipientId(f.followerId);
                            setSelectedRecipientName(f.followerName || 'Follower');
                            setActiveTab('chat');
                          }}
                          className="px-2.5 py-1 rounded-lg bg-indigo-600/20 hover:bg-indigo-600 text-indigo-300 hover:text-white text-xs font-semibold transition-all"
                        >
                          Message
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Direct Chat Box */}
        {activeTab === 'chat' && (
          <div className="flex-1 flex overflow-hidden">
            {/* Conversations List */}
            <div className={`w-full sm:w-1/3 sm:min-w-[220px] sm:max-w-[280px] border-r border-slate-800 bg-slate-950/70 flex flex-col ${selectedRecipientId ? 'hidden sm:flex' : 'flex'}`}>
              <div className="p-3 border-b border-slate-800">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Active Conversations ({threads.length})
                </span>
              </div>

              <div className="flex-1 overflow-y-auto p-2 space-y-1.5">
                {threads.map((t) => {
                  const isSelected = selectedRecipientId === t.contactId;
                  const initials = t.contactName?.split(' ').map((n: string) => n[0]).join('').slice(0, 2).toUpperCase() || 'U';

                  return (
                    <button
                      key={t.contactId}
                      onClick={() => {
                        setSelectedRecipientId(t.contactId);
                        setSelectedRecipientName(t.contactName);
                      }}
                      className={`w-full p-2.5 rounded-xl flex items-center gap-2.5 text-left transition-all ${
                        isSelected
                          ? 'bg-indigo-600/20 border border-indigo-500/40 text-white'
                          : 'hover:bg-slate-800/60 text-slate-300'
                      }`}
                    >
                      <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-indigo-500 to-cyan-500 flex items-center justify-center text-white font-bold text-xs shrink-0">
                        {initials}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <p className="text-xs font-semibold truncate">{t.contactName}</p>
                          <span className="text-[9px] text-slate-500 font-mono">
                            {t.contactId.slice(0, 8)}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 truncate mt-0.5">
                          {t.lastMessage?.message}
                        </p>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Chat Box */}
            <div className={`flex-1 flex flex-col bg-slate-900/60 ${!selectedRecipientId ? 'hidden sm:flex' : 'flex'}`}>
              {selectedRecipientId ? (
                <>
                  {/* Chat Top Info */}
                  <div className="p-3 px-4 border-b border-slate-800 bg-slate-950/60 flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <button 
                        className="sm:hidden p-1.5 -ml-1.5 mr-1 bg-slate-800/80 rounded-lg text-slate-300 hover:text-white"
                        onClick={() => setSelectedRecipientId(null)}
                      >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7"></path></svg>
                      </button>
                      <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-indigo-600 to-pink-500 flex items-center justify-center text-white text-xs font-bold shrink-0">
                        {selectedRecipientName?.charAt(0) || 'U'}
                      </div>
                      <div className="min-w-0">
                        <p className="text-xs font-bold text-white truncate">{selectedRecipientName || 'Chat Recipient'}</p>
                        <p className="text-[10px] font-mono text-indigo-400 truncate">User ID: {selectedRecipientId}</p>
                      </div>
                    </div>
                  </div>

                  {/* Messages Area */}
                  <div className="flex-1 overflow-y-auto p-4 space-y-3">
                    {loadingChat ? (
                      <div className="flex justify-center items-center h-full">
                        <div className="w-6 h-6 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
                      </div>
                    ) : (
                      messages.map((m) => {
                        const isMe = m.senderId === (user?.id || 'usr_guest');
                        return (
                          <div
                            key={m.id}
                            className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                          >
                            <div
                              className={`max-w-[80%] p-3 rounded-2xl text-xs leading-relaxed ${
                                isMe
                                  ? 'bg-indigo-600 text-white rounded-br-none shadow-md shadow-indigo-600/20'
                                  : 'bg-slate-800 border border-slate-700 text-slate-200 rounded-bl-none'
                              }`}
                            >
                              <p>{m.message}</p>
                            </div>
                            <span className="text-[10px] text-slate-500 mt-1 px-1">
                              {m.senderName} • {formatDate(m.createdAt)}
                            </span>
                          </div>
                        );
                      })
                    )}
                  </div>

                  {/* Quick Starter Chips */}
                  <div className="px-4 py-1.5 bg-slate-950/40 border-t border-slate-800/60 flex items-center gap-1.5 overflow-x-auto text-[11px]">
                    <button
                      type="button"
                      onClick={() => handleSendMessage('👋 Namaste! Masti video streaming test successful.')}
                      className="px-2.5 py-1 rounded-full bg-slate-800/80 hover:bg-indigo-600/30 border border-slate-700/60 text-slate-300 whitespace-nowrap"
                    >
                      👋 Namaste! Video stream test
                    </button>
                    <button
                      type="button"
                      onClick={() => handleSendMessage('🔥 Super video! Likes and comments database me save ho rahe hain.')}
                      className="px-2.5 py-1 rounded-full bg-slate-800/80 hover:bg-indigo-600/30 border border-slate-700/60 text-slate-300 whitespace-nowrap"
                    >
                      🔥 Super hit content
                    </button>
                    <button
                      type="button"
                      onClick={() => handleSendMessage('🎬 New video upload live hai!')}
                      className="px-2.5 py-1 rounded-full bg-slate-800/80 hover:bg-indigo-600/30 border border-slate-700/60 text-slate-300 whitespace-nowrap"
                    >
                      🎬 New video live
                    </button>
                  </div>

                  {/* Message Input Box */}
                  <form onSubmit={(e) => { e.preventDefault(); handleSendMessage(); }} className="p-3 bg-slate-950 border-t border-slate-800">
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        placeholder="Type your message..."
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        className="flex-1 px-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
                      />
                      <button
                        type="submit"
                        disabled={!newMessage.trim()}
                        className="p-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white rounded-xl shadow-md transition-all flex items-center justify-center"
                      >
                        <Send className="w-4 h-4" />
                      </button>
                    </div>
                  </form>
                </>
              ) : (
                <div className="flex-1 flex flex-col items-center justify-center p-8 text-center text-slate-500">
                  <MessageCircle className="w-12 h-12 mb-3 text-slate-600" />
                  <h3 className="text-sm font-bold text-slate-300">Select or Start a Chat</h3>
                  <p className="text-xs text-slate-500 max-w-sm mt-1">
                    Select a conversation from the left or choose any creator from the Followers & Creators tab.
                  </p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tab 3: Notifications Feed */}
        {activeTab === 'notifications' && (
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Bell className="w-4 h-4 text-amber-400" />
                  Live Notification Stream ({notifications.length})
                </h3>
                <p className="text-xs text-slate-400">
                  Likes, Comments, Shares, Follows aur Monetization Alerts real-time server par save hote hain.
                </p>
              </div>

              {notifications.length > 0 && (
                <div className="flex items-center gap-2">
                  {notifications.some(n => !n.isRead) && (
                    <button
                      onClick={handleMarkAllRead}
                      className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-indigo-300 text-xs font-semibold transition-all flex items-center gap-1.5"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>Mark Read</span>
                    </button>
                  )}
                  <button
                    onClick={handleClearAllNotifications}
                    className="px-3 py-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 text-rose-400 text-xs font-semibold transition-all flex items-center gap-1.5"
                  >
                    <X className="w-3.5 h-3.5" />
                    <span>Clear All</span>
                  </button>
                </div>
              )}
            </div>

            {loadingNotifs ? (
              <div className="flex justify-center p-12">
                <div className="w-8 h-8 border-2 border-amber-500 border-t-transparent rounded-full animate-spin" />
              </div>
            ) : notifications.length === 0 ? (
              <div className="p-12 text-center rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                <Bell className="w-10 h-10 text-slate-600 mx-auto opacity-60" />
                <h4 className="text-sm font-bold text-slate-300">No Notifications Yet</h4>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  When someone likes, comments, shares your video, or follows you, notifications will appear here in real-time.
                </p>
              </div>
            ) : (
              <div className="space-y-2.5">
                {notifications.map((notif) => (
                  <div
                    key={notif.id}
                    onClick={() => handleMarkNotificationRead(notif.id)}
                    className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-start gap-3.5 ${
                      notif.isRead
                        ? 'bg-slate-950/60 border-slate-800/80 text-slate-300'
                        : 'bg-indigo-950/30 border-indigo-500/40 text-white shadow-lg'
                    }`}
                  >
                    {/* Icon based on notification type */}
                    <div className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0 mt-0.5 bg-slate-900 border border-slate-800">
                      {notif.type === 'like' && <Heart className="w-4 h-4 text-rose-400 fill-rose-400" />}
                      {notif.type === 'comment' && <MessageCircle className="w-4 h-4 text-indigo-400" />}
                      {notif.type === 'follow' && <UserPlus className="w-4 h-4 text-emerald-400" />}
                      {notif.type === 'share' && <Share2 className="w-4 h-4 text-cyan-400" />}
                      {notif.type === 'chat' && <Send className="w-4 h-4 text-blue-400" />}
                      {notif.type === 'monetization' && <IndianRupee className="w-4 h-4 text-emerald-400" />}
                      {notif.type === 'system' && <Sparkles className="w-4 h-4 text-amber-400" />}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <h4 className="text-xs font-bold truncate flex items-center gap-2">
                          {notif.title}
                          {!notif.isRead && (
                            <span className="w-2 h-2 rounded-full bg-indigo-500" />
                          )}
                        </h4>
                        <span className="text-[10px] text-slate-500 font-mono shrink-0">
                          {formatDate(notif.createdAt)}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 mt-0.5 leading-relaxed">
                        {notif.message}
                      </p>
                      {notif.actorName && (
                        <div className="flex items-center gap-2 mt-2 text-[10px] font-mono text-indigo-300">
                          <span>By: {notif.actorName}</span>
                          {notif.actorId && <span>• ID: {notif.actorId.slice(0, 10)}</span>}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Tab 4: Help & Support Tickets */}
        {activeTab === 'support' && (
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Shield className="w-4 h-4 text-emerald-400" />
                  Help & Support Center ({supportTickets.length} Tickets)
                </h3>
                <p className="text-xs text-slate-400">
                  Raise support inquiries or view ticket resolution status and replies from Admin (Rajkali).
                </p>
              </div>
            </div>

            {/* Submit Ticket Form */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
              <h4 className="text-xs font-bold text-white flex items-center gap-2">
                <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                Submit New Support Ticket
              </h4>
              <form onSubmit={handleSubmitSupportTicket} className="space-y-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-400 mb-1">Subject / Issue Title</label>
                  <input
                    type="text"
                    placeholder="e.g. Monetization withdrawal query or Video upload issue"
                    value={supportSubject}
                    onChange={(e) => setSupportSubject(e.target.value)}
                    className="w-full px-3.5 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-400 mb-1">Detailed Description</label>
                  <textarea
                    rows={3}
                    placeholder="Describe your issue or question in detail..."
                    value={supportMessage}
                    onChange={(e) => setSupportMessage(e.target.value)}
                    className="w-full px-3.5 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500 resize-none"
                  />
                </div>
                <div className="flex justify-end">
                  <button
                    type="submit"
                    disabled={isSubmittingSupport}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded-xl text-xs font-semibold shadow-md transition-all flex items-center gap-1.5"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>{isSubmittingSupport ? 'Submitting...' : 'Submit Ticket'}</span>
                  </button>
                </div>
              </form>
            </div>

            {/* Tickets List */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-slate-300">All Support Tickets</h4>
              {loadingTickets ? (
                <div className="flex justify-center p-8">
                  <div className="w-6 h-6 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin" />
                </div>
              ) : supportTickets.length === 0 ? (
                <div className="p-8 text-center rounded-2xl bg-slate-950 border border-slate-800 text-slate-500 text-xs">
                  No support tickets raised yet.
                </div>
              ) : (
                supportTickets.map((ticket) => (
                  <div key={ticket.id} className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold ${
                          ticket.status === 'resolved' 
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' 
                            : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                        }`}>
                          {ticket.status.toUpperCase()}
                        </span>
                        <h5 className="text-xs font-bold text-white">{ticket.subject}</h5>
                      </div>
                      <span className="text-[10px] text-slate-500 font-mono">{formatDate(ticket.createdAt)}</span>
                    </div>

                    <p className="text-xs text-slate-300 leading-relaxed bg-slate-900/50 p-2.5 rounded-lg border border-slate-800">
                      {ticket.message}
                    </p>

                    <div className="flex items-center justify-between text-[11px] text-slate-400">
                      <span>By: <strong className="text-indigo-300">{ticket.userName}</strong> ({ticket.userEmail})</span>
                    </div>

                    {ticket.adminReply && (
                      <div className="p-3 rounded-lg bg-emerald-950/20 border border-emerald-500/30 text-emerald-200 text-xs space-y-1">
                        <div className="font-bold flex items-center gap-1.5 text-emerald-400">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          Admin Reply (Rajkali):
                        </div>
                        <p>{ticket.adminReply}</p>
                      </div>
                    )}

                    {/* Admin Reply Input */}
                    {ticket.status !== 'resolved' && (
                      <div className="pt-2 border-t border-slate-800/80 flex items-center gap-2">
                        <input
                          type="text"
                          placeholder="Type admin reply to resolve..."
                          value={adminReplyText[ticket.id] || ''}
                          onChange={(e) => setAdminReplyText({ ...adminReplyText, [ticket.id]: e.target.value })}
                          className="flex-1 px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-slate-100 focus:outline-none focus:border-emerald-500"
                        />
                        <button
                          onClick={() => handleResolveTicket(ticket.id)}
                          className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold shadow transition-all shrink-0 flex items-center gap-1"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>Resolve</span>
                        </button>
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
