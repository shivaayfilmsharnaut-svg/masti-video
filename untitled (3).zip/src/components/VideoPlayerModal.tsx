import React, { useRef, useState, useEffect } from 'react';
import { MediaFile } from '../types.js';
import { useToast } from './Toast.js';
import { formatBytes, formatDate, resolveMediaUrl, api } from '../services/api.js';
import { useAuth } from '../context/AuthContext.js';
import { CommentsDrawer } from './CommentsDrawer.js';
import { RichCaption } from './RichCaption.js';
import {
  X,
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize,
  Copy,
  Download,
  Code,
  Check,
  Film,
  Layers,
  Sparkles,
  AlertCircle,
  RefreshCw,
  ExternalLink,
  RotateCcw,
  RotateCw,
  Tv,
  Monitor,
  Heart,
  MessageSquare,
  Share2,
  User as UserIcon,
  UserPlus,
  UserCheck,
  CheckCircle2,
  Globe,
  MessageCircle,
  Music,
  Link as LinkIcon,
  Edit2,
  Save
} from 'lucide-react';

const UniqueMastiVerifiedBadge = ({ className = "w-3.5 h-3.5" }: { className?: string }) => (
  <svg 
    aria-label="Verified" 
    className={`shrink-0 drop-shadow-[0_0_3px_rgba(168,85,247,0.6)] ${className}`} 
    viewBox="0 0 100 100" 
    fill="none" 
    xmlns="http://www.w3.org/2000/svg"
  >
    <defs>
      <linearGradient id="mastiPremiumGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#00F0FF" />
        <stop offset="50%" stopColor="#8A2BE2" />
        <stop offset="100%" stopColor="#FF1493" />
      </linearGradient>
    </defs>
    <path d="M50 0L64.4 12.5H82.5V30.6L100 50L82.5 69.4V87.5H64.4L50 100L35.6 87.5H17.5V69.4L0 50L17.5 30.6V12.5H35.6L50 0Z" fill="url(#mastiPremiumGrad)" />
    <path d="M35 50L45 60L65 40" stroke="white" strokeWidth="8" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

interface VideoPlayerModalProps {
  media: MediaFile | null;
  onClose: () => void;
  onMediaUpdated?: (updated: MediaFile) => void;
}

export const VideoPlayerModal: React.FC<VideoPlayerModalProps> = ({ media, onClose, onMediaUpdated }) => {
  const [currentMedia, setCurrentMedia] = useState<MediaFile | null>(media);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(1);
  const [hasError, setHasError] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState<number>(media?.duration || 0);
  const [videoDimensions, setVideoDimensions] = useState<{ width: number; height: number } | null>(
    media?.width && media?.height ? { width: media.width, height: media.height } : null
  );
  const [playbackRate, setPlaybackRate] = useState(1);
  const [copiedType, setCopiedType] = useState<string | null>(null);
  const [isLiked, setIsLiked] = useState(false);
  const [likesCount, setLikesCount] = useState(media?.likesCount || 0);
  const [commentsCount, setCommentsCount] = useState(media?.commentsCount || 0);
  const [sharesCount, setSharesCount] = useState(media?.sharesCount || 0);
  const [showCommentsDrawer, setShowCommentsDrawer] = useState(false);

  // Quick edit title & caption state
  const [isEditingMeta, setIsEditingMeta] = useState(false);
  const [editTitle, setEditTitle] = useState('');
  const [editCaption, setEditCaption] = useState('');
  const [editSoundtrackTitle, setEditSoundtrackTitle] = useState('');
  const [editAudioUrl, setEditAudioUrl] = useState('');
  const [isSavingMeta, setIsSavingMeta] = useState(false);

  // Follow / Unfollow & Creator state
  const [isFollowing, setIsFollowing] = useState(false);
  const [followersCount, setFollowersCount] = useState(128);
  const [creatorProfile, setCreatorProfile] = useState<{
    id: string;
    name: string;
    username: string;
    avatarUrl: string;
    bio: string;
    followersCount: number;
    followingCount: number;
    isVerified?: boolean;
    socialLinks?: {
      instagram?: string;
      youtube?: string;
      facebook?: string;
      twitter?: string;
      website?: string;
      whatsapp?: string;
    };
  } | null>(null);

  const { user } = useAuth();
  const { showToast } = useToast();

  useEffect(() => {
    setCurrentMedia(media);
  }, [media]);

  const activeItem = currentMedia || media;
  const resolvedUrl = activeItem ? resolveMediaUrl(activeItem.fileUrl) : '';
  const streamUrl = activeItem ? `/api/v1/media/stream/${activeItem.id}` : '';

  useEffect(() => {
    setHasError(false);
    setIsLoading(true);
    setIsPlaying(false);
    setCurrentTime(0);
    setDuration(activeItem?.duration || 0);
    setLikesCount(activeItem?.likesCount || 0);
    setCommentsCount(activeItem?.commentsCount || 0);
    setSharesCount(activeItem?.sharesCount || 0);
    setIsEditingMeta(false);
    if (activeItem?.width && activeItem?.height) {
      setVideoDimensions({ width: activeItem.width, height: activeItem.height });
    } else {
      setVideoDimensions(null);
    }

    if (activeItem) {
      setEditTitle(activeItem.title || '');
      setEditCaption(activeItem.caption || '');
      setEditSoundtrackTitle(activeItem.music?.title || activeItem.soundtrackTitle || '');
      setEditAudioUrl(activeItem.music?.url || activeItem.audioUrl || '');
    }

    if (activeItem) {
      // Determine creator info from media
      const targetUserId = activeItem.userId || 'usr_creator';
      const targetEmail = activeItem.userEmail || (targetUserId.includes('@') ? targetUserId : `${targetUserId}@mastiapp.io`);
      const targetName = targetEmail ? targetEmail.split('@')[0] : 'Masti Creator';
      const formattedUsername = targetName.toLowerCase().replace(/[^a-z0-9_]/g, '');

      const initialCreator = {
        id: targetUserId,
        name: targetName.charAt(0).toUpperCase() + targetName.slice(1),
        username: `@${formattedUsername}`,
        avatarUrl: `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(targetEmail || targetUserId)}`,
        bio: 'Professional Video Creator & Masti Partner 🎥✨',
        followersCount: 340,
        followingCount: 48,
        isVerified: false,
        socialLinks: {
          instagram: `https://instagram.com/${formattedUsername}`,
          youtube: `https://youtube.com/@${formattedUsername}`,
          facebook: '',
          twitter: '',
          website: `https://${formattedUsername}.mastiapp.io`,
          whatsapp: ''
        }
      };

      setCreatorProfile(initialCreator);
      setFollowersCount(initialCreator.followersCount);

      // Fetch dynamic profile and follow state
      api.getUserSyncedProfile(targetEmail || targetUserId).then((res) => {
        if (res?.success && res?.data?.user) {
          const u = res.data.user;
          setCreatorProfile((prev) => ({
            id: u.id || targetUserId,
            name: u.name || prev?.name || 'Masti Creator',
            username: `@${(u.name || formattedUsername).toLowerCase().replace(/[^a-z0-9_]/g, '')}`,
            avatarUrl: u.avatarUrl || prev?.avatarUrl || '',
            bio: u.bio || prev?.bio || 'Masti Video Creator',
            followersCount: u.followersCount || prev?.followersCount || 340,
            followingCount: u.followingCount || prev?.followingCount || 48,
            isVerified: u.isVerified !== undefined ? Boolean(u.isVerified) : false,
            socialLinks: u.socialLinks || prev?.socialLinks
          }));
          if (u.followersCount !== undefined) {
            setFollowersCount(u.followersCount);
          }
        }
      }).catch((e: any) => console.warn('Could not fetch creator profile:', e?.message));

      // Check if current user follows this creator
      if (user?.id) {
        api.getFollowing(user.id).then((res) => {
          if (res.success && Array.isArray(res.data)) {
            const alreadyFollowing = res.data.some((f: any) => f.followingId === targetUserId || f.followingName === targetName);
            setIsFollowing(alreadyFollowing);
          }
        }).catch((e: any) => console.warn('Could not check following status:', e?.message));
      }
    }

    if (media?.id && user?.id) {
      api.getUserLikedMediaIds(user.id).then((res) => {
        if (res.success && Array.isArray(res.likedMediaIds)) {
          setIsLiked(res.likedMediaIds.includes(media.id));
        }
      }).catch((e: any) => console.warn('Could not fetch like status:', e?.message));
    }
  }, [media?.id, user?.id]);

  const handleToggleLike = async () => {
    if (!media) return;
    try {
      const res = await api.toggleLike(media.id, user?.id, user?.name);
      if (res.success && res.data) {
        setIsLiked(res.data.isLiked);
        setLikesCount(res.data.likesCount);
        showToast('info', res.data.isLiked ? 'Liked' : 'Unliked', res.data.isLiked ? 'Saved to your favorites' : 'Like removed');
      }
    } catch (err: any) {
      showToast('error', 'Error', err?.message || 'Could not toggle like');
    }
  };

  const handleToggleFollow = async (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (!media) return;

    const targetId = creatorProfile?.id || media.userId || 'usr_creator';
    const targetName = creatorProfile?.name || media.userId || 'Creator';
    const nextState = !isFollowing;

    setIsFollowing(nextState);
    setFollowersCount((prev) => (nextState ? prev + 1 : Math.max(0, prev - 1)));

    try {
      const res = await api.toggleFollow(targetId, targetName, user?.id || user?.email || 'anon_user', user?.name || 'Masti Viewer');
      if (res.success && res.data) {
        setIsFollowing(res.data.isFollowing);
        if (res.data.followersCount !== undefined) {
          setFollowersCount(res.data.followersCount);
        }
        showToast(
          'success',
          res.data.isFollowing ? `Following ${targetName}` : `Unfollowed ${targetName}`,
          res.data.isFollowing ? 'You will now receive updates on new videos from this creator.' : 'Removed from your following list.'
        );
      }
    } catch (err: any) {
      showToast('error', 'Error', err?.message || 'Could not update follow state');
    }
  };

  const handleShareVideo = async () => {
    if (!media) return;
    const url = window.location.origin + resolveMediaUrl(media.fileUrl);
    try {
      if (navigator.clipboard) {
        await navigator.clipboard.writeText(url);
      }
      const res = await api.recordShare(media.id, 'clipboard', url, user?.id);
      if (res.success && res.data) {
        setSharesCount(res.data.totalShares);
      }
      showToast('success', 'Link Copied & Share Saved', 'Video streaming URL copied to clipboard.');
    } catch (err: any) {
      showToast('info', 'Link Copied', url);
    }
  };

  if (!media) return null;

  const togglePlay = () => {
    if (videoRef.current) {
      if (!videoRef.current.paused) {
        videoRef.current.pause();
        setIsPlaying(false);
      } else {
        const playPromise = videoRef.current.play();
        if (playPromise !== undefined) {
          playPromise
            .then(() => {
              setIsPlaying(true);
              setHasError(false);
            })
            .catch(err => {
              if (err?.name === 'AbortError') {
                // Ignore harmless interruption caused by quick pause or seek
                return;
              }
              if (err?.name === 'NotAllowedError') {
                console.warn('Video playback requires user permission');
                return;
              }
              console.warn('Video play error:', err?.message || 'Playback failed');
            });
        }
      }
    }
  };

  const toggleMute = () => {
    if (videoRef.current) {
      const nextMute = !isMuted;
      videoRef.current.muted = nextMute;
      setIsMuted(nextMute);
    }
  };

  const handleVolumeChange = (newVol: number) => {
    if (videoRef.current) {
      videoRef.current.volume = newVol;
      setVolume(newVol);
      if (newVol === 0) {
        setIsMuted(true);
        videoRef.current.muted = true;
      } else if (isMuted) {
        setIsMuted(false);
        videoRef.current.muted = false;
      }
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = parseFloat(e.target.value);
    if (videoRef.current) {
      videoRef.current.currentTime = time;
      setCurrentTime(time);
    }
  };

  const skipTime = (seconds: number) => {
    if (videoRef.current) {
      const newTime = Math.min(Math.max(0, videoRef.current.currentTime + seconds), duration || videoRef.current.duration || 0);
      videoRef.current.currentTime = newTime;
      setCurrentTime(newTime);
    }
  };

  const handleFullScreen = () => {
    if (videoRef.current) {
      if (videoRef.current.requestFullscreen) {
        videoRef.current.requestFullscreen();
      }
    }
  };

  const togglePiP = async () => {
    if (videoRef.current && document.pictureInPictureEnabled) {
      try {
        if (document.pictureInPictureElement) {
          await document.exitPictureInPicture();
        } else {
          await videoRef.current.requestPictureInPicture();
        }
      } catch (err) {
        console.warn('PiP error:', err);
      }
    }
  };

  const handleSpeedChange = (rate: number) => {
    if (videoRef.current) {
      videoRef.current.playbackRate = rate;
      setPlaybackRate(rate);
    }
  };

  const handleRetry = () => {
    setHasError(false);
    setIsLoading(true);
    if (videoRef.current) {
      videoRef.current.load();
      const playPromise = videoRef.current.play();
      if (playPromise !== undefined) {
        playPromise
          .then(() => {
            setIsPlaying(true);
            setHasError(false);
          })
          .catch((err) => {
            if (err.name === 'AbortError') return;
            console.warn('Retry playback notice:', err);
          });
      }
    }
  };

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedType(label);
    showToast('success', 'Copied to Clipboard', label);
    setTimeout(() => setCopiedType(null), 2000);
  };

  const formatTime = (secs: number) => {
    if (!secs || isNaN(secs)) return '00:00';
    const totalSecs = Math.floor(secs);
    const m = Math.floor(totalSecs / 60);
    const s = totalSecs % 60;
    const h = Math.floor(m / 60);
    if (h > 0) {
      const remM = m % 60;
      return `${h}:${remM.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
    }
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  // Determine resolution and 4K quality
  const w = videoDimensions?.width || media.width || 0;
  const h = videoDimensions?.height || media.height || 0;

  let qualityLabel = 'Full HD 1080p';
  let is4K = false;
  if (w >= 3800 || h >= 2000) {
    qualityLabel = '4K Ultra HD (2160p)';
    is4K = true;
  } else if (w >= 2400 || h >= 1400) {
    qualityLabel = '2K Quad HD (1440p)';
  } else if (w >= 1800 || h >= 1000) {
    qualityLabel = 'Full HD (1080p)';
  } else if (w >= 1200 || h >= 700) {
    qualityLabel = 'HD (720p)';
  } else if (w > 0) {
    qualityLabel = 'SD Video';
  }

  const absolutePublicUrl = typeof window !== 'undefined' 
    ? `${window.location.origin}${resolvedUrl}` 
    : resolvedUrl;

  const embedHtml = `<video controls width="100%" preload="metadata" playsinline>
  <source src="${absolutePublicUrl}" type="${media.mimeType || 'video/mp4'}">
  <source src="${streamUrl}" type="${media.mimeType || 'video/mp4'}">
  Your browser does not support HTML5 video streaming.
</video>`;

  const cleanHeaderTitle = activeItem ? (activeItem.title || (activeItem.caption ? activeItem.caption.split('\n')[0] : activeItem.originalName)) : '';

  const handleSaveQuickEdit = async () => {
    if (!activeItem) return;
    setIsSavingMeta(true);
    try {
      const res = await api.updateMedia(activeItem.id, {
        title: editTitle.trim(),
        caption: editCaption.trim(),
        soundtrackTitle: editSoundtrackTitle.trim(),
        audioUrl: editAudioUrl.trim()
      });

      if (res.success && res.data) {
        const updated = res.data;
        setCurrentMedia(updated);
        setIsEditingMeta(false);
        showToast('success', 'Video Details Saved', 'Unique title & caption saved for this video.');
        if (onMediaUpdated) {
          onMediaUpdated(updated);
        }
      } else {
        showToast('error', 'Update Failed', res.error || 'Failed to update video details');
      }
    } catch (err: any) {
      showToast('error', 'Error', err.message || 'Failed to update video');
    } finally {
      setIsSavingMeta(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/90 backdrop-blur-xl animate-in fade-in duration-200">
      <div className="relative w-full max-w-5xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/90 shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <div className="p-2 rounded-xl bg-purple-600/20 text-purple-400 border border-purple-500/30 shrink-0">
              <Film className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h3 className="text-base font-semibold text-white truncate" title={cleanHeaderTitle}>
                  {cleanHeaderTitle}
                </h3>
                {is4K && (
                  <span className="px-2 py-0.5 rounded-md bg-gradient-to-r from-purple-500 to-indigo-600 text-white font-extrabold text-[10px] tracking-wider shadow-sm uppercase shrink-0">
                    4K UHD
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400 truncate">
                {activeItem.originalName !== cleanHeaderTitle && (
                  <span className="text-slate-400 mr-1.5 font-mono">[{activeItem.originalName}] •</span>
                )}
                {formatBytes(activeItem.fileSize)} • {duration > 0 ? `${formatTime(duration)} duration • ` : ''}Uploaded {formatDate(activeItem.createdAt)}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto grid grid-cols-1 lg:grid-cols-3 gap-6 p-6">
          {/* Video Player Column */}
          <div className="lg:col-span-2 flex flex-col items-center justify-center bg-black rounded-xl overflow-hidden border border-slate-800 relative group min-h-[360px]">
            {/* 4K UHD Quality Badge Overlay */}
            <div className="absolute top-3 left-3 z-10 flex items-center gap-2 pointer-events-none">
              <div className="px-2.5 py-1 rounded-lg bg-slate-950/80 backdrop-blur-md border border-purple-500/40 flex items-center gap-1.5 shadow-lg">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-[11px] font-bold text-white tracking-wide">
                  {is4K ? '4K ULTRA HD' : qualityLabel}
                </span>
              </div>
              {w > 0 && h > 0 && (
                <div className="px-2 py-1 rounded-lg bg-slate-950/80 backdrop-blur-md border border-slate-800 text-[10px] font-mono text-slate-300">
                  {w}×{h}
                </div>
              )}
            </div>

            {/* Top Right Creator Floating Pill on Video */}
            {creatorProfile && (
              <div className="absolute top-3 right-3 z-10 flex items-center gap-2">
                <div className="flex items-center gap-2 px-2.5 py-1.5 rounded-full bg-slate-950/85 backdrop-blur-md border border-slate-700/80 shadow-lg">
                  <img
                    src={creatorProfile.avatarUrl}
                    alt={creatorProfile.name}
                    className="w-6 h-6 rounded-full border border-purple-400/60 object-cover bg-slate-800"
                    referrerPolicy="no-referrer"
                  />
                  <div className="flex flex-col">
                    <span className="text-[11px] font-bold text-white leading-tight flex items-center gap-1">
                      {creatorProfile.name}
                      {creatorProfile.isVerified && <UniqueMastiVerifiedBadge className="w-3 h-3" />}
                    </span>
                    <span className="text-[9px] text-purple-300 font-mono">
                      UID: {creatorProfile.id}
                    </span>
                    <span className="text-[9px] text-purple-300 font-mono">
                      {followersCount} {followersCount === 1 ? 'follower' : 'followers'}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={handleToggleFollow}
                    className={`ml-1 px-2.5 py-1 rounded-full text-[10px] font-bold transition-all flex items-center gap-1 ${
                      isFollowing
                        ? 'bg-slate-800 hover:bg-slate-700 text-emerald-400 border border-emerald-500/40 shadow-sm'
                        : 'bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white shadow-md'
                    }`}
                  >
                    {isFollowing ? (
                      <>
                        <UserCheck className="w-3 h-3" />
                        <span>Following</span>
                      </>
                    ) : (
                      <>
                        <UserPlus className="w-3 h-3" />
                        <span>Follow</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}

            {/* Native Video Stream */}
            <video
              ref={videoRef}
              key={resolvedUrl}
              src={resolvedUrl}
              playsInline
              preload="auto"
              onTimeUpdate={() => {
                if (videoRef.current) {
                  setCurrentTime(videoRef.current.currentTime);
                }
              }}
              onLoadedMetadata={() => {
                if (videoRef.current) {
                  setDuration(videoRef.current.duration);
                  if (videoRef.current.videoWidth && videoRef.current.videoHeight) {
                    setVideoDimensions({
                      width: videoRef.current.videoWidth,
                      height: videoRef.current.videoHeight
                    });
                  }
                }
                setIsLoading(false);
              }}
              onLoadStart={() => setIsLoading(true)}
              onLoadedData={() => {
                setIsLoading(false);
                setHasError(false);
              }}
              onCanPlay={() => setIsLoading(false)}
              onPlay={() => setIsPlaying(true)}
              onPause={() => setIsPlaying(false)}
              onError={() => {
                setIsLoading(false);
                setHasError(true);
              }}
              className="w-full h-full max-h-[460px] object-contain cursor-pointer"
              onClick={togglePlay}
            />

            {/* Loading Spinner */}
            {isLoading && (
              <div className="absolute inset-0 bg-black/50 backdrop-blur-sm flex flex-col items-center justify-center z-10">
                <div className="w-10 h-10 border-3 border-purple-500/30 border-t-purple-500 rounded-full animate-spin mb-2" />
                <span className="text-xs text-purple-300 font-medium">Buffering 4K Stream...</span>
              </div>
            )}

            {/* Error Overlay with Fallback & Direct Controls */}
            {hasError && (
              <div className="absolute inset-0 bg-slate-950/95 flex flex-col items-center justify-center p-6 text-center z-20 space-y-4">
                <div className="w-12 h-12 rounded-2xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400">
                  <AlertCircle className="w-6 h-6" />
                </div>
                <div className="max-w-md">
                  <h4 className="text-sm font-bold text-white">Video Playback Notice</h4>
                  <p className="text-xs text-slate-400 mt-1">
                    Your browser or player may require an alternate streaming channel or direct link to decode this video codec ({media.mimeType || 'video/mp4'}).
                  </p>
                </div>
                <div className="flex flex-wrap items-center justify-center gap-2">
                  <button
                    onClick={handleRetry}
                    className="flex items-center gap-1.5 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold shadow-md transition-all"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Retry Stream</span>
                  </button>
                  <a
                    href={resolvedUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-semibold transition-all"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>Open in New Tab</span>
                  </a>
                  <a
                    href={resolvedUrl}
                    download={media.originalName}
                    className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-semibold transition-all"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download File</span>
                  </a>
                </div>
              </div>
            )}

            {/* Custom Scrub Timeline & Player Controls */}
            <div className="w-full bg-slate-950/90 backdrop-blur-md border-t border-slate-800 px-4 py-3 flex flex-col gap-2 text-xs text-slate-300">
              {/* Scrub Seek Bar */}
              <div className="flex items-center gap-3">
                <span className="text-[11px] font-mono text-slate-300 w-12 text-right">
                  {formatTime(currentTime)}
                </span>
                <input
                  type="range"
                  min="0"
                  max={duration || 100}
                  step="0.1"
                  value={currentTime}
                  onChange={handleSeek}
                  className="flex-1 h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-purple-500 hover:accent-purple-400 transition-all"
                />
                <span className="text-[11px] font-mono text-slate-400 w-12">
                  {formatTime(duration)}
                </span>
              </div>

              {/* Bottom Controls Row */}
              <div className="flex items-center justify-between gap-2 pt-1">
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => skipTime(-10)}
                    className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
                    title="Rewind 10s"
                  >
                    <RotateCcw className="w-4 h-4" />
                  </button>

                  <button
                    onClick={togglePlay}
                    className="p-2 bg-purple-600 hover:bg-purple-500 text-white rounded-xl shadow-md transition-all flex items-center justify-center"
                    title={isPlaying ? 'Pause' : 'Play'}
                  >
                    {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-current ml-0.5" />}
                  </button>

                  <button
                    onClick={() => skipTime(10)}
                    className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
                    title="Forward 10s"
                  >
                    <RotateCw className="w-4 h-4" />
                  </button>

                  {/* Volume Control */}
                  <div className="flex items-center gap-1.5 ml-2 group/vol">
                    <button
                      onClick={toggleMute}
                      className="p-1.5 text-slate-400 hover:text-white transition-colors"
                      title={isMuted ? 'Unmute' : 'Mute'}
                    >
                      {isMuted || volume === 0 ? (
                        <VolumeX className="w-4 h-4 text-rose-400" />
                      ) : (
                        <Volume2 className="w-4 h-4" />
                      )}
                    </button>
                    <input
                      type="range"
                      min="0"
                      max="1"
                      step="0.05"
                      value={isMuted ? 0 : volume}
                      onChange={(e) => handleVolumeChange(parseFloat(e.target.value))}
                      className="w-16 h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-500"
                    />
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {/* Speed Selector */}
                  <div className="flex items-center gap-1 bg-slate-900 px-2 py-0.5 rounded-lg border border-slate-800 text-[11px]">
                    {[0.75, 1, 1.25, 1.5, 2].map(speed => (
                      <button
                        key={speed}
                        onClick={() => handleSpeedChange(speed)}
                        className={`px-1.5 py-0.5 rounded transition-colors ${
                          playbackRate === speed ? 'bg-purple-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        {speed}x
                      </button>
                    ))}
                  </div>

                  {/* PiP Button */}
                  <button
                    onClick={togglePiP}
                    className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
                    title="Picture in Picture"
                  >
                    <Tv className="w-4 h-4" />
                  </button>

                  {/* Fullscreen Button */}
                  <button
                    onClick={handleFullScreen}
                    className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
                    title="Fullscreen"
                  >
                    <Maximize className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Details & Delivery Sidebar */}
          <div className="flex flex-col gap-4">
            {/* Title & Caption Card */}
            <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Video Title & Caption</span>
                <button
                  type="button"
                  onClick={() => setIsEditingMeta(!isEditingMeta)}
                  className="flex items-center gap-1 text-[11px] font-semibold text-purple-400 hover:text-purple-300 transition-colors"
                >
                  <Edit2 className="w-3 h-3" />
                  <span>{isEditingMeta ? 'Cancel' : 'Quick Edit'}</span>
                </button>
              </div>

              {isEditingMeta ? (
                <div className="space-y-2.5 pt-1">
                  <div>
                    <label className="text-[10px] text-slate-400 uppercase font-semibold block mb-1">Title</label>
                    <input
                      type="text"
                      value={editTitle}
                      onChange={(e) => setEditTitle(e.target.value)}
                      placeholder="e.g. प्यार वाले को गाली देते"
                      className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white focus:outline-none focus:border-purple-500"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] text-slate-400 uppercase font-semibold block mb-1">Caption & Hashtags</label>
                    <textarea
                      rows={3}
                      value={editCaption}
                      onChange={(e) => setEditCaption(e.target.value)}
                      placeholder="e.g. @real #lipstick #shadowsense #mysenelook"
                      className="w-full px-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white focus:outline-none focus:border-purple-500 leading-relaxed"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[10px] text-slate-400 uppercase font-semibold block mb-1">Soundtrack Title</label>
                      <input
                        type="text"
                        value={editSoundtrackTitle}
                        onChange={(e) => setEditSoundtrackTitle(e.target.value)}
                        placeholder="Soundtrack name"
                        className="w-full px-2.5 py-1 bg-slate-950 border border-slate-700 rounded-lg text-xs text-amber-300 focus:outline-none focus:border-amber-500"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-slate-400 uppercase font-semibold block mb-1">Audio URL</label>
                      <input
                        type="text"
                        value={editAudioUrl}
                        onChange={(e) => setEditAudioUrl(e.target.value)}
                        placeholder="https://..."
                        className="w-full px-2.5 py-1 bg-slate-950 border border-slate-700 rounded-lg text-xs text-slate-300 focus:outline-none focus:border-amber-500"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end gap-2 pt-1">
                    <button
                      type="button"
                      disabled={isSavingMeta}
                      onClick={() => setIsEditingMeta(false)}
                      className="px-3 py-1 text-xs text-slate-400 hover:text-white"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      disabled={isSavingMeta}
                      onClick={handleSaveQuickEdit}
                      className="flex items-center gap-1.5 px-3 py-1 bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold rounded-lg transition-all shadow-md"
                    >
                      <Save className="w-3.5 h-3.5" />
                      <span>{isSavingMeta ? 'Saving...' : 'Save Details'}</span>
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  {activeItem.title && activeItem.title !== activeItem.originalName && (
                    <div className="text-sm font-bold text-white leading-snug">
                      <RichCaption
                        text={activeItem.title}
                        showAll={true}
                        className="text-sm font-bold text-white leading-snug"
                      />
                    </div>
                  )}
                  <RichCaption
                    text={activeItem.caption || activeItem.title || activeItem.originalName}
                    showAll={true}
                    className="text-xs font-medium text-slate-200 leading-relaxed"
                  />
                </>
              )}
            </div>

            {/* Audio Soundtrack Info */}
            <div className="p-3.5 rounded-xl bg-slate-950 border border-amber-900/40 flex items-center justify-between gap-3 shadow-md">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center justify-center shrink-0">
                  <Music className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <span className="text-[10px] uppercase font-bold text-amber-400/80 block">Soundtrack / Audio Link</span>
                  <span className="text-xs font-bold text-amber-200 truncate block">
                    {activeItem.music?.title || activeItem.soundtrackTitle || `Original Audio - ${activeItem.userName || 'Creator'}`}
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono truncate block">
                    {activeItem.music?.url || activeItem.audioUrl || `${window.location.origin}/api/v1/media/stream/${activeItem.id}`}
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  const audioLink = activeItem.music?.url || activeItem.audioUrl || `${window.location.origin}/api/v1/media/stream/${activeItem.id}`;
                  handleCopy(audioLink, 'Audio Track URL');
                }}
                className="px-3 py-1.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-bold shrink-0 flex items-center gap-1.5 transition-all"
              >
                {copiedType === 'Audio Track URL' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <LinkIcon className="w-3.5 h-3.5" />}
                <span>{copiedType === 'Audio Track URL' ? 'Copied' : 'Audio Link'}</span>
              </button>
            </div>

            {/* Creator Channel & Follow Card */}
            {creatorProfile && (
              <div className="p-4 rounded-xl bg-gradient-to-b from-slate-900 to-slate-950 border border-purple-900/40 shadow-lg space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <img
                      src={creatorProfile.avatarUrl}
                      alt={creatorProfile.name}
                      className="w-12 h-12 rounded-2xl border-2 border-purple-500/50 shadow-md object-cover bg-slate-800 shrink-0"
                      referrerPolicy="no-referrer"
                    />
                    <div>
                      <h3 className="text-sm font-bold text-white flex items-center gap-1.5 leading-tight">
                        {creatorProfile.name}
                        {creatorProfile.isVerified && <UniqueMastiVerifiedBadge className="w-4 h-4" />}
                      </h3>
                      <div className="flex flex-col gap-0.5 mt-0.5">
                        <span className="text-xs text-purple-400 font-medium">
                          {creatorProfile.username}
                        </span>
                        <span className="text-[10px] font-mono text-slate-500">
                          UID: {creatorProfile.id}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-0.5 line-clamp-1">
                        {creatorProfile.bio}
                      </p>
                    </div>
                  </div>

                  {/* Follow / Unfollow Action Button */}
                  <button
                    type="button"
                    onClick={handleToggleFollow}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 flex items-center gap-1.5 shadow-md ${
                      isFollowing
                        ? 'bg-slate-800 hover:bg-slate-700 text-emerald-400 border border-emerald-500/50 hover:border-emerald-400'
                        : 'bg-gradient-to-r from-purple-600 via-indigo-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white shadow-purple-900/30'
                    }`}
                  >
                    {isFollowing ? (
                      <>
                        <UserCheck className="w-3.5 h-3.5" />
                        <span>Following</span>
                      </>
                    ) : (
                      <>
                        <UserPlus className="w-3.5 h-3.5" />
                        <span>Follow</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Creator Stats */}
                <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-800/80 text-center">
                  <div className="p-2 bg-slate-900/80 rounded-lg border border-slate-800">
                    <span className="text-xs font-bold text-purple-300 block">{followersCount}</span>
                    <span className="text-[10px] text-slate-400 uppercase tracking-wider">Followers</span>
                  </div>
                  <div className="p-2 bg-slate-900/80 rounded-lg border border-slate-800">
                    <span className="text-xs font-bold text-slate-200 block">{creatorProfile.followingCount || 48}</span>
                    <span className="text-[10px] text-slate-400 uppercase tracking-wider">Following</span>
                  </div>
                </div>

                {/* Social Media Links if present */}
                {creatorProfile.socialLinks && (
                  <div className="flex flex-wrap items-center gap-1.5 pt-1">
                    {creatorProfile.socialLinks.instagram && (
                      <a
                        href={creatorProfile.socialLinks.instagram}
                        target="_blank"
                        rel="noreferrer"
                        className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-pink-950/50 hover:bg-pink-900/60 text-pink-300 border border-pink-800/40 text-[11px] font-semibold transition-colors"
                      >
                        <span className="text-pink-400">📸</span> Instagram
                      </a>
                    )}
                    {creatorProfile.socialLinks.youtube && (
                      <a
                        href={creatorProfile.socialLinks.youtube}
                        target="_blank"
                        rel="noreferrer"
                        className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-rose-950/50 hover:bg-rose-900/60 text-rose-300 border border-rose-800/40 text-[11px] font-semibold transition-colors"
                      >
                        <span className="text-rose-400">▶</span> YouTube
                      </a>
                    )}
                    {creatorProfile.socialLinks.website && (
                      <a
                        href={creatorProfile.socialLinks.website}
                        target="_blank"
                        rel="noreferrer"
                        className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-indigo-950/50 hover:bg-indigo-900/60 text-indigo-300 border border-indigo-800/40 text-[11px] font-semibold transition-colors"
                      >
                        <Globe className="w-3 h-3 text-indigo-400" /> Website
                      </a>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* Direct URL Box */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span className="font-semibold uppercase tracking-wider text-[11px] text-purple-400 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" /> 4K Direct Streaming URL
                </span>
                <span className="text-emerald-400 text-[11px] font-semibold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  Active CDN
                </span>
              </div>
              <div className="flex items-center gap-2 bg-slate-900 p-2 rounded-lg border border-slate-800 font-mono text-xs text-slate-300 break-all">
                <span className="truncate flex-1">{absolutePublicUrl}</span>
                <button
                  onClick={() => handleCopy(absolutePublicUrl, 'Direct Streaming URL')}
                  className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-md transition-colors shrink-0"
                  title="Copy Direct URL"
                >
                  {copiedType === 'Direct Streaming URL' ? (
                    <Check className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                </button>
              </div>
            </div>

            {/* Social Engagement Actions */}
            <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-300">Social Engagement</span>
                <span className="text-[10px] font-mono text-slate-500">
                  Uploaded by: {media.userId ? media.userId.slice(0, 10) : 'creator'}
                </span>
              </div>

              <div className="grid grid-cols-3 gap-2">
                {/* Like Button */}
                <button
                  type="button"
                  onClick={handleToggleLike}
                  className={`flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-xl text-xs font-bold transition-all border ${
                    isLiked
                      ? 'bg-rose-500/20 text-rose-300 border-rose-500/40 shadow-sm shadow-rose-500/20'
                      : 'bg-slate-950 text-slate-300 hover:text-rose-400 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <Heart className={`w-4 h-4 ${isLiked ? 'fill-rose-500 text-rose-500' : ''}`} />
                  <span>{likesCount} {likesCount === 1 ? 'Like' : 'Likes'}</span>
                </button>

                {/* Comments Button */}
                <button
                  type="button"
                  onClick={() => setShowCommentsDrawer(true)}
                  className="flex items-center justify-center gap-1.5 py-2 px-2.5 bg-slate-950 hover:bg-indigo-600/20 text-slate-300 hover:text-indigo-300 border border-slate-800 hover:border-indigo-500/40 rounded-xl text-xs font-bold transition-all"
                >
                  <MessageSquare className="w-4 h-4 text-indigo-400" />
                  <span>{commentsCount} Comments</span>
                </button>

                {/* Share Button */}
                <button
                  type="button"
                  onClick={handleShareVideo}
                  className="flex items-center justify-center gap-1.5 py-2 px-2.5 bg-slate-950 hover:bg-emerald-600/20 text-slate-300 hover:text-emerald-300 border border-slate-800 hover:border-emerald-500/40 rounded-xl text-xs font-bold transition-all"
                >
                  <Share2 className="w-4 h-4 text-emerald-400" />
                  <span>{sharesCount} Shares</span>
                </button>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="grid grid-cols-2 gap-2">

              <button
                onClick={() => handleCopy(embedHtml, 'HTML5 Embed Snippet')}
                className="flex items-center justify-center gap-2 p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold border border-slate-700 transition-all"
              >
                <Code className="w-3.5 h-3.5 text-cyan-400" />
                <span>Copy 4K Embed</span>
              </button>

              <a
                href={resolvedUrl}
                download={media.originalName}
                target="_blank"
                rel="noreferrer"
                className="flex items-center justify-center gap-2 p-2.5 bg-purple-600/20 hover:bg-purple-600/30 text-purple-300 border border-purple-500/30 rounded-xl text-xs font-semibold transition-all"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download Original</span>
              </a>
            </div>

            {/* File & Stream Metadata */}
            <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800/80 space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5" /> Video Specifications
              </h4>
              <div className="grid grid-cols-2 gap-2.5 text-xs">
                <div className="p-2 bg-slate-900 rounded-lg border border-slate-800/80">
                  <span className="text-slate-500 block text-[10px] uppercase">Resolution</span>
                  <span className="font-semibold text-purple-300">
                    {w > 0 && h > 0 ? `${w} × ${h} (${is4K ? '4K UHD' : 'HD'})` : qualityLabel}
                  </span>
                </div>
                <div className="p-2 bg-slate-900 rounded-lg border border-slate-800/80">
                  <span className="text-slate-500 block text-[10px] uppercase">Duration</span>
                  <span className="font-semibold text-slate-200">
                    {duration > 0 ? formatTime(duration) : 'Stream live'}
                  </span>
                </div>
                <div className="p-2 bg-slate-900 rounded-lg border border-slate-800/80">
                  <span className="text-slate-500 block text-[10px] uppercase">File Size</span>
                  <span className="font-semibold text-slate-200">{formatBytes(media.fileSize)}</span>
                </div>
                <div className="p-2 bg-slate-900 rounded-lg border border-slate-800/80">
                  <span className="text-slate-500 block text-[10px] uppercase">Codec / Format</span>
                  <span className="font-semibold text-slate-200">{media.mimeType || 'video/mp4'}</span>
                </div>
                <div className="p-2 bg-slate-900 rounded-lg border border-slate-800/80">
                  <span className="text-slate-500 block text-[10px] uppercase">Folder</span>
                  <span className="font-semibold text-slate-200 capitalize">{media.folder || 'general'}</span>
                </div>
                <div className="p-2 bg-slate-900 rounded-lg border border-slate-800/80">
                  <span className="text-slate-500 block text-[10px] uppercase">Asset ID</span>
                  <span className="font-mono text-[11px] text-slate-300 truncate block">{media.id}</span>
                </div>
              </div>

              {/* Tags */}
              {media.tags && media.tags.length > 0 && (
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase mb-1.5">Tags</span>
                  <div className="flex flex-wrap gap-1.5">
                    {media.tags.map((t, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-0.5 rounded-md bg-purple-950/80 text-purple-300 border border-purple-800/50 text-[11px]"
                      >
                        #{t}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      {/* Comments Drawer for Video Player */}
      {showCommentsDrawer && activeItem && (
        <CommentsDrawer
          media={activeItem}
          isOpen={showCommentsDrawer}
          onClose={() => setShowCommentsDrawer(false)}
          onCommentsUpdated={(mediaId, count) => {
            setCommentsCount(count);
          }}
        />
      )}
    </div>
  );
};


