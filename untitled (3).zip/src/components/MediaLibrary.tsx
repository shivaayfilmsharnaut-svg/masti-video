import React, { useState, useEffect, useMemo } from 'react';
import { MediaFile, MediaType, CreatorProfileItem } from '../types.js';
import { api, formatBytes, formatDate, resolveMediaUrl } from '../services/api.js';
import { useAuth } from '../context/AuthContext.js';
import { useToast } from './Toast.js';
import { PosterSelectorModal } from './PosterSelectorModal.js';
import { CommentsDrawer } from './CommentsDrawer.js';
import { RichCaption } from './RichCaption.js';
import { UserMonetizationCard } from './UserMonetizationCard.js';
import { UserFoldersFullscreenModal } from './UserFoldersFullscreenModal.js';
import {
  Film,
  Image as ImageIcon,
  Music,
  Grid,
  List,
  Maximize2,
  Search,
  Filter,
  ArrowUpDown,
  Copy,
  Trash2,
  ExternalLink,
  Play,
  Check,
  MoreVertical,
  Edit2,
  Folder,
  Tag,
  CheckSquare,
  Square,
  Sparkles,
  Download,
  Volume2,
  Disc,
  Heart,
  MessageSquare,
  Share2,
  User as UserIcon,
  UserPlus,
  UserCheck,
  Users,
  CheckCircle2,
  Globe,
  Info,
  Calendar,
  Layers,
  FileVideo,
  X,
  Mail,
  ShieldCheck,
  Flame,
  Activity,
  Link as LinkIcon,
  Headphones,
  Wallet,
  IndianRupee
} from 'lucide-react';

interface MediaLibraryProps {
  media: MediaFile[];
  loading: boolean;
  onRefresh: () => void;
  onSelectVideo: (media: MediaFile) => void;
  onSelectImage: (media: MediaFile) => void;
  onSelectAudio?: (media: MediaFile) => void;
  onNavigateToUpload: () => void;
}

const UniqueMastiVerifiedBadge = ({ className = "w-3.5 h-3.5" }: { className?: string }) => (
  <svg 
    aria-label="Verified" 
    className={`shrink-0 drop-shadow-[0_0_3px_rgba(168,85,247,0.6)] ${className}`} 
    viewBox="0 0 100 100" 
    fill="none" 
    xmlns="http://www.w3.org/2000/svg"
  >
    <defs>
      <linearGradient id="mastiPremiumGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#00F0FF" />
        <stop offset="50%" stopColor="#8A2BE2" />
        <stop offset="100%" stopColor="#FF1493" />
      </linearGradient>
    </defs>
    <g transform="translate(50, 50)">
      <rect x="-40" y="-40" width="80" height="80" rx="18" fill="url(#mastiPremiumGrad)" />
      <rect x="-40" y="-40" width="80" height="80" rx="18" fill="url(#mastiPremiumGrad)" transform="rotate(45)" />
    </g>
    <path d="M30 52 L43 65 L70 36" stroke="white" strokeWidth="10" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

export const MediaLibrary: React.FC<MediaLibraryProps> = ({
  media,
  loading,
  onRefresh,
  onSelectVideo,
  onSelectImage,
  onSelectAudio,
  onNavigateToUpload
}) => {
  const [activeTab, setActiveTab] = useState<'all' | 'video' | 'audio' | 'image' | 'profiles'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFolder, setSelectedFolder] = useState<string>('all');
  const [sortBy, setSortBy] = useState<string>('newest');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [folderStats, setFolderStats] = useState<Array<{
    name: string;
    isUserFolder: boolean;
    userId?: string;
    userName?: string;
    userEmail?: string;
    userAvatar?: string;
    count: number;
    totalSize: number;
    videoCount: number;
  }>>([]);

  // Creators directory state
  const [creatorsList, setCreatorsList] = useState<CreatorProfileItem[]>([]);
  const [loadingCreators, setLoadingCreators] = useState(false);
  const [selectedCreatorDetail, setSelectedCreatorDetail] = useState<CreatorProfileItem | null>(null);
  const [creatorViewMode, setCreatorViewMode] = useState<'compact' | 'cards'>('compact');

  // User Folders Fullscreen Directory Modal state
  const [isUserFoldersFullscreenOpen, setIsUserFoldersFullscreenOpen] = useState(false);
  const [selectedFullscreenFolder, setSelectedFullscreenFolder] = useState<string | null>(null);
  const [selectedFullscreenUserId, setSelectedFullscreenUserId] = useState<string | null>(null);

  // Video inspect / metadata detail modal
  const [inspectedMedia, setInspectedMedia] = useState<MediaFile | null>(null);

  // Edit modal state
  const [editingMedia, setEditingMedia] = useState<MediaFile | null>(null);
  const [editName, setEditName] = useState('');
  const [editTitle, setEditTitle] = useState('');
  const [editCaption, setEditCaption] = useState('');
  const [editUserName, setEditUserName] = useState('');
  const [editUserAvatar, setEditUserAvatar] = useState('');
  const [editUserId, setEditUserId] = useState('');
  const [editSoundtrackTitle, setEditSoundtrackTitle] = useState('');
  const [editAudioUrl, setEditAudioUrl] = useState('');
  const [editFolder, setEditFolder] = useState('');
  const [editTags, setEditTags] = useState('');
  const [copiedAudioId, setCopiedAudioId] = useState<string | null>(null);

  // Delete confirmation modal state
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [isBatchDeleting, setIsBatchDeleting] = useState(false);

  // Poster selector modal state
  const [posterModalMedia, setPosterModalMedia] = useState<MediaFile | null>(null);

  // Social interactive states
  const [commentDrawerMedia, setCommentDrawerMedia] = useState<MediaFile | null>(null);
  const [likedMediaIds, setLikedMediaIds] = useState<Set<string>>(new Set());
  const [followingUserIds, setFollowingUserIds] = useState<Set<string>>(new Set());
  const [likesCounts, setLikesCounts] = useState<Record<string, number>>({});
  const [commentsCounts, setCommentsCounts] = useState<Record<string, number>>({});
  const [sharesCounts, setSharesCounts] = useState<Record<string, number>>({});

  const { isAuthenticated, user, isAdmin } = useAuth();
  const { showToast } = useToast();

  const fetchCreators = () => {
    setLoadingCreators(true);
    api.getCreators()
      .then((res) => {
        if (res.success && Array.isArray(res.data)) {
          const seen = new Set<string>();
          const uniqueCreators = res.data.filter((c: CreatorProfileItem) => {
            if (!c.id || seen.has(c.id)) return false;
            seen.add(c.id);
            return true;
          });
          setCreatorsList(uniqueCreators);
        }
      })
      .catch((e: any) => console.warn('Could not fetch creators:', e?.message))
      .finally(() => setLoadingCreators(false));
  };

  const fetchFolders = () => {
    api.getFolders()
      .then((res) => {
        if (res.success && Array.isArray(res.data)) {
          setFolderStats(res.data);
        }
      })
      .catch((e: any) => console.warn('Could not fetch folders:', e?.message));
  };

  useEffect(() => {
    fetchCreators();
    fetchFolders();
  }, []);

  useEffect(() => {
    fetchFolders();
  }, [media.length]);

  useEffect(() => {
    if (user?.id) {
      api.getUserLikedMediaIds(user.id).then((res) => {
        if (res.success && Array.isArray(res.likedMediaIds)) {
          setLikedMediaIds(new Set(res.likedMediaIds));
        }
      }).catch((e: any) => console.warn('Could not fetch user likes:', e?.message));

      api.getFollowing(user.id).then((res) => {
        if (res.success && Array.isArray(res.data)) {
          const ids = res.data.map((f: any) => f.followingId);
          setFollowingUserIds(new Set(ids));
        }
      }).catch((e: any) => console.warn('Could not fetch user following list:', e?.message));
    }
  }, [user?.id]);

  const handleToggleFollowCreator = async (creatorId: string, creatorName: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const isCurrentlyFollowing = followingUserIds.has(creatorId);
    setFollowingUserIds((prev) => {
      const next = new Set(prev);
      if (isCurrentlyFollowing) {
        next.delete(creatorId);
      } else {
        next.add(creatorId);
      }
      return next;
    });

    // Update local creator follower count
    setCreatorsList((prev) =>
      prev.map((c) => {
        if (c.id === creatorId) {
          return {
            ...c,
            followersCount: isCurrentlyFollowing ? Math.max(0, c.followersCount - 1) : c.followersCount + 1
          };
        }
        return c;
      })
    );

    try {
      const res = await api.toggleFollow(creatorId, creatorName, user?.id || 'anon_user', user?.name || 'Masti Viewer');
      if (res.success && res.data) {
        setFollowingUserIds((prev) => {
          const next = new Set(prev);
          if (res.data.isFollowing) {
            next.add(creatorId);
          } else {
            next.delete(creatorId);
          }
          return next;
        });
        showToast(
          'success',
          res.data.isFollowing ? `Following ${creatorName}` : `Unfollowed ${creatorName}`,
          res.data.isFollowing ? 'Creator added to your following list' : 'Creator removed from following'
        );
      }
    } catch (err: any) {
      showToast('error', 'Error', err?.message || 'Could not update follow status');
    }
  };

  const handleToggleLike = async (item: MediaFile, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      const res = await api.toggleLike(item.id, user?.id, user?.name);
      if (res.success && res.data) {
        setLikedMediaIds((prev) => {
          const next = new Set(prev);
          if (res.data.isLiked) {
            next.add(item.id);
          } else {
            next.delete(item.id);
          }
          return next;
        });
        setLikesCounts((prev) => ({
          ...prev,
          [item.id]: res.data.likesCount
        }));
        showToast('info', res.data.isLiked ? 'Liked' : 'Unliked', res.data.isLiked ? 'Saved to your likes' : 'Like removed');
      }
    } catch (err: any) {
      showToast('error', 'Error', err?.message || 'Could not update like');
    }
  };

  const handleShareMedia = async (item: MediaFile, e: React.MouseEvent) => {
    e.stopPropagation();
    const url = window.location.origin + resolveMediaUrl(item.fileUrl);
    try {
      if (navigator.clipboard) {
        await navigator.clipboard.writeText(url);
      }
      const res = await api.recordShare(item.id, 'clipboard', url, user?.id);
      if (res.success && res.data) {
        setSharesCounts((prev) => ({
          ...prev,
          [item.id]: res.data.totalShares
        }));
      }
      showToast('success', 'Link Copied & Share Saved', 'Media link copied to clipboard and recorded in Masti Bash.');
    } catch (err: any) {
      showToast('info', 'Link Copied', url);
    }
  };

  // Extract unique folders including registered user folders
  const allFolders: string[] = Array.from(new Set([
    ...folderStats.map(f => f.name),
    ...media.map(m => m.folder || 'general')
  ])).filter((f): f is string => Boolean(f));

  // Format duration helper
  const formatDuration = (seconds?: number) => {
    if (!seconds || isNaN(seconds)) return null;
    const totalSecs = Math.floor(seconds);
    const m = Math.floor(totalSecs / 60);
    const s = totalSecs % 60;
    const h = Math.floor(m / 60);
    if (h > 0) {
      const remM = m % 60;
      return `${h}:${remM.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
    }
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  // Filter and sort items locally
  const filteredMedia = media
    .filter(item => {
      // Tab filter
      if (activeTab === 'profiles') return true;
      if (activeTab !== 'all' && item.mediaType !== activeTab) return false;
      // Folder filter
      if (selectedFolder !== 'all' && (item.folder || 'general').toLowerCase() !== selectedFolder.toLowerCase()) {
        return false;
      }
      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchesName = item.originalName.toLowerCase().includes(q) || (item.title && item.title.toLowerCase().includes(q));
        const matchesTag = item.tags?.some(t => t.toLowerCase().includes(q));
        const matchesFolder = item.folder?.toLowerCase().includes(q);
        const matchesUser = (item.userName && item.userName.toLowerCase().includes(q)) || (item.userId && item.userId.toLowerCase().includes(q));
        if (!matchesName && !matchesTag && !matchesFolder && !matchesUser) return false;
      }
      return true;
    })
    .sort((a, b) => {
      if (sortBy === 'newest') return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      if (sortBy === 'oldest') return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
      if (sortBy === 'name_asc') return a.originalName.localeCompare(b.originalName);
      if (sortBy === 'name_desc') return b.originalName.localeCompare(a.originalName);
      if (sortBy === 'size_desc') return b.fileSize - a.fileSize;
      if (sortBy === 'size_asc') return a.fileSize - b.fileSize;
      return 0;
    });

  // Filter creators list
  const filteredCreators = useMemo(() => {
    const seen = new Set<string>();
    return creatorsList.filter(creator => {
      if (!creator.id || seen.has(creator.id)) return false;
      seen.add(creator.id);
      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase().trim();
      return (
        creator.name.toLowerCase().includes(q) ||
        creator.username.toLowerCase().includes(q) ||
        creator.email.toLowerCase().includes(q) ||
        creator.id.toLowerCase().includes(q) ||
        (creator.bio && creator.bio.toLowerCase().includes(q))
      );
    });
  }, [creatorsList, searchQuery]);

  const handleCopyUrl = (item: MediaFile, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    navigator.clipboard.writeText(item.fileUrl);
    setCopiedId(item.id);
    showToast('success', 'Direct URL Copied', item.originalName);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleToggleSelect = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setSelectedIds(prev =>
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const handleSelectAll = () => {
    if (selectedIds.length === filteredMedia.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filteredMedia.map(m => m.id));
    }
  };

  const handleCopyAudioUrl = (item: MediaFile, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const audioLink = item.music?.url || (item.mediaType === 'audio' ? item.fileUrl : `${window.location.origin}/api/v1/media/stream/${item.id}`);
    navigator.clipboard.writeText(audioLink);
    setCopiedAudioId(item.id);
    showToast('success', 'Audio Track Link Copied', item.music?.title || 'Original Soundtrack URL');
    setTimeout(() => setCopiedAudioId(null), 2000);
  };

  const openEditModal = (item: MediaFile, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setEditingMedia(item);
    setEditName(item.originalName || '');
    setEditTitle(item.title || '');
    setEditCaption(item.caption || item.title || '');
    setEditUserName(item.userName || '');
    setEditUserAvatar(item.userAvatar || '');
    setEditUserId(item.userId || '');
    setEditSoundtrackTitle(item.music?.title || '');
    setEditAudioUrl(item.music?.url || '');
    setEditFolder(item.folder || '');
    setEditTags(item.tags ? item.tags.join(', ') : '');
  };

  const handleSaveEdit = async () => {
    if (!editingMedia) return;
    try {
      const tagsArray = editTags
        .split(',')
        .map(t => t.trim())
        .filter(Boolean);

      const res = await api.updateMedia(editingMedia.id, {
        originalName: editName,
        title: editTitle || editName,
        caption: editCaption,
        userName: editUserName,
        userAvatar: editUserAvatar,
        userId: editUserId,
        soundtrackTitle: editSoundtrackTitle,
        audioUrl: editAudioUrl,
        music: {
          title: editSoundtrackTitle,
          url: editAudioUrl
        },
        folder: editFolder || 'general',
        tags: tagsArray
      });

      if (res.success) {
        showToast('success', 'Asset & Details Updated', 'Metadata, title, creator DP and audio link saved.');
        setEditingMedia(null);
        onRefresh();
      } else {
        showToast('error', 'Update Failed', res.error || 'Could not update asset.');
      }
    } catch (err: any) {
      showToast('error', 'Update Failed', err?.message || 'Server error.');
    }
  };

  const handleDeleteSingle = async () => {
    if (!deleteConfirmId) return;
    try {
      const res = await api.deleteMedia(deleteConfirmId);
      if (res.success) {
        showToast('success', 'Asset Deleted', 'File removed from cloud storage.');
        setDeleteConfirmId(null);
        setSelectedIds(prev => prev.filter(id => id !== deleteConfirmId));
        onRefresh();
      } else {
        showToast('error', 'Delete Failed', res.error || 'Could not delete file.');
      }
    } catch (err: any) {
      showToast('error', 'Delete Failed', err?.message || 'Server error.');
    }
  };

  const handleBatchDelete = async () => {
    if (selectedIds.length === 0) return;
    try {
      const res = await api.batchDeleteMedia(selectedIds);
      if (res.success) {
        showToast('success', 'Batch Deleted', `Deleted ${res.deletedCount || selectedIds.length} files.`);
        setSelectedIds([]);
        setIsBatchDeleting(false);
        onRefresh();
      } else {
        showToast('error', 'Batch Delete Failed', res.error || 'Error deleting batch.');
      }
    } catch (err: any) {
      showToast('error', 'Batch Delete Failed', err?.message || 'Server error.');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header and Quick Stats */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-indigo-400" />
            <span>Masti Media & Profiles Library</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Browse videos, photos, audio tracks, and explore registered Masti creators with full UID profile records.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          {selectedIds.length > 0 && (
            <div className="flex items-center gap-2 bg-indigo-950/80 border border-indigo-500/30 px-3 py-1.5 rounded-xl text-xs text-indigo-200">
              <span className="font-semibold">{selectedIds.length} selected</span>
              <button
                onClick={() => setIsBatchDeleting(true)}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-rose-600/80 hover:bg-rose-600 text-white text-xs font-semibold transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete Selected</span>
              </button>
            </div>
          )}

          <button
            type="button"
            onClick={onNavigateToUpload}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl shadow-lg shadow-indigo-600/20 transition-all"
          >
            <span>+ Upload Media</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          {/* Media & Profile Tabs */}
          <div className="flex items-center gap-1.5 p-1 bg-slate-950 rounded-xl border border-slate-800 self-start flex-wrap">
            <button
              onClick={() => setActiveTab('all')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'all'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              All Assets ({media.length})
            </button>
            <button
              onClick={() => setActiveTab('video')}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'video'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Film className="w-3.5 h-3.5" />
              <span>Videos ({media.filter(m => m.mediaType === 'video').length})</span>
            </button>
            <button
              onClick={() => setActiveTab('image')}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'image'
                  ? 'bg-cyan-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <ImageIcon className="w-3.5 h-3.5" />
              <span>Images ({media.filter(m => m.mediaType === 'image').length})</span>
            </button>
            <button
              onClick={() => setActiveTab('audio')}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'audio'
                  ? 'bg-amber-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Music className="w-3.5 h-3.5" />
              <span>Audio ({media.filter(m => m.mediaType === 'audio').length})</span>
            </button>
            
            {/* New Profile / Creator Details Tab */}
            <button
              onClick={() => {
                setActiveTab('profiles');
                fetchCreators();
              }}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'profiles'
                  ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-sm'
                  : 'text-purple-300 hover:text-white'
              }`}
            >
              <Users className="w-3.5 h-3.5 text-pink-300" />
              <span>User Profiles ({creatorsList.length})</span>
            </button>
          </div>

          {/* Search, Folder, Sort, and View Mode */}
          <div className="flex flex-wrap items-center gap-2.5">
            {/* Search Input */}
            <div className="relative flex-1 sm:w-64">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder={activeTab === 'profiles' ? "Search creator name, user ID, bio..." : "Search title, user ID, tags, folder..."}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3.5 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>

            {/* Folder Dropdown (Hide for Profiles Tab) */}
            {activeTab !== 'profiles' && allFolders.length > 0 && (
              <select
                value={selectedFolder}
                onChange={(e) => setSelectedFolder(e.target.value)}
                className="px-3 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-300 focus:outline-none focus:border-indigo-500"
              >
                <option value="all">All Folders</option>
                {allFolders.map(f => (
                  <option key={f} value={f}>{f.toUpperCase()}</option>
                ))}
              </select>
            )}

            {/* Sort Dropdown */}
            {activeTab !== 'profiles' && (
              <div className="relative flex items-center">
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="px-3 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-300 focus:outline-none focus:border-indigo-500"
                >
                  <option value="newest">Newest First</option>
                  <option value="oldest">Oldest First</option>
                  <option value="name_asc">Name (A-Z)</option>
                  <option value="name_desc">Name (Z-A)</option>
                  <option value="size_desc">Size (Large to Small)</option>
                  <option value="size_asc">Size (Small to Large)</option>
                </select>
              </div>
            )}

            {/* View Mode Toggle (Hide for Profiles Tab) */}
            {activeTab !== 'profiles' && (
              <div className="flex items-center p-1 bg-slate-950 rounded-xl border border-slate-800">
                <button
                  type="button"
                  onClick={() => setViewMode('grid')}
                  className={`p-1.5 rounded-lg transition-colors ${
                    viewMode === 'grid' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200'
                  }`}
                  title="Grid View"
                >
                  <Grid className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => setViewMode('list')}
                  className={`p-1.5 rounded-lg transition-colors ${
                    viewMode === 'list' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-slate-200'
                  }`}
                  title="List View"
                >
                  <List className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </div>
        </div>

        {/* User Dedicated Folders Quick Bar */}
        {activeTab !== 'profiles' && folderStats.length > 0 && (
          <div className="pt-2 border-t border-slate-800/60">
            <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-thin">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1 shrink-0">
                <Folder className="w-3 h-3 text-indigo-400" />
                <span>User Folders:</span>
              </span>

              {/* Prominent Fullscreen Directory Launcher */}
              <button
                type="button"
                onClick={() => {
                  setSelectedFullscreenFolder(null);
                  setSelectedFullscreenUserId(null);
                  setIsUserFoldersFullscreenOpen(true);
                }}
                className="flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-bold bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white shadow-md shadow-purple-950/40 shrink-0 transition-all cursor-pointer"
                title="Open Full Screen User ID List & Multi-Select Directory"
              >
                <Maximize2 className="w-3.5 h-3.5 text-purple-200" />
                <span>Fullscreen Users Directory ({folderStats.length})</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedFolder('all')}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold shrink-0 transition-all ${
                  selectedFolder === 'all'
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'bg-slate-950 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                All Assets ({media.length})
              </button>

              {folderStats.map((f) => {
                const isSelected = selectedFolder.toLowerCase() === f.name.toLowerCase();
                return (
                  <button
                    key={f.name}
                    type="button"
                    onClick={() => {
                      // Clicking on a user folder opens Fullscreen view focusing this user's ID & profile!
                      setSelectedFullscreenFolder(f.name);
                      setSelectedFullscreenUserId(f.userId || f.userEmail || f.name);
                      setIsUserFoldersFullscreenOpen(true);
                    }}
                    className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold shrink-0 transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-indigo-600 text-white shadow-sm border border-indigo-400'
                        : 'bg-slate-950 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800'
                    }`}
                    title={`Click to open full screen ID list & details for ${f.userName || f.name}`}
                  >
                    {f.userAvatar ? (
                      <img
                        src={f.userAvatar}
                        alt={f.userName || f.name}
                        className="w-4 h-4 rounded-full object-cover border border-white/20"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <Folder className={`w-3 h-3 ${isSelected ? 'text-white' : 'text-indigo-400'}`} />
                    )}
                    <span>{f.userName || f.name}</span>
                    <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-bold ${
                      isSelected ? 'bg-indigo-800 text-indigo-100' : 'bg-slate-800 text-slate-400'
                    }`}>
                      {f.count}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Action Header bar */}
        {activeTab !== 'profiles' && (
          <div className="flex items-center justify-between text-xs text-slate-400 pt-2 border-t border-slate-800/80">
            <button
              onClick={handleSelectAll}
              className="flex items-center gap-1.5 text-slate-300 hover:text-white"
            >
              {selectedIds.length === filteredMedia.length && filteredMedia.length > 0 ? (
                <CheckSquare className="w-4 h-4 text-indigo-400" />
              ) : (
                <Square className="w-4 h-4" />
              )}
              <span>Select All ({filteredMedia.length} items)</span>
            </button>
            <span>Showing {filteredMedia.length} results</span>
          </div>
        )}
      </div>

      {/* ----------------- PROFILES DIRECTORY TAB ----------------- */}
      {activeTab === 'profiles' ? (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 p-3.5 rounded-2xl border border-slate-800">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Users className="w-4 h-4 text-purple-400" />
                <span>Registered Masti Creators & User Details</span>
                <span className="text-xs text-purple-300 bg-purple-950/60 px-2 py-0.5 rounded-full border border-purple-800/50 font-mono">
                  {filteredCreators.length}
                </span>
              </h3>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Compact ID list view • Click on any User ID to inspect full profile details
              </p>
            </div>

            <div className="flex items-center gap-2">
              {/* Fullscreen Multi-Select Button */}
              <button
                type="button"
                onClick={() => {
                  setSelectedFullscreenFolder(null);
                  setSelectedFullscreenUserId(null);
                  setIsUserFoldersFullscreenOpen(true);
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-bold shadow-md shadow-purple-950/40 transition-all cursor-pointer"
              >
                <Maximize2 className="w-3.5 h-3.5" />
                <span>Open Fullscreen Directory</span>
              </button>

              {/* View Mode Toggle (Compact List vs Big Cards) */}
              <div className="flex items-center p-0.5 bg-slate-950 rounded-xl border border-slate-800 text-xs">
                <button
                  type="button"
                  onClick={() => setCreatorViewMode('compact')}
                  className={`px-2.5 py-1 rounded-lg font-semibold flex items-center gap-1 transition-all cursor-pointer ${
                    creatorViewMode === 'compact'
                      ? 'bg-purple-600 text-white'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                  title="Compact List View (Chhota Chhota list)"
                >
                  <List className="w-3.5 h-3.5" />
                  <span>List</span>
                </button>
                <button
                  type="button"
                  onClick={() => setCreatorViewMode('cards')}
                  className={`px-2.5 py-1 rounded-lg font-semibold flex items-center gap-1 transition-all cursor-pointer ${
                    creatorViewMode === 'cards'
                      ? 'bg-purple-600 text-white'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                  title="Card View"
                >
                  <Grid className="w-3.5 h-3.5" />
                  <span>Cards</span>
                </button>
              </div>
            </div>
          </div>

          {loadingCreators ? (
            <div className="flex flex-col items-center justify-center p-16 space-y-3">
              <div className="w-8 h-8 border-3 border-purple-500/30 border-t-purple-500 rounded-full animate-spin" />
              <span className="text-xs text-slate-400 font-medium">Loading user profiles...</span>
            </div>
          ) : filteredCreators.length === 0 ? (
            <div className="p-12 text-center rounded-2xl bg-slate-900/50 border border-slate-800">
              <Users className="w-10 h-10 text-slate-600 mx-auto mb-2" />
              <p className="text-sm font-semibold text-slate-300">No matching user profiles found</p>
              <p className="text-xs text-slate-500 mt-1">Try another search keyword or sync user accounts.</p>
            </div>
          ) : creatorViewMode === 'compact' ? (
            /* COMPACT LIST VIEW (Chhota Chhota User ID List with Click-to-Detail) */
            <div className="rounded-2xl bg-slate-900/90 border border-slate-800 overflow-hidden divide-y divide-slate-800/80">
              <div className="px-4 py-2 bg-slate-950/80 text-[11px] font-bold text-slate-400 flex items-center justify-between uppercase tracking-wider">
                <div className="flex items-center gap-3">
                  <span>User / Creator</span>
                </div>
                <div className="flex items-center gap-6">
                  <span className="hidden sm:inline">Uploads</span>
                  <span className="hidden md:inline">Monetization</span>
                  <span>Action</span>
                </div>
              </div>

              {filteredCreators.map((creator) => {
                const creatorMediaCount = media.filter(m => m.userId === creator.id || (creator.email && m.userEmail === creator.email)).length || creator.mediaCount || 0;
                const isMonetized = creator.monetization?.isEnabled !== false && creator.monetization?.monetizationStatus !== 'disabled';
                const walletBalance = creator.monetization?.walletBalance ?? 152.91;

                return (
                  <div
                    key={creator.id}
                    onClick={() => setSelectedCreatorDetail(creator)}
                    className="px-4 py-2.5 flex items-center justify-between gap-3 hover:bg-slate-800/50 transition-colors cursor-pointer group select-none"
                  >
                    {/* User Identity & ID Tag */}
                    <div className="flex items-center gap-3 min-w-0 flex-1">
                      <img
                        src={creator.avatarUrl}
                        alt={creator.name}
                        className="w-8 h-8 rounded-lg object-cover bg-slate-800 border border-purple-500/30 shrink-0"
                        referrerPolicy="no-referrer"
                      />
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-xs font-bold text-white truncate max-w-[160px]">
                            {creator.name}
                          </span>
                          {creator.isVerified && <UniqueMastiVerifiedBadge className="w-3 h-3" />}
                          <span className="text-[10px] text-purple-400 font-mono hidden sm:block mt-0.5">
                            {creator.username.startsWith('@') ? creator.username : `@${creator.username}`}
                          </span>
                        </div>

                        {/* Monospace User ID Tag */}
                        <div className="flex items-center gap-1 mt-0.5">
                          <span className="font-mono text-[10px] text-purple-300 bg-purple-950/60 px-1.5 py-0.2 rounded border border-purple-800/50 select-all truncate max-w-[160px]">
                            {creator.id}
                          </span>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              navigator.clipboard.writeText(creator.id);
                              showToast('success', 'User ID Copied', creator.id);
                            }}
                            className="text-slate-500 hover:text-cyan-400 p-0.5 cursor-pointer"
                            title="Copy User ID"
                          >
                            <Copy className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Stats, Wallet & Inspect Button */}
                    <div className="flex items-center gap-3 sm:gap-6 shrink-0 text-xs">
                      {/* Uploads Count */}
                      <span className="text-[11px] font-mono text-slate-300 bg-slate-950 px-2 py-0.5 rounded border border-slate-800 hidden sm:flex items-center gap-1">
                        <Film className="w-3 h-3 text-indigo-400" />
                        <span>{creatorMediaCount}</span>
                      </span>

                      {/* Monetization Pill */}
                      <span
                        className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full hidden md:inline-block ${
                          isMonetized
                            ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-800/50'
                            : 'bg-rose-950/80 text-rose-300 border border-rose-800/50'
                        }`}
                      >
                        ₹{walletBalance.toFixed(0)} • {isMonetized ? 'Active' : 'Disabled'}
                      </span>

                      {/* Click-to-Detail Action */}
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedCreatorDetail(creator);
                        }}
                        className="px-2.5 py-1 rounded-lg bg-purple-950/80 hover:bg-purple-900 text-purple-300 border border-purple-800/50 text-xs font-semibold flex items-center gap-1 cursor-pointer transition-colors"
                      >
                        <span>Inspect Profile</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredCreators.map((creator) => {
                const isFollowed = followingUserIds.has(creator.id) || (creator.email && followingUserIds.has(creator.email));
                const creatorMediaCount = media.filter(m => m.userId === creator.id || (creator.email && m.userEmail === creator.email)).length || creator.mediaCount || 0;

                return (
                  <div
                    key={creator.id}
                    onClick={() => setSelectedCreatorDetail(creator)}
                    className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-purple-500/50 transition-all duration-200 hover:shadow-xl hover:shadow-purple-950/20 cursor-pointer flex flex-col justify-between space-y-4 group"
                  >
                    <div>
                      {/* Top Row: Avatar & Badges */}
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <img
                            src={creator.avatarUrl}
                            alt={creator.name}
                            className="w-14 h-14 rounded-2xl border-2 border-purple-500/40 object-cover bg-slate-800 group-hover:scale-105 transition-transform"
                            referrerPolicy="no-referrer"
                          />
                          <div className="min-w-0">
                            <h4 className="text-sm font-bold text-white flex items-center gap-1.5 leading-tight truncate">
                              {creator.name}
                              {creator.isVerified && <UniqueMastiVerifiedBadge className="w-3.5 h-3.5" />}
                            </h4>
                            <span className="text-xs text-purple-400 font-mono block mt-0.5 truncate">
                              {creator.username.startsWith('@') ? creator.username : `@${creator.username}`}
                            </span>
                            <span className="text-[10px] px-1.5 py-0.2 mt-1 inline-block rounded bg-purple-950/80 text-purple-300 border border-purple-800/50 font-medium">
                              {creator.badge || 'Creator'}
                            </span>
                          </div>
                        </div>

                        {/* Follow Button */}
                        <button
                          type="button"
                          onClick={(e) => handleToggleFollowCreator(creator.id, creator.name, e)}
                          className={`px-3 py-1 rounded-xl text-xs font-bold transition-all shrink-0 flex items-center gap-1 shadow-md ${
                            isFollowed
                              ? 'bg-slate-800 text-emerald-400 border border-emerald-500/40'
                              : 'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white'
                          }`}
                        >
                          {isFollowed ? (
                            <>
                              <UserCheck className="w-3 h-3" />
                              <span>Following</span>
                            </>
                          ) : (
                            <>
                              <UserPlus className="w-3 h-3" />
                              <span>+ Follow</span>
                            </>
                          )}
                        </button>
                      </div>

                      {/* Bio */}
                      <p className="text-xs text-slate-300 mt-3 line-clamp-2 leading-relaxed">
                        {creator.bio || 'Masti Video Creator & Content Contributor'}
                      </p>

                      {/* User ID and Email Box */}
                      <div className="mt-3 p-2 rounded-xl bg-slate-950/80 border border-slate-800 space-y-1 text-[11px]">
                        <div className="flex items-center justify-between text-slate-400">
                          <span className="text-slate-500 font-medium">User ID:</span>
                          <span className="font-mono text-purple-300 select-all font-bold">{creator.id}</span>
                        </div>
                        {creator.email && (
                          <div className="flex items-center justify-between text-slate-400">
                            <span className="text-slate-500 font-medium">Email:</span>
                            <span className="text-slate-300 truncate max-w-[170px] select-all">{creator.email}</span>
                          </div>
                        )}
                      </div>

                      {/* Monetization Status Pill */}
                      <div className="mt-2.5 flex items-center justify-between p-2 rounded-xl bg-slate-950/60 border border-slate-800 text-[11px]">
                        <span className="text-slate-400 font-medium flex items-center gap-1">
                          <IndianRupee className="w-3 h-3 text-emerald-400" /> Monetization
                        </span>
                        {creator.monetization?.isEnabled === false ? (
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30 font-bold">
                            Disabled
                          </span>
                        ) : (
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold">
                            ₹{(creator.monetization?.walletBalance ?? 152.91).toFixed(2)} • Active
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Stats Matrix */}
                    <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-800/80 text-center">
                      <div className="p-2 rounded-xl bg-slate-950 border border-slate-800/80">
                        <span className="text-xs font-bold text-white block">{creator.followersCount || 0}</span>
                        <span className="text-[9px] text-slate-400 uppercase tracking-wider">Followers</span>
                      </div>
                      <div className="p-2 rounded-xl bg-slate-950 border border-slate-800/80">
                        <span className="text-xs font-bold text-white block">{creatorMediaCount}</span>
                        <span className="text-[9px] text-slate-400 uppercase tracking-wider">Uploads</span>
                      </div>
                      <div className="p-2 rounded-xl bg-slate-950 border border-slate-800/80">
                        <span className="text-xs font-bold text-rose-400 block">{creator.likesCount || 0}</span>
                        <span className="text-[9px] text-slate-400 uppercase tracking-wider">Likes</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      ) : loading ? (
        /* ----------------- MEDIA ASSETS LOADING ----------------- */
        <div className="flex flex-col items-center justify-center p-16 space-y-3">
          <div className="w-8 h-8 border-3 border-indigo-500/30 border-t-indigo-500 rounded-full animate-spin" />
          <span className="text-xs text-slate-400 font-medium">Loading cloud media assets...</span>
        </div>
      ) : filteredMedia.length === 0 ? (
        <div className="flex flex-col items-center justify-center p-16 rounded-2xl bg-slate-900/50 border border-slate-800 text-center space-y-4">
          <div className="w-16 h-16 rounded-2xl bg-slate-800/80 flex items-center justify-center text-slate-400">
            <Sparkles className="w-8 h-8 text-indigo-400" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">No Media Files Found</h3>
            <p className="text-xs text-slate-400 mt-1 max-w-sm">
              {searchQuery || selectedFolder !== 'all' || activeTab !== 'all'
                ? 'Try adjusting your filters or search terms.'
                : 'Your Masti Bash library is ready for your first video or image upload.'}
            </p>
          </div>
          <button
            onClick={onNavigateToUpload}
            className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl shadow-lg transition-all"
          >
            Upload Media Now
          </button>
        </div>
      ) : viewMode === 'grid' ? (
        /* ----------------- GRID VIEW ----------------- */
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4">
          {filteredMedia.map(item => {
            const isSelected = selectedIds.includes(item.id);
            const isVideo = item.mediaType === 'video';
            const isAudio = item.mediaType === 'audio';

            const handleCardClick = () => {
              if (isAudio && onSelectAudio) {
                onSelectAudio(item);
              } else if (isVideo) {
                onSelectVideo(item);
              } else {
                onSelectImage(item);
              }
            };

            const creatorDisplayName = item.userName || (item.userEmail ? item.userEmail.split('@')[0] : (item.userId || 'Masti User'));
            const creatorMatch = creatorsList.find(c => c.id === item.userId || c.email === item.userEmail);

            return (
              <div
                key={item.id}
                onClick={handleCardClick}
                className={`group relative flex flex-col rounded-2xl bg-slate-900 border overflow-hidden transition-all duration-200 cursor-pointer hover:shadow-xl hover:shadow-indigo-950/40 hover:-translate-y-0.5 ${
                  isSelected
                    ? 'border-indigo-500 ring-2 ring-indigo-500/30'
                    : 'border-slate-800 hover:border-slate-700'
                }`}
              >
                {/* Media Thumbnail Container */}
                <div className="relative aspect-video w-full bg-slate-950 flex items-center justify-center overflow-hidden">
                  {isAudio ? (
                    item.posterUrl ? (
                      <div className="relative w-full h-full">
                        <img
                          src={resolveMediaUrl(item.posterUrl)}
                          alt={item.originalName}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                        <div className="absolute inset-0 bg-slate-950/40 group-hover:bg-slate-950/20 transition-colors flex items-center justify-center">
                          <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-amber-500 to-rose-600 flex items-center justify-center text-white shadow-lg shadow-amber-500/30 group-hover:scale-110 transition-transform">
                            <Play className="w-5 h-5 ml-0.5 fill-current" />
                          </div>
                        </div>
                        <div className="absolute bottom-2 left-2 px-1.5 py-0.5 rounded bg-slate-950/90 text-amber-300 text-[9px] font-bold border border-amber-500/30 flex items-center gap-1">
                          <Music className="w-3 h-3 text-amber-400" />
                          <span>Official Poster</span>
                        </div>
                      </div>
                    ) : (
                      <div className="w-full h-full bg-gradient-to-tr from-slate-950 via-slate-900 to-slate-800 flex flex-col items-center justify-center relative p-4">
                        <div className="w-14 h-14 rounded-full bg-gradient-to-tr from-amber-500 to-rose-600 flex items-center justify-center text-white shadow-lg shadow-amber-500/20 group-hover:scale-110 transition-transform">
                          <Play className="w-6 h-6 ml-0.5 fill-current" />
                        </div>
                        <div className="absolute bottom-3 left-4 right-4 flex items-center justify-center gap-1 opacity-60 group-hover:opacity-100 transition-opacity">
                          <Volume2 className="w-3.5 h-3.5 text-amber-400" />
                          <span className="text-[10px] font-mono text-amber-300">Audio Track</span>
                        </div>
                      </div>
                    )
                  ) : isVideo ? (
                    <>
                      <video
                        src={resolveMediaUrl(item.fileUrl)}
                        preload="metadata"
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-slate-950/30 group-hover:bg-slate-950/10 transition-colors flex items-center justify-center">
                        <div className="w-11 h-11 rounded-full bg-indigo-600/90 text-white flex items-center justify-center shadow-lg transform group-hover:scale-110 transition-transform">
                          <Play className="w-5 h-5 ml-0.5 fill-current" />
                        </div>
                      </div>
                    </>
                  ) : (
                    <img
                      src={resolveMediaUrl(item.fileUrl)}
                      alt={item.originalName}
                      loading="lazy"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  )}

                  {/* Top Badges */}
                  <div className="absolute top-2.5 left-2.5 right-2.5 flex items-center justify-between pointer-events-none">
                    {/* Checkbox */}
                    <button
                      type="button"
                      onClick={(e) => handleToggleSelect(item.id, e)}
                      className={`pointer-events-auto p-1 rounded-lg backdrop-blur-md transition-all ${
                        isSelected
                          ? 'bg-indigo-600 text-white'
                          : 'bg-slate-950/70 text-slate-300 hover:text-white opacity-0 group-hover:opacity-100'
                      }`}
                    >
                      {isSelected ? <CheckSquare className="w-4 h-4" /> : <Square className="w-4 h-4" />}
                    </button>

                    {/* Format & 4K Badges */}
                    <div className="flex items-center gap-1.5">
                      {(isVideo && ((item.width && item.width >= 3800) || (item.height && item.height >= 2000) || item.tags?.includes('4k'))) && (
                        <span className="px-1.5 py-0.5 rounded-md bg-purple-600 text-[9px] font-mono font-extrabold text-white shadow-sm uppercase">
                          4K UHD
                        </span>
                      )}
                      <span className="px-2 py-0.5 rounded-md bg-slate-950/80 backdrop-blur-md text-[10px] font-mono font-bold text-slate-200 border border-slate-800 uppercase">
                        {item.mimeType ? item.mimeType.split('/')[1] : item.mediaType}
                      </span>
                    </div>
                  </div>

                  {/* Size & Duration pill */}
                  <div className="absolute bottom-2.5 right-2.5 pointer-events-none flex items-center gap-1.5">
                    {item.duration && (
                      <span className="px-2 py-0.5 rounded-md bg-slate-950/80 backdrop-blur-md text-[10px] font-mono text-indigo-300 border border-slate-800">
                        {formatDuration(item.duration)}
                      </span>
                    )}
                    <span className="px-2 py-0.5 rounded-md bg-slate-950/80 backdrop-blur-md text-[10px] font-mono text-slate-300 border border-slate-800">
                      {formatBytes(item.fileSize)}
                    </span>
                  </div>
                </div>

                {/* Details Footer */}
                <div className="p-3.5 flex flex-col flex-1 justify-between bg-slate-900 space-y-2.5">
                  <div className="min-w-0 space-y-2">
                    {/* Rich Title / Caption with Mentions and Hashtags */}
                    <div className="bg-slate-950/40 p-2 rounded-xl border border-slate-800/60">
                      <RichCaption
                        text={item.caption || item.title || item.originalName}
                        maxLines={4}
                        className="text-xs font-semibold text-white group-hover:text-purple-200 transition-colors"
                      />
                    </div>

                    {/* Creator Identity & User ID Record with High-Res DP */}
                    <div
                      onClick={(e) => {
                        e.stopPropagation();
                        if (creatorMatch) {
                          setSelectedCreatorDetail(creatorMatch);
                        } else {
                          setSelectedCreatorDetail({
                            id: item.userId || 'usr_creator',
                            name: creatorDisplayName,
                            username: (item.userName || 'creator').toLowerCase().replace(/[^a-z0-9_]/g, ''),
                            email: item.userEmail || '',
                            role: 'user',
                            avatarUrl: item.userAvatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(item.userEmail || item.userId || 'user')}`,
                            followersCount: 154,
                            followingCount: 32,
                            mediaCount: 1,
                            likesCount: item.likesCount || 0,
                            badge: 'Verified Creator',
                            bio: 'Masti Video Creator & Content Contributor 🎥✨'
                          });
                        }
                      }}
                      className="p-2 rounded-xl bg-slate-950/95 border border-slate-800/90 hover:border-purple-500/50 flex items-center justify-between gap-2 transition-all cursor-pointer group/creator"
                      title="Click to view creator profile details"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className="relative shrink-0">
                          <img
                            src={item.userAvatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(item.userEmail || item.userId || 'user')}`}
                            alt="Creator DP"
                            className="w-9 h-9 rounded-full object-cover border-2 border-purple-500/60 shadow-md bg-slate-800 group-hover/creator:scale-105 transition-transform"
                            referrerPolicy="no-referrer"
                            onError={(e) => {
                              (e.target as HTMLImageElement).src = `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(item.userId || 'user')}`;
                            }}
                          />
                          <div className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-500 border-2 border-slate-950" title="Active" />
                        </div>
                        <div className="flex flex-col min-w-0">
                          <span className="text-xs font-bold text-slate-100 truncate leading-tight flex items-center gap-1 group-hover/creator:text-purple-300">
                            {creatorDisplayName}
                            {creatorMatch?.isVerified && <UniqueMastiVerifiedBadge className="w-3 h-3 ml-0.5" />}
                          </span>
                          <span className="text-[10px] font-mono text-purple-300 truncate font-semibold" title={`User ID: ${item.userId}`}>
                            UID: {item.userId ? (item.userId.length > 14 ? `${item.userId.slice(0, 12)}...` : item.userId) : 'guest'}
                          </span>
                        </div>
                      </div>

                      {/* Follow Creator Toggle Badge */}
                      {item.userId && (
                        <button
                          type="button"
                          onClick={(e) => handleToggleFollowCreator(item.userId, creatorDisplayName, e)}
                          className={`flex items-center gap-1 px-2 py-1 rounded-lg text-[10px] font-bold transition-all shrink-0 shadow-sm ${
                            followingUserIds.has(item.userId)
                              ? 'bg-emerald-950/90 text-emerald-300 border border-emerald-700/60 hover:bg-emerald-900/60'
                              : 'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white shadow-purple-950'
                          }`}
                          title={followingUserIds.has(item.userId) ? 'Unfollow Creator' : 'Follow Creator'}
                        >
                          {followingUserIds.has(item.userId) ? (
                            <>
                              <UserCheck className="w-3 h-3 text-emerald-300" />
                              <span>Following</span>
                            </>
                          ) : (
                            <>
                              <UserPlus className="w-3 h-3 text-white" />
                              <span>Follow</span>
                            </>
                          )}
                        </button>
                      )}
                    </div>

                    {/* Audio Soundtrack & Direct Audio Link Bar */}
                    <div
                      onClick={(e) => e.stopPropagation()}
                      className="p-2 rounded-xl bg-slate-950/80 border border-slate-800/80 flex items-center justify-between gap-2 text-xs"
                    >
                      <div className="flex items-center gap-2 min-w-0 flex-1">
                        <div className="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center justify-center shrink-0">
                          <Music className="w-3.5 h-3.5" />
                        </div>
                        <div className="flex flex-col min-w-0 flex-1">
                          <span className="text-[11px] font-semibold text-amber-200 truncate leading-tight flex items-center gap-1">
                            {item.music?.title || `Original Audio - ${creatorDisplayName}`}
                          </span>
                          <span className="text-[9px] text-slate-400 font-mono truncate" title={item.music?.url || item.fileUrl}>
                            {item.music?.url ? item.music.url : (item.mediaType === 'audio' ? 'Direct Audio Stream' : 'Video Soundtrack')}
                          </span>
                        </div>
                      </div>

                      {/* Copy Audio Link button */}
                      <button
                        type="button"
                        onClick={(e) => handleCopyAudioUrl(item, e)}
                        className="px-2 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-500/30 text-[10px] font-bold transition-all flex items-center gap-1 shrink-0"
                        title="Copy Audio Link"
                      >
                        {copiedAudioId === item.id ? (
                          <>
                            <Check className="w-3 h-3 text-emerald-400" />
                            <span className="text-emerald-400">Copied</span>
                          </>
                        ) : (
                          <>
                            <LinkIcon className="w-3 h-3 text-amber-300" />
                            <span>Audio Link</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Social Live Action Row */}
                  <div className="flex items-center justify-between py-1 px-2 bg-slate-950/60 rounded-lg border border-slate-800/80 text-slate-400 text-xs">
                    {/* Like Button */}
                    <button
                      type="button"
                      onClick={(e) => handleToggleLike(item, e)}
                      className={`flex items-center gap-1 hover:text-rose-400 transition-colors ${
                        likedMediaIds.has(item.id) ? 'text-rose-500 font-bold' : ''
                      }`}
                    >
                      <Heart className={`w-3.5 h-3.5 ${likedMediaIds.has(item.id) ? 'fill-current text-rose-500' : ''}`} />
                      <span className="text-[11px] font-mono">{likesCounts[item.id] ?? item.likesCount ?? 0}</span>
                    </button>

                    {/* Comments Drawer Button */}
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setCommentDrawerMedia(item);
                      }}
                      className="flex items-center gap-1 hover:text-cyan-400 transition-colors"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span className="text-[11px] font-mono">{commentsCounts[item.id] ?? item.commentsCount ?? 0}</span>
                    </button>

                    {/* Share Button */}
                    <button
                      type="button"
                      onClick={(e) => handleShareMedia(item, e)}
                      className="flex items-center gap-1 hover:text-emerald-400 transition-colors"
                    >
                      <Share2 className="w-3.5 h-3.5" />
                      <span className="text-[11px] font-mono">{sharesCounts[item.id] ?? item.sharesCount ?? 0}</span>
                    </button>

                    {/* Inspect Info / Details Button */}
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setInspectedMedia(item);
                      }}
                      className="p-1 hover:text-indigo-300 text-slate-400 transition-colors"
                      title="View Full Metadata & Video Details"
                    >
                      <Info className="w-3.5 h-3.5 text-indigo-400" />
                    </button>
                  </div>

                  {/* Action Bar */}
                  <div className="flex items-center justify-between pt-1 border-t border-slate-800/80">
                    <button
                      type="button"
                      onClick={(e) => handleCopyUrl(item, e)}
                      className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-slate-200 transition-colors"
                    >
                      {copiedId === item.id ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span className="text-emerald-400">Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5 text-slate-400" />
                          <span>Copy URL</span>
                        </>
                      )}
                    </button>

                    <div className="flex items-center gap-1">
                      {/* Set / Change Official Poster Button */}
                      {(isAudio || isVideo) && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setPosterModalMedia(item);
                          }}
                          className="p-1 text-slate-400 hover:text-amber-300 rounded-lg hover:bg-slate-800 transition-colors"
                          title="Select Official Terminal Poster"
                        >
                          <ImageIcon className="w-3.5 h-3.5" />
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={(e) => openEditModal(item, e)}
                        className="p-1 text-slate-400 hover:text-slate-200 rounded-lg hover:bg-slate-800 transition-colors"
                        title="Edit Details & Tags"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>

                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setDeleteConfirmId(item.id);
                        }}
                        className="p-1 text-slate-400 hover:text-rose-400 rounded-lg hover:bg-slate-800 transition-colors"
                        title="Delete Media"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>

              </div>
            );
          })}
        </div>
      ) : (
        /* ----------------- LIST VIEW ----------------- */
        <div className="rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] font-bold tracking-wider border-b border-slate-800">
                <tr>
                  <th className="p-3.5 w-10">
                    <button onClick={handleSelectAll} className="hover:text-white">
                      {selectedIds.length === filteredMedia.length && filteredMedia.length > 0 ? (
                        <CheckSquare className="w-4 h-4 text-indigo-400" />
                      ) : (
                        <Square className="w-4 h-4" />
                      )}
                    </button>
                  </th>
                  <th className="p-3.5">Asset & Creator Details</th>
                  <th className="p-3.5">User ID</th>
                  <th className="p-3.5">Folder</th>
                  <th className="p-3.5">Size</th>
                  <th className="p-3.5">Format</th>
                  <th className="p-3.5">Uploaded</th>
                  <th className="p-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80">
                {filteredMedia.map(item => {
                  const isSelected = selectedIds.includes(item.id);
                  const isVideo = item.mediaType === 'video';
                  const isAudio = item.mediaType === 'audio';

                  const handleRowClick = () => {
                    if (isAudio && onSelectAudio) {
                      onSelectAudio(item);
                    } else if (isVideo) {
                      onSelectVideo(item);
                    } else {
                      onSelectImage(item);
                    }
                  };

                  return (
                    <tr
                      key={item.id}
                      onClick={handleRowClick}
                      className={`hover:bg-slate-800/50 cursor-pointer transition-colors ${
                        isSelected ? 'bg-indigo-950/20' : ''
                      }`}
                    >
                      <td className="p-3.5" onClick={(e) => e.stopPropagation()}>
                        <button onClick={(e) => handleToggleSelect(item.id, e)}>
                          {isSelected ? (
                            <CheckSquare className="w-4 h-4 text-indigo-400" />
                          ) : (
                            <Square className="w-4 h-4 text-slate-500" />
                          )}
                        </button>
                      </td>
                      <td className="p-3.5">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg bg-slate-950 border border-slate-800 overflow-hidden shrink-0 flex items-center justify-center relative">
                            {isAudio ? (
                              item.posterUrl ? (
                                <>
                                  <img src={resolveMediaUrl(item.posterUrl)} alt={item.originalName} className="w-full h-full object-cover" />
                                  <div className="absolute inset-0 bg-slate-950/30 flex items-center justify-center">
                                    <Music className="w-3.5 h-3.5 text-amber-300 drop-shadow" />
                                  </div>
                                </>
                              ) : (
                                <div className="w-full h-full bg-gradient-to-tr from-amber-600/20 to-rose-600/20 flex items-center justify-center text-amber-400">
                                  <Music className="w-4 h-4" />
                                </div>
                              )
                            ) : isVideo ? (
                              <Film className="w-4 h-4 text-indigo-400" />
                            ) : (
                              <img src={resolveMediaUrl(item.fileUrl)} alt={item.originalName} className="w-full h-full object-cover" />
                            )}
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-2">
                              <span className="font-semibold text-white truncate block max-w-xs sm:max-w-md">
                                {item.title || item.originalName}
                              </span>
                              {item.posterUrl && isAudio && (
                                <span className="px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[8px] font-bold uppercase shrink-0">
                                  Poster
                                </span>
                              )}
                              {(isVideo && ((item.width && item.width >= 3800) || (item.height && item.height >= 2000) || item.tags?.includes('4k'))) && (
                                <span className="px-1.5 py-0.2 rounded bg-purple-600 text-[9px] font-mono font-extrabold text-white uppercase shrink-0">
                                  4K UHD
                                </span>
                              )}
                              {item.duration && (
                                <span className="px-1.5 py-0.2 rounded bg-slate-800 text-[9px] font-mono text-indigo-300 border border-slate-700 shrink-0">
                                  {formatDuration(item.duration)}
                                </span>
                              )}
                            </div>
                            <div className="flex items-center gap-1.5 mt-0.5">
                              <img
                                src={item.userAvatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(item.userId || 'user')}`}
                                alt="DP"
                                className="w-4 h-4 rounded-full object-cover border border-purple-500/50"
                                referrerPolicy="no-referrer"
                              />
                              <span className="text-[10px] text-purple-300 font-medium truncate">
                                {item.userName || (item.userEmail ? item.userEmail.split('@')[0] : 'Masti User')}
                              </span>
                              {item.music?.title && (
                                <span className="text-[9px] text-amber-300 flex items-center gap-0.5 ml-2 font-mono truncate">
                                  <Music className="w-2.5 h-2.5" />
                                  {item.music.title}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="p-3.5 font-mono text-purple-300 text-[11px] font-bold">
                        {item.userId || 'guest'}
                      </td>
                      <td className="p-3.5 capitalize text-indigo-300 font-medium">
                        {item.folder || 'general'}
                      </td>
                      <td className="p-3.5 font-mono text-slate-400">
                        {formatBytes(item.fileSize)}
                      </td>
                      <td className="p-3.5 uppercase font-mono text-[10px] text-slate-400">
                        {item.mimeType ? item.mimeType.split('/')[1] : item.mediaType}
                      </td>
                      <td className="p-3.5 text-slate-400">
                        {formatDate(item.createdAt)}
                      </td>
                      <td className="p-3.5 text-right" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            type="button"
                            onClick={(e) => handleCopyAudioUrl(item, e)}
                            className="p-1.5 text-slate-400 hover:text-amber-300 rounded-lg hover:bg-slate-800 transition-colors"
                            title="Copy Audio Link"
                          >
                            {copiedAudioId === item.id ? <Check className="w-4 h-4 text-emerald-400" /> : <LinkIcon className="w-4 h-4" />}
                          </button>
                          <button
                            type="button"
                            onClick={() => setInspectedMedia(item)}
                            className="p-1.5 text-slate-400 hover:text-indigo-400 rounded-lg hover:bg-slate-800 transition-colors"
                            title="Video Details"
                          >
                            <Info className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={(e) => handleCopyUrl(item, e)}
                            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
                            title="Copy Direct URL"
                          >
                            {copiedId === item.id ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                          </button>
                          {(isAudio || isVideo) && (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setPosterModalMedia(item);
                              }}
                              className="p-1.5 text-slate-400 hover:text-amber-300 rounded-lg hover:bg-slate-800 transition-colors"
                              title="Select Official Terminal Poster"
                            >
                              <ImageIcon className="w-4 h-4" />
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={(e) => openEditModal(item, e)}
                            className="p-1.5 text-slate-400 hover:text-slate-200 rounded-lg hover:bg-slate-800 transition-colors"
                            title="Edit"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setDeleteConfirmId(item.id);
                            }}
                            className="p-1.5 text-slate-400 hover:text-rose-400 rounded-lg hover:bg-slate-800 transition-colors"
                            title="Delete"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ----------------- VIDEO / ASSET DETAIL INSPECTOR MODAL ----------------- */}
      {inspectedMedia && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-xl rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-5 shadow-2xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileVideo className="w-5 h-5 text-indigo-400" />
                <h3 className="text-base font-bold text-white">Full Video & User Details</h3>
              </div>
              <button
                onClick={() => setInspectedMedia(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Creator Profile Box */}
            <div className="p-4 rounded-xl bg-gradient-to-r from-purple-950/60 to-slate-950 border border-purple-800/40 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <img
                  src={inspectedMedia.userAvatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(inspectedMedia.userId || 'user')}`}
                  alt="Creator"
                  className="w-12 h-12 rounded-xl object-cover border-2 border-purple-500/50 bg-slate-800"
                  referrerPolicy="no-referrer"
                />
                <div>
                  <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                    {inspectedMedia.userName || (inspectedMedia.userEmail ? inspectedMedia.userEmail.split('@')[0] : 'Masti Creator')}
                    {creatorsList.find(c => c.id === inspectedMedia.userId || c.email === inspectedMedia.userEmail)?.isVerified && <UniqueMastiVerifiedBadge className="w-3.5 h-3.5" />}
                  </h4>
                  <p className="text-xs text-purple-300 font-mono">
                    UID: {inspectedMedia.userId || 'usr_anonymous'}
                  </p>
                  {inspectedMedia.userEmail && (
                    <p className="text-[11px] text-slate-400">{inspectedMedia.userEmail}</p>
                  )}
                </div>
              </div>

              <button
                type="button"
                onClick={() => handleToggleFollowCreator(inspectedMedia.userId, inspectedMedia.userName || 'Creator')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 ${
                  followingUserIds.has(inspectedMedia.userId)
                    ? 'bg-slate-800 text-emerald-400 border border-emerald-500/40'
                    : 'bg-gradient-to-r from-purple-600 to-pink-600 text-white'
                }`}
              >
                {followingUserIds.has(inspectedMedia.userId) ? <UserCheck className="w-3 h-3" /> : <UserPlus className="w-3 h-3" />}
                <span>{followingUserIds.has(inspectedMedia.userId) ? 'Following' : 'Follow'}</span>
              </button>
            </div>

            {/* Video File Technical Specs */}
            <div className="space-y-2">
              <span className="text-slate-400 text-xs font-bold block">Video Title & Caption</span>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <RichCaption
                  text={inspectedMedia.caption || inspectedMedia.title || inspectedMedia.originalName}
                  className="text-xs font-medium text-slate-100"
                />
              </div>
            </div>

            {/* Audio Soundtrack Info */}
            <div className="p-3 rounded-xl bg-slate-950 border border-amber-900/40 flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center justify-center shrink-0">
                  <Music className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <span className="text-[10px] uppercase font-bold text-amber-400/80 block">Soundtrack / Audio Link</span>
                  <span className="text-xs font-bold text-amber-200 truncate block">
                    {inspectedMedia.music?.title || `Original Audio - ${inspectedMedia.userName || 'Creator'}`}
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono truncate block">
                    {inspectedMedia.music?.url || inspectedMedia.fileUrl}
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={(e) => handleCopyAudioUrl(inspectedMedia, e)}
                className="px-3 py-1.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-bold shrink-0 flex items-center gap-1.5 transition-all"
              >
                {copiedAudioId === inspectedMedia.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <LinkIcon className="w-3.5 h-3.5" />}
                <span>{copiedAudioId === inspectedMedia.id ? 'Copied' : 'Copy Audio URL'}</span>
              </button>
            </div>

            {/* Video File Technical Specs */}
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-slate-500 text-[10px] uppercase font-bold block">File Title</span>
                <span className="text-slate-200 font-semibold truncate block mt-0.5">{inspectedMedia.title || inspectedMedia.originalName}</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-slate-500 text-[10px] uppercase font-bold block">Folder Storage</span>
                <span className="text-indigo-400 font-semibold block mt-0.5">📁 {inspectedMedia.folder || 'Default'}</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-slate-500 text-[10px] uppercase font-bold block">File Size & MIME</span>
                <span className="text-slate-200 font-mono block mt-0.5">{formatBytes(inspectedMedia.fileSize)} ({inspectedMedia.mimeType})</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-slate-500 text-[10px] uppercase font-bold block">Upload Date</span>
                <span className="text-slate-200 block mt-0.5">{formatDate(inspectedMedia.createdAt)}</span>
              </div>
            </div>

            {/* Direct CDN URL */}
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
              <span className="text-[10px] uppercase font-bold text-slate-500">Public CDN Stream URL</span>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  readOnly
                  value={window.location.origin + resolveMediaUrl(inspectedMedia.fileUrl)}
                  className="w-full bg-transparent text-xs font-mono text-purple-300 focus:outline-none select-all"
                />
                <button
                  type="button"
                  onClick={() => {
                    navigator.clipboard.writeText(window.location.origin + resolveMediaUrl(inspectedMedia.fileUrl));
                    showToast('success', 'URL Copied', 'Stream link copied to clipboard');
                  }}
                  className="px-2.5 py-1 rounded bg-purple-900/60 hover:bg-purple-800 text-purple-200 text-xs font-bold shrink-0"
                >
                  Copy
                </button>
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="button"
                onClick={() => setInspectedMedia(null)}
                className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all"
              >
                Close Details
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ----------------- CREATOR PROFILE DETAIL MODAL ----------------- */}
      {selectedCreatorDetail && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-0 sm:p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full h-full sm:h-auto sm:max-w-xl max-h-[100vh] sm:max-h-[92vh] overflow-y-auto sm:rounded-2xl bg-slate-900 border-0 sm:border border-purple-900/50 p-4 sm:p-6 space-y-4 sm:space-y-5 shadow-2xl">
            <div className="flex items-center justify-between sticky top-0 bg-slate-900/95 backdrop-blur-md pb-3 z-10 border-b border-slate-800/60 pt-2 sm:pt-0">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-purple-400" />
                <h3 className="text-sm sm:text-base font-bold text-white">Masti Creator Profile Details</h3>
              </div>
              <button
                onClick={() => setSelectedCreatorDetail(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Profile Hero Header */}
            <div className="flex items-center gap-3 sm:gap-4 p-3.5 sm:p-4 rounded-2xl bg-gradient-to-r from-purple-950/80 to-slate-950 border border-purple-800/40">
              <div className="relative group shrink-0">
                <label className="cursor-pointer block relative">
                  <input 
                    type="file" 
                    accept="image/*" 
                    className="hidden" 
                    onChange={async (e) => {
                      const file = e.target.files?.[0];
                      if (!file) return;
                      try {
                        const uploadRes = await api.uploadFiles([file]);
                        const uploadedData = uploadRes.data;
                        const uploadedFileUrl = Array.isArray(uploadedData) ? uploadedData[0]?.fileUrl : uploadedData?.fileUrl;

                        if (uploadRes.success && uploadedFileUrl) {
                          const newUrl = uploadedFileUrl;
                          const res = await api.updateUserAvatar(selectedCreatorDetail.id, newUrl);
                          if (res.success) {
                            setSelectedCreatorDetail(prev => prev ? { ...prev, avatarUrl: newUrl } : null);
                            setCreatorsList(prev => prev.map(c => c.id === selectedCreatorDetail.id ? { ...c, avatarUrl: newUrl } : c));
                            showToast('success', 'DP Updated', 'Profile picture updated successfully!');
                          } else {
                            showToast('error', 'Update Failed', res.error || 'Failed to update DP');
                          }
                        } else {
                           showToast('error', 'Upload Failed', uploadRes.error || 'Failed to upload image');
                        }
                      } catch (err: any) {
                        showToast('error', 'Error', err.message);
                      }
                      e.target.value = ''; // Reset input
                    }}
                  />
                  {selectedCreatorDetail.avatarUrl ? (
                    <img
                      src={selectedCreatorDetail.avatarUrl}
                      alt={selectedCreatorDetail.name}
                      className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl border-2 border-purple-500/60 object-cover bg-slate-800"
                      referrerPolicy="no-referrer"
                      onError={(e) => {
                        (e.target as HTMLImageElement).style.display = 'none';
                        const fallback = (e.target as HTMLImageElement).nextElementSibling as HTMLElement;
                        if (fallback && fallback.className.includes('fallback-avatar')) {
                          fallback.classList.remove('hidden');
                          fallback.classList.add('flex');
                        }
                      }}
                    />
                  ) : null}
                  <div 
                    className={`w-14 h-14 sm:w-16 sm:h-16 rounded-2xl border-2 border-purple-500/60 items-center justify-center bg-gradient-to-br from-purple-600 to-indigo-800 text-white font-bold text-xl fallback-avatar ${selectedCreatorDetail.avatarUrl ? 'hidden' : 'flex'}`}
                  >
                    {selectedCreatorDetail.name.charAt(0).toUpperCase()}
                  </div>
                  <div className="absolute inset-0 bg-black/60 rounded-2xl flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <span className="text-[10px] font-bold text-white text-center leading-tight px-1">Upload<br/>DP</span>
                  </div>
                </label>
              </div>
              <div className="min-w-0 flex-1">
                <h4 className="text-sm sm:text-base font-bold text-white flex items-center gap-1.5 leading-tight truncate">
                  <span className="truncate">{selectedCreatorDetail.name}</span>
                  {selectedCreatorDetail.isVerified && (
                    <UniqueMastiVerifiedBadge className="w-4 h-4" />
                  )}
                </h4>
                <span className="text-xs text-purple-400 font-mono block truncate mt-0.5">
                  {selectedCreatorDetail.username.startsWith('@') ? selectedCreatorDetail.username : `@${selectedCreatorDetail.username}`}
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-900/60 text-purple-200 font-semibold border border-purple-700/50 mt-1 inline-block">
                  {selectedCreatorDetail.badge || 'Verified Creator'}
                </span>
              </div>
            </div>

            {/* Bio */}
            <div className="p-3 sm:p-3.5 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">Creator Bio</span>
              <p className="text-xs text-slate-200 leading-relaxed">
                {selectedCreatorDetail.bio || 'Masti Video Creator & Content Contributor.'}
              </p>
            </div>

            {/* Identifier Details - Mobile Stack friendly */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 overflow-hidden">
                <span className="text-[10px] uppercase font-bold text-slate-500 block">Permanent User ID</span>
                <span className="font-mono text-purple-300 font-bold block mt-0.5 truncate select-all">{selectedCreatorDetail.id}</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 overflow-hidden">
                <span className="text-[10px] uppercase font-bold text-slate-500 block">Registered Email</span>
                <span className="text-slate-200 block mt-0.5 truncate select-all" title={selectedCreatorDetail.email}>{selectedCreatorDetail.email || 'None'}</span>
              </div>
            </div>

            {/* Admin Verification Control */}
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CheckCircle2 className={`w-4 h-4 ${selectedCreatorDetail.isVerified ? 'text-blue-400' : 'text-slate-500'}`} />
                <div>
                  <span className="text-xs font-bold text-slate-200 block">Blue Tick (Verified Badge)</span>
                  <span className="text-[10px] text-slate-400">Give verified badge on profile</span>
                </div>
              </div>
              <button
                type="button"
                onClick={async () => {
                  const nextVal = !selectedCreatorDetail.isVerified;
                  try {
                    const res = await api.updateUserVerification(selectedCreatorDetail.id, nextVal);
                    if (res.success) {
                      setSelectedCreatorDetail(prev => prev ? { ...prev, isVerified: nextVal } : null);
                      setCreatorsList(prev => prev.map(c => c.id === selectedCreatorDetail.id ? { ...c, isVerified: nextVal } : c));
                      showToast('success', 'Verification Updated', `${selectedCreatorDetail.name} Blue Tick is now ${nextVal ? 'ON' : 'OFF'}`);
                    } else {
                      showToast('error', 'Failed', res.error || 'Could not update verification');
                    }
                  } catch (err: any) {
                    showToast('error', 'Error', err.message);
                  }
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all border inline-flex items-center gap-1.5 ${
                  selectedCreatorDetail.isVerified
                    ? 'bg-blue-600 text-white border-blue-500 shadow-lg shadow-blue-600/30'
                    : 'bg-slate-900 text-slate-400 border-slate-800 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <span className={`w-2 h-2 rounded-full ${selectedCreatorDetail.isVerified ? 'bg-white animate-pulse' : 'bg-slate-600'}`}></span>
                <span>{selectedCreatorDetail.isVerified ? 'VERIFIED' : 'UNVERIFIED'}</span>
              </button>
            </div>

            {/* Creator Monetization Profile & Admin Controls (Enable/Disable & Revenue Adjust) */}
            <div className="p-3 sm:p-4 rounded-2xl bg-gradient-to-b from-slate-950 to-slate-900 border border-purple-800/40 space-y-3">
              <UserMonetizationCard
                userId={selectedCreatorDetail.id}
                userName={selectedCreatorDetail.name}
                userEmail={selectedCreatorDetail.email}
                initialData={selectedCreatorDetail.monetization}
                onUpdate={(updated) => {
                  setSelectedCreatorDetail(prev => prev ? { ...prev, monetization: updated } : null);
                  setCreatorsList(prev => prev.map(c => c.id === selectedCreatorDetail.id ? { ...c, monetization: updated } : c));
                }}
                canControl={true}
              />
            </div>

            {/* Social Links */}
            {selectedCreatorDetail.socialLinks && (
              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <span className="text-[10px] uppercase font-bold text-slate-500 block">Social Media Links</span>
                <div className="flex flex-wrap gap-2">
                  {selectedCreatorDetail.socialLinks.instagram && (
                    <a
                      href={selectedCreatorDetail.socialLinks.instagram}
                      target="_blank"
                      rel="noreferrer"
                      className="px-2.5 py-1 rounded-lg bg-pink-950/60 text-pink-300 border border-pink-800/40 text-xs font-semibold hover:bg-pink-900/60 transition-colors"
                    >
                      Instagram
                    </a>
                  )}
                  {selectedCreatorDetail.socialLinks.youtube && (
                    <a
                      href={selectedCreatorDetail.socialLinks.youtube}
                      target="_blank"
                      rel="noreferrer"
                      className="px-2.5 py-1 rounded-lg bg-rose-950/60 text-rose-300 border border-rose-800/40 text-xs font-semibold hover:bg-rose-900/60 transition-colors"
                    >
                      YouTube
                    </a>
                  )}
                  {selectedCreatorDetail.socialLinks.website && (
                    <a
                      href={selectedCreatorDetail.socialLinks.website}
                      target="_blank"
                      rel="noreferrer"
                      className="px-2.5 py-1 rounded-lg bg-indigo-950/60 text-indigo-300 border border-indigo-800/40 text-xs font-semibold hover:bg-indigo-900/60 transition-colors"
                    >
                      Website
                    </a>
                  )}
                </div>
              </div>
            )}

            {/* Action Bar */}
            <div className="flex items-center justify-between pt-2">
              <button
                type="button"
                onClick={() => {
                  setActiveTab('all');
                  setSearchQuery(selectedCreatorDetail.name);
                  setSelectedCreatorDetail(null);
                }}
                className="px-4 py-2 rounded-xl bg-purple-950/80 hover:bg-purple-900 text-purple-300 border border-purple-800/50 text-xs font-bold transition-all"
              >
                View Uploaded Videos
              </button>

              <button
                type="button"
                onClick={() => handleToggleFollowCreator(selectedCreatorDetail.id, selectedCreatorDetail.name)}
                className={`px-5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                  followingUserIds.has(selectedCreatorDetail.id)
                    ? 'bg-slate-800 text-emerald-400 border border-emerald-500/40'
                    : 'bg-gradient-to-r from-purple-600 to-pink-600 text-white'
                }`}
              >
                {followingUserIds.has(selectedCreatorDetail.id) ? <UserCheck className="w-4 h-4" /> : <UserPlus className="w-4 h-4" />}
                <span>{followingUserIds.has(selectedCreatorDetail.id) ? 'Following' : 'Follow Creator'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Metadata Modal */}
      {editingMedia && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="w-full max-w-lg rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4 shadow-2xl max-h-[90vh] overflow-y-auto">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Edit2 className="w-4 h-4 text-purple-400" />
              Edit Media & Creator Details
            </h3>

            <div className="space-y-3 text-xs">
              {/* Title */}
              <div>
                <label className="text-slate-300 font-semibold block mb-1">Title (Heading)</label>
                <input
                  type="text"
                  value={editTitle}
                  onChange={e => setEditTitle(e.target.value)}
                  placeholder="e.g. प्यार वाले को गाली देते @real #lipstick"
                  className="w-full px-3.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-slate-100 focus:border-purple-500 focus:outline-none"
                />
              </div>

              {/* Caption */}
              <div>
                <label className="text-slate-300 font-semibold block mb-1">Full Caption & Hashtags (Multi-line)</label>
                <textarea
                  rows={4}
                  value={editCaption}
                  onChange={e => setEditCaption(e.target.value)}
                  placeholder="Enter full caption with @mentions and #hashtags..."
                  className="w-full px-3.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-slate-100 focus:border-purple-500 focus:outline-none leading-relaxed font-sans"
                />
              </div>

              {/* Creator Info */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Creator Name</label>
                  <input
                    type="text"
                    value={editUserName}
                    onChange={e => setEditUserName(e.target.value)}
                    placeholder="e.g. Riya Sharma"
                    className="w-full px-3.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-slate-100 focus:border-purple-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Creator User ID</label>
                  <input
                    type="text"
                    value={editUserId}
                    onChange={e => setEditUserId(e.target.value)}
                    placeholder="e.g. usr_riya_01"
                    className="w-full px-3.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-slate-100 focus:border-purple-500 focus:outline-none font-mono"
                  />
                </div>
              </div>

              {/* Creator DP Avatar URL */}
              <div>
                <label className="text-slate-300 font-semibold block mb-1">Creator Avatar DP URL</label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={editUserAvatar}
                    onChange={e => setEditUserAvatar(e.target.value)}
                    placeholder="https://images.unsplash.com/... or dicebear avatar"
                    className="w-full px-3.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-slate-100 focus:border-purple-500 focus:outline-none text-[11px]"
                  />
                  {editUserAvatar && (
                    <img
                      src={editUserAvatar}
                      alt="Preview"
                      className="w-8 h-8 rounded-full object-cover border border-purple-500/60 shrink-0"
                      onError={(e) => { (e.target as HTMLElement).style.display = 'none'; }}
                    />
                  )}
                </div>
              </div>

              {/* Soundtrack & Audio Link */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Soundtrack Title</label>
                  <input
                    type="text"
                    value={editSoundtrackTitle}
                    onChange={e => setEditSoundtrackTitle(e.target.value)}
                    placeholder="e.g. Teri Aankhon Ki Masti"
                    className="w-full px-3.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-slate-100 focus:border-amber-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Audio URL / Link</label>
                  <input
                    type="text"
                    value={editAudioUrl}
                    onChange={e => setEditAudioUrl(e.target.value)}
                    placeholder="https://... audio stream URL"
                    className="w-full px-3.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-slate-100 focus:border-amber-500 focus:outline-none text-[11px]"
                  />
                </div>
              </div>

              {/* Folder and Tags */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 block mb-1">Folder</label>
                  <input
                    type="text"
                    value={editFolder}
                    onChange={e => setEditFolder(e.target.value)}
                    className="w-full px-3.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-slate-100 focus:border-indigo-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Tags (comma separated)</label>
                  <input
                    type="text"
                    value={editTags}
                    onChange={e => setEditTags(e.target.value)}
                    className="w-full px-3.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-slate-100 focus:border-indigo-500 focus:outline-none"
                  />
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setEditingMedia(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveEdit}
                className="px-5 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-bold rounded-xl shadow-lg transition-all"
              >
                Save Details
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Single Delete Confirm Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="w-full max-w-sm rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4 shadow-2xl">
            <h3 className="text-base font-bold text-white">Confirm Delete</h3>
            <p className="text-xs text-slate-400">
              Are you sure you want to permanently delete this media asset? This action cannot be undone.
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setDeleteConfirmId(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleDeleteSingle}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold rounded-xl shadow-lg transition-all"
              >
                Delete File
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Batch Delete Confirm Modal */}
      {isBatchDeleting && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="w-full max-w-sm rounded-2xl bg-slate-900 border border-slate-800 p-6 space-y-4 shadow-2xl">
            <h3 className="text-base font-bold text-white">Batch Delete Media</h3>
            <p className="text-xs text-slate-400">
              Are you sure you want to delete <span className="text-white font-bold">{selectedIds.length}</span> selected files permanently?
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsBatchDeleting(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleBatchDelete}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold rounded-xl shadow-lg transition-all"
              >
                Delete {selectedIds.length} Files
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Official Poster Selector Modal */}
      {posterModalMedia && (
        <PosterSelectorModal
          media={posterModalMedia}
          isOpen={Boolean(posterModalMedia)}
          onClose={() => setPosterModalMedia(null)}
          availableImages={media.filter(m => m.mediaType === 'image')}
          onPosterUpdated={() => {
            onRefresh();
            setPosterModalMedia(null);
          }}
        />
      )}

      {/* Comments Drawer */}
      {commentDrawerMedia && (
        <CommentsDrawer
          media={commentDrawerMedia}
          isOpen={Boolean(commentDrawerMedia)}
          onClose={() => setCommentDrawerMedia(null)}
          onCommentsUpdated={(mediaId, count) => {
            setCommentsCounts((prev) => ({
              ...prev,
              [mediaId]: count
            }));
          }}
        />
      )}

      {/* Fullscreen User Folders & ID Directory Modal */}
      {isUserFoldersFullscreenOpen && (
        <UserFoldersFullscreenModal
          isOpen={isUserFoldersFullscreenOpen}
          onClose={() => setIsUserFoldersFullscreenOpen(false)}
          creators={creatorsList}
          media={media}
          initialUserId={selectedFullscreenUserId}
          initialFolder={selectedFullscreenFolder}
          onSelectFolderInLibrary={(folderName) => {
            setSelectedFolder(folderName);
            setActiveTab('all');
            setIsUserFoldersFullscreenOpen(false);
          }}
          onSelectVideo={onSelectVideo}
          onSelectImage={onSelectImage}
          onRefreshData={() => {
            fetchCreators();
            fetchFolders();
            onRefresh();
          }}
        />
      )}
    </div>
  );
};
