import React from 'react';
import { ExternalLink } from 'lucide-react';

interface RichCaptionProps {
  text?: string;
  className?: string;
  maxLines?: number;
  showAll?: boolean;
}

export const RichCaption: React.FC<RichCaptionProps> = ({
  text,
  className = '',
  maxLines,
  showAll = false
}) => {
  if (!text) return null;

  // Split into tokens: URLs, mentions (@word), hashtags (#word), and text
  const renderFormattedText = (rawText: string) => {
    const lines = rawText.split('\n');

    return lines.map((line, lineIdx) => {
      // Regular expression matching URLs, hashtags, and mentions
      const tokenRegex = /(https?:\/\/[^\s]+|www\.[^\s]+|#[a-zA-Z0-9_\u0900-\u097F]+|@[a-zA-Z0-9_\u0900-\u097F]+)/gi;
      const tokens = line.split(tokenRegex);

      return (
        <span key={lineIdx} className="block">
          {tokens.map((token, tokenIdx) => {
            if (!token) return null;

            // Check if token is a link (http://, https://, www.)
            const isUrl = /^https?:\/\//i.test(token) || /^www\./i.test(token);
            if (isUrl) {
              const fullHref = token.startsWith('www.') ? `https://${token}` : token;
              return (
                <a
                  key={tokenIdx}
                  href={fullHref}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={(e) => {
                    e.stopPropagation();
                  }}
                  className="inline-flex items-center gap-1 text-cyan-400 font-semibold hover:text-cyan-300 underline underline-offset-2 decoration-cyan-500/60 hover:decoration-cyan-300 break-all transition-all mr-1 cursor-pointer"
                  title={`Open link: ${fullHref}`}
                >
                  <span>{token}</span>
                  <ExternalLink className="w-3 h-3 shrink-0 opacity-80" />
                </a>
              );
            }

            // Check if token is a hashtag
            if (token.startsWith('#')) {
              return (
                <span
                  key={tokenIdx}
                  className="inline-block text-indigo-400 font-semibold hover:text-indigo-300 hover:underline cursor-pointer mr-1 transition-colors"
                  onClick={(e) => {
                    e.stopPropagation();
                  }}
                >
                  {token}
                </span>
              );
            }

            // Check if token is a mention
            if (token.startsWith('@')) {
              return (
                <span
                  key={tokenIdx}
                  className="inline-block text-pink-400 font-bold hover:text-pink-300 hover:underline cursor-pointer mr-1 transition-colors"
                  onClick={(e) => {
                    e.stopPropagation();
                  }}
                >
                  {token}
                </span>
              );
            }

            return <span key={tokenIdx}>{token}</span>;
          })}
        </span>
      );
    });
  };

  const lineClampClass = maxLines && !showAll ? `line-clamp-${maxLines}` : '';

  return (
    <div
      className={`text-xs text-slate-100 font-medium whitespace-pre-line leading-relaxed break-words ${lineClampClass} ${className}`}
    >
      {renderFormattedText(text)}
    </div>
  );
};

