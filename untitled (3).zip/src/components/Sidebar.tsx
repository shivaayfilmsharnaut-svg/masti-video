import React from 'react';
import { useAuth } from '../context/AuthContext.js';
import {
  LayoutDashboard,
  FolderKanban,
  UploadCloud,
  Code2,
  Shield,
  X,
  Radio,
  Sparkles,
  ExternalLink,
  MessageCircle,
  Mail,
  Zap,
  IndianRupee,
  Wallet,
  DollarSign
} from 'lucide-react';

export type ActiveTab = 'overview' | 'connect' | 'library' | 'upload' | 'social' | 'wallet' | 'account' | 'admob' | 'payouts' | 'admin' | 'easyconnect' | 'api';

interface SidebarProps {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  isOpen: boolean;
  onClose: () => void;
  totalMediaCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onTabChange,
  isOpen,
  onClose,
  totalMediaCount
}) => {
  const { isAdmin, isAuthenticated } = useAuth();

  const navItems = [
    {
      id: 'overview' as ActiveTab,
      label: 'Overview',
      icon: LayoutDashboard
    },
    {
      id: 'connect' as ActiveTab,
      label: 'Connect Masti Video',
      icon: Zap,
      tag: 'Full 360°'
    },
    {
      id: 'library' as ActiveTab,
      label: 'Media Library',
      icon: FolderKanban,
      badge: totalMediaCount > 0 ? String(totalMediaCount) : undefined
    },
    {
      id: 'upload' as ActiveTab,
      label: 'Upload Hub',
      icon: UploadCloud
    },
    {
      id: 'social' as ActiveTab,
      label: 'Community & Chat',
      icon: MessageCircle,
      tag: 'Live DMs'
    },
    {
      id: 'account' as ActiveTab,
      label: 'Gmail & Login Hub',
      icon: Mail,
      tag: 'Firebase Auth'
    },
    {
      id: 'wallet' as ActiveTab,
      label: 'My Wallet & Payouts',
      icon: IndianRupee,
      tag: 'Secure & Fast'
    },
    {
      id: 'admob' as ActiveTab,
      label: 'App Control Center',
      icon: DollarSign,
      tag: 'Config & Ads'
    },
    {
      id: 'payouts' as ActiveTab,
      label: 'Withdrawal Request',
      icon: IndianRupee,
      tag: 'Payouts'
    }
  ];


  if (isAdmin) {
    navItems.push({
      id: 'admin' as ActiveTab,
      label: 'Admin Console',
      icon: Shield
    });
  }

  const handleSelect = (tab: ActiveTab) => {
    onTabChange(tab);
    if (window.innerWidth < 1024) {
      onClose();
    }
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 z-40 bg-slate-950/80 backdrop-blur-sm lg:hidden animate-in fade-in"
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-50 w-64 bg-slate-950 border-r border-slate-800/80 flex flex-col transition-transform duration-300 ease-in-out lg:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Sidebar Header */}
        <div className="h-16 px-6 border-b border-slate-800/80 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-600 to-cyan-400 flex items-center justify-center text-white shadow-md shadow-indigo-600/30">
              <Sparkles className="w-4 h-4" />
            </div>
            <span className="font-extrabold text-sm tracking-tight text-white font-['Outfit']">
              MASTI BASH
            </span>
          </div>

          <button
            onClick={onClose}
            className="lg:hidden p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-900 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Navigation List */}
        <div className="flex-1 px-3 py-6 space-y-1.5 overflow-y-auto">
          <div className="px-3 pb-2 text-[10px] font-bold uppercase tracking-wider text-slate-500">
            Navigation
          </div>

          {navItems.map(item => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;

            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleSelect(item.id)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                  isActive
                    ? 'bg-gradient-to-r from-indigo-600 to-indigo-700 text-white shadow-lg shadow-indigo-600/20'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                </div>

                {item.badge && (
                  <span
                    className={`px-2 py-0.5 rounded-md text-[10px] font-mono font-bold ${
                      isActive ? 'bg-indigo-800 text-indigo-100' : 'bg-slate-900 text-slate-400'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}

                {item.tag && (
                  <span
                    className={`px-1.5 py-0.5 rounded text-[9px] font-bold tracking-tight uppercase ${
                      isActive ? 'bg-indigo-900 text-indigo-200' : 'bg-amber-500/10 text-amber-300 border border-amber-500/20'
                    }`}
                  >
                    {item.tag}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Admin Unlock Guide Helper */}
        {!isAdmin && (
          <div className="px-4 py-2">
            <button
              type="button"
              onClick={() => handleSelect('account')}
              className="w-full p-3.5 rounded-2xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/20 text-left space-y-1 cursor-pointer transition-all active:scale-95"
            >
              <div className="flex items-center gap-1.5 text-[11px] font-black text-amber-400">
                <span>🔑 Admin Panel Locked</span>
              </div>
              <p className="text-[10px] text-slate-300 leading-snug">
                <strong>Gmail & Login Hub</strong> tab me jaakar <strong>Raj Kali Kumar (Admin)</strong> par click karein, fir tab dikhne lagega.
              </p>
            </button>
          </div>
        )}

        {/* Bottom Integration Status Widget */}
        <div className="p-4 border-t border-slate-800/80">
          <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-[11px]">
              <span className="font-bold text-white flex items-center gap-1.5">
                <Radio className="w-3 h-3 text-emerald-400 animate-pulse" />
                <span>Masti Video Ready</span>
              </span>
              <span className="text-[10px] text-emerald-400 font-semibold uppercase">Active</span>
            </div>
            <p className="text-[10px] text-slate-400 leading-tight">
              Universal CORS & REST API endpoints ready for high-speed streaming.
            </p>
          </div>
        </div>
      </aside>
    </>
  );
};
