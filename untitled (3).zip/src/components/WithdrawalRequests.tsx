import React, { useState, useEffect } from 'react';
import { api, formatDate } from '../services/api.js';
import { PayoutTransaction } from '../types.js';
import {
  IndianRupee,
  CheckCircle2,
  XCircle,
  Clock,
  RefreshCw,
  Search,
  AlertCircle,
  Smartphone,
  CreditCard,
  TrendingUp,
  FileSpreadsheet,
  Check,
  X
} from 'lucide-react';

export const WithdrawalRequests: React.FC = () => {
  const [requests, setRequests] = useState<(PayoutTransaction & { userName?: string; userEmail?: string; avatarUrl?: string })[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<'all' | 'pending' | 'completed' | 'rejected'>('all');
  
  // Modal state for approving
  const [approvingItem, setApprovingItem] = useState<(PayoutTransaction & { userName?: string }) | null>(null);
  const [txnRef, setTxnRef] = useState('');
  const [processingAction, setProcessingAction] = useState(false);
  
  // State for rejection
  const [rejectingItem, setRejectingItem] = useState<(PayoutTransaction & { userName?: string }) | null>(null);

  const [toast, setToast] = useState<{ type: 'success' | 'error'; title: string; message: string } | null>(null);

  const showToast = (type: 'success' | 'error', title: string, message: string) => {
    setToast({ type, title, message });
    setTimeout(() => setToast(null), 4000);
  };

  const loadRequests = async () => {
    setLoading(true);
    try {
      const res = await api.getPayoutRequests();
      if (res.success && res.data) {
        setRequests(res.data);
      } else {
        showToast('error', 'Failed to fetch', res.error || 'Unable to load withdrawal requests.');
      }
    } catch (err: any) {
      showToast('error', 'Error', err.message || 'Something went wrong.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadRequests();
  }, []);

  const handleApprove = async () => {
    if (!approvingItem) return;
    setProcessingAction(true);
    try {
      const ref = txnRef.trim() || 'MB_REF_' + Math.floor(100000000 + Math.random() * 900000000);
      const res = await api.updatePayoutStatus(approvingItem.id, 'completed', ref);
      if (res.success && res.data) {
        setRequests(prev => prev.map(r => r.id === approvingItem.id ? { ...r, ...res.data } : r));
        showToast('success', 'Request Approved', `Payout request for ₹${approvingItem.amount.toFixed(2)} approved successfully!`);
        setApprovingItem(null);
        setTxnRef('');
      } else {
        showToast('error', 'Approval Failed', res.error || 'Could not approve.');
      }
    } catch (err: any) {
      showToast('error', 'Error', err.message);
    } finally {
      setProcessingAction(false);
    }
  };

  const handleReject = async () => {
    if (!rejectingItem) return;
    setProcessingAction(true);
    try {
      const res = await api.updatePayoutStatus(rejectingItem.id, 'rejected');
      if (res.success && res.data) {
        setRequests(prev => prev.map(r => r.id === rejectingItem.id ? { ...r, ...res.data } : r));
        showToast('success', 'Request Rejected', `Payout request for ₹${rejectingItem.amount.toFixed(2)} has been rejected. Refund sent to creator's wallet.`);
        setRejectingItem(null);
      } else {
        showToast('error', 'Rejection Failed', res.error || 'Could not reject.');
      }
    } catch (err: any) {
      showToast('error', 'Error', err.message);
    } finally {
      setProcessingAction(false);
    }
  };

  // Filters and search
  const filteredRequests = requests.filter(r => {
    const matchesFilter = activeFilter === 'all' || r.status === activeFilter;
    const searchLower = searchQuery.toLowerCase();
    const matchesSearch = 
      (r.userName || '').toLowerCase().includes(searchLower) ||
      (r.userEmail || '').toLowerCase().includes(searchLower) ||
      (r.accountInfo || '').toLowerCase().includes(searchLower) ||
      r.id.toLowerCase().includes(searchLower) ||
      (r.transactionRef || '').toLowerCase().includes(searchLower);
    
    return matchesFilter && matchesSearch;
  });

  const totalPendingAmount = requests
    .filter(r => r.status === 'pending')
    .reduce((sum, r) => sum + r.amount, 0);

  const totalApprovedAmount = requests
    .filter(r => r.status === 'completed')
    .reduce((sum, r) => sum + r.amount, 0);

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {toast && (
        <div className={`fixed top-5 right-5 z-50 flex items-center gap-3 px-4 py-3 rounded-2xl border shadow-2xl animate-in slide-in-from-top-4 duration-300 ${
          toast.type === 'success' 
            ? 'bg-emerald-950/90 text-emerald-300 border-emerald-500/30' 
            : 'bg-rose-950/90 text-rose-300 border-rose-500/30'
        }`}>
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <div>
            <h4 className="font-bold text-xs text-white">{toast.title}</h4>
            <p className="text-[11px] leading-snug mt-0.5">{toast.message}</p>
          </div>
        </div>
      )}

      {/* Header Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-violet-950/60 via-slate-900 to-indigo-950/60 border border-violet-500/30 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-violet-500 to-indigo-500 flex items-center justify-center text-white shadow-lg shadow-violet-500/20 font-black">
              <IndianRupee className="w-6 h-6 stroke-[2.5]" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                Creator Withdrawal Requests
              </h1>
              <p className="text-xs text-slate-300 mt-0.5">
                Masti Video App ke users jab apna wallet balance withdraw karenge, toh unka saara detail yahan aayega.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={loadRequests}
            disabled={loading}
            className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer self-start sm:self-auto"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-indigo-400 ${loading ? 'animate-spin' : ''}`} />
            <span>Refresh requests</span>
          </button>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5 pt-2">
          <div className="p-4 rounded-2xl bg-slate-950/50 border border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Total Pending requests</span>
              <span className="text-xl font-black text-amber-400 mt-1 block">
                {requests.filter(r => r.status === 'pending').length} Files
              </span>
            </div>
            <div className="px-3 py-1.5 rounded-lg bg-amber-500/10 text-amber-400 text-xs font-bold border border-amber-500/20">
              Review Pending
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-slate-950/50 border border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Total Pending Amount</span>
              <span className="text-xl font-black text-rose-400 mt-1 block">
                ₹{totalPendingAmount.toFixed(2)}
              </span>
            </div>
            <div className="w-8 h-8 rounded-full bg-rose-500/10 flex items-center justify-center text-rose-400 font-black text-xs">
              ⏳
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-slate-950/50 border border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Total Paid Out Amount</span>
              <span className="text-xl font-black text-emerald-400 mt-1 block">
                ₹{totalApprovedAmount.toFixed(2)}
              </span>
            </div>
            <div className="w-8 h-8 rounded-full bg-emerald-500/10 flex items-center justify-center text-emerald-400 font-black text-xs">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-2xl bg-slate-900 border border-slate-800">
        {/* Filter buttons */}
        <div className="flex flex-wrap items-center gap-1.5">
          {(['all', 'pending', 'completed', 'rejected'] as const).map(tab => {
            const isActive = activeFilter === tab;
            const count = requests.filter(r => tab === 'all' || r.status === tab).length;
            
            return (
              <button
                key={tab}
                type="button"
                onClick={() => setActiveFilter(tab)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all border ${
                  isActive
                    ? 'bg-violet-600 text-white border-violet-500 shadow-md shadow-violet-600/20'
                    : 'bg-slate-950 text-slate-400 border-slate-800 hover:bg-slate-800'
                }`}
              >
                <span className="capitalize">{tab === 'completed' ? 'Approved' : tab}</span>
                <span className={`ml-1.5 px-1.5 py-0.2 rounded-md text-[9px] font-mono font-black ${
                  isActive ? 'bg-violet-800 text-violet-100' : 'bg-slate-900 text-slate-500'
                }`}>
                  {count}
                </span>
              </button>
            );
          })}
        </div>

        {/* Search */}
        <div className="relative max-w-sm w-full">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by Creator name, UPI ID, Txn Ref..."
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-violet-500 focus:ring-1 focus:ring-violet-500 transition-all"
          />
        </div>
      </div>

      {/* Main Table */}
      <div className="rounded-2xl border border-slate-800 bg-slate-950 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-900/50 text-[11px] font-bold uppercase tracking-wider text-slate-400">
                <th className="p-4">Creator / ID</th>
                <th className="p-4">Withdraw Amount</th>
                <th className="p-4">Payment Method & details</th>
                <th className="p-4">Request date</th>
                <th className="p-4">Ref/Transaction ID</th>
                <th className="p-4 text-center">Status</th>
                <th className="p-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-xs">
              {filteredRequests.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-slate-500">
                    <div className="flex flex-col items-center justify-center gap-2 max-w-sm mx-auto">
                      <AlertCircle className="w-8 h-8 text-slate-600 animate-bounce" />
                      <p className="font-bold text-slate-400 text-xs">No Requests Found</p>
                      <p className="text-[11px] text-slate-500 leading-normal">
                        Masti Video App par users jab withdraw request karenge, unki entries aapko yahan real-time dikhayi dengi.
                      </p>
                    </div>
                  </td>
                </tr>
              ) : (
                filteredRequests.map(r => {
                  const isUPI = r.method === 'upi' || r.method === 'paytm';
                  return (
                    <tr key={r.id} className="hover:bg-slate-900/20 transition-colors">
                      {/* Creator */}
                      <td className="p-4">
                        <div className="flex items-center gap-3">
                          {/* Beautiful Circular DP */}
                          <div className="relative w-10 h-10 rounded-full border-2 border-violet-500/30 overflow-hidden bg-slate-900 flex-shrink-0">
                            {r.avatarUrl ? (
                              <img
                                src={r.avatarUrl}
                                alt={r.userName || 'Masti Creator'}
                                referrerPolicy="no-referrer"
                                className="w-full h-full object-cover"
                                onError={(e) => {
                                  // Fallback if image fails to load
                                  (e.currentTarget as HTMLImageElement).src = `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(r.userName || 'MC')}`;
                                }}
                              />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-violet-600 to-indigo-700 text-white font-extrabold text-xs">
                                {(r.userName || 'MC').split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()}
                              </div>
                            )}
                            {/* Verification indicator */}
                            <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-slate-950 rounded-full" />
                          </div>
                          <div className="flex flex-col gap-0.5">
                            <span className="font-extrabold text-white text-xs sm:text-sm">
                              {r.userName || 'Masti Creator'}
                            </span>
                            <span className="text-[10px] text-violet-400 font-mono font-bold leading-none">
                              ID: {r.userId}
                            </span>
                            <span className="text-[10px] text-slate-500">
                              {r.userEmail}
                            </span>
                          </div>
                        </div>
                      </td>

                      {/* Amount */}
                      <td className="p-4 font-black text-white text-sm">
                        <div className="flex items-center gap-0.5 text-emerald-400">
                          <IndianRupee className="w-3.5 h-3.5" />
                          <span>{r.amount.toFixed(2)}</span>
                        </div>
                      </td>

                      {/* Payment Detail */}
                      <td className="p-4">
                        <div className="flex items-start gap-2.5 max-w-[280px]">
                          <div className={`w-8 h-8 rounded-xl flex items-center justify-center mt-0.5 flex-shrink-0 ${
                            r.method === 'bank_transfer'
                              ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                              : 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/20'
                          }`}>
                            {r.method === 'bank_transfer' ? (
                              <CreditCard className="w-4 h-4" />
                            ) : (
                              <Smartphone className="w-4 h-4" />
                            )}
                          </div>
                          <div className="flex flex-col gap-1">
                            <div className="flex items-center gap-1.5">
                              <span className="font-black text-[9px] uppercase tracking-wider px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300">
                                {r.method === 'bank_transfer' ? '🏦 Bank Transfer' : r.method === 'paytm' ? '📱 Paytm Wallet' : '⚡ UPI Pay'}
                              </span>
                            </div>
                            
                            {r.method === 'bank_transfer' ? (
                              <div className="text-[11px] leading-relaxed text-slate-200 select-all space-y-0.5 font-sans">
                                {r.accountInfo.split(',').map((part, i) => (
                                  <div key={i} className="font-medium">
                                    {part.trim()}
                                  </div>
                                ))}
                              </div>
                            ) : (
                              <span className="text-[11px] font-mono text-violet-300 select-all font-bold tracking-tight leading-tight break-all bg-violet-950/20 px-1.5 py-0.5 rounded border border-violet-500/10">
                                {r.accountInfo}
                              </span>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* Created At */}
                      <td className="p-4 text-slate-400">
                        {formatDate(r.createdAt)}
                      </td>

                      {/* Ref/Transaction ID */}
                      <td className="p-4 font-mono text-[11px] text-slate-300 select-all">
                        {r.transactionRef || 'N/A'}
                      </td>

                      {/* Status */}
                      <td className="p-4 text-center">
                        <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-extrabold uppercase border ${
                          r.status === 'pending'
                            ? 'bg-amber-500/10 text-amber-400 border-amber-500/20 animate-pulse'
                            : r.status === 'completed'
                            ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                            : 'bg-rose-500/10 text-rose-400 border-rose-500/20'
                        }`}>
                          {r.status === 'pending' && <Clock className="w-3 h-3" />}
                          {r.status === 'completed' && <CheckCircle2 className="w-3 h-3" />}
                          {r.status === 'rejected' && <XCircle className="w-3 h-3" />}
                          <span>{r.status === 'completed' ? 'APPROVED' : r.status === 'pending' ? 'PENDING' : 'REJECTED'}</span>
                        </span>
                      </td>

                      {/* Actions */}
                      <td className="p-4 text-right">
                        {r.status === 'pending' ? (
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              type="button"
                              onClick={() => {
                                setApprovingItem(r);
                                setTxnRef('');
                              }}
                              className="px-2.5 py-1.5 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/30 text-emerald-300 font-bold text-[10px] transition-all flex items-center gap-1 cursor-pointer"
                              title="Approve Payout"
                            >
                              <Check className="w-3 h-3" />
                              <span>APPROVE</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => setRejectingItem(r)}
                              className="px-2.5 py-1.5 rounded-xl bg-rose-600/20 hover:bg-rose-600/30 border border-rose-500/30 text-rose-300 font-bold text-[10px] transition-all flex items-center gap-1 cursor-pointer"
                              title="Reject & Refund Payout"
                            >
                              <X className="w-3 h-3" />
                              <span>REJECT</span>
                            </button>
                          </div>
                        ) : (
                          <span className="text-[10px] font-bold text-slate-500">Processed</span>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* APPROVAL MODAL */}
      {approvingItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3 text-emerald-400">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center border border-emerald-500/20">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-extrabold text-white text-sm">Approve Withdrawal Request</h3>
                <p className="text-[11px] text-slate-400">Creator ko paise bhej diye gaye hain? Yahan transaction ID dalein.</p>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">Creator Name:</span>
                <span className="font-bold text-white">{approvingItem.userName}</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">Withdraw Amount:</span>
                <span className="font-black text-emerald-400">₹{approvingItem.amount.toFixed(2)}</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">Method:</span>
                <span className="font-semibold text-slate-200 capitalize">{approvingItem.method.replace('_', ' ')}</span>
              </div>
              <div className="flex flex-col gap-0.5 text-xs border-t border-slate-800/80 pt-2 mt-1">
                <span className="text-slate-400">Payment details:</span>
                <span className="font-mono text-slate-100 break-all select-all">{approvingItem.accountInfo}</span>
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-[11px] font-bold text-slate-400 block">Bank Ref / UPI Transaction ID (Optional)</label>
              <input
                type="text"
                value={txnRef}
                onChange={(e) => setTxnRef(e.target.value)}
                placeholder="e.g. TXN9876543210 or UPI_9823..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-emerald-500 transition-all font-mono"
              />
              <span className="text-[9px] text-slate-500 block">Blank chhodne par platform ek dynamic reference code auto-generate kar dega.</span>
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setApprovingItem(null)}
                disabled={processingAction}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white hover:bg-slate-800/50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleApprove}
                disabled={processingAction}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-slate-950 cursor-pointer flex items-center gap-1.5 active:scale-95 transition-all shadow-lg shadow-emerald-600/10"
              >
                {processingAction ? 'Processing...' : 'Yes, Approve Payout'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* REJECTION MODAL */}
      {rejectingItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3 text-rose-400">
              <div className="w-10 h-10 rounded-xl bg-rose-500/10 flex items-center justify-center border border-rose-500/20">
                <XCircle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-extrabold text-white text-sm">Reject Withdrawal Request?</h3>
                <p className="text-[11px] text-slate-400">Aap is request ko reject kyun karna chahte hain?</p>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950 border border-rose-500/10 space-y-2 text-xs">
              <p className="text-slate-300">
                Is request ko reject karne par <strong>₹{rejectingItem.amount.toFixed(2)}</strong> ki poori rashi automatic tarike se <strong>{rejectingItem.userName}</strong> ke wallet balance mein wapas credit (refund) ho jayegi.
              </p>
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setRejectingItem(null)}
                disabled={processingAction}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white hover:bg-slate-800/50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleReject}
                disabled={processingAction}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-rose-600 hover:bg-rose-500 text-white cursor-pointer flex items-center gap-1.5 active:scale-95 transition-all"
              >
                {processingAction ? 'Processing...' : 'Yes, Reject & Refund'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
