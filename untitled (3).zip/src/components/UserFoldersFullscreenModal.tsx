import React, { useState, useEffect, useMemo } from 'react';
import { MediaFile, MonetizationData, CreatorProfileItem } from '../types.js';
import { api, formatDate, formatBytes, resolveMediaUrl } from '../services/api.js';
import { UserMonetizationCard } from './UserMonetizationCard.js';
import { useToast } from './Toast.js';
import { useAuth } from '../context/AuthContext.js';
import {
  X,
  Search,
  CheckSquare,
  Square,
  Users,
  Folder,
  CheckCircle2,
  AlertTriangle,
  Copy,
  Check,
  IndianRupee,
  Film,
  Play,
  ArrowRight,
  UserCheck,
  UserPlus,
  RefreshCw,
  ShieldCheck,
  Sliders,
  ExternalLink,
  ChevronRight,
  Filter,
  Maximize2,
  Trash2,
  Download,
  Share2,
  Eye,
  Lock,
  Unlock
} from 'lucide-react';

interface UserFoldersFullscreenModalProps {
  isOpen: boolean;
  onClose: () => void;
  creators: CreatorProfileItem[];
  media: MediaFile[];
  initialUserId?: string | null;
  initialFolder?: string | null;
  onSelectFolderInLibrary?: (folderName: string) => void;
  onSelectVideo?: (media: MediaFile) => void;
  onSelectImage?: (media: MediaFile) => void;
  onRefreshData?: () => void;
}

export const UserFoldersFullscreenModal: React.FC<UserFoldersFullscreenModalProps> = ({
  isOpen,
  onClose,
  creators,
  media,
  initialUserId,
  initialFolder,
  onSelectFolderInLibrary,
  onSelectVideo,
  onSelectImage,
  onRefreshData
}) => {
  const { user: currentUser } = useAuth();
  const { showToast } = useToast();

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'monetized' | 'disabled' | 'has_media'>('all');
  const [selectedUserIds, setSelectedUserIds] = useState<Set<string>>(new Set());
  const [activeCreatorId, setActiveCreatorId] = useState<string>('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isBatchProcessing, setIsBatchProcessing] = useState(false);
  const [mobileShowDetail, setMobileShowDetail] = useState(false);
  const [followingMap, setFollowingMap] = useState<Record<string, boolean>>({});

  // Merge creators with any media users that might not have a formal profile, strictly ensuring unique IDs
  const allUserItems = useMemo(() => {
    const userMap = new Map<string, CreatorProfileItem>();
    const emailToId = new Map<string, string>();

    // 1. Add formal creators indexed strictly by creator.id
    creators.forEach((c) => {
      if (!c.id) return;
      if (!userMap.has(c.id)) {
        userMap.set(c.id, { ...c });
      }
      if (c.email) {
        emailToId.set(c.email.toLowerCase(), c.id);
      }
    });

    // 2. Add any users from media files that don't match existing creator id or email
    media.forEach((m) => {
      const uId = m.userId;
      const uEmail = m.userEmail ? m.userEmail.toLowerCase() : '';

      const matchedCreatorId = (uId && userMap.has(uId))
        ? uId
        : (uEmail && emailToId.has(uEmail))
          ? emailToId.get(uEmail)
          : null;

      if (!matchedCreatorId) {
        const canonicalId = uId || (uEmail ? `usr_${uEmail.replace(/[^a-zA-Z0-9]/g, '_')}` : (m.folder || 'unknown'));
        if (!userMap.has(canonicalId)) {
          const derivedName = m.userName || (uEmail ? uEmail.split('@')[0] : canonicalId);
          const item: CreatorProfileItem = {
            id: canonicalId,
            name: derivedName,
            username: uEmail ? uEmail.split('@')[0] : derivedName.toLowerCase().replace(/\s+/g, '_'),
            email: m.userEmail || (canonicalId.includes('@') ? canonicalId : ''),
            role: 'user',
            avatarUrl: m.userAvatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${canonicalId}`,
            followersCount: 0,
            followingCount: 0,
            mediaCount: 0,
            likesCount: 0,
            badge: 'Creator'
          };
          userMap.set(canonicalId, item);
          if (uEmail) {
            emailToId.set(uEmail, canonicalId);
          }
        }
      }
    });

    // Extract strictly unique items by user id
    const list = Array.from(userMap.values());
    return list.map((item) => {
      const userMedia = media.filter(
        (m) =>
          m.userId === item.id ||
          (item.email && m.userEmail?.toLowerCase() === item.email.toLowerCase()) ||
          (m.folder && m.folder.toLowerCase() === item.id.toLowerCase()) ||
          (m.folder && item.email && m.folder.toLowerCase() === item.email.toLowerCase())
      );
      const computedLikes = userMedia.reduce((sum, m) => sum + (m.likes || 0), 0);
      return {
        ...item,
        mediaCount: userMedia.length,
        likesCount: item.likesCount || computedLikes
      };
    });
  }, [creators, media]);

  // Set initial active creator
  useEffect(() => {
    if (!isOpen) return;

    if (initialUserId) {
      const matched = allUserItems.find(
        (u) => u.id === initialUserId || (u.email && u.email === initialUserId)
      );
      if (matched) {
        setActiveCreatorId(matched.id);
        setMobileShowDetail(true);
        return;
      }
    }

    if (initialFolder) {
      const matched = allUserItems.find(
        (u) =>
          u.id.toLowerCase() === initialFolder.toLowerCase() ||
          (u.email && u.email.toLowerCase() === initialFolder.toLowerCase()) ||
          u.name.toLowerCase() === initialFolder.toLowerCase()
      );
      if (matched) {
        setActiveCreatorId(matched.id);
        setMobileShowDetail(true);
        return;
      }
    }

    // Default to first user if none active
    if (!activeCreatorId && allUserItems.length > 0) {
      setActiveCreatorId(allUserItems[0].id);
    }
  }, [isOpen, initialUserId, initialFolder, allUserItems]);

  // Escape key handler to close modal
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  // Filtered users list
  const filteredUsers = useMemo(() => {
    const seenIds = new Set<string>();
    return allUserItems.filter((u) => {
      if (!u.id || seenIds.has(u.id)) return false;
      seenIds.add(u.id);

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchesName = u.name?.toLowerCase().includes(q);
        const matchesId = u.id?.toLowerCase().includes(q);
        const matchesEmail = u.email?.toLowerCase().includes(q);
        const matchesUsername = u.username?.toLowerCase().includes(q);
        if (!matchesName && !matchesId && !matchesEmail && !matchesUsername) {
          return false;
        }
      }

      // Status filter
      if (statusFilter === 'monetized') {
        if (u.monetization?.isEnabled === false || u.monetization?.monetizationStatus === 'disabled') {
          return false;
        }
      } else if (statusFilter === 'disabled') {
        if (u.monetization?.isEnabled !== false && u.monetization?.monetizationStatus !== 'disabled') {
          return false;
        }
      } else if (statusFilter === 'has_media') {
        if (u.mediaCount === 0) return false;
      }

      return true;
    });
  }, [allUserItems, searchQuery, statusFilter]);

  // Current active user object
  const activeUser = useMemo(() => {
    return allUserItems.find((u) => u.id === activeCreatorId) || allUserItems[0] || null;
  }, [allUserItems, activeCreatorId]);

  // Media uploaded by the active user in their user folder
  const activeUserMedia = useMemo(() => {
    if (!activeUser) return [];
    return media.filter(
      (m) =>
        m.userId === activeUser.id ||
        (activeUser.email && m.userEmail === activeUser.email) ||
        (m.folder && m.folder.toLowerCase() === activeUser.id.toLowerCase()) ||
        (m.folder && activeUser.email && m.folder.toLowerCase() === activeUser.email.toLowerCase())
    );
  }, [media, activeUser]);

  // Checkbox Selection Handlers
  const handleToggleSelectUser = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setSelectedUserIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const handleSelectAll = () => {
    if (selectedUserIds.size === filteredUsers.length && filteredUsers.length > 0) {
      setSelectedUserIds(new Set());
    } else {
      setSelectedUserIds(new Set(filteredUsers.map((u) => u.id)));
    }
  };

  const handleCopyId = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    navigator.clipboard.writeText(id);
    setCopiedId(id);
    showToast('success', 'User ID Copied', id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleCopySelectedIds = () => {
    if (selectedUserIds.size === 0) return;
    const idsString = Array.from(selectedUserIds).join(', ');
    navigator.clipboard.writeText(idsString);
    showToast('success', 'IDs Copied', `${selectedUserIds.size} User IDs copied to clipboard!`);
  };

  // Bulk Monetization Enable / Disable
  const handleBulkSetMonetization = async (enable: boolean) => {
    if (selectedUserIds.size === 0) return;
    setIsBatchProcessing(true);
    const ids: string[] = Array.from(selectedUserIds);
    let successCount = 0;

    for (const id of ids) {
      try {
        await api.updateMonetizationControl(String(id), {
          isEnabled: enable,
          monetizationStatus: enable ? 'active' : 'disabled'
        });
        successCount++;
      } catch (err) {
        console.warn(`Failed to update monetization for ${id}:`, err);
      }
    }

    setIsBatchProcessing(false);
    showToast(
      'success',
      enable ? 'Monetization Enabled' : 'Monetization Disabled',
      `Updated ${successCount} user accounts successfully.`
    );
    if (onRefreshData) onRefreshData();
  };

  // Handle Follow / Unfollow
  const handleToggleFollow = async (targetId: string, name: string) => {
    if (!currentUser?.id) {
      showToast('error', 'Login Required', 'Please sign in to follow creators.');
      return;
    }
    const isCurrentlyFollowing = Boolean(followingMap[targetId]);
    setFollowingMap((prev) => ({ ...prev, [targetId]: !isCurrentlyFollowing }));

    try {
      const res = await api.toggleFollow(
        targetId,
        name,
        currentUser.id,
        currentUser.name || 'Masti Viewer'
      );
      if (res.success && res.data) {
        setFollowingMap((prev) => ({ ...prev, [targetId]: res.data.isFollowing }));
        showToast(
          res.data.isFollowing ? 'success' : 'info',
          res.data.isFollowing ? 'Following' : 'Unfollowed',
          res.data.isFollowing ? `Now following ${name}` : `Unfollowed ${name}`
        );
      }
    } catch (err) {
      setFollowingMap((prev) => ({ ...prev, [targetId]: isCurrentlyFollowing }));
      showToast('error', 'Action Failed', 'Could not update follow status.');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-slate-950 text-slate-100 animate-in fade-in duration-150 h-[100dvh] w-[100dvw] overflow-hidden">
      {/* ========================================================================= */}
      {/* 1. FULLSCREEN TOP NAVIGATION & ACTION BAR */}
      {/* ========================================================================= */}
      <header className="h-14 sm:h-16 px-3 sm:px-6 bg-slate-900/95 border-b border-slate-800 flex items-center justify-between gap-3 shrink-0 z-20 backdrop-blur-md">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-tr from-indigo-600 to-purple-600 flex items-center justify-center text-white shadow-md shadow-indigo-600/30 shrink-0">
            <Users className="w-4 h-4 sm:w-5 sm:h-5" />
          </div>
          <div className="min-w-0">
            <h2 className="text-xs sm:text-sm font-black text-white tracking-wide truncate flex items-center gap-2">
              <span>User Folders & ID Directory</span>
              <span className="px-2 py-0.5 rounded-full text-[10px] bg-purple-950/80 text-purple-300 font-bold border border-purple-800/50">
                {allUserItems.length} IDs
              </span>
            </h2>
            <p className="text-[10px] sm:text-[11px] text-slate-400 truncate hidden sm:block">
              Compact multi-select user list • Click any User ID to inspect full profile & live wallet
            </p>
          </div>
        </div>

        {/* Action Controls & Close */}
        <div className="flex items-center gap-2">
          {onRefreshData && (
            <button
              type="button"
              onClick={onRefreshData}
              className="p-1.5 sm:px-2.5 sm:py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
              title="Refresh User Data"
            >
              <RefreshCw className="w-3.5 h-3.5 text-cyan-400" />
              <span className="hidden md:inline">Sync</span>
            </button>
          )}

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 sm:px-3 sm:py-1.5 rounded-xl bg-rose-600/20 hover:bg-rose-600 text-rose-300 hover:text-white border border-rose-500/30 text-xs font-bold flex items-center gap-1 transition-all cursor-pointer"
            title="Close Fullscreen View (Esc)"
          >
            <X className="w-4 h-4" />
            <span className="hidden sm:inline">Close</span>
          </button>
        </div>
      </header>

      {/* ========================================================================= */}
      {/* 2. BATCH SELECTION & FILTER TOOLBAR */}
      {/* ========================================================================= */}
      <div className="px-3 sm:px-6 py-2 bg-slate-900/60 border-b border-slate-800/80 flex flex-wrap items-center justify-between gap-2.5 shrink-0 text-xs">
        {/* Search Input & Filter Tabs */}
        <div className="flex items-center gap-2 flex-1 min-w-[240px]">
          <div className="relative flex-1 max-w-md">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search User ID (usr_...), Name, Email, Username..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>

          {/* Status Filter Chips */}
          <div className="hidden lg:flex items-center gap-1 p-0.5 bg-slate-950 rounded-xl border border-slate-800">
            <button
              type="button"
              onClick={() => setStatusFilter('all')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
                statusFilter === 'all'
                  ? 'bg-indigo-600 text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              All ({allUserItems.length})
            </button>
            <button
              type="button"
              onClick={() => setStatusFilter('monetized')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
                statusFilter === 'monetized'
                  ? 'bg-emerald-600 text-white'
                  : 'text-emerald-400 hover:text-emerald-300'
              }`}
            >
              Monetized
            </button>
            <button
              type="button"
              onClick={() => setStatusFilter('disabled')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
                statusFilter === 'disabled'
                  ? 'bg-rose-600 text-white'
                  : 'text-rose-400 hover:text-rose-300'
              }`}
            >
              Disabled
            </button>
            <button
              type="button"
              onClick={() => setStatusFilter('has_media')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
                statusFilter === 'has_media'
                  ? 'bg-purple-600 text-white'
                  : 'text-purple-400 hover:text-purple-300'
              }`}
            >
              With Uploads
            </button>
          </div>
        </div>

        {/* Batch Operations Bar (Tik Maarke Ek Bar Me Sabhi Select & Actions) */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Master Select All Checkbox Button */}
          <button
            type="button"
            onClick={handleSelectAll}
            className={`px-3 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
              selectedUserIds.size === filteredUsers.length && filteredUsers.length > 0
                ? 'bg-indigo-600 text-white border-indigo-500 shadow-md shadow-indigo-600/30'
                : 'bg-slate-950 hover:bg-slate-800 text-slate-300 border-slate-800'
            }`}
          >
            {selectedUserIds.size === filteredUsers.length && filteredUsers.length > 0 ? (
              <CheckSquare className="w-3.5 h-3.5 text-white" />
            ) : (
              <Square className="w-3.5 h-3.5 text-slate-400" />
            )}
            <span>
              {selectedUserIds.size === filteredUsers.length && filteredUsers.length > 0
                ? 'Deselect All'
                : `Select All (${filteredUsers.length})`}
            </span>
          </button>

          {/* Active Selection Count & Batch Actions */}
          {selectedUserIds.size > 0 && (
            <div className="flex items-center gap-1.5 animate-in fade-in">
              <span className="px-2 py-1 rounded-lg bg-indigo-950 text-indigo-300 border border-indigo-800/60 text-[11px] font-bold">
                ✓ {selectedUserIds.size} Selected
              </span>

              {/* Copy Selected IDs */}
              <button
                type="button"
                onClick={handleCopySelectedIds}
                className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center gap-1 cursor-pointer"
                title="Copy all selected IDs to clipboard"
              >
                <Copy className="w-3 h-3 text-cyan-400" />
                <span>Copy IDs</span>
              </button>

              {/* Bulk Enable Monetize */}
              <button
                type="button"
                disabled={isBatchProcessing}
                onClick={() => handleBulkSetMonetization(true)}
                className="px-2.5 py-1.5 rounded-xl bg-emerald-600/30 hover:bg-emerald-600 text-emerald-300 hover:text-white border border-emerald-500/40 text-xs font-semibold flex items-center gap-1 transition-all cursor-pointer"
                title="Enable monetization for all selected users"
              >
                <Unlock className="w-3 h-3" />
                <span>Enable ({selectedUserIds.size})</span>
              </button>

              {/* Bulk Disable Monetize */}
              <button
                type="button"
                disabled={isBatchProcessing}
                onClick={() => handleBulkSetMonetization(false)}
                className="px-2.5 py-1.5 rounded-xl bg-rose-600/30 hover:bg-rose-600 text-rose-300 hover:text-white border border-rose-500/40 text-xs font-semibold flex items-center gap-1 transition-all cursor-pointer"
                title="Disable monetization for all selected users"
              >
                <Lock className="w-3 h-3" />
                <span>Disable ({selectedUserIds.size})</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 3. MAIN BODY: SPLIT VIEW (COMPACT LIST ON LEFT, FULL DETAILS ON RIGHT) */}
      {/* ========================================================================= */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* ----------------- LEFT PANE: COMPACT USER ID LIST ----------------- */}
        <div
          className={`flex-1 md:w-5/12 lg:w-4/12 md:max-w-md lg:max-w-lg border-r border-slate-800 flex flex-col bg-slate-950 overflow-hidden ${
            mobileShowDetail ? 'hidden md:flex' : 'flex'
          }`}
        >
          {/* List Header Count */}
          <div className="px-4 py-2 bg-slate-900/40 border-b border-slate-800/60 flex items-center justify-between text-[11px] text-slate-400 shrink-0">
            <span>
              Showing <strong className="text-white font-mono">{filteredUsers.length}</strong> user IDs
            </span>
            <span className="text-slate-500 text-[10px]">Click any user to inspect profile</span>
          </div>

          {/* Scrollable Compact Rows */}
          <div className="flex-1 overflow-y-auto divide-y divide-slate-900 scrollbar-thin">
            {filteredUsers.length === 0 ? (
              <div className="p-8 text-center space-y-2">
                <Users className="w-8 h-8 text-slate-600 mx-auto" />
                <p className="text-xs text-slate-400 font-semibold">No user IDs found</p>
                <p className="text-[11px] text-slate-600">Try changing your search keyword.</p>
              </div>
            ) : (
              filteredUsers.map((item) => {
                const isSelected = selectedUserIds.has(item.id);
                const isActive = activeUser?.id === item.id;
                const isMonetized = item.monetization?.isEnabled !== false && item.monetization?.monetizationStatus !== 'disabled';
                const walletBalance = item.monetization?.walletBalance ?? 142.91;

                return (
                  <div
                    key={item.id}
                    onClick={() => {
                      setActiveCreatorId(item.id);
                      setMobileShowDetail(true);
                    }}
                    className={`px-3.5 py-2.5 flex items-center justify-between gap-3 transition-colors cursor-pointer select-none group ${
                      isActive
                        ? 'bg-purple-950/40 border-l-4 border-l-purple-500'
                        : isSelected
                        ? 'bg-indigo-950/20 hover:bg-slate-900/80 border-l-4 border-l-indigo-600'
                        : 'hover:bg-slate-900/60 border-l-4 border-l-transparent'
                    }`}
                  >
                    {/* Left: Checkbox + Avatar + IDs (Chhota Chhota list view) */}
                    <div className="flex items-center gap-2.5 min-w-0 flex-1">
                      {/* Checkbox (Tik maarne ke liye) */}
                      <button
                        type="button"
                        onClick={(e) => handleToggleSelectUser(item.id, e)}
                        className={`w-5 h-5 rounded-md flex items-center justify-center transition-all shrink-0 cursor-pointer ${
                          isSelected
                            ? 'bg-indigo-600 text-white shadow-sm'
                            : 'bg-slate-900 border border-slate-700 text-transparent hover:border-indigo-400'
                        }`}
                        title="Tick / Untick select"
                      >
                        <Check className="w-3.5 h-3.5" />
                      </button>

                      {/* Small Avatar */}
                      <img
                        src={item.avatarUrl}
                        alt={item.name}
                        className="w-7 h-7 rounded-lg object-cover bg-slate-800 border border-slate-700 shrink-0"
                        referrerPolicy="no-referrer"
                      />

                      {/* User Info & Monospace ID */}
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs font-bold text-white truncate max-w-[130px]">
                            {item.name}
                          </span>
                          <span
                            className={`w-1.5 h-1.5 rounded-full shrink-0 ${
                              isMonetized ? 'bg-emerald-400' : 'bg-rose-500'
                            }`}
                            title={isMonetized ? 'Monetization Active' : 'Monetization Disabled'}
                          />
                        </div>

                        {/* Monospace User ID with copy button */}
                        <div className="flex items-center gap-1 mt-0.5">
                          <span
                            className="font-mono text-[10px] text-purple-300 bg-purple-950/50 px-1.5 py-0.2 rounded border border-purple-800/40 select-all truncate max-w-[130px]"
                            title={item.id}
                          >
                            {item.id}
                          </span>
                          <button
                            type="button"
                            onClick={(e) => handleCopyId(item.id, e)}
                            className="text-slate-500 hover:text-cyan-400 transition-colors p-0.5 cursor-pointer"
                            title="Copy User ID"
                          >
                            {copiedId === item.id ? (
                              <Check className="w-3 h-3 text-emerald-400" />
                            ) : (
                              <Copy className="w-3 h-3" />
                            )}
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Right: Uploads count + Wallet Badge + Arrow */}
                    <div className="flex items-center gap-2 shrink-0">
                      {/* Uploads Count */}
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-400 font-mono flex items-center gap-1">
                        <Film className="w-2.5 h-2.5 text-indigo-400" />
                        <span>{item.mediaCount}</span>
                      </span>

                      {/* Wallet Balance / Monetization Pill */}
                      <span
                        className={`text-[10px] font-mono px-1.5 py-0.5 rounded font-bold ${
                          isMonetized
                            ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-800/40'
                            : 'bg-rose-950/80 text-rose-300 border border-rose-800/40'
                        }`}
                      >
                        ₹{walletBalance.toFixed(0)}
                      </span>

                      <ChevronRight
                        className={`w-3.5 h-3.5 transition-transform ${
                          isActive ? 'text-purple-400 translate-x-0.5' : 'text-slate-600 group-hover:text-slate-400'
                        }`}
                      />
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* ----------------- RIGHT PANE: FULL PROFILE & WALLET DETAILS ----------------- */}
        <div
          className={`flex-1 bg-slate-900/40 overflow-y-auto scrollbar-thin p-3 sm:p-6 space-y-4 ${
            mobileShowDetail ? 'flex flex-col' : 'hidden md:flex md:flex-col'
          }`}
        >
          {/* Mobile Back to List Button */}
          <div className="md:hidden flex items-center justify-between pb-2 border-b border-slate-800">
            <button
              type="button"
              onClick={() => setMobileShowDetail(false)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 text-slate-200 text-xs font-bold cursor-pointer"
            >
              <span>← Back to User IDs List</span>
            </button>
            <span className="text-xs text-purple-300 font-mono">
              ID: {activeUser?.id}
            </span>
          </div>

          {activeUser ? (
            <div className="space-y-4 max-w-4xl mx-auto w-full animate-in fade-in duration-150">
              {/* Profile Card Header */}
              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-purple-950/60 via-slate-900 to-indigo-950/50 border border-purple-800/40 shadow-xl">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex items-center gap-3.5">
                    <img
                      src={activeUser.avatarUrl}
                      alt={activeUser.name}
                      className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl border-2 border-purple-500/50 object-cover bg-slate-800 shrink-0 shadow-lg"
                      referrerPolicy="no-referrer"
                    />
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="text-base sm:text-lg font-bold text-white leading-tight">
                          {activeUser.name}
                        </h3>
                        <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase bg-purple-900/60 text-purple-200 border border-purple-700/50">
                          {activeUser.badge || 'Creator'}
                        </span>
                      </div>

                      <span className="text-xs text-purple-400 font-mono block mt-0.5">
                        {activeUser.username.startsWith('@') ? activeUser.username : `@${activeUser.username}`}
                      </span>

                      {activeUser.email && (
                        <span className="text-[11px] text-slate-300 block truncate mt-0.5">
                          {activeUser.email}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Actions (Follow & Filter Library) */}
                  <div className="flex items-center gap-2 flex-wrap">
                    <button
                      type="button"
                      onClick={() => handleToggleFollow(activeUser.id, activeUser.name)}
                      className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-md cursor-pointer ${
                        followingMap[activeUser.id]
                          ? 'bg-slate-800 text-emerald-400 border border-emerald-500/40'
                          : 'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white'
                      }`}
                    >
                      {followingMap[activeUser.id] ? (
                        <>
                          <UserCheck className="w-3.5 h-3.5" />
                          <span>Following</span>
                        </>
                      ) : (
                        <>
                          <UserPlus className="w-3.5 h-3.5" />
                          <span>+ Follow</span>
                        </>
                      )}
                    </button>

                    {onSelectFolderInLibrary && (
                      <button
                        type="button"
                        onClick={() => {
                          onSelectFolderInLibrary(activeUser.id);
                          onClose();
                        }}
                        className="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all flex items-center gap-1.5 shadow-md shadow-indigo-950/40 cursor-pointer"
                        title="View files in Media Library"
                      >
                        <Folder className="w-3.5 h-3.5" />
                        <span>Filter in Library</span>
                      </button>
                    )}
                  </div>
                </div>

                {/* Permanent Identifiers Bar */}
                <div className="mt-3.5 pt-3 border-t border-slate-800/80 grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-500 block">
                        Permanent User ID
                      </span>
                      <span className="font-mono text-purple-300 font-bold select-all text-xs">
                        {activeUser.id}
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={(e) => handleCopyId(activeUser.id, e)}
                      className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700/60 cursor-pointer"
                      title="Copy User ID"
                    >
                      {copiedId === activeUser.id ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center justify-between">
                    <div className="min-w-0 flex-1">
                      <span className="text-[10px] uppercase font-bold text-slate-500 block">
                        Registered Email
                      </span>
                      <span className="text-slate-200 select-all truncate block text-xs">
                        {activeUser.email || 'None registered'}
                      </span>
                    </div>
                    {activeUser.email && (
                      <button
                        type="button"
                        onClick={(e) => handleCopyId(activeUser.email, e)}
                        className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700/60 cursor-pointer"
                        title="Copy Email"
                      >
                        {copiedId === activeUser.email ? (
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    )}
                  </div>
                </div>

                {/* Bio */}
                <div className="mt-3 text-xs text-slate-300 bg-slate-950/60 p-2.5 rounded-xl border border-slate-800/80 leading-relaxed">
                  <span className="text-[10px] uppercase font-bold text-slate-500 block mb-0.5">Creator Bio</span>
                  <p>{activeUser.bio || 'Masti Video Creator & Content Contributor on Masti Platform.'}</p>
                </div>

                {/* Numeric Stats */}
                <div className="grid grid-cols-3 gap-2 mt-3 text-center">
                  <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                    <span className="text-sm font-black text-white block">{activeUser.followersCount || 0}</span>
                    <span className="text-[9px] uppercase font-bold text-slate-500">Followers</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                    <span className="text-sm font-black text-white block">{activeUserMedia.length}</span>
                    <span className="text-[9px] uppercase font-bold text-slate-500">Folder Uploads</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                    <span className="text-sm font-black text-rose-400 block">{activeUser.likesCount || 0}</span>
                    <span className="text-[9px] uppercase font-bold text-slate-500">Total Likes</span>
                  </div>
                </div>
              </div>

              {/* Live Monetization & Direct UPI Withdrawal Card */}
              <div className="rounded-2xl border border-purple-800/30 overflow-hidden shadow-lg">
                <UserMonetizationCard
                  key={activeUser.id}
                  userId={activeUser.id}
                  userName={activeUser.name}
                  userEmail={activeUser.email}
                  initialData={activeUser.monetization}
                  canControl={true}
                  onUpdate={(updated) => {
                    activeUser.monetization = updated;
                    if (onRefreshData) onRefreshData();
                  }}
                />
              </div>

              {/* Creator's Folder Uploads Gallery */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Folder className="w-4 h-4 text-indigo-400" />
                    <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                      User Folder Files ({activeUserMedia.length})
                    </h4>
                  </div>
                  <span className="text-[10px] text-slate-500 font-mono">
                    Folder: {activeUser.id}
                  </span>
                </div>

                {activeUserMedia.length === 0 ? (
                  <div className="p-8 text-center rounded-xl bg-slate-900/50 border border-dashed border-slate-800 space-y-1">
                    <Film className="w-6 h-6 text-slate-600 mx-auto" />
                    <p className="text-xs text-slate-400">No media assets in this user's folder yet.</p>
                    <p className="text-[10px] text-slate-600">Uploaded videos, images, or audio will appear here.</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2.5 max-h-72 overflow-y-auto pr-1">
                    {activeUserMedia.map((m) => {
                      const isVideo = m.mediaType === 'video';
                      return (
                        <div
                          key={m.id}
                          className="group relative rounded-xl bg-slate-900 border border-slate-800 overflow-hidden hover:border-indigo-500/50 transition-all"
                        >
                          <div className="aspect-video bg-black/60 relative overflow-hidden flex items-center justify-center">
                            {m.thumbnailUrl ? (
                              <img
                                src={resolveMediaUrl(m.thumbnailUrl)}
                                alt={m.title || m.originalName}
                                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                                referrerPolicy="no-referrer"
                              />
                            ) : (
                              <div className="flex flex-col items-center justify-center text-slate-600">
                                <Film className="w-6 h-6" />
                              </div>
                            )}

                            {/* Play Overlay Button */}
                            <button
                              type="button"
                              onClick={() => {
                                if (isVideo && onSelectVideo) {
                                  onSelectVideo(m);
                                } else if (onSelectImage) {
                                  onSelectImage(m);
                                }
                              }}
                              className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white cursor-pointer"
                            >
                              <div className="w-8 h-8 rounded-full bg-indigo-600/90 flex items-center justify-center shadow-lg">
                                <Play className="w-3.5 h-3.5 fill-white ml-0.5" />
                              </div>
                            </button>
                          </div>

                          <div className="p-2 space-y-1">
                            <p className="text-[11px] font-bold text-white truncate" title={m.title || m.originalName}>
                              {m.title || m.originalName}
                            </p>
                            <div className="flex items-center justify-between text-[9px] text-slate-400 font-mono">
                              <span className="uppercase">{m.mediaType}</span>
                              <span>{formatBytes(m.fileSize)}</span>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center p-12 text-slate-500 space-y-2">
              <Users className="w-10 h-10 text-slate-700" />
              <p className="text-xs">Select any user ID from the list on the left to view profile details.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
