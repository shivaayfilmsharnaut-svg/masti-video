import React, { useState, useRef, useEffect } from 'react';
import { MediaFile } from '../types.js';
import { useToast } from './Toast.js';
import { formatBytes, formatDate, resolveMediaUrl } from '../services/api.js';
import { PosterSelectorModal } from './PosterSelectorModal.js';
import {
  X,
  Play,
  Pause,
  Volume2,
  VolumeX,
  RotateCcw,
  Copy,
  Download,
  Code,
  Check,
  Music,
  ExternalLink,
  Sparkles,
  Radio,
  Disc,
  FastForward,
  Repeat,
  Image as ImageIcon,
  SlidersHorizontal
} from 'lucide-react';

interface AudioPlayerModalProps {
  media: MediaFile | null;
  onClose: () => void;
  onMediaUpdated?: (updated: MediaFile) => void;
  availableImages?: MediaFile[];
}

export const AudioPlayerModal: React.FC<AudioPlayerModalProps> = ({
  media,
  onClose,
  onMediaUpdated,
  availableImages = []
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [playbackRate, setPlaybackRate] = useState(1);
  const [isLooping, setIsLooping] = useState(false);
  const [copiedType, setCopiedType] = useState<string | null>(null);
  const [loadError, setLoadError] = useState(false);
  const [showPosterModal, setShowPosterModal] = useState(false);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const { showToast } = useToast();

  useEffect(() => {
    setIsPlaying(false);
    setCurrentTime(0);
    setDuration(media?.duration || 0);
    setLoadError(false);
  }, [media?.id]);

  if (!media) return null;

  const resolvedUrl = resolveMediaUrl(media.fileUrl);
  const resolvedPosterUrl = media.posterUrl ? resolveMediaUrl(media.posterUrl) : null;
  const absolutePublicUrl = typeof window !== 'undefined'
    ? `${window.location.origin}${resolvedUrl}`
    : resolvedUrl;

  const handlePlayPause = () => {
    if (!audioRef.current) return;
    if (!audioRef.current.paused) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      const playPromise = audioRef.current.play();
      if (playPromise !== undefined) {
        playPromise
          .then(() => {
            setIsPlaying(true);
            setLoadError(false);
          })
          .catch((err) => {
            if (err?.name === 'AbortError') {
              // Harmless pause interruption
              return;
            }
            if (err?.name === 'NotAllowedError') {
              console.warn('Audio playback requires user interaction');
              return;
            }
            console.warn('Audio playback notice:', err?.message || 'Playback failed');
          });
      }
    }
  };

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setCurrentTime(audioRef.current.currentTime);
    }
  };

  const handleLoadedMetadata = () => {
    if (audioRef.current) {
      setDuration(audioRef.current.duration || media.duration || 0);
      audioRef.current.volume = volume;
      audioRef.current.playbackRate = playbackRate;
      audioRef.current.loop = isLooping;
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = parseFloat(e.target.value);
    setCurrentTime(time);
    if (audioRef.current) {
      audioRef.current.currentTime = time;
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setVolume(val);
    if (audioRef.current) {
      audioRef.current.volume = val;
    }
    setIsMuted(val === 0);
  };

  const toggleMute = () => {
    if (!audioRef.current) return;
    if (isMuted) {
      audioRef.current.volume = volume || 0.5;
      setIsMuted(false);
    } else {
      audioRef.current.volume = 0;
      setIsMuted(true);
    }
  };

  const changePlaybackRate = (rate: number) => {
    setPlaybackRate(rate);
    if (audioRef.current) {
      audioRef.current.playbackRate = rate;
    }
  };

  const toggleLoop = () => {
    const newLoop = !isLooping;
    setIsLooping(newLoop);
    if (audioRef.current) {
      audioRef.current.loop = newLoop;
    }
  };

  const formatTime = (secs: number) => {
    if (isNaN(secs) || secs < 0) return '0:00';
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const handleCopy = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    setCopiedType(type);
    showToast(`${type} copied to clipboard`, 'success');
    setTimeout(() => setCopiedType(null), 2000);
  };

  const embedAudioHtml = `<audio controls preload="metadata" src="${absolutePublicUrl}"></audio>`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/90 backdrop-blur-xl animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-2xl flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-rose-500 flex items-center justify-center text-white shrink-0 shadow-lg shadow-amber-500/20 overflow-hidden">
              {resolvedPosterUrl ? (
                <img src={resolvedPosterUrl} alt="Poster" className="w-full h-full object-cover" />
              ) : (
                <Music className="w-5 h-5" />
              )}
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h2 className="text-sm sm:text-base font-bold text-white truncate">
                  {media.originalName}
                </h2>
                {media.posterUrl && (
                  <span className="px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[9px] font-bold uppercase shrink-0">
                    Official Poster
                  </span>
                )}
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <span className="text-amber-400 font-medium uppercase">{media.mimeType.split('/')[1] || 'AUDIO'}</span>
                <span>•</span>
                <span>{formatBytes(media.fileSize)}</span>
                <span>•</span>
                <span>{formatDate(media.createdAt)}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setShowPosterModal(true)}
              className="px-2.5 py-1.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 hover:text-amber-300 border border-amber-500/30 text-xs font-semibold flex items-center gap-1.5 transition-all"
              title="Attach or Change Official Terminal Poster"
            >
              <ImageIcon className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{media.posterUrl ? 'Change Poster' : 'Set Official Poster'}</span>
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Audio Player Core Interface */}
        <div className="p-6 flex flex-col items-center justify-center space-y-5 relative">
          {/* Subtle Ambient Glow from Cover Poster if available */}
          {resolvedPosterUrl && (
            <div
              className="absolute inset-0 opacity-15 blur-3xl pointer-events-none bg-cover bg-center rounded-2xl"
              style={{ backgroundImage: `url(${resolvedPosterUrl})` }}
            />
          )}

          <audio
            ref={audioRef}
            src={resolvedUrl}
            onTimeUpdate={handleTimeUpdate}
            onLoadedMetadata={handleLoadedMetadata}
            onEnded={() => setIsPlaying(false)}
            onError={() => setLoadError(true)}
            preload="metadata"
          />

          {/* Album Artwork / Vinyl visualizer */}
          <div className="relative group/cover flex flex-col items-center">
            <div className="relative w-40 h-40 rounded-2xl sm:rounded-full bg-slate-950 border-4 border-slate-700/80 shadow-2xl flex items-center justify-center overflow-hidden">
              {resolvedPosterUrl ? (
                <>
                  <img
                    src={resolvedPosterUrl}
                    alt="Official Poster"
                    className={`w-full h-full object-cover transition-transform duration-700 ${
                      isPlaying ? 'scale-105' : 'scale-100'
                    }`}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent flex items-end justify-center p-2">
                    <span className="px-2 py-0.5 rounded-full bg-slate-950/80 backdrop-blur-md text-[9px] font-bold text-amber-300 border border-amber-500/30 uppercase">
                      Official Terminal Poster
                    </span>
                  </div>
                </>
              ) : (
                <>
                  <div
                    className={`absolute inset-0 rounded-full border-2 border-dashed border-amber-500/30 transition-transform ${
                      isPlaying ? 'animate-[spin_4s_linear_infinite]' : ''
                    }`}
                  />
                  <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-amber-500 to-rose-600 flex items-center justify-center shadow-lg text-white">
                    <Disc className={`w-8 h-8 ${isPlaying ? 'animate-spin' : ''}`} />
                  </div>
                </>
              )}
            </div>

            {/* Quick Poster Edit Overlay Button */}
            <button
              type="button"
              onClick={() => setShowPosterModal(true)}
              className="mt-2 text-[11px] text-slate-400 hover:text-amber-300 font-medium flex items-center gap-1 transition-colors"
            >
              <ImageIcon className="w-3.5 h-3.5 text-amber-400" />
              <span>{media.posterUrl ? 'Change Cover Art / Poster' : 'Attach Official Cover Image'}</span>
            </button>
          </div>

          {/* Equalizer animation bar */}
          <div className="flex items-end justify-center gap-1.5 h-8 w-full max-w-xs">
            {[40, 75, 100, 60, 90, 45, 80, 65, 95, 50, 70, 85].map((h, i) => (
              <div
                key={i}
                style={{
                  height: isPlaying ? `${Math.max(20, (h * (i % 2 === 0 ? 0.8 : 1.2)) % 100)}%` : '15%',
                  transition: 'height 0.15s ease-in-out'
                }}
                className={`flex-1 rounded-full ${
                  isPlaying ? 'bg-gradient-to-t from-amber-500 to-rose-500' : 'bg-slate-800'
                }`}
              />
            ))}
          </div>

          {/* Timeline & Scrubber */}
          <div className="w-full space-y-1.5">
            <input
              type="range"
              min="0"
              max={duration || 100}
              step="0.1"
              value={currentTime}
              onChange={handleSeek}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500 hover:accent-amber-400"
            />
            <div className="flex items-center justify-between text-xs font-mono text-slate-400">
              <span>{formatTime(currentTime)}</span>
              <span>{formatTime(duration)}</span>
            </div>
          </div>

          {/* Controls bar */}
          <div className="w-full flex items-center justify-between gap-4">
            {/* Speed selection */}
            <div className="flex items-center gap-1">
              {[1, 1.25, 1.5, 2].map((rate) => (
                <button
                  key={rate}
                  onClick={() => changePlaybackRate(rate)}
                  className={`px-2 py-1 rounded text-[11px] font-mono transition-colors ${
                    playbackRate === rate
                      ? 'bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {rate}x
                </button>
              ))}
            </div>

            {/* Main Play / Pause Button */}
            <div className="flex items-center gap-3">
              <button
                onClick={toggleLoop}
                className={`p-2 rounded-xl transition-colors ${
                  isLooping ? 'bg-amber-500/20 text-amber-400' : 'text-slate-400 hover:text-slate-200'
                }`}
                title={isLooping ? 'Looping enabled' : 'Enable loop'}
              >
                <Repeat className="w-4 h-4" />
              </button>

              <button
                onClick={handlePlayPause}
                className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 to-rose-600 hover:from-amber-400 hover:to-rose-500 text-white flex items-center justify-center shadow-lg shadow-amber-500/25 transition-transform active:scale-95"
              >
                {isPlaying ? <Pause className="w-6 h-6 fill-current" /> : <Play className="w-6 h-6 fill-current ml-0.5" />}
              </button>

              <button
                onClick={() => {
                  if (audioRef.current) {
                    audioRef.current.currentTime = 0;
                    setCurrentTime(0);
                  }
                }}
                className="p-2 rounded-xl text-slate-400 hover:text-white transition-colors"
                title="Restart"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>

            {/* Volume control */}
            <div className="flex items-center gap-2">
              <button onClick={toggleMute} className="text-slate-400 hover:text-white">
                {isMuted || volume === 0 ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4" />}
              </button>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={isMuted ? 0 : volume}
                onChange={handleVolumeChange}
                className="w-16 h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
              />
            </div>
          </div>
        </div>

        {/* CDN & Embed URLs */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/60 space-y-3">
          <div className="space-y-1.5">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Direct Audio Stream URL</span>
            <div className="flex items-center gap-2 bg-slate-900 p-2 rounded-xl border border-slate-800 font-mono text-xs text-slate-300">
              <span className="truncate flex-1">{absolutePublicUrl}</span>
              <button
                onClick={() => handleCopy(absolutePublicUrl, 'Audio URL')}
                className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg shrink-0 transition-colors"
                title="Copy URL"
              >
                {copiedType === 'Audio URL' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              </button>
              <a
                href={resolvedUrl}
                download={media.originalName}
                className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg shrink-0 transition-colors"
                title="Download Audio"
              >
                <Download className="w-4 h-4" />
              </a>
            </div>
          </div>

          <div className="flex items-center justify-between pt-1 text-xs">
            <button
              onClick={() => handleCopy(embedAudioHtml, 'HTML Audio Embed')}
              className="text-amber-400 hover:text-amber-300 flex items-center gap-1 font-semibold"
            >
              <Code className="w-3.5 h-3.5" />
              <span>Copy HTML &lt;audio&gt; Embed</span>
            </button>
            <a
              href={resolvedUrl}
              target="_blank"
              rel="noreferrer"
              className="text-slate-400 hover:text-slate-200 flex items-center gap-1"
            >
              <span>Open in New Tab</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>
      </div>

      {/* Official Poster Selector Modal */}
      {showPosterModal && (
        <PosterSelectorModal
          media={media}
          isOpen={showPosterModal}
          onClose={() => setShowPosterModal(false)}
          availableImages={availableImages}
          onPosterUpdated={(updated) => {
            if (onMediaUpdated) onMediaUpdated(updated);
          }}
        />
      )}
    </div>
  );
};
