import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.js';
import { useToast } from './Toast.js';
import { api, formatDate } from '../services/api.js';
import { ApiKey, MediaFile } from '../types.js';
import { 
  Zap, Copy, Check, Smartphone, Flame, 
  Code, RefreshCw, Globe, CheckCircle2,
  Heart, MessageCircle, Share2, Play, Eye,
  Sparkles, ShieldCheck, ArrowUpRight, Key, Lock, Terminal, Layers,
  Plus, Trash2, Code2, Server, Database,
  IndianRupee, Bell, Users, Search, Film, CheckCircle, ExternalLink,
  Cpu, Radio, FileText, Send, UserCheck
} from 'lucide-react';

export const ConnectHub: React.FC = () => {
  const { user, isAuthenticated } = useAuth();
  const { showToast } = useToast();
  
  // Tab Navigation
  const [hubSection, setHubSection] = useState<'prompt' | 'sdk' | 'keys' | 'playground' | 'docs'>('prompt');
  
  // SDK Code tab state
  const [selectedTech, setSelectedTech] = useState<'masti_360' | 'flutter' | 'android_native' | 'curl'>('masti_360');
  const [copiedSection, setCopiedSection] = useState<string | null>(null);
  const [showKey, setShowKey] = useState<boolean>(false);
  
  // API Keys state
  const [keys, setKeys] = useState<ApiKey[]>([]);
  const [newKeyName, setNewKeyName] = useState('');
  const [isCreatingKey, setIsCreatingKey] = useState(false);
  
  // Playground state
  const [selectedEndpoint, setSelectedEndpoint] = useState<string>('GET /api/videos/feed');
  const [testUserId, setTestUserId] = useState('rajkalikumar8789@gmail.com');
  const [playgroundResponse, setPlaygroundResponse] = useState<string | null>(null);
  const [isRunningPlayground, setIsRunningPlayground] = useState(false);
  const [responseStatus, setResponseStatus] = useState<number | null>(null);
  const [responseTime, setResponseTime] = useState<number | null>(null);
  
  // Real Database Videos from Server
  const [realVideos, setRealVideos] = useState<MediaFile[]>([]);
  const [loadingVideos, setLoadingVideos] = useState(false);
  const [serverStats, setServerStats] = useState<{ totalFiles: number; totalUsers: number; serverStatus: string }>({
    totalFiles: 0,
    totalUsers: 1,
    serverStatus: 'Online'
  });

  // Automatically detect current server host origin
  const currentBaseUrl = typeof window !== 'undefined' ? window.location.origin : 'https://ais-dev-vqsmp4cogfojsrm6tre6zu-18143192690.asia-east1.run.app';
  
  const activeApiKey = keys[0]?.key || user?.apiKey || 'mb_live_usr_masti_cinema';
  const currentUserEmail = user?.email || 'rajkalikumar8789@gmail.com';
  const currentUserName = user?.name || 'Rajkali Kumar';

  const copyText = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(label);
    showToast('success', 'Copied!', 'Copied to clipboard.');
    setTimeout(() => setCopiedSection(null), 2500);
  };

  useEffect(() => {
    loadKeys();
    fetchRealMedia();
  }, []);

  const loadKeys = async () => {
    try {
      const res = await api.getApiKeys();
      if (res.success && Array.isArray(res.data)) {
        setKeys(res.data);
      }
    } catch (err: any) {
      console.error(err);
    }
  };

  const fetchRealMedia = async () => {
    setLoadingVideos(true);
    try {
      const res = await fetch('/api/videos/feed');
      const data = await res.json();
      if (data.success && Array.isArray(data.data)) {
        setRealVideos(data.data);
        setServerStats(prev => ({
          ...prev,
          totalFiles: data.data.length,
          serverStatus: 'Online (200 OK)'
        }));
      }
    } catch (err) {
      console.error('Failed to load real video feed', err);
    }
    setLoadingVideos(false);
  };

  const handleCreateKey = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newKeyName.trim()) {
      showToast('Please enter a name for the API key', 'error');
      return;
    }

    setIsCreatingKey(true);
    try {
      const res = await api.createApiKey(newKeyName.trim());
      if (res.success && res.data) {
        setKeys(prev => [res.data, ...prev]);
        setNewKeyName('');
        showToast('API Key Created Successfully', 'success');
      } else {
        showToast(res.error || 'Could not generate API key.', 'error');
      }
    } catch (err: any) {
      showToast(err.message, 'error');
    }
    setIsCreatingKey(false);
  };

  const handleDeleteKey = async (id: string) => {
    try {
      const res = await api.deleteApiKey(id);
      if (res.success) {
        setKeys(prev => prev.filter(k => k.id !== id));
        showToast('API Key Revoked', 'success');
      }
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  const runPlaygroundTest = async () => {
    setIsRunningPlayground(true);
    setPlaygroundResponse('Sending live request to server...');
    setResponseStatus(null);
    const startTime = performance.now();

    try {
      let url = '/api/videos/feed';
      let options: RequestInit = {
        headers: {
          'x-api-key': activeApiKey
        }
      };

      if (selectedEndpoint === 'GET /api/videos/feed') {
        url = '/api/videos/feed';
      } else if (selectedEndpoint === 'GET /api/v1/social/synced-profile') {
        url = `/api/v1/social/user/${encodeURIComponent(testUserId || currentUserEmail)}/synced-profile`;
      } else if (selectedEndpoint === 'POST /api/auth/email-sync') {
        url = '/api/auth/email-sync';
        options = {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-api-key': activeApiKey
          },
          body: JSON.stringify({
            email: testUserId || currentUserEmail,
            name: currentUserName,
            avatarUrl: `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(testUserId || 'creator')}`
          })
        };
      } else if (selectedEndpoint === 'GET /api/v1/social/notifications') {
        url = `/api/v1/social/notifications/${encodeURIComponent(testUserId || currentUserEmail)}`;
      } else if (selectedEndpoint === 'GET /api/v1/social/monetization') {
        url = `/api/v1/social/monetization/${encodeURIComponent(testUserId || currentUserEmail)}`;
      } else if (selectedEndpoint === 'GET /api/videos/admob') {
        url = '/api/videos/admob';
      } else if (selectedEndpoint === 'GET /api/v1/media') {
        url = '/api/v1/media?limit=5';
      }

      const res = await fetch(url, options);
      const endTime = performance.now();
      setResponseTime(Math.round(endTime - startTime));
      setResponseStatus(res.status);

      const data = await res.json();
      setPlaygroundResponse(JSON.stringify(data, null, 2));
    } catch (err: any) {
      setPlaygroundResponse(JSON.stringify({ error: err.message || 'Request failed' }, null, 2));
      setResponseStatus(500);
    }
    setIsRunningPlayground(false);
  };

  // Replit Master Prompt
  const replitAiPrompt = `Connect this Mobile/Web App to our Live MastiBase Cloud Backend API:

1. CONFIGURATION CREDENTIALS:
   - Server Base URL: "${currentBaseUrl}"
   - Auth Headers: Send 'x-api-key': "${activeApiKey}" in every API request header.
   - Master Creator/Admin Email: "${currentUserEmail}"

2. CORE FUNCTIONAL MODULES & ENDPOINTS:

   A. AUTHENTICATION & PROFILE SYNC:
      - Email-Based Sync: POST "${currentBaseUrl}/api/auth/email-sync"
        Payload: { "email": "user@gmail.com", "name": "User Name", "avatarUrl": "optional_url", "bio": "Hello World" }
      - Firebase Auth Sync: POST "${currentBaseUrl}/api/auth/firebase-login"
        Payload: { "firebaseUid": "UID_123", "email": "user@gmail.com", "name": "Display Name", "avatarUrl": "https://...", "phoneNumber": "+91...", "username": "custom_username" }
      - Fetch Creator Profile Stats & Blue Tick Status: GET "${currentBaseUrl}/api/v1/social/user/:email/synced-profile"
        Returns user details including:
        • "isVerified": true/false (Blue Tick Verification status controlled by the Admin Console!)
        • "followersCount", "followingCount", "totalLikes"
        • "bio", "avatarUrl"
        • "socialLinks": { "instagram", "youtube", "facebook", "website", "whatsapp", "telegram" }

   B. ACTIVE VIDEO REELS FEED:
      - Fetch Live Feed: GET "${currentBaseUrl}/api/videos/feed"
        (Returns real uploaded MP4 media objects with URLs, captions, creator details, views, and counts)
      - Map each item dynamically in your video list:
        • Video Resource: item.videoUrl
        • Thumbnail/Preview: item.thumbnailUrl
        • Creator DP/Avatar: item.profile.avatarUrl (shows initials fallback if image fails)
        • Creator Name & ID: item.profile.name & item.profile.id
        • Blue Tick Status: item.profile.isVerified (display verified badge if true)
        • Social Stats: item.social.likes, item.social.comments, item.social.shares
        • Likes State: item.social.isLiked, item.social.isFollowingCreator

   C. SOCIAL INTERACTIONS:
      - Like/Unlike Video: POST "${currentBaseUrl}/api/v1/social/like"
        Payload: { "mediaId": "video_id", "userId": "user@gmail.com", "userName": "User Name" }
      - Post Live Comment: POST "${currentBaseUrl}/api/v1/social/comment"
        Payload: { "mediaId": "video_id", "userId": "user@gmail.com", "userName": "User Name", "comment": "Amazing dance!" }
      - Load Comments: GET "${currentBaseUrl}/api/v1/social/comments/:mediaId"
      - Follow Creator: POST "${currentBaseUrl}/api/v1/social/follow"
        Payload: { "followerId": "follower_email_or_id", "followingId": "target_creator_id" }

   D. REAL MEDIA UPLOADER (CAMERA & GALLERY):
      - Upload Video: POST "${currentBaseUrl}/api/v1/media/upload"
        Type: multipart/form-data
        Parameters:
        • "files" (the MP4/image file)
        • "userEmail" (uploader's email)
        • "title" (video title)
        • "description" (optional description)

   E. CREATOR WALLET, AD REVENUE & EARNINGS:
      - Load Balance & Stats: GET "${currentBaseUrl}/api/v1/social/monetization/:email"
        Returns:
        • "walletBalance": current redeemable balance (INR ₹)
        • "totalEarnings": lifetime earnings
        • "rpm": earnings rate per 1,000 views
        • "totalViews": total video views tracked
      - Submit UPI Withdrawal Request: POST "${currentBaseUrl}/api/v1/social/monetization/payout"
        Payload: { "userId": "user_id_or_email", "amount": 1000, "method": "upi", "accountInfo": "userupi@ybl" }
      - Submit Bank Withdrawal Request: POST "${currentBaseUrl}/api/v1/social/monetization/payout"
        Payload: { 
          "userId": "user_id_or_email", 
          "amount": 2500, 
          "method": "bank", 
          "accountInfo": "{\\\"bankName\\\":\\\"State Bank of India\\\",\\\"accountNumber\\\":\\\"1234567890\\\",\\\"ifscCode\\\":\\\"SBIN0001234\\\",\\\"accountHolderName\\\":\\\"User Name\\\"}" 
        }

   F. LIVE ADMOB INTEGRATION CONFIGURATION:
      - Load Settings: GET "${currentBaseUrl}/api/videos/admob"
        Returns live configurations controlled by the Admin:
        • "isAdMobEnabled": true/false
        • "appId", "bannerAdUnitId", "interstitialAdUnitId", "rewardedAdUnitId", "nativeAdUnitId"
        • "adFrequency": show ad every X reels
        • "testMode": true/false
        • "isBadgesEnabled": true/false (Unlock creator badges)
        • "isSubscriptionsEnabled": true/false (Unlock monthly subscriptions)
        • "isStarsEnabled": true/false (Unlock virtual gifting)
        • "isPremiumGoldEnabled": true/false (Global Premium Gold mode)
        • "isUploadAllowed": true/false (Enable/Disable new video uploads)

   G. REAL-TIME AUDIO & VIDEO CALLING (WEBRTC SIGNALLING):
      - Initiate/Ringing: POST "${currentBaseUrl}/api/v1/social/call"
        Payload: { "receiverId": "user_id_or_email", "receiverName": "User Name", "callType": "video" | "audio" }
        (Triggers calling state & sends native push/notification block to the receiver)
      - Send WebRTC Signals (SDP Offer/Answer/ICE Candidate): POST "${currentBaseUrl}/api/v1/social/call/signal"
        Payload: { "senderId": "my_email", "receiverId": "their_email", "type": "offer" | "answer" | "candidate", "payload": sdp_or_candidate_object }
      - Fetch Pending Signaling Packets (Poll every 1.5 seconds during call): GET "${currentBaseUrl}/api/v1/social/call/signals/:my_email"
      - Accept/Connect/End Call: POST "${currentBaseUrl}/api/v1/social/call/status"
        Payload: { "callId": "call_id_received", "status": "connected" | "ended" }

   H. REMOTE THEME ENGINE & ADVANCED CAMERA SWITCHER:
      - Load Remote Settings: GET "${currentBaseUrl}/api/videos/admob"
        Apply these fields dynamically to your app UI:
        • "theme.primaryColor": Use this for all Buttons, Headers, and Highlight text colors.
        • "theme.secondaryColor": Use for secondary accents/badges.
        • "theme.fontFamily": Options: 'modern', 'classic', 'gothic', 'bold'. (Map to your local font families).
        • "theme.borderRadius": Apply this (px) to all Buttons, Cards, and Input fields for consistent roundness.
        • "theme.layoutType": Options: 'reels' (full screen), 'grid' (insta-style), 'list' (fb-style). Switch Home Feed UI based on this.
        • "theme.isDarkMode": If true, force Dark Theme across the app.
        • "theme.cameraEngine": Options: 'expo' or 'vision'. Switch your camera module dynamically!
          (If 'vision', use 'react-native-vision-camera', else use 'expo-camera').

3. INTEGRATION DIRECTIVES:
   - Ensure to handle null/missing data states gracefully (e.g. use default values or loaders).
   - Display the Blue Tick Verification Badge dynamically beside creator profiles based on the "isVerified" boolean field.
   - Replace all static, local, or placeholder mockup data across your app's screens (Home, Feed, Profile, Wallet, Upload) with the real API responses fetched using the above endpoints!`;

  // Full 360 SDK Code
  const masti360FullCode = `import axios from 'axios';

const MASTI_BASE_URL = '${currentBaseUrl}';
const API_KEY = '${activeApiKey}';

const client = axios.create({
  baseURL: MASTI_BASE_URL,
  headers: {
    'x-api-key': API_KEY,
    'Content-Type': 'application/json'
  }
});

// 1. Sync User Login (Firebase/Google)
export const syncUserAuth = async (email, name, avatarUrl) => {
  const { data } = await client.post('/api/auth/email-sync', { email, name, avatarUrl });
  return data;
};

// 2. Fetch Live Reels Feed
export const getReelsFeed = async () => {
  const { data } = await client.get('/api/videos/feed');
  return data.data || [];
};

// 3. Like Video
export const likeReel = async (mediaId, userId, userName) => {
  const { data } = await client.post('/api/v1/social/like', { mediaId, userId, userName });
  return data;
};

// 4. Post Comment
export const commentReel = async (mediaId, userId, userName, comment) => {
  const { data } = await client.post('/api/v1/social/comment', { mediaId, userId, userName, comment });
  return data;
};

// 5. Creator Wallet & Earnings
export const getWalletData = async (userEmail) => {
  const { data } = await client.get(\`/api/v1/social/monetization/\${encodeURIComponent(userEmail)}\`);
  return data.data;
};

// 6. Request Instant UPI Payout
export const requestPayout = async (userEmail, amount, upiId) => {
  const { data } = await client.post('/api/v1/social/monetization/payout', {
    userId: userEmail,
    amount,
    method: 'upi',
    accountInfo: upiId
  });
  return data;
};

// 7. Google AdMob (Ads Config)
export const getAdMobConfig = async () => {
  const { data } = await client.get('/api/videos/admob');
  return data.data;
};`;

  const flutterCode = `// lib/masti_service.dart
import 'dart:convert';
import 'package:http/http.dart' as http;

class MastiService {
  static const String baseUrl = '${currentBaseUrl}';
  static const String apiKey = '${activeApiKey}';

  static Map<String, String> get headers => {
    'x-api-key': apiKey,
    'Content-Type': 'application/json',
  };

  static Future<List<dynamic>> fetchFeed() async {
    final res = await http.get(Uri.parse('\$baseUrl/api/videos/feed'), headers: headers);
    if (res.statusCode == 200) {
      final body = jsonDecode(res.body);
      return body['data'] ?? [];
    }
    return [];
  }

  static Future<Map<String, dynamic>> syncUser(String email, String name, String avatarUrl) async {
    final res = await http.post(
      Uri.parse('\$baseUrl/api/auth/email-sync'),
      headers: headers,
      body: jsonEncode({'email': email, 'name': name, 'avatarUrl': avatarUrl}),
    );
    return jsonDecode(res.body);
  }
}`;

  const androidCode = `// MastiApi.kt
package com.mastivideo.app

import okhttp3.*
import org.json.JSONObject

object MastiApi {
    const val BASE_URL = "${currentBaseUrl}"
    const val API_KEY = "${activeApiKey}"
    private val client = OkHttpClient()

    fun getReelsFeed(callback: (String) -> Unit) {
        val request = Request.Builder()
            .url("$BASE_URL/api/videos/feed")
            .addHeader("x-api-key", API_KEY)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: java.io.IOException) {}
            override fun onResponse(call: Call, response: Response) {
                callback(response.body?.string() ?: "")
            }
        })
    }
}`;

  const curlCode = `# 1. Fetch Real Video Feed
curl -X GET "${currentBaseUrl}/api/videos/feed" \\
  -H "x-api-key: ${activeApiKey}"

# 2. Sync User
curl -X POST "${currentBaseUrl}/api/auth/email-sync" \\
  -H "Content-Type: application/json" \\
  -d '{"email": "${currentUserEmail}", "name": "${currentUserName}"}'

# 3. Creator Synced Profile
curl -X GET "${currentBaseUrl}/api/v1/social/user/${encodeURIComponent(currentUserEmail)}/synced-profile" \\
  -H "x-api-key: ${activeApiKey}"`;

  return (
    <div className="space-y-6">
      {/* 🌟 Top Live Credentials & Server Status Header */}
      <div className="relative overflow-hidden rounded-3xl bg-slate-900 border border-slate-800 p-6 sm:p-8 shadow-2xl">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-xs font-bold flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span>MastiBase Live Server</span>
              </div>
              <div className="px-3 py-1 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/30 text-xs font-mono">
                {currentUserEmail}
              </div>
            </div>

            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              Connect <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 to-indigo-400">Masti Video App</span>
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 max-w-2xl leading-relaxed">
              Real API endpoints, real database sync, real Replit integration prompt, and active API credentials.
            </p>
          </div>

          {/* Quick Real Credentials Box */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 shadow-xl space-y-3 min-w-[300px]">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                <Key className="w-3.5 h-3.5 text-amber-400" />
                Active API Key
              </span>
              <button
                onClick={() => setShowKey(!showKey)}
                className="text-[11px] text-indigo-400 hover:text-indigo-300 font-semibold"
              >
                {showKey ? 'Hide' : 'Show'}
              </button>
            </div>
            
            <div className="flex items-center gap-2">
              <code className="flex-1 px-3 py-1.5 rounded-lg bg-slate-900 text-amber-300 text-xs font-mono border border-slate-800 truncate">
                {showKey ? activeApiKey : `${activeApiKey.slice(0, 12)}••••••••`}
              </code>
              <button
                onClick={() => copyText(activeApiKey, 'api_key_header')}
                className="p-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg transition-all"
                title="Copy API Key"
              >
                {copiedSection === 'api_key_header' ? <Check className="w-4 h-4 text-emerald-300" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>

            <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-[11px]">
              <span className="text-slate-400">Base Server URL</span>
              <button
                onClick={() => copyText(currentBaseUrl, 'base_url_header')}
                className="text-cyan-400 hover:text-cyan-300 font-mono text-xs flex items-center gap-1"
              >
                <span>{currentBaseUrl.replace(/^https?:\/\//, '').slice(0, 24)}...</span>
                <Copy className="w-3 h-3" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 🧭 Clean Section Tabs */}
      <div className="flex items-center gap-2 p-1.5 bg-slate-900 rounded-2xl border border-slate-800 overflow-x-auto">
        <button
          onClick={() => setHubSection('prompt')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
            hubSection === 'prompt'
              ? 'bg-amber-500 text-slate-950 shadow-md font-black'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span>📋 Replit AI Master Prompt</span>
        </button>

        <button
          onClick={() => setHubSection('sdk')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
            hubSection === 'sdk'
              ? 'bg-indigo-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Code className="w-4 h-4" />
          <span>💻 SDKs & Code (JS, Flutter, Android)</span>
        </button>

        <button
          onClick={() => setHubSection('keys')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
            hubSection === 'keys'
              ? 'bg-indigo-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Key className="w-4 h-4" />
          <span>🔑 Manage API Keys ({keys.length || 1})</span>
        </button>

        <button
          onClick={() => setHubSection('playground')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
            hubSection === 'playground'
              ? 'bg-indigo-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Terminal className="w-4 h-4" />
          <span>⚡ Live Server Tester</span>
        </button>

        <button
          onClick={() => setHubSection('docs')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
            hubSection === 'docs'
              ? 'bg-indigo-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>📖 REST Endpoints ({8})</span>
        </button>
      </div>

      {/* 📋 TAB 1: REPLIT AI MASTER PROMPT */}
      {hubSection === 'prompt' && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-amber-400" />
                  1-Click Replit AI Integration Prompt
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  Copy this complete prompt and paste it directly into your Replit AI chat to connect your mobile/web app.
                </p>
              </div>

              <button
                onClick={() => copyText(replitAiPrompt, 'replit_prompt_main')}
                className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-xs flex items-center gap-2 shadow-lg transition-all"
              >
                {copiedSection === 'replit_prompt_main' ? <Check className="w-4 h-4 text-emerald-950" /> : <Copy className="w-4 h-4" />}
                <span>{copiedSection === 'replit_prompt_main' ? 'Prompt Copied!' : 'Copy Replit Prompt'}</span>
              </button>
            </div>

            <div className="rounded-xl bg-slate-950 border border-slate-800 p-4">
              <pre className="text-xs font-mono text-amber-300/90 whitespace-pre-wrap leading-relaxed overflow-x-auto">
                {replitAiPrompt}
              </pre>
            </div>

            {/* Step-by-Step Instructions */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
              <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-2">
                <div className="w-7 h-7 rounded-lg bg-indigo-600/20 text-indigo-400 font-bold flex items-center justify-center text-xs">
                  1
                </div>
                <h4 className="text-xs font-bold text-white">Copy Prompt</h4>
                <p className="text-[11px] text-slate-400">Click the button above to copy the real server URL and API credentials.</p>
              </div>

              <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-2">
                <div className="w-7 h-7 rounded-lg bg-indigo-600/20 text-indigo-400 font-bold flex items-center justify-center text-xs">
                  2
                </div>
                <h4 className="text-xs font-bold text-white">Paste in Replit Chat</h4>
                <p className="text-[11px] text-slate-400">Open your Masti Video project on Replit, open AI Chat, and paste.</p>
              </div>

              <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-2">
                <div className="w-7 h-7 rounded-lg bg-indigo-600/20 text-indigo-400 font-bold flex items-center justify-center text-xs">
                  3
                </div>
                <h4 className="text-xs font-bold text-white">Live Real Sync</h4>
                <p className="text-[11px] text-slate-400">Replit will automatically wire up all API routes, video feed, and login sync.</p>
              </div>
            </div>
          </div>

          {/* Real Media Videos in Database */}
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Film className="w-4 h-4 text-indigo-400" />
                <span>Real Videos Ready in Database Feed ({realVideos.length})</span>
              </h3>
              <button
                onClick={fetchRealMedia}
                disabled={loadingVideos}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-lg border border-slate-700 flex items-center gap-1.5"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${loadingVideos ? 'animate-spin text-indigo-400' : ''}`} />
                <span>Refresh Feed</span>
              </button>
            </div>

            {realVideos.length === 0 ? (
              <div className="p-8 text-center bg-slate-950 rounded-xl border border-slate-800 text-slate-400 text-xs">
                No videos uploaded yet. Use the Upload tab to add real videos.
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                {realVideos.slice(0, 6).map((vid: any, i: number) => (
                  <div key={vid.id || i} className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-white truncate max-w-[140px]">{vid.title || vid.originalName || `Video #${i + 1}`}</span>
                      <span className="px-2 py-0.5 rounded bg-indigo-950 text-indigo-300 text-[10px] font-mono">
                        {vid.size ? `${(vid.size / (1024 * 1024)).toFixed(1)} MB` : 'Stream Ready'}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-400 truncate">
                      Stream: <code className="text-cyan-400">{vid.videoUrl || vid.url || `/api/v1/media/stream/${vid.id}`}</code>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* 💻 TAB 2: SDKS & CODE */}
      {hubSection === 'sdk' && (
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
          <div className="flex items-center justify-between flex-wrap gap-3">
            {/* Tech Selector */}
            <div className="flex items-center gap-2 p-1 bg-slate-950 rounded-xl border border-slate-800">
              <button
                onClick={() => setSelectedTech('masti_360')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  selectedTech === 'masti_360' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                JavaScript / TypeScript (Full 360°)
              </button>
              <button
                onClick={() => setSelectedTech('flutter')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  selectedTech === 'flutter' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Flutter (Dart)
              </button>
              <button
                onClick={() => setSelectedTech('android_native')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  selectedTech === 'android_native' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Android (Kotlin)
              </button>
              <button
                onClick={() => setSelectedTech('curl')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  selectedTech === 'curl' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Terminal (cURL)
              </button>
            </div>

            <button
              onClick={() => {
                const code = selectedTech === 'masti_360' ? masti360FullCode : selectedTech === 'flutter' ? flutterCode : selectedTech === 'android_native' ? androidCode : curlCode;
                copyText(code, 'sdk_code_copy');
              }}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl flex items-center gap-2 transition-all shadow-md"
            >
              {copiedSection === 'sdk_code_copy' ? <Check className="w-4 h-4 text-emerald-300" /> : <Copy className="w-4 h-4" />}
              <span>{copiedSection === 'sdk_code_copy' ? 'Copied!' : 'Copy Code'}</span>
            </button>
          </div>

          <div className="rounded-xl bg-slate-950 border border-slate-800 overflow-hidden">
            <pre className="p-4 text-xs font-mono text-emerald-400 overflow-x-auto max-h-[500px] overflow-y-auto leading-relaxed">
              {selectedTech === 'masti_360' && masti360FullCode}
              {selectedTech === 'flutter' && flutterCode}
              {selectedTech === 'android_native' && androidCode}
              {selectedTech === 'curl' && curlCode}
            </pre>
          </div>
        </div>
      )}

      {/* 🔑 TAB 3: MANAGE API KEYS */}
      {hubSection === 'keys' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Create Key */}
          <div className="lg:col-span-5 space-y-4">
            <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Plus className="w-4 h-4 text-indigo-400" />
                Generate New API Key
              </h3>
              <p className="text-xs text-slate-400">
                Create dedicated keys for production apps, development environments, or test clients.
              </p>

              <form onSubmit={handleCreateKey} className="space-y-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    API Key Name / App Label
                  </label>
                  <input
                    type="text"
                    value={newKeyName}
                    onChange={(e) => setNewKeyName(e.target.value)}
                    placeholder="e.g. Masti Video Android App"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isCreatingKey}
                  className="w-full py-2.5 bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 text-white text-xs font-bold rounded-xl shadow-md transition-all flex items-center justify-center gap-2"
                >
                  <Key className="w-4 h-4" />
                  <span>{isCreatingKey ? 'Creating...' : 'Generate Key'}</span>
                </button>
              </form>
            </div>
          </div>

          {/* Active Keys List */}
          <div className="lg:col-span-7 space-y-4">
            <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Key className="w-4 h-4 text-amber-400" />
                Active API Keys ({keys.length || 1})
              </h3>

              <div className="space-y-3">
                {/* Default Master Key */}
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-white">Default Master Key</span>
                      <span className="px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800 text-[9px] font-bold">
                        Active
                      </span>
                    </div>
                    <code className="text-xs font-mono text-amber-300">
                      {activeApiKey}
                    </code>
                  </div>
                  <button
                    onClick={() => copyText(activeApiKey, 'active_key_row')}
                    className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg transition-all"
                    title="Copy Key"
                  >
                    {copiedSection === 'active_key_row' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>

                {/* Additional Keys */}
                {keys.map((k) => (
                  <div key={k.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-white">{k.name}</span>
                        <span className="text-[10px] text-slate-500">{formatDate(k.createdAt)}</span>
                      </div>
                      <code className="text-xs font-mono text-indigo-300">
                        {k.key}
                      </code>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => copyText(k.key, k.id)}
                        className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg transition-all"
                        title="Copy Key"
                      >
                        {copiedSection === k.id ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                      </button>
                      <button
                        onClick={() => handleDeleteKey(k.id)}
                        className="p-2 bg-rose-950/40 hover:bg-rose-900/60 text-rose-400 rounded-lg border border-rose-800/40 transition-all"
                        title="Revoke Key"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ⚡ TAB 4: LIVE SERVER TESTER */}
      {hubSection === 'playground' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Controls */}
          <div className="lg:col-span-5 space-y-4">
            <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Terminal className="w-4 h-4 text-emerald-400" />
                Live API Request Runner
              </h3>

              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Target Endpoint
                  </label>
                  <select
                    value={selectedEndpoint}
                    onChange={(e) => setSelectedEndpoint(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500"
                  >
                    <option value="GET /api/videos/feed">GET /api/videos/feed (Video Reels Feed)</option>
                    <option value="GET /api/v1/social/synced-profile">GET /api/v1/social/user/:email/synced-profile</option>
                    <option value="POST /api/auth/email-sync">POST /api/auth/email-sync (User Login Sync)</option>
                    <option value="GET /api/v1/social/notifications">GET /api/v1/social/notifications/:email</option>
                    <option value="GET /api/v1/social/monetization">GET /api/v1/social/monetization/:email</option>
                    <option value="GET /api/videos/admob">GET /api/videos/admob (Google AdMob Ads Config)</option>
                    <option value="GET /api/v1/media">GET /api/v1/media (Media Files List)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    User Email / ID
                  </label>
                  <input
                    type="text"
                    value={testUserId}
                    onChange={(e) => setTestUserId(e.target.value)}
                    placeholder="rajkalikumar8789@gmail.com"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500"
                  />
                </div>

                <button
                  onClick={runPlaygroundTest}
                  disabled={isRunningPlayground}
                  className="w-full py-3 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-xl text-xs transition-all flex items-center justify-center gap-2 shadow-lg"
                >
                  <Send className={`w-4 h-4 ${isRunningPlayground ? 'animate-spin' : ''}`} />
                  <span>{isRunningPlayground ? 'Executing...' : 'Execute Live API Request'}</span>
                </button>
              </div>
            </div>
          </div>

          {/* Response Box */}
          <div className="lg:col-span-7 space-y-4">
            <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Code2 className="w-4 h-4 text-indigo-400" />
                    Server Response
                  </h3>
                  {responseStatus && (
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      responseStatus === 200 ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-rose-950 text-rose-400 border border-rose-800'
                    }`}>
                      {responseStatus} OK ({responseTime}ms)
                    </span>
                  )}
                </div>

                {playgroundResponse && (
                  <button
                    onClick={() => copyText(playgroundResponse, 'playground_json')}
                    className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-bold flex items-center gap-1.5"
                  >
                    {copiedSection === 'playground_json' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>Copy JSON</span>
                  </button>
                )}
              </div>

              <pre className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono text-emerald-400 overflow-x-auto max-h-[420px] overflow-y-auto leading-relaxed">
                {playgroundResponse || '// Click "Execute Live API Request" above to test the live server response...'}
              </pre>
            </div>
          </div>
        </div>
      )}

      {/* 📖 TAB 5: REST ENDPOINTS REFERENCE */}
      {hubSection === 'docs' && (
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <FileText className="w-4 h-4 text-cyan-400" />
            Complete REST API Endpoints Reference
          </h3>
          <p className="text-xs text-slate-400">
            Pass <code className="text-amber-300">x-api-key: {activeApiKey}</code> in headers or use Bearer token.
          </p>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400">
                  <th className="py-2.5 px-3">Method</th>
                  <th className="py-2.5 px-3">Endpoint</th>
                  <th className="py-2.5 px-3">Description</th>
                  <th className="py-2.5 px-3">Return Data</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
                <tr>
                  <td className="py-3 px-3"><span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 font-bold">GET</span></td>
                  <td className="py-3 px-3 text-indigo-300 font-bold">/api/videos/feed</td>
                  <td className="py-3 px-3 text-slate-300 font-sans">Fetch unlimited video reels feed</td>
                  <td className="py-3 px-3 text-slate-400 font-sans">Video URL, Creator DP, Likes, Comments</td>
                </tr>
                <tr>
                  <td className="py-3 px-3"><span className="px-2 py-0.5 rounded bg-blue-950 text-blue-400 font-bold">POST</span></td>
                  <td className="py-3 px-3 text-indigo-300 font-bold">/api/auth/email-sync</td>
                  <td className="py-3 px-3 text-slate-300 font-sans">Sync Firebase / Google login user</td>
                  <td className="py-3 px-3 text-slate-400 font-sans">User ID, DP, Email, API Key, Token</td>
                </tr>
                <tr>
                  <td className="py-3 px-3"><span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 font-bold">GET</span></td>
                  <td className="py-3 px-3 text-indigo-300 font-bold">/api/v1/social/user/:email/synced-profile</td>
                  <td className="py-3 px-3 text-slate-300 font-sans">Get 360° profile, DP, followers, reels, wallet</td>
                  <td className="py-3 px-3 text-slate-400 font-sans">Complete creator profile & stats</td>
                </tr>
                <tr>
                  <td className="py-3 px-3"><span className="px-2 py-0.5 rounded bg-blue-950 text-blue-400 font-bold">POST</span></td>
                  <td className="py-3 px-3 text-indigo-300 font-bold">/api/v1/media/upload</td>
                  <td className="py-3 px-3 text-slate-300 font-sans">Upload video linked to userEmail</td>
                  <td className="py-3 px-3 text-slate-400 font-sans">Uploaded media record with stream URL</td>
                </tr>
                <tr>
                  <td className="py-3 px-3"><span className="px-2 py-0.5 rounded bg-blue-950 text-blue-400 font-bold">POST</span></td>
                  <td className="py-3 px-3 text-indigo-300 font-bold">/api/v1/social/like</td>
                  <td className="py-3 px-3 text-slate-300 font-sans">Like / Heart a video reel</td>
                  <td className="py-3 px-3 text-slate-400 font-sans">Updated like count & isLiked state</td>
                </tr>
                <tr>
                  <td className="py-3 px-3"><span className="px-2 py-0.5 rounded bg-blue-950 text-blue-400 font-bold">POST</span></td>
                  <td className="py-3 px-3 text-indigo-300 font-bold">/api/v1/social/comment</td>
                  <td className="py-3 px-3 text-slate-300 font-sans">Post comment on video</td>
                  <td className="py-3 px-3 text-slate-400 font-sans">New comment object</td>
                </tr>
                <tr>
                  <td className="py-3 px-3"><span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 font-bold">GET</span></td>
                  <td className="py-3 px-3 text-indigo-300 font-bold">/api/v1/social/monetization/:email</td>
                  <td className="py-3 px-3 text-slate-300 font-sans">Get creator wallet balance & views</td>
                  <td className="py-3 px-3 text-slate-400 font-sans">Wallet balance (₹), RPM, Total Earnings</td>
                </tr>
                <tr>
                  <td className="py-3 px-3"><span className="px-2 py-0.5 rounded bg-blue-950 text-blue-400 font-bold">POST</span></td>
                  <td className="py-3 px-3 text-indigo-300 font-bold">/api/v1/social/monetization/payout</td>
                  <td className="py-3 px-3 text-slate-300 font-sans">Request UPI withdrawal</td>
                  <td className="py-3 px-3 text-slate-400 font-sans">Payout transaction status</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
