import React, { useState, useRef } from 'react';
import { api, formatBytes } from '../services/api.js';
import { useAuth } from '../context/AuthContext.js';
import { useToast } from './Toast.js';
import { 
  UploadCloud, 
  File, 
  Film, 
  Image as ImageIcon, 
  Music, 
  X, 
  CheckCircle2, 
  AlertCircle, 
  Plus, 
  Sparkles, 
  Folder, 
  Tag, 
  Copy, 
  Check,
  Edit3,
  ChevronDown,
  ChevronUp,
  Hash,
  MessageSquare,
  Link as LinkIcon
} from 'lucide-react';

interface UploadQueueItem {
  id: string;
  file?: File;
  isUrlImport?: boolean;
  importedUrl?: string;
  previewUrl: string;
  mediaType: 'image' | 'video' | 'audio';
  progress: number;
  status: 'pending' | 'uploading' | 'completed' | 'error';
  error?: string;
  uploadedUrl?: string;
  duration?: number;
  width?: number;
  height?: number;
  qualityBadge?: string;
  posterFile?: File;
  posterPreviewUrl?: string;
  posterUrl?: string;
  // Per-video custom metadata
  title?: string;
  caption?: string;
  soundtrackTitle?: string;
  audioUrl?: string;
  isDetailsExpanded?: boolean;
}

interface UploadHubProps {
  onUploadComplete?: () => void;
  onNavigateToLibrary?: () => void;
}

export const UploadHub: React.FC<UploadHubProps> = ({ onUploadComplete, onNavigateToLibrary }) => {
  const [queue, setQueue] = useState<UploadQueueItem[]>([]);
  const [folder, setFolder] = useState('general');
  const [tagsInput, setTagsInput] = useState('');
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [copiedAll, setCopiedAll] = useState(false);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const { isAuthenticated } = useAuth();
  const { showToast } = useToast();

  const extractMediaMetadata = (file: File, mediaType: 'video' | 'audio' | 'image'): Promise<{ duration?: number; width?: number; height?: number; qualityBadge?: string }> => {
    return new Promise((resolve) => {
      const url = URL.createObjectURL(file);

      if (mediaType === 'video') {
        const video = document.createElement('video');
        video.preload = 'metadata';
        video.src = url;
        video.onloadedmetadata = () => {
          const duration = video.duration;
          const width = video.videoWidth;
          const height = video.videoHeight;
          let qualityBadge = 'HD';
          if (width >= 3800 || height >= 2000) qualityBadge = '4K UHD';
          else if (width >= 2400 || height >= 1400) qualityBadge = '2K QHD';
          else if (width >= 1800 || height >= 1000) qualityBadge = '1080p FHD';
          else if (width >= 1200 || height >= 700) qualityBadge = '720p HD';
          else if (width > 0) qualityBadge = 'SD';
          URL.revokeObjectURL(url);
          resolve({ duration, width, height, qualityBadge });
        };
        video.onerror = () => {
          URL.revokeObjectURL(url);
          resolve({});
        };
      } else if (mediaType === 'audio') {
        const audio = document.createElement('audio');
        audio.preload = 'metadata';
        audio.src = url;
        audio.onloadedmetadata = () => {
          const duration = audio.duration;
          URL.revokeObjectURL(url);
          resolve({ duration });
        };
        audio.onerror = () => {
          URL.revokeObjectURL(url);
          resolve({});
        };
      } else {
        const img = new Image();
        img.src = url;
        img.onload = () => {
          const width = img.naturalWidth;
          const height = img.naturalHeight;
          let qualityBadge = undefined;
          if (width >= 3800 || height >= 2000) qualityBadge = '4K Res';
          else if (width >= 1900) qualityBadge = 'FHD';
          URL.revokeObjectURL(url);
          resolve({ width, height, qualityBadge });
        };
        img.onerror = () => {
          URL.revokeObjectURL(url);
          resolve({});
        };
      }
    });
  };

  const handleFilesAdded = async (fileList: FileList | null) => {
    if (!fileList || fileList.length === 0) return;

    const newItems: UploadQueueItem[] = [];
    for (let i = 0; i < fileList.length; i++) {
      const file = fileList[i];

      // Unlimited file size & batch support - no restrictive file size blockage

      const isVideo = file.type.startsWith('video/') || file.name.match(/\.(mp4|webm|mov|mkv|avi|ogv)$/i);
      const isAudio = file.type.startsWith('audio/') || file.name.match(/\.(mp3|wav|ogg|oga|opus|m4a|aac|flac|weba)$/i);
      const isImage = file.type.startsWith('image/') || file.name.match(/\.(jpg|jpeg|png|webp|gif|svg|avif)$/i);

      if (!isVideo && !isImage && !isAudio) {
        showToast('error', 'Unsupported File', `${file.name} is not a supported image, video, or audio file.`);
        continue;
      }

      const mediaType: 'image' | 'video' | 'audio' = isVideo ? 'video' : isAudio ? 'audio' : 'image';
      const previewUrl = URL.createObjectURL(file);
      const id = Math.random().toString(36).substring(2, 9);
      
      // Clean default title from filename without extension
      const cleanDefaultTitle = file.name.replace(/\.[^/.]+$/, "").replace(/[_-]/g, " ");

      newItems.push({
        id,
        file,
        previewUrl,
        mediaType,
        progress: 0,
        status: 'pending',
        title: cleanDefaultTitle,
        caption: '',
        soundtrackTitle: '',
        audioUrl: '',
        isDetailsExpanded: Boolean(isVideo || isAudio)
      });
    }

    if (newItems.length > 0) {
      setQueue(prev => [...prev, ...newItems]);
      showToast('info', 'Files Queued', `Added ${newItems.length} media file(s). Set unique title & caption for each video below.`);

      // Asynchronously extract metadata for video/audio/image
      for (const item of newItems) {
        extractMediaMetadata(item.file, item.mediaType).then(meta => {
          setQueue(prev => prev.map(q => q.id === item.id ? { ...q, ...meta } : q));
        });
      }
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    handleFilesAdded(e.dataTransfer.files);
  };

  const removeItem = (id: string) => {
    setQueue(prev => prev.filter(item => item.id !== id));
  };

  const clearCompleted = () => {
    setQueue(prev => prev.filter(item => item.status !== 'completed'));
  };

  const formatDuration = (seconds?: number) => {
    if (!seconds || isNaN(seconds)) return null;
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const startUpload = async () => {
    if (!isAuthenticated) {
      showToast('error', 'Authentication Required', 'Please sign in or use a demo account to upload files.');
      return;
    }

    const pendingItems = queue.filter(item => item.status === 'pending' || item.status === 'error');
    if (pendingItems.length === 0) return;

    setIsUploading(true);

    // Upload items sequentially or in small parallel batches with real progress
    for (const item of pendingItems) {
      setQueue(prev => prev.map(q => q.id === item.id ? { ...q, status: 'uploading', progress: 10 } : q));

      let posterUrlToAttach = item.posterUrl;

      // If user selected a poster image file from device for this audio item, upload poster first
      if (item.posterFile && !posterUrlToAttach) {
        try {
          const posterRes = await api.uploadFiles([item.posterFile], undefined, 'covers', 'poster,cover');
          if (posterRes.success) {
            const pData = Array.isArray(posterRes.data) ? posterRes.data[0] : posterRes.data;
            posterUrlToAttach = pData?.fileUrl;
          }
        } catch (e: any) {
          console.warn('Could not auto-upload poster file, proceeding with media upload:', e?.message || 'Upload error');
        }
      }

      const metadataMap: Record<string, { duration?: number; width?: number; height?: number; posterUrl?: string }> = {};
      if (item.duration || item.width || item.height || posterUrlToAttach) {
        metadataMap[item.file.name] = {
          duration: item.duration,
          width: item.width,
          height: item.height,
          posterUrl: posterUrlToAttach
        };
      }

      const itemTitle = item.title?.trim() || item.file.name;
      const itemCaption = item.caption?.trim() || '';
      const itemSoundtrack = item.soundtrackTitle?.trim() || '';
      const itemAudioUrl = item.audioUrl?.trim() || '';

      const itemExtra = {
        title: itemTitle,
        caption: itemCaption,
        soundtrackTitle: itemSoundtrack,
        audioUrl: itemAudioUrl,
        itemDetails: {
          [item.file.name]: {
            title: itemTitle,
            caption: itemCaption,
            soundtrackTitle: itemSoundtrack,
            audioUrl: itemAudioUrl
          }
        }
      };

      try {
        const result = await api.uploadFiles(
          [item.file],
          (percent) => {
            setQueue(prev => prev.map(q => q.id === item.id ? { ...q, progress: Math.max(15, percent) } : q));
          },
          folder,
          tagsInput,
          metadataMap,
          itemExtra
        );

        if (result.success) {
          const uploadedUrl = Array.isArray(result.data) ? result.data[0]?.fileUrl : result.data?.fileUrl;
          setQueue(prev => prev.map(q => q.id === item.id ? {
            ...q,
            status: 'completed',
            progress: 100,
            uploadedUrl
          } : q));
        } else {
          setQueue(prev => prev.map(q => q.id === item.id ? {
            ...q,
            status: 'error',
            error: result.error || 'Upload failed'
          } : q));
        }
      } catch (err: any) {
        setQueue(prev => prev.map(q => q.id === item.id ? {
          ...q,
          status: 'error',
          error: err.message || 'Upload error'
        } : q));
      }
    }

    setIsUploading(false);
    showToast('success', 'Upload Processing Complete', 'Uploaded media files are now available on Masti Bash Cloud CDN.');
    if (onUploadComplete) {
      onUploadComplete();
    }
  };

  const handleCopyAllUrls = () => {
    const urls = queue.filter(q => q.status === 'completed' && q.uploadedUrl).map(q => q.uploadedUrl);
    if (urls.length === 0) return;

    navigator.clipboard.writeText(urls.join('\n'));
    setCopiedAll(true);
    showToast('success', 'Copied All URLs', `${urls.length} media stream URLs copied.`);
    setTimeout(() => setCopiedAll(false), 2500);
  };

  const completedCount = queue.filter(q => q.status === 'completed').length;
  const hasCompleted = completedCount > 0;

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header Section */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2.5">
            <UploadCloud className="w-7 h-7 text-indigo-400" />
            Media Upload Hub
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Upload videos (MP4, WebM), audio tracks (MP3, WAV, AAC, M4A, OGG), and images with instant Masti Bash CDN distribution.
          </p>
        </div>

        {/* Quick Actions */}
        <div className="flex items-center gap-2">
          {hasCompleted && (
            <>
              <button
                type="button"
                onClick={handleCopyAllUrls}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-all"
              >
                {copiedAll ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>Copy All URLs ({completedCount})</span>
              </button>

              {onNavigateToLibrary && (
                <button
                  type="button"
                  onClick={onNavigateToLibrary}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 text-xs font-semibold transition-all"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>View in Library</span>
                </button>
              )}
            </>
          )}
        </div>
      </div>

      {/* Feature Highlights Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="p-3.5 rounded-xl bg-purple-950/30 border border-purple-800/40 flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-purple-600/20 text-purple-400 border border-purple-500/30 flex items-center justify-center shrink-0">
            <Film className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-bold text-white">4K Ultra HD Playback</span>
              <span className="px-1.5 py-0.2 bg-purple-500 text-white rounded text-[9px] font-extrabold uppercase">4K UHD</span>
            </div>
            <p className="text-[11px] text-purple-300/80 mt-0.5">Direct 2160p / 1080p stream</p>
          </div>
        </div>

        <div className="p-3.5 rounded-xl bg-indigo-950/30 border border-indigo-800/40 flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center shrink-0">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-bold text-white">3+ Minutes Full Video</span>
              <span className="px-1.5 py-0.2 bg-indigo-500 text-white rounded text-[9px] font-extrabold uppercase">3m+</span>
            </div>
            <p className="text-[11px] text-indigo-300/80 mt-0.5">High-bitrate timeline seek</p>
          </div>
        </div>

        <div className="p-3.5 rounded-xl bg-cyan-950/30 border border-cyan-800/40 flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-cyan-600/20 text-cyan-400 border border-cyan-500/30 flex items-center justify-center shrink-0">
            <UploadCloud className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-bold text-white">Unlimited Storage & File Size</span>
              <span className="px-1.5 py-0.2 bg-cyan-500 text-slate-950 rounded text-[9px] font-extrabold uppercase">Unlimited</span>
            </div>
            <p className="text-[11px] text-cyan-300/80 mt-0.5">Zero file limits & batch upload</p>
          </div>
        </div>
      </div>

      {/* Target Folder and Tags Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 rounded-2xl bg-slate-900/80 border border-slate-800 backdrop-blur-md">
        <div>
          <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
            <Folder className="w-3.5 h-3.5 text-indigo-400" /> Destination Folder / Category
          </label>
          <input
            type="text"
            placeholder="e.g. promos, songs, podcast, highlights, general"
            value={folder}
            onChange={(e) => setFolder(e.target.value)}
            className="w-full px-3.5 py-2 bg-slate-950/70 border border-slate-700/80 rounded-xl text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
            <Tag className="w-3.5 h-3.5 text-cyan-400" /> Tags (comma separated)
          </label>
          <input
            type="text"
            placeholder="e.g. mastivideo, music, 4k, action, hero"
            value={tagsInput}
            onChange={(e) => setTagsInput(e.target.value)}
            className="w-full px-3.5 py-2 bg-slate-950/70 border border-slate-700/80 rounded-xl text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-cyan-500"
          />
        </div>
      </div>

      {/* Drag & Drop Zone & Direct Link Import */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* File Dropzone */}
        <div
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={`relative flex flex-col items-center justify-center p-8 rounded-2xl border-2 border-dashed transition-all cursor-pointer text-center ${
            isDragging
              ? 'border-indigo-500 bg-indigo-950/30 scale-[1.01]'
              : 'border-slate-800 bg-slate-900/40 hover:bg-slate-900/70 hover:border-slate-700'
          }`}
        >
          <input
            ref={fileInputRef}
            type="file"
            multiple
            accept="image/*,video/*,audio/*,.mp3,.wav,.ogg,.oga,.opus,.m4a,.aac,.flac,.weba,.mp4,.webm,.mov,.mkv"
            className="hidden"
            onChange={(e) => handleFilesAdded(e.target.files)}
          />

          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-indigo-600/20 to-cyan-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 mb-3 shadow-lg shadow-indigo-950/40">
            <UploadCloud className="w-7 h-7" />
          </div>

          <h3 className="text-base font-bold text-white mb-1">
            Drag & drop video files
          </h3>
          <p className="text-xs text-slate-400 max-w-xs mb-3">
            Support for MP4, WebM, MOV, MP3, WAV, JPG, PNG files.
          </p>

          <button
            type="button"
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl shadow-lg shadow-indigo-600/25 transition-all flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Browse Device Files</span>
          </button>
        </div>

        {/* Direct Link Import Box */}
        <div className="flex flex-col justify-center p-6 rounded-2xl border border-slate-800 bg-slate-900/40 hover:border-slate-700 transition-all space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-purple-600/20 to-pink-600/20 border border-purple-500/30 flex items-center justify-center text-purple-400 shrink-0 shadow-lg">
              <LinkIcon className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Import Video via Link (URL)</h3>
              <p className="text-xs text-slate-400">Paste any video or social link to publish as Sponsored Ad</p>
            </div>
          </div>

          <div className="flex gap-2">
            <input
              id="direct_video_url_input"
              type="url"
              placeholder="https://... paste video link here"
              className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-purple-500"
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  const val = (e.target as HTMLInputElement).value.trim();
                  if (val) {
                    const id = Math.random().toString(36).substring(2, 9);
                    const newItem: UploadQueueItem = {
                      id,
                      isUrlImport: true,
                      importedUrl: val,
                      previewUrl: val,
                      mediaType: 'video',
                      progress: 0,
                      status: 'pending',
                      title: 'Sponsored Video Ad',
                      caption: '#Sponsored #Ad Check this out'
                    };
                    setQueue(prev => [newItem, ...prev]);
                    (e.target as HTMLInputElement).value = '';
                    showToast('success', 'Link Added to Queue', 'Ready to publish as sponsored video!');
                  }
                }
              }}
            />
            <button
              type="button"
              onClick={() => {
                const inputEl = document.getElementById('direct_video_url_input') as HTMLInputElement;
                const val = inputEl?.value.trim();
                if (val) {
                  const id = Math.random().toString(36).substring(2, 9);
                  const newItem: UploadQueueItem = {
                    id,
                    isUrlImport: true,
                    importedUrl: val,
                    previewUrl: val,
                    mediaType: 'video',
                    progress: 0,
                    status: 'pending',
                    title: 'Sponsored Video Ad',
                    caption: '#Sponsored #Ad Check this out'
                  };
                  setQueue(prev => [newItem, ...prev]);
                  if (inputEl) inputEl.value = '';
                  showToast('success', 'Link Added to Queue', 'Ready to publish as sponsored video!');
                } else {
                  showToast('error', 'Enter Valid URL', 'Please paste a video link first.');
                }
              }}
              className="px-4 py-2.5 bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold rounded-xl shadow-md transition-all shrink-0 flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Link</span>
            </button>
          </div>
          <p className="text-[11px] text-slate-500">Press Enter or click Add Link to push into upload queue.</p>
        </div>
      </div>

      {/* Queue List */}
      {queue.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Upload Queue ({queue.length} items)
            </h3>
            <div className="flex items-center gap-2">
              {hasCompleted && (
                <button
                  type="button"
                  onClick={clearCompleted}
                  className="text-xs text-slate-400 hover:text-slate-200 transition-colors"
                >
                  Clear Completed
                </button>
              )}
              <button
                type="button"
                onClick={() => setQueue([])}
                className="text-xs text-rose-400 hover:text-rose-300 transition-colors"
              >
                Clear All
              </button>
            </div>
          </div>

          <div className="space-y-3">
            {queue.map(item => (
              <div
                key={item.id}
                className="rounded-2xl bg-slate-900 border border-slate-800/90 shadow-sm overflow-hidden transition-all"
              >
                {/* Main Item Row */}
                <div className="flex items-center gap-3.5 p-3.5">
                  {/* Thumbnail / Icon */}
                  <div className="relative w-12 h-12 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center overflow-hidden shrink-0">
                    {item.posterPreviewUrl ? (
                      <>
                        <img src={item.posterPreviewUrl} alt="Poster" className="w-full h-full object-cover" />
                        <div className="absolute bottom-0 inset-x-0 bg-amber-500 text-slate-950 text-[8px] font-bold text-center py-0.2">
                          POSTER
                        </div>
                      </>
                    ) : item.mediaType === 'image' ? (
                      <img src={item.previewUrl} alt={item.file.name} className="w-full h-full object-cover" />
                    ) : item.mediaType === 'audio' ? (
                      <div className="w-full h-full bg-gradient-to-tr from-amber-600/20 to-rose-600/20 flex items-center justify-center">
                        <Music className="w-5 h-5 text-amber-400" />
                      </div>
                    ) : (
                      <Film className="w-5 h-5 text-indigo-400" />
                    )}
                  </div>

                  {/* Info & Progress */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <div className="flex items-center gap-2 min-w-0">
                        <span className="text-xs font-bold text-white truncate max-w-xs">
                          {item.title || item.file.name}
                        </span>
                        {item.posterPreviewUrl && (
                          <span className="px-1.5 py-0.5 rounded bg-amber-500/20 border border-amber-500/30 text-amber-300 font-mono text-[9px] font-bold shrink-0">
                            Cover
                          </span>
                        )}
                        {item.qualityBadge && (
                          <span className="px-1.5 py-0.5 rounded bg-purple-500/20 border border-purple-500/30 text-purple-300 font-mono text-[9px] font-bold shrink-0">
                            {item.qualityBadge}
                          </span>
                        )}
                        {item.duration && (
                          <span className="px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-300 font-mono text-[9px] shrink-0">
                            {formatDuration(item.duration)}
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] text-slate-400 shrink-0 font-mono">
                        {item.file ? formatBytes(item.file.size) : 'URL Link (1.2 MB)'}
                      </span>
                    </div>

                    {/* Progress Bar */}
                    <div className="w-full bg-slate-950 rounded-full h-1.5 overflow-hidden border border-slate-800">
                      <div
                        className={`h-full transition-all duration-300 ${
                          item.status === 'completed'
                            ? 'bg-emerald-500'
                            : item.status === 'error'
                            ? 'bg-rose-500'
                            : 'bg-gradient-to-r from-indigo-500 to-cyan-400'
                        }`}
                        style={{ width: `${item.progress}%` }}
                      />
                    </div>

                    <div className="flex items-center justify-between text-[10px] text-slate-400 mt-1 font-medium">
                      <span>
                        {item.status === 'pending' && 'Ready to upload'}
                        {item.status === 'uploading' && `Uploading... ${item.progress}%`}
                        {item.status === 'completed' && 'Uploaded to Masti Bash Cloud'}
                        {item.status === 'error' && (item.error || 'Failed')}
                      </span>
                      <div className="flex items-center gap-2">
                        {item.mediaType === 'audio' && item.status === 'pending' && (
                          <label className="text-[10px] text-amber-400 hover:text-amber-300 cursor-pointer flex items-center gap-1 font-semibold underline">
                            <span>{item.posterPreviewUrl ? 'Change Poster' : '+ Cover'}</span>
                            <input
                              type="file"
                              accept="image/*"
                              className="hidden"
                              onChange={(e) => {
                                const pFile = e.target.files?.[0];
                                if (pFile) {
                                  const preview = URL.createObjectURL(pFile);
                                  setQueue(prev => prev.map(q => q.id === item.id ? { ...q, posterFile: pFile, posterPreviewUrl: preview } : q));
                                  showToast('info', 'Poster Attached', `Cover set for ${item.file.name}`);
                                }
                              }}
                            />
                          </label>
                        )}
                        <span className="uppercase text-[9px] tracking-wider text-indigo-300 font-bold">
                          {item.mediaType}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Actions & Details Toggle */}
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      type="button"
                      onClick={() => setQueue(prev => prev.map(q => q.id === item.id ? { ...q, isDetailsExpanded: !q.isDetailsExpanded } : q))}
                      className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold border transition-all ${
                        item.isDetailsExpanded
                          ? 'bg-purple-950/60 border-purple-600/50 text-purple-300'
                          : 'bg-slate-800/80 hover:bg-slate-800 border-slate-700/60 text-slate-300'
                      }`}
                    >
                      <Edit3 className="w-3 h-3" />
                      <span className="hidden sm:inline">Details</span>
                      {item.isDetailsExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                    </button>

                    {item.status === 'completed' && (
                      <div className="p-1 rounded-lg bg-emerald-950/60 text-emerald-400 border border-emerald-800/40">
                        <CheckCircle2 className="w-4 h-4" />
                      </div>
                    )}
                    {item.status === 'error' && (
                      <div className="p-1 rounded-lg bg-rose-950/60 text-rose-400 border border-rose-800/40" title={item.error}>
                        <AlertCircle className="w-4 h-4" />
                      </div>
                    )}
                    {item.status === 'uploading' && (
                      <div className="w-4 h-4 border-2 border-indigo-500/30 border-t-indigo-500 rounded-full animate-spin" />
                    )}

                    <button
                      type="button"
                      onClick={() => removeItem(item.id)}
                      className="p-1.5 text-slate-400 hover:text-rose-400 rounded-lg hover:bg-slate-800 transition-colors"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Per-Video Custom Details Editor Drawer */}
                {item.isDetailsExpanded && (
                  <div className="border-t border-slate-800/80 bg-slate-950/60 p-3.5 sm:p-4 space-y-3 animate-in fade-in duration-150">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] uppercase font-bold text-indigo-300 tracking-wider flex items-center gap-1.5">
                        <Edit3 className="w-3.5 h-3.5" /> Custom Title & Caption For This Video
                      </span>
                      <span className="text-[10px] text-slate-500 font-mono">
                        Saved specifically to this video
                      </span>
                    </div>

                    <div className="grid grid-cols-1 gap-2.5">
                      {/* Video Title Input */}
                      <div>
                        <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">
                          Video Title & Link (शीर्षक या लिंक)
                        </label>
                        <input
                          type="text"
                          value={item.title || ''}
                          onChange={(e) => {
                            const val = e.target.value;
                            setQueue(prev => prev.map(q => q.id === item.id ? { ...q, title: val } : q));
                          }}
                          placeholder="e.g. My Cool Video / https://..."
                          className="w-full px-3 py-1.5 bg-slate-900 border border-slate-700/80 rounded-xl text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
                        />
                      </div>

                      {/* Video Caption & Hashtags & Links */}
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="block text-[10px] uppercase font-bold text-slate-400">
                            Caption, Hashtags & Links (कैप्शन, हैशटैग और लिंक)
                          </label>
                          {/* Quick Hashtags & Link Button */}
                          <div className="flex items-center gap-1 overflow-x-auto max-w-xs">
                            {['#masti', '#viral', '#reels', '#trending', '#song'].map(tag => (
                              <button
                                key={tag}
                                type="button"
                                onClick={() => {
                                  const currentCaption = item.caption || '';
                                  const newCaption = currentCaption.includes(tag) ? currentCaption : `${currentCaption} ${tag}`.trim();
                                  setQueue(prev => prev.map(q => q.id === item.id ? { ...q, caption: newCaption } : q));
                                }}
                                className="px-1.5 py-0.5 rounded-md bg-slate-800 hover:bg-indigo-600/30 text-slate-300 hover:text-indigo-200 text-[9px] font-semibold border border-slate-700 transition-colors"
                              >
                                {tag}
                              </button>
                            ))}
                          </div>
                        </div>
                        <textarea
                          rows={2}
                          value={item.caption || ''}
                          onChange={(e) => {
                            const val = e.target.value;
                            setQueue(prev => prev.map(q => q.id === item.id ? { ...q, caption: val } : q));
                          }}
                          placeholder="e.g. My new dance video! Check out https://instagram.com/user #masti #viral @creator"
                          className="w-full px-3 py-1.5 bg-slate-900 border border-slate-700/80 rounded-xl text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-indigo-500 leading-relaxed"
                        />
                        <span className="text-[10px] text-cyan-400/90 font-medium mt-0.5 block">
                          🔗 Link support: https://, http://, www. लिंक्स ऑटोमैटिकली सेव होंगे और क्लिक करने योग्य (Clickable) रहेंगे।
                        </span>
                      </div>

                      {/* Soundtrack / Audio Fields */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        <div>
                          <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1 flex items-center gap-1">
                            <Music className="w-3 h-3 text-amber-400" /> Soundtrack Name (म्यूजिक नाम)
                          </label>
                          <input
                            type="text"
                            value={item.soundtrackTitle || ''}
                            onChange={(e) => {
                              const val = e.target.value;
                              setQueue(prev => prev.map(q => q.id === item.id ? { ...q, soundtrackTitle: val } : q));
                            }}
                            placeholder="e.g. Original Sound / Song Title"
                            className="w-full px-2.5 py-1 bg-slate-900 border border-slate-700/80 rounded-lg text-xs text-amber-200 placeholder:text-slate-500 focus:outline-none focus:border-amber-500"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">
                            Soundtrack Audio URL (Optional)
                          </label>
                          <input
                            type="text"
                            value={item.audioUrl || ''}
                            onChange={(e) => {
                              const val = e.target.value;
                              setQueue(prev => prev.map(q => q.id === item.id ? { ...q, audioUrl: val } : q));
                            }}
                            placeholder="https://... (Custom Audio Link)"
                            className="w-full px-2.5 py-1 bg-slate-900 border border-slate-700/80 rounded-lg text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-amber-500 font-mono"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Upload Button Trigger */}
          <div className="pt-2">
            <button
              type="button"
              onClick={startUpload}
              disabled={isUploading || queue.filter(q => q.status === 'pending').length === 0}
              className="w-full py-3.5 px-6 bg-gradient-to-r from-indigo-600 via-indigo-500 to-cyan-500 hover:from-indigo-500 hover:to-cyan-400 text-white font-bold text-sm rounded-xl shadow-xl shadow-indigo-600/25 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {isUploading ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Streaming Media to Cloud Server...</span>
                </>
              ) : (
                <>
                  <UploadCloud className="w-5 h-5" />
                  <span>Start Upload ({queue.filter(q => q.status === 'pending').length} items)</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
