import React, { useState, useEffect } from 'react';
import { 
  Zap, Copy, Check, Smartphone, Flame, 
  Code, RefreshCw, Globe, CheckCircle2,
  Heart, MessageCircle, Bookmark, Share2, UserCheck, Play, Eye,
  Sparkles, ShieldCheck, ArrowUpRight, Key, Lock, Terminal, Layers
} from 'lucide-react';
import { useToast } from './Toast';

export const EasyConnectWizard: React.FC = () => {
  const { showToast } = useToast();
  const [copiedSection, setCopiedSection] = useState<string | null>(null);
  const [selectedTech, setSelectedTech] = useState<'masti_360' | 'replit_prompt' | 'flutter' | 'android_native' | 'reactnative' | 'curl'>('masti_360');
  const [testResult, setTestResult] = useState<any | null>(null);
  const [testingEndpoint, setTestingEndpoint] = useState(false);
  const [feedVideos, setFeedVideos] = useState<any[]>([]);
  const [apiKey, setApiKey] = useState<string>('mb_live_usr_masti_cinema');
  const [showKey, setShowKey] = useState<boolean>(false);

  // Automatically detect current server host origin
  const currentBaseUrl = typeof window !== 'undefined' ? window.location.origin : 'https://ais-dev-vqsmp4cogfojsrm6tre6zu-18143192690.asia-east1.run.app';

  const copyCode = (code: string, label: string) => {
    navigator.clipboard.writeText(code);
    setCopiedSection(label);
    showToast('success', 'Copied!', 'Copied to clipboard.');
    setTimeout(() => setCopiedSection(null), 2500);
  };

  const masti360FullCode = `// ==============================================================
// 🌟 MASTI VIDEO APP -> MASTI BASH FULL 360° SYNC & INTEGRATION
// Includes: User ID, DP, Notifications, Likes, Comments, Shares,
// Followers, Following, Direct Chat, Monetization (₹) & UPI Payouts
// ==============================================================
import axios from 'axios';

const MASTI_BASH_API_URL = '${currentBaseUrl}';
let currentUserToken = null;
let currentApiKey = '${apiKey}';

/**
 * 1. AUTHENTICATE / LOGIN WITH USER EMAIL (Google / Phone / Email)
 * When a user logs in on Masti Video, sync email with Masti Base:
 */
export const loginOrSyncUserWithEmail = async (email, name, avatarUrl = '') => {
  const response = await axios.post(\`\${MASTI_BASH_API_URL}/api/auth/email-sync\`, {
    email,
    name,
    avatarUrl
  });

  if (response.data.success) {
    currentUserToken = response.data.token;
    currentApiKey = response.data.user.apiKey || currentApiKey;
    return response.data.user; // Contains id, email, name, avatarUrl, apiKey
  }
  throw new Error(response.data.error || 'Authentication failed');
};

/**
 * 2. GET FULL 360° SYNCED DATA FOR LOGGED-IN USER
 * Returns: User ID, DP, Notifications, Likes, Comments, Shares,
 * Followers, Following, Chat Threads & Monetization Wallet!
 */
export const getFullUserSyncedData = async (userEmailOrId) => {
  const response = await axios.get(\`\${MASTI_BASH_API_URL}/api/v1/social/user/\${encodeURIComponent(userEmailOrId)}/synced-profile\`, {
    headers: { 'x-api-key': currentApiKey }
  });
  return response.data.data;
};

/**
 * 3. GET UNLIMITED VIDEO REELS FEED
 * Returns: Video URL, Creator DP, Name, Likes Count, IsLiked, Followers
 */
export const getVideoFeed = async () => {
  const response = await axios.get(\`\${MASTI_BASH_API_URL}/api/videos/feed\`, {
    headers: { 'x-api-key': currentApiKey }
  });
  return response.data.data || [];
};

/**
 * 4. UPLOAD VIDEO LINKED TO USER EMAIL (Unlimited Size)
 */
export const uploadUserVideo = async (fileUri, fileName, userEmail, userName = '', title = '') => {
  const formData = new FormData();
  formData.append('files', {
    uri: fileUri,
    name: fileName,
    type: 'video/mp4'
  });
  formData.append('userEmail', userEmail); // 👈 Binds video to creator's profile
  formData.append('userName', userName);
  formData.append('title', title || fileName);
  formData.append('folder', 'mastivideo_feed');

  const response = await axios.post(\`\${MASTI_BASH_API_URL}/api/v1/media/upload\`, formData, {
    headers: {
      'x-api-key': currentApiKey,
      'Content-Type': 'multipart/form-data'
    }
  });
  return response.data;
};

/**
 * 5. SOCIAL ACTIONS (LIKE, COMMENT, SHARE, FOLLOW)
 */
export const likeVideo = async (mediaId, userId, userName) => {
  const res = await axios.post(\`\${MASTI_BASH_API_URL}/api/v1/social/like\`, { mediaId, userId, userName });
  return res.data;
};

export const commentOnVideo = async (mediaId, userId, userName, comment) => {
  const res = await axios.post(\`\${MASTI_BASH_API_URL}/api/v1/social/comment\`, { mediaId, userId, userName, comment });
  return res.data;
};

export const shareVideo = async (mediaId, platform, userId, userName) => {
  const res = await axios.post(\`\${MASTI_BASH_API_URL}/api/v1/social/share\`, { mediaId, platform, userId, userName });
  return res.data;
};

export const followCreator = async (creatorId, creatorName, myUserId, myName) => {
  const res = await axios.post(\`\${MASTI_BASH_API_URL}/api/v1/social/follow\`, {
    targetUserId: creatorId,
    targetUserName: creatorName,
    followerId: myUserId,
    followerName: myName
  });
  return res.data;
};

/**
 * 6. DIRECT 1-TO-1 CHAT MESSAGES
 */
export const sendChatMessage = async (senderId, senderName, receiverId, receiverName, message) => {
  const res = await axios.post(\`\${MASTI_BASH_API_URL}/api/v1/social/chat/send\`, {
    senderId,
    senderName,
    receiverId,
    receiverName,
    message
  });
  return res.data;
};

/**
 * 7. USER NOTIFICATIONS
 */
export const getUserNotifications = async (userId) => {
  const res = await axios.get(\`\${MASTI_BASH_API_URL}/api/v1/social/notifications/\${userId}\`);
  return res.data.data;
};

/**
 * 8. MONETIZATION EARNINGS & INSTANT UPI WITHDRAWAL (₹)
 */
export const getMonetizationData = async (userEmailOrId) => {
  const res = await axios.get(\`\${MASTI_BASH_API_URL}/api/v1/social/monetization/\${encodeURIComponent(userEmailOrId)}\`);
  return res.data.data; // { walletBalance, totalEarnings, rpm: 28.50, totalViews, payouts }
};

export const requestUpiPayout = async (userId, amount, upiId) => {
  const res = await axios.post(\`\${MASTI_BASH_API_URL}/api/v1/social/monetization/payout\`, {
    userId,
    amount,
    method: 'upi',
    accountInfo: upiId
  });
  return res.data;
};`;

  const fetchQuickKey = async () => {
    try {
      const res = await fetch('/api/auth/quick-key');
      const data = await res.json();
      if (data.apiKey) {
        setApiKey(data.apiKey);
      }
    } catch {
      // fallback to default
    }
  };

  const handleTestConnection = async () => {
    setTestingEndpoint(true);
    try {
      const res = await fetch('/api/videos/feed', {
        headers: {
          'x-api-key': apiKey
        }
      });
      const data = await res.json();
      setTestResult(data);
      if (data.data && Array.isArray(data.data)) {
        setFeedVideos(data.data);
      }
      showToast('API Key Valid! Live Video Feed Loaded.', 'success');
    } catch (err: any) {
      setTestResult({ error: err.message || 'Failed to reach server' });
      showToast('Connection failed. Check network.', 'error');
    } finally {
      setTestingEndpoint(false);
    }
  };

  useEffect(() => {
    fetchQuickKey();
    handleTestConnection();
  }, []);

  // Replit One-Prompt Integration Instructions with API Key
  const replitAiPrompt = `Connect our Masti Video app to the MastiBase Cloud backend using this API Key & Base URL:

1. CONFIGURATION:
- Base Server URL: "${currentBaseUrl}"
- API Key Header: "x-api-key: ${apiKey}"
- Replit Secret / Env Variable: MASTI_API_KEY="${apiKey}"

2. LIVE SOCIAL ENDPOINTS:
- Feed: GET ${currentBaseUrl}/api/videos/feed (Returns Creator DP, Name, Followers, Likes, Comments, Caption)
- Like/Unlike Video: POST ${currentBaseUrl}/api/videos/social/videos/:videoId/like
- Bookmark/Save: POST ${currentBaseUrl}/api/videos/social/videos/:videoId/save
- Comments List/Post: GET & POST ${currentBaseUrl}/api/videos/social/videos/:videoId/comments
- Follow/Unfollow Creator: POST ${currentBaseUrl}/api/videos/social/users/:userId/follow
- Video Upload: POST ${currentBaseUrl}/api/videos/upload (multipart formData with 'file', 'title', 'description')
- Profile & Earnings: GET ${currentBaseUrl}/api/videos/social/profile/me

3. AUTHENTICATION:
Send 'x-api-key: ${apiKey}' in all request headers (or 'Authorization: Bearer <Firebase_ID_Token>').

4. UI DATA BINDING:
- Creator DP: item.profile.avatarUrl
- Creator Name: item.profile.name (@item.profile.username)
- Followers Count: item.profile.followersCount
- Likes Count & State: item.social.likes, item.social.isLiked (Heart button)
- Comments Count: item.social.comments
- Video Title & Caption: item.title, item.caption

Please implement the API service layer and connect all feed, like, follow, and comment components to these live endpoints.`;

  const flutterOneFileCode = `// ==============================================================
// 📱 MASTI VIDEO APP (APK / REPLIT) -> FLUTTER CONNECTOR
// File Location: lib/services/masti_api.dart
// ==============================================================

import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:firebase_auth/firebase_auth.dart';

class MastiApi {
  // 🌐 1. Live MastiBase Server URL
  static const String baseUrl = '${currentBaseUrl}';

  // 🔑 2. Live MastiBase API Key
  static const String apiKey = '${apiKey}';

  // 🛡️ 3. Request Headers with API Key & Firebase Token
  static Future<Map<String, String>> _getHeaders() async {
    final user = FirebaseAuth.instance.currentUser;
    final token = await user?.getIdToken();
    return {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'x-api-key': apiKey, // 🔑 Direct API Key Authorization
      if (token != null) 'Authorization': 'Bearer $token',
    };
  }

  // 🎬 4. UNLIMITED VIDEO FEED (Includes Likes, Comments, Creator DP, Name, Caption & Followers)
  static Future<List<dynamic>> getVideoFeed() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/videos/feed'),
        headers: await _getHeaders(),
      );
      if (response.statusCode == 200) {
        final json = jsonDecode(response.body);
        return json['data'] ?? [];
      }
    } catch (e) {
      print('Error fetching feed: $e');
    }
    return [];
  }

  // 📤 5. UPLOAD VIDEO (Unlimited 4K/HD Video Size)
  static Future<bool> uploadVideo({
    required String filePath,
    required String title,
    String description = '',
  }) async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      final token = await user?.getIdToken();

      var request = http.MultipartRequest('POST', Uri.parse('$baseUrl/api/videos/upload'));
      request.headers['x-api-key'] = apiKey;
      if (token != null) request.headers['Authorization'] = 'Bearer $token';
      request.fields['title'] = title;
      request.fields['description'] = description;
      request.files.add(await http.MultipartFile.fromPath('file', filePath));

      var streamedResponse = await request.send();
      return streamedResponse.statusCode == 200 || streamedResponse.statusCode == 201;
    } catch (e) {
      print('Error uploading video: $e');
      return false;
    }
  }

  // ❤️ 6. LIKE / UNLIKE VIDEO
  static Future<bool> toggleLike(String videoId) async {
    final response = await http.post(
      Uri.parse('$baseUrl/api/videos/social/videos/$videoId/like'),
      headers: await _getHeaders(),
    );
    return response.statusCode == 200;
  }

  // 🔖 7. SAVE / BOOKMARK VIDEO
  static Future<bool> toggleSave(String videoId) async {
    final response = await http.post(
      Uri.parse('$baseUrl/api/videos/social/videos/$videoId/save'),
      headers: await _getHeaders(),
    );
    return response.statusCode == 200;
  }

  // 💬 8. POST COMMENT
  static Future<bool> postComment(String videoId, String text) async {
    final response = await http.post(
      Uri.parse('$baseUrl/api/videos/social/videos/$videoId/comments'),
      headers: await _getHeaders(),
      body: jsonEncode({'text': text}),
    );
    return response.statusCode == 200 || response.statusCode == 201;
  }

  // 👥 9. FOLLOW / UNFOLLOW CREATOR
  static Future<bool> toggleFollow(String creatorUserId) async {
    final response = await http.post(
      Uri.parse('$baseUrl/api/videos/social/users/$creatorUserId/follow'),
      headers: await _getHeaders(),
    );
    return response.statusCode == 200;
  }

  // 👤 10. PROFILE & EARNINGS
  static Future<Map<String, dynamic>?> getMyProfile() async {
    final response = await http.get(
      Uri.parse('$baseUrl/api/videos/social/profile/me'),
      headers: await _getHeaders(),
    );
    if (response.statusCode == 200) {
      return jsonDecode(response.body)['data'];
    }
    return null;
  }
}
`;

  const androidNativeCode = `// ==============================================================
// 📱 ANDROID APK (KOTLIN) -> CONNECTOR WITH API KEY
// File Location in Android / Replit: MastiApi.kt
// ==============================================================

package com.mastivideo.app

import com.google.firebase.auth.FirebaseAuth
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File
import java.io.IOException

object MastiApi {
    const val BASE_URL = "${currentBaseUrl}"
    const val API_KEY = "${apiKey}"
    private val client = OkHttpClient()

    private fun buildRequest(url: String): Request.Builder {
        val builder = Request.Builder().url(url)
        builder.header("x-api-key", API_KEY)
        val user = FirebaseAuth.getInstance().currentUser
        if (user != null) {
            user.getIdToken(false).addOnSuccessListener { res ->
                if (res.token != null) builder.header("Authorization", "Bearer \${res.token}")
            }
        }
        return builder
    }

    // 1. Fetch Unlimited Video Feed with Profile, DP, Likes
    fun fetchFeed(onSuccess: (String) -> Unit, onError: (String) -> Unit) {
        val req = buildRequest("$BASE_URL/api/videos/feed").build()
        client.newCall(req).enqueue(object : Callback {
            override fun onResponse(call: Call, response: Response) {
                onSuccess(response.body?.string() ?: "[]")
            }
            override fun onFailure(call: Call, e: IOException) {
                onError(e.message ?: "Network error")
            }
        })
    }

    // 2. Upload Video with API Key
    fun uploadVideo(file: File, title: String, onSuccess: () -> Unit, onError: (String) -> Unit) {
        val mediaType = "video/mp4".toMediaTypeOrNull()
        val requestBody = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("title", title)
            .addFormDataPart("file", file.name, file.asRequestBody(mediaType))
            .build()

        val req = Request.Builder()
            .url("$BASE_URL/api/videos/upload")
            .header("x-api-key", API_KEY)
            .post(requestBody)
            .build()

        client.newCall(req).enqueue(object : Callback {
            override fun onResponse(call: Call, response: Response) {
                if (response.isSuccessful) onSuccess() else onError("HTTP \${response.code}")
            }
            override fun onFailure(call: Call, e: IOException) {
                onError(e.message ?: "Upload failed")
            }
        })
    }

    // 3. Like Video
    fun toggleLike(videoId: String, callback: () -> Unit) {
        val req = Request.Builder()
            .url("$BASE_URL/api/videos/social/videos/$videoId/like")
            .header("x-api-key", API_KEY)
            .post(RequestBody.create(null, ByteArray(0)))
            .build()
        client.newCall(req).enqueue(object: Callback {
            override fun onResponse(call: Call, response: Response) { callback() }
            override fun onFailure(call: Call, e: IOException) {}
        })
    }
}
`;

  const reactNativeCode = `// ==============================================================
// 📱 REACT NATIVE / EXPO APK -> CONNECTOR WITH API KEY
// File Location in Replit: services/mastiApi.js
// ==============================================================

import auth from '@react-native-firebase/auth';

const BASE_URL = '${currentBaseUrl}';
const API_KEY = '${apiKey}';

async function getHeaders() {
  const user = auth().currentUser;
  const token = user ? await user.getIdToken() : null;
  return {
    'Content-Type': 'application/json',
    'x-api-key': API_KEY,
    ...(token ? { Authorization: \`Bearer \${token}\` } : {}),
  };
}

export const MastiApi = {
  // 1. Get Unlimited Video Feed
  getVideoFeed: async () => {
    const headers = await getHeaders();
    const res = await fetch(\`\${BASE_URL}/api/videos/feed\`, { headers });
    const json = await res.json();
    return json.data || [];
  },

  // 2. Like Video
  toggleLike: async (videoId) => {
    const headers = await getHeaders();
    const res = await fetch(\`\${BASE_URL}/api/videos/social/videos/\${videoId}/like\`, {
      method: 'POST',
      headers,
    });
    return res.json();
  },

  // 3. Save / Bookmark Video
  toggleSave: async (videoId) => {
    const headers = await getHeaders();
    const res = await fetch(\`\${BASE_URL}/api/videos/social/videos/\${videoId}/save\`, {
      method: 'POST',
      headers,
    });
    return res.json();
  },

  // 4. Get Current User Profile
  getMyProfile: async () => {
    const headers = await getHeaders();
    const res = await fetch(\`\${BASE_URL}/api/videos/social/profile/me\`, { headers });
    return res.json();
  }
};
`;

  const curlCode = `# 1. Fetch Video Feed with API Key
curl -X GET "${currentBaseUrl}/api/videos/feed" \\
  -H "x-api-key: ${apiKey}"

# 2. Like a Video with API Key
curl -X POST "${currentBaseUrl}/api/videos/social/videos/med_video1/like" \\
  -H "x-api-key: ${apiKey}"

# 3. Post a Comment
curl -X POST "${currentBaseUrl}/api/videos/social/videos/med_video1/comments" \\
  -H "x-api-key: ${apiKey}" \\
  -H "Content-Type: application/json" \\
  -d '{"text": "Bhai mast video hai! 🔥"}'
`;

  // Sample or live video item
  const sampleVideo = feedVideos.length > 0 ? feedVideos[0] : {
    id: "med_video1",
    title: "Super Dance Reel 💃",
    caption: "#masti #trending #dance viral short by Rajkali",
    videoUrl: "/sample_video_1.mp4",
    thumbnailUrl: "/sample_thumb_1.jpg",
    profile: {
      id: "usr_rajkali",
      name: "Rajkali Kumar",
      username: "rajkali8789",
      avatarUrl: "https://api.dicebear.com/7.x/bottts/svg?seed=rajkali",
      followersCount: 1420,
      followingCount: 230,
      isVerified: true
    },
    social: {
      likes: 540,
      comments: 62,
      shares: 110,
      saves: 85,
      isLiked: true,
      isSaved: false,
      isFollowingCreator: true
    }
  };

  return (
    <div id="apk-connect-wizard" className="w-full max-w-6xl mx-auto space-y-6">
      {/* Top Banner */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-emerald-950 via-slate-900 to-indigo-950 border border-emerald-500/40 shadow-2xl relative overflow-hidden">
        <div className="relative z-10 space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-500/20 border border-emerald-500/50 text-emerald-300 text-xs font-black uppercase tracking-wider">
            <Key className="w-4 h-4 text-emerald-400" />
            Live API Key & Replit Connect
          </div>

          <h1 className="text-2xl sm:text-4xl font-black text-white tracking-tight">
            MastiBase Live API Key & Replit Connection
          </h1>
          <p className="text-sm sm:text-base text-slate-300 max-w-2xl leading-relaxed">
            Replit ya kisi bhi mobile app me ye <span className="text-emerald-400 font-bold">Live API Key</span> daalein — aapka video feed, likes, comments, DP aur user data turant connect ho jayega!
          </p>

          {/* Quick Server Details & Test */}
          <div className="flex flex-wrap items-center gap-3 pt-2">
            <div className="flex items-center gap-2 bg-slate-950/90 border border-slate-700/80 rounded-xl px-4 py-2.5">
              <Globe className="w-4 h-4 text-emerald-400" />
              <span className="text-xs text-slate-400">Base URL:</span>
              <span className="text-xs font-mono font-bold text-emerald-300 select-all">{currentBaseUrl}</span>
              <button
                onClick={() => copyCode(currentBaseUrl, 'server-url')}
                className="ml-1 p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-white transition-colors"
                title="Copy URL"
              >
                {copiedSection === 'server-url' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>

            <button
              onClick={handleTestConnection}
              disabled={testingEndpoint}
              className="flex items-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white text-xs font-bold rounded-xl shadow-lg shadow-emerald-600/30 transition-all cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${testingEndpoint ? 'animate-spin' : ''}`} />
              <span>{testingEndpoint ? 'Verifying Key...' : 'Test API Key Connection'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* HIGHLIGHTED API KEY BOX */}
      <div className="bg-gradient-to-b from-slate-900 to-slate-950 border-2 border-emerald-500/60 rounded-3xl p-6 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-500/50 flex items-center justify-center text-emerald-400 shadow-md shadow-emerald-500/20">
              <Key className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-mono font-bold text-emerald-400 uppercase tracking-wider">
                MastiBase Live Project Secret API Key
              </div>
              <div className="text-sm font-bold text-white">
                Replit Secrets (`MASTI_API_KEY`) ya `x-api-key` header me use karein
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowKey(!showKey)}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-300 hover:text-white transition-colors"
            >
              {showKey ? 'Hide Key' : 'Show Key'}
            </button>
            <button
              onClick={() => copyCode(apiKey, 'master-api-key')}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-lg shadow-emerald-600/30 transition-all cursor-pointer"
            >
              {copiedSection === 'master-api-key' ? <Check className="w-4 h-4 text-emerald-200" /> : <Copy className="w-4 h-4" />}
              <span>{copiedSection === 'master-api-key' ? 'API Key Copied!' : 'Copy API Key'}</span>
            </button>
          </div>
        </div>

        {/* Key Display & Replit Secret Config */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3 pt-1">
          <div className="md:col-span-8 p-3 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between">
            <div className="space-y-0.5 overflow-hidden">
              <div className="text-[10px] text-slate-400 uppercase font-mono">API Key Value</div>
              <div className="font-mono text-xs sm:text-sm font-bold text-emerald-300 truncate">
                {showKey ? apiKey : `${apiKey.slice(0, 10)}••••••••••••••••••••`}
              </div>
            </div>
            <button
              onClick={() => copyCode(apiKey, 'api-key-val')}
              className="p-2 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white transition-colors"
              title="Copy"
            >
              {copiedSection === 'api-key-val' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>

          <div className="md:col-span-4 p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-0.5">
            <div className="text-[10px] text-slate-400 uppercase font-mono">Header Name</div>
            <div className="font-mono text-xs font-bold text-cyan-300">
              x-api-key: {showKey ? apiKey.slice(0, 12) + '...' : 'mb_live_...'}
            </div>
          </div>
        </div>
      </div>

      {/* 3 Step Replit Quick Guide */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-5 rounded-2xl bg-slate-900/70 border border-slate-800 flex flex-col justify-between">
          <div className="space-y-2">
            <div className="w-8 h-8 rounded-xl bg-orange-500/20 text-orange-400 flex items-center justify-center font-black text-sm">
              1
            </div>
            <h3 className="text-sm font-bold text-white">Replit Open Karein</h3>
            <p className="text-xs text-slate-400">
              Apne Replit project me jayein aur Replit AI / Assistant chat open karein.
            </p>
          </div>
          <div className="mt-3 text-[11px] text-orange-400 font-semibold">replit.com</div>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/70 border border-slate-800 flex flex-col justify-between">
          <div className="space-y-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-black text-sm">
              2
            </div>
            <h3 className="text-sm font-bold text-white">Copy Replit Prompt (With Key)</h3>
            <p className="text-xs text-slate-400">
              Neeche diya gaya Replit AI Prompt copy karke Replit Chat me bhej dein.
            </p>
          </div>
          <div className="mt-3 text-[11px] text-emerald-400 font-semibold">Pre-Configured with API Key</div>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/70 border border-slate-800 flex flex-col justify-between">
          <div className="space-y-2">
            <div className="w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center font-black text-sm">
              3
            </div>
            <h3 className="text-sm font-bold text-white">Replit Connect Kar Dega</h3>
            <p className="text-xs text-slate-400">
              Replit saari video screens, like buttons aur profile data ko turant connect kar dega!
            </p>
          </div>
          <div className="mt-3 text-[11px] text-cyan-400 font-semibold">Done in 30 Seconds!</div>
        </div>
      </div>

      {/* Main Code & Replit Prompt Section */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Code className="w-5 h-5 text-emerald-400" />
              <span>Replit AI Prompt & Connector Codes (Pre-loaded with API Key)</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Replit AI Prompt select karein aur copy karke Replit me paste kar dein:
            </p>
          </div>

          {/* Platform Switcher */}
          <div className="flex items-center gap-1.5 p-1 bg-slate-950 rounded-xl border border-slate-800 flex-wrap">
            <button
              onClick={() => setSelectedTech('masti_360')}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all ${
                selectedTech === 'masti_360' 
                  ? 'bg-gradient-to-r from-indigo-600 to-violet-600 text-white shadow-md' 
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <span>📱 Masti Video App (Full 360°)</span>
            </button>
            <button
              onClick={() => setSelectedTech('replit_prompt')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all ${
                selectedTech === 'replit_prompt' 
                  ? 'bg-gradient-to-r from-orange-500 to-amber-500 text-white shadow-md' 
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              ⚡ Replit AI Prompt
            </button>
            <button
              onClick={() => setSelectedTech('flutter')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all ${
                selectedTech === 'flutter' 
                  ? 'bg-gradient-to-r from-emerald-600 to-cyan-600 text-white shadow-md' 
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Flutter (Dart)
            </button>
            <button
              onClick={() => setSelectedTech('android_native')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all ${
                selectedTech === 'android_native' 
                  ? 'bg-gradient-to-r from-emerald-600 to-green-600 text-white shadow-md' 
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Android (Kotlin)
            </button>
            <button
              onClick={() => setSelectedTech('reactnative')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all ${
                selectedTech === 'reactnative' 
                  ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-md' 
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              React Native
            </button>
            <button
              onClick={() => setSelectedTech('curl')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all ${
                selectedTech === 'curl' 
                  ? 'bg-gradient-to-r from-slate-700 to-slate-600 text-white shadow-md' 
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              cURL / Terminal
            </button>
          </div>
        </div>

        {/* Code Box */}
        <div className="relative rounded-2xl bg-slate-950 border border-slate-800/90 overflow-hidden">
          <div className="flex items-center justify-between px-4 py-3 bg-slate-900/80 border-b border-slate-800 text-xs font-mono text-slate-400">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-white font-bold">
                {selectedTech === 'masti_360' && '🌟 Masti Video App Full 360° SDK (User ID, DP, Notifs, Monetization & Feed)'}
                {selectedTech === 'replit_prompt' && '💬 Copy & Paste into Replit Chat'}
                {selectedTech === 'flutter' && '📁 lib/services/masti_api.dart'}
                {selectedTech === 'android_native' && '📁 MastiApi.kt'}
                {selectedTech === 'reactnative' && '📁 services/mastiApi.js'}
                {selectedTech === 'curl' && '💻 Terminal / cURL Commands'}
              </span>
            </div>

            <button
              onClick={() => {
                const code = selectedTech === 'masti_360'
                  ? masti360FullCode
                  : selectedTech === 'replit_prompt' 
                  ? replitAiPrompt 
                  : selectedTech === 'flutter' 
                  ? flutterOneFileCode 
                  : selectedTech === 'android_native' 
                  ? androidNativeCode 
                  : selectedTech === 'reactnative' 
                  ? reactNativeCode 
                  : curlCode;
                copyCode(code, 'apk-file');
              }}
              className="flex items-center gap-1.5 px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-lg shadow transition-all cursor-pointer"
            >
              {copiedSection === 'apk-file' ? <Check className="w-3.5 h-3.5 text-emerald-200" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedSection === 'apk-file' ? 'Copied!' : selectedTech === 'replit_prompt' ? 'Copy Replit Prompt' : 'Copy Full File'}</span>
            </button>
          </div>

          <pre className="p-4 text-xs font-mono text-emerald-400/90 overflow-x-auto max-h-[460px] overflow-y-auto leading-relaxed">
            {selectedTech === 'masti_360' && masti360FullCode}
            {selectedTech === 'replit_prompt' && replitAiPrompt}
            {selectedTech === 'flutter' && flutterOneFileCode}
            {selectedTech === 'android_native' && androidNativeCode}
            {selectedTech === 'reactnative' && reactNativeCode}
            {selectedTech === 'curl' && curlCode}
          </pre>
        </div>
      </div>
    </div>
  );
};
