import React, { useState, useEffect } from 'react';
import { Comment, MediaFile } from '../types.js';
import { api, formatDate } from '../services/api.js';
import { useAuth } from '../context/AuthContext.js';
import { useToast } from './Toast.js';
import { X, Send, Trash2, MessageSquare, Heart, Share2, Sparkles, User as UserIcon } from 'lucide-react';

interface CommentsDrawerProps {
  media: MediaFile | null;
  isOpen: boolean;
  onClose: () => void;
  onCommentsUpdated?: (mediaId: string, count: number) => void;
}

export const CommentsDrawer: React.FC<CommentsDrawerProps> = ({
  media,
  isOpen,
  onClose,
  onCommentsUpdated
}) => {
  const { user } = useAuth();
  const { showToast } = useToast();
  const [comments, setComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState('');
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (isOpen && media) {
      loadComments();
    }
  }, [isOpen, media?.id]);

  const loadComments = async () => {
    if (!media) return;
    setLoading(true);
    try {
      const res = await api.getComments(media.id);
      if (res.success && Array.isArray(res.data)) {
        setComments(res.data);
      }
    } catch (err: any) {
      console.warn('Failed to load comments:', err?.message);
    } finally {
      setLoading(false);
    }
  };

  const handlePostComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!media || !newComment.trim()) return;

    setSubmitting(true);
    try {
      const res = await api.addComment(
        media.id,
        newComment.trim(),
        user?.id,
        user?.name || 'Anonymous User',
        user?.avatarUrl
      );

      if (res.success && res.data) {
        const updated = [res.data, ...comments];
        setComments(updated);
        setNewComment('');
        showToast('success', 'Comment Added', 'Your comment has been saved to Masti Bash permanently.');
        if (onCommentsUpdated) {
          onCommentsUpdated(media.id, updated.length);
        }
      } else {
        showToast('error', 'Failed to post', res.error || 'Could not save comment');
      }
    } catch (err: any) {
      showToast('error', 'Error', err?.message || 'Failed to submit comment');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteComment = async (commentId: string) => {
    try {
      const res = await api.deleteComment(commentId, user?.id);
      if (res.success) {
        const filtered = comments.filter(c => c.id !== commentId);
        setComments(filtered);
        showToast('info', 'Comment Deleted', 'Comment removed from database.');
        if (media && onCommentsUpdated) {
          onCommentsUpdated(media.id, filtered.length);
        }
      }
    } catch (err: any) {
      showToast('error', 'Error', err?.message || 'Could not delete comment');
    }
  };

  if (!isOpen || !media) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-end bg-black/60 backdrop-blur-sm transition-opacity">
      <div 
        className="w-full max-w-md h-full bg-slate-900 border-l border-slate-800 flex flex-col shadow-2xl animate-in slide-in-from-right duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/80">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <MessageSquare className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                Comments
                <span className="px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-400 text-xs font-mono">
                  {comments.length}
                </span>
              </h3>
              <p className="text-[11px] text-slate-400 truncate max-w-[240px]">
                {media.originalName}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Media Mini Info Bar */}
        <div className="px-4 py-2.5 bg-slate-950/40 border-b border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-1.5">
            <UserIcon className="w-3.5 h-3.5 text-slate-500" />
            <span>User ID: <span className="font-mono text-indigo-400">{media.userId || 'usr_anonymous'}</span></span>
          </div>
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1">
              <Heart className="w-3.5 h-3.5 text-rose-500" />
              {media.likesCount || 0}
            </span>
            <span className="flex items-center gap-1">
              <Share2 className="w-3.5 h-3.5 text-emerald-500" />
              {media.sharesCount || 0}
            </span>
          </div>
        </div>

        {/* Comments List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3.5">
          {loading ? (
            <div className="flex flex-col items-center justify-center h-48 text-slate-500">
              <div className="w-6 h-6 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin mb-2" />
              <p className="text-xs">Loading real-time comments...</p>
            </div>
          ) : comments.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-56 text-center text-slate-500 px-6">
              <MessageSquare className="w-10 h-10 mb-2 opacity-30" />
              <p className="text-sm font-medium text-slate-400">No comments yet</p>
              <p className="text-xs text-slate-500 mt-1">Be the first to share your thoughts on this media.</p>
            </div>
          ) : (
            comments.map((cmt) => {
              const isOwner = user?.id === cmt.userId || user?.role === 'admin';
              return (
                <div 
                  key={cmt.id} 
                  className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800/80 hover:border-slate-700/80 transition-all space-y-2 group"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-indigo-600 to-purple-600 flex items-center justify-center text-white text-xs font-bold uppercase shadow-sm">
                        {cmt.userName?.charAt(0) || 'U'}
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs font-semibold text-slate-200">{cmt.userName}</span>
                          <span className="text-[10px] font-mono text-slate-500">({cmt.userId?.slice(0, 8)})</span>
                        </div>
                        <span className="text-[10px] text-slate-500">{formatDate(cmt.createdAt)}</span>
                      </div>
                    </div>

                    {isOwner && (
                      <button
                        onClick={() => handleDeleteComment(cmt.id)}
                        title="Delete comment"
                        className="opacity-0 group-hover:opacity-100 p-1 text-slate-500 hover:text-rose-400 hover:bg-slate-800 rounded transition-all"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  <p className="text-xs text-slate-300 pl-9 leading-relaxed whitespace-pre-wrap">
                    {cmt.text}
                  </p>
                </div>
              );
            })
          )}
        </div>

        {/* Input Form */}
        <form onSubmit={handlePostComment} className="p-3 bg-slate-950 border-t border-slate-800">
          <div className="flex items-center gap-2">
            <input
              type="text"
              placeholder={user ? `Comment as ${user.name}...` : 'Write a comment...'}
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              className="flex-1 px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
            />
            <button
              type="submit"
              disabled={submitting || !newComment.trim()}
              className="p-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white rounded-xl shadow-md transition-all flex items-center justify-center"
            >
              {submitting ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <Send className="w-4 h-4" />
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
