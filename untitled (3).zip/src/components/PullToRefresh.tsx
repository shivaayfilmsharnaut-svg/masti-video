import React, { useState, useEffect, useRef } from 'react';
import { RefreshCw, ArrowDown, Check } from 'lucide-react';

interface PullToRefreshProps {
  onRefresh: () => Promise<void> | void;
  children: React.ReactNode;
  disabled?: boolean;
}

export const PullToRefresh: React.FC<PullToRefreshProps> = ({
  onRefresh,
  children,
  disabled = false,
}) => {
  const [pullDistance, setPullDistance] = useState(0);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [justCompleted, setJustCompleted] = useState(false);
  
  const startYRef = useRef(0);
  const currentYRef = useRef(0);
  const isDraggingRef = useRef(false);
  const isMouseDownRef = useRef(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const THRESHOLD = 75; // Distance in px required to trigger refresh
  const MAX_PULL = 135;  // Maximum pull distance cap

  // TOUCH EVENT HANDLERS
  const handleTouchStart = (e: TouchEvent) => {
    if (disabled || isRefreshing) return;
    const scrollTop = window.scrollY || document.documentElement.scrollTop || containerRef.current?.scrollTop || 0;
    if (scrollTop <= 1) {
      startYRef.current = e.touches[0].clientY;
      currentYRef.current = e.touches[0].clientY;
      isDraggingRef.current = true;
    }
  };

  const handleTouchMove = (e: TouchEvent) => {
    if (!isDraggingRef.current || disabled || isRefreshing) return;

    const scrollTop = window.scrollY || document.documentElement.scrollTop || containerRef.current?.scrollTop || 0;
    if (scrollTop > 1) {
      isDraggingRef.current = false;
      setPullDistance(0);
      return;
    }

    currentYRef.current = e.touches[0].clientY;
    const diff = currentYRef.current - startYRef.current;

    if (diff > 0) {
      const resistance = 0.45;
      const calculatedPull = Math.min(diff * resistance, MAX_PULL);
      setPullDistance(calculatedPull);
      
      if (calculatedPull > 10 && e.cancelable) {
        e.preventDefault();
      }
    } else {
      setPullDistance(0);
    }
  };

  const handleTouchEnd = async () => {
    if (!isDraggingRef.current || disabled || isRefreshing) return;
    isDraggingRef.current = false;

    if (pullDistance >= THRESHOLD) {
      if (typeof navigator !== 'undefined' && navigator.vibrate) {
        try {
          navigator.vibrate(25);
        } catch {
          // ignore
        }
      }

      setIsRefreshing(true);
      setPullDistance(THRESHOLD * 0.75);

      try {
        await onRefresh();
        setJustCompleted(true);
        setTimeout(() => {
          setJustCompleted(false);
          setIsRefreshing(false);
          setPullDistance(0);
        }, 500);
      } catch (err) {
        console.error('Pull to refresh failed:', err);
        setIsRefreshing(false);
        setPullDistance(0);
      }
    } else {
      setPullDistance(0);
    }
  };

  // MOUSE EVENT HANDLERS (For desktop drag-to-refresh)
  const handleMouseDown = (e: React.MouseEvent) => {
    if (disabled || isRefreshing || e.button !== 0) return;
    const scrollTop = window.scrollY || document.documentElement.scrollTop || containerRef.current?.scrollTop || 0;
    if (scrollTop <= 1) {
      isMouseDownRef.current = true;
      isDraggingRef.current = true;
      startYRef.current = e.clientY;
      currentYRef.current = e.clientY;
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isMouseDownRef.current || !isDraggingRef.current || disabled || isRefreshing) return;
    const scrollTop = window.scrollY || document.documentElement.scrollTop || containerRef.current?.scrollTop || 0;
    if (scrollTop > 1) {
      isMouseDownRef.current = false;
      isDraggingRef.current = false;
      setPullDistance(0);
      return;
    }

    currentYRef.current = e.clientY;
    const diff = currentYRef.current - startYRef.current;

    if (diff > 0) {
      const resistance = 0.4;
      const calculatedPull = Math.min(diff * resistance, MAX_PULL);
      setPullDistance(calculatedPull);
    } else {
      setPullDistance(0);
    }
  };

  const handleMouseUp = () => {
    if (isMouseDownRef.current) {
      isMouseDownRef.current = false;
      handleTouchEnd();
    }
  };

  // Touch listener binding
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;

    const onTouchStart = (e: TouchEvent) => handleTouchStart(e);
    const onTouchMove = (e: TouchEvent) => handleTouchMove(e);
    const onTouchEnd = () => handleTouchEnd();

    el.addEventListener('touchstart', onTouchStart, { passive: true });
    el.addEventListener('touchmove', onTouchMove, { passive: false });
    el.addEventListener('touchend', onTouchEnd);
    el.addEventListener('touchcancel', onTouchEnd);

    return () => {
      el.removeEventListener('touchstart', onTouchStart);
      el.removeEventListener('touchmove', onTouchMove);
      el.removeEventListener('touchend', onTouchEnd);
      el.removeEventListener('touchcancel', onTouchEnd);
    };
  }, [disabled, isRefreshing, pullDistance]);

  const progress = Math.min(pullDistance / THRESHOLD, 1);
  const isReadyToRelease = pullDistance >= THRESHOLD;

  return (
    <div
      ref={containerRef}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      className="relative w-full flex-1 flex flex-col min-h-0"
    >
      {/* Pull Indicator Header */}
      <div
        style={{
          height: `${pullDistance}px`,
          opacity: pullDistance > 5 ? 1 : 0,
        }}
        className={`w-full overflow-hidden flex items-center justify-center transition-all duration-75 pointer-events-none select-none z-30 ${
          !isDraggingRef.current && 'transition-all duration-300 ease-out'
        }`}
      >
        <div className="flex items-center gap-2.5 px-4 py-2 rounded-full bg-slate-900/95 border border-slate-800 shadow-xl backdrop-blur-md text-xs">
          {justCompleted ? (
            <>
              <div className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                <Check className="w-3.5 h-3.5" />
              </div>
              <span className="text-emerald-400 font-medium">Refreshed!</span>
            </>
          ) : isRefreshing ? (
            <>
              <RefreshCw className="w-4 h-4 text-indigo-400 animate-spin" />
              <span className="text-slate-200 font-medium">Refreshing media library...</span>
            </>
          ) : (
            <>
              <div
                style={{
                  transform: `rotate(${progress * 180}deg)`,
                  transition: 'transform 0.1s ease',
                }}
                className={`w-5 h-5 rounded-full flex items-center justify-center transition-colors ${
                  isReadyToRelease ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30' : 'bg-slate-800 text-slate-400'
                }`}
              >
                <ArrowDown className="w-3.5 h-3.5" />
              </div>
              <span
                className={`font-semibold transition-colors ${
                  isReadyToRelease ? 'text-indigo-400' : 'text-slate-300'
                }`}
              >
                {isReadyToRelease ? 'Chhodiye refresh karne ke liye (Release to refresh)' : 'Niche khinchein refresh karne ke liye (Pull down)'}
              </span>
            </>
          )}
        </div>
      </div>

      {/* Main Content Area with elastic bounce */}
      <div
        style={{
          transform: `translateY(${pullDistance > 0 ? pullDistance * 0.25 : 0}px)`,
          transition: isDraggingRef.current ? 'none' : 'transform 0.3s cubic-bezier(0.2, 0.8, 0.2, 1)',
        }}
        className="w-full flex-1 flex flex-col"
      >
        {children}
      </div>
    </div>
  );
};
