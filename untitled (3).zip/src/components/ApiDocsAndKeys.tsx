import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.js';
import { useToast } from './Toast.js';
import { api, formatDate } from '../services/api.js';
import { ApiKey, MediaFile } from '../types.js';
import { 
  Key, Plus, Trash2, Copy, Check, Code2, Terminal, 
  ExternalLink, Sparkles, Server, Zap, RefreshCw, Smartphone,
  FileCode, Play, Bell, IndianRupee, Heart, MessageCircle, Share2, Users
} from 'lucide-react';

export const ApiDocsAndKeys: React.FC = () => {
  const { user } = useAuth();
  const { showToast } = useToast();
  const [keys, setKeys] = useState<ApiKey[]>([]);
  const [newKeyName, setNewKeyName] = useState('');
  const [copiedKeyId, setCopiedKeyId] = useState<string | null>(null);
  const [activeCodeTab, setActiveCodeTab] = useState<'mastivideo' | 'flutter' | 'kotlin' | 'curl' | 'js' | 'python'>('mastivideo');

  // Playground state
  const [selectedEndpoint, setSelectedEndpoint] = useState<string>('GET /api/v1/social/synced-profile');
  const [testSearchQuery, setTestSearchQuery] = useState('');
  const [testMediaId, setTestMediaId] = useState('');
  const [testUserId, setTestUserId] = useState('rajkalikumar8789@gmail.com');
  const [playgroundResponse, setPlaygroundResponse] = useState<string | null>(null);
  const [isRunningPlayground, setIsRunningPlayground] = useState(false);

  useEffect(() => {
    loadKeys();
  }, []);

  const loadKeys = async () => {
    try {
      const res = await api.getApiKeys();
      if (res.success && Array.isArray(res.data)) {
        setKeys(res.data);
      }
    } catch (err: any) {
      console.error(err);
    }
  };

  const handleCreateKey = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newKeyName.trim()) {
      showToast('error', 'Required Field', 'Please provide a name for this API key.');
      return;
    }

    try {
      const res = await api.createApiKey(newKeyName.trim());
      if (res.success && res.data) {
        setKeys(prev => [res.data, ...prev]);
        setNewKeyName('');
        showToast('success', 'API Key Created', 'Keep your new key confidential.');
      } else {
        showToast('error', 'Failed', res.error || 'Could not generate API key.');
      }
    } catch (err: any) {
      showToast('error', 'Error', err.message);
    }
  };

  const handleDeleteKey = async (id: string) => {
    try {
      const res = await api.deleteApiKey(id);
      if (res.success) {
        setKeys(prev => prev.filter(k => k.id !== id));
        showToast('success', 'Key Revoked', 'API Key has been deleted and invalidated.');
      } else {
        showToast('error', 'Error', res.error);
      }
    } catch (err: any) {
      showToast('error', 'Error', err.message);
    }
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKeyId(id);
    showToast('success', 'Copied!', 'Text copied to your clipboard.');
    setTimeout(() => setCopiedKeyId(null), 2000);
  };

  const activeApiKey = keys[0]?.key || user?.apiKey || 'mb_live_sec_prod_99f8d1c2e4';

  const runPlaygroundTest = async () => {
    setIsRunningPlayground(true);
    setPlaygroundResponse('Sending request to Masti Bash REST API...');

    try {
      let url = '/api/v1/media';
      let options: RequestInit = {
        headers: {
          'x-api-key': activeApiKey
        }
      };

      if (selectedEndpoint === 'GET /api/v1/social/synced-profile') {
        url = `/api/v1/social/user/${encodeURIComponent(testUserId || 'rajkalikumar8789@gmail.com')}/synced-profile`;
      } else if (selectedEndpoint === 'GET /api/v1/social/notifications') {
        url = `/api/v1/social/notifications/${encodeURIComponent(testUserId || 'usr_rajkali')}`;
      } else if (selectedEndpoint === 'GET /api/v1/social/monetization') {
        url = `/api/v1/social/monetization/${encodeURIComponent(testUserId || 'rajkalikumar8789@gmail.com')}`;
      } else if (selectedEndpoint === 'GET /api/v1/social/stats') {
        url = '/api/v1/social/stats';
      } else if (selectedEndpoint === 'GET /api/v1/media') {
        url = '/api/v1/media?limit=5';
      } else if (selectedEndpoint === 'GET /api/v1/media/search') {
        url = `/api/v1/media/search?q=${encodeURIComponent(testSearchQuery || 'video')}`;
      } else if (selectedEndpoint === 'GET /api/v1/media/stats/overview') {
        url = '/api/v1/media/stats/overview';
      }

      const res = await fetch(url, options);
      const data = await res.json();
      setPlaygroundResponse(JSON.stringify(data, null, 2));
    } catch (err: any) {
      setPlaygroundResponse(JSON.stringify({ error: err.message || 'Request failed' }, null, 2));
    }
    setIsRunningPlayground(false);
  };

  const [customServerUrl, setCustomServerUrl] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('mb_custom_server_url');
      if (!saved || saved.includes('replit.app') || saved.includes('rajkalifacts')) {
        localStorage.setItem('mb_custom_server_url', 'https://masti-base.lovable.app');
        return 'https://masti-base.lovable.app';
      }
      return saved;
    }
    return 'https://masti-base.lovable.app';
  });

  const handleServerUrlChange = (val: string) => {
    setCustomServerUrl(val);
    localStorage.setItem('mb_custom_server_url', val);
  };

  const defaultLocalHost = 'https://masti-base.lovable.app';
  const currentHost = (customServerUrl.includes('replit.app') || customServerUrl.includes('rajkalifacts') ? defaultLocalHost : customServerUrl.trim()) || defaultLocalHost;

  // Email Auth & Sync Tester state
  const [testEmail, setTestEmail] = useState('rajkalikumar8789@gmail.com');
  const [testName, setTestName] = useState('Rajkali Kumar');
  const [isSyncingEmail, setIsSyncingEmail] = useState(false);
  const [emailSyncResult, setEmailSyncResult] = useState<any>(null);

  const handleTestEmailSync = async () => {
    if (!testEmail || !testEmail.includes('@')) {
      showToast('error', 'Invalid Email', 'Please enter a valid email address.');
      return;
    }
    setIsSyncingEmail(true);
    try {
      const res = await api.syncUserByEmail({
        email: testEmail,
        name: testName || testEmail.split('@')[0]
      });
      setEmailSyncResult(res);
      if (res.success) {
        showToast('success', 'Email Connected & Synced', `All 360° user data, notifications & monetization synced for ${testEmail}`);
      } else {
        showToast('error', 'Sync Failed', res.error);
      }
    } catch (err: any) {
      setEmailSyncResult({ success: false, error: err.message });
      showToast('error', 'Error', err.message);
    }
    setIsSyncingEmail(false);
  };

  const codeSnippets = {
    mastivideo: `// ========================================================
// MASTI VIDEO APP -> MASTI BASH FULL 360° SYNC & INTEGRATION
// Includes: User ID, DP, Notifications, Likes, Comments, 
// Shares, Followers, Direct Chat, Monetization & UPI Payouts
// ========================================================
import axios from 'axios';

const MASTI_BASH_API_URL = '${currentHost}';
let currentUserToken = null;
let currentApiKey = '${activeApiKey}';

/**
 * 1. AUTHENTICATE / LOGIN WITH USER EMAIL (Google / Phone / Email)
 * When a user logs in on Masti Video, sync email with Masti Base:
 */
export const loginOrSyncUserWithEmail = async (email, name, avatarUrl = '') => {
  const response = await axios.post(\`\${MASTI_BASH_API_URL}/api/auth/email-sync\`, {
    email,
    name,
    avatarUrl
  });

  if (response.data.success) {
    currentUserToken = response.data.token;
    currentApiKey = response.data.user.apiKey;
    return response.data.user; // Contains id, email, name, avatarUrl, apiKey
  }
  throw new Error(response.data.error || 'Authentication failed');
};

/**
 * 2. GET FULL 360° SYNCED DATA FOR LOGGED-IN USER
 * Returns: User ID, DP, Notifications, Likes, Comments, Shares,
 * Followers, Following, Chat Threads & Monetization Wallet!
 */
export const getFullUserSyncedData = async (userEmailOrId) => {
  const response = await axios.get(\`\${MASTI_BASH_API_URL}/api/v1/social/user/\${encodeURIComponent(userEmailOrId)}/synced-profile\`, {
    headers: { 'x-api-key': currentApiKey }
  });
  return response.data.data;
};

/**
 * 3. GET UNLIMITED VIDEO REELS FEED
 * Returns: Video URL, Creator DP, Name, Likes Count, IsLiked, Followers
 */
export const getVideoFeed = async () => {
  const response = await axios.get(\`\${MASTI_BASH_API_URL}/api/videos/feed\`, {
    headers: { 'x-api-key': currentApiKey }
  });
  return response.data.data || [];
};

/**
 * 4. UPLOAD VIDEO LINKED TO USER EMAIL (Unlimited Size)
 */
export const uploadUserVideo = async (fileUri, fileName, userEmail, userName = '', title = '') => {
  const formData = new FormData();
  formData.append('files', {
    uri: fileUri,
    name: fileName,
    type: 'video/mp4'
  });
  formData.append('userEmail', userEmail); // 👈 Binds video to creator's profile
  formData.append('userName', userName);
  formData.append('title', title || fileName);
  formData.append('folder', 'mastivideo_feed');

  const response = await axios.post(\`\${MASTI_BASH_API_URL}/api/v1/media/upload\`, formData, {
    headers: {
      'x-api-key': currentApiKey,
      'Content-Type': 'multipart/form-data'
    }
  });
  return response.data;
};

/**
 * 5. SOCIAL ACTIONS (LIKE, COMMENT, SHARE, FOLLOW)
 */
export const likeVideo = async (mediaId, userId, userName) => {
  const res = await axios.post(\`\${MASTI_BASH_API_URL}/api/v1/social/like\`, { mediaId, userId, userName });
  return res.data;
};

export const commentOnVideo = async (mediaId, userId, userName, comment) => {
  const res = await axios.post(\`\${MASTI_BASH_API_URL}/api/v1/social/comment\`, { mediaId, userId, userName, comment });
  return res.data;
};

export const shareVideo = async (mediaId, platform, userId, userName) => {
  const res = await axios.post(\`\${MASTI_BASH_API_URL}/api/v1/social/share\`, { mediaId, platform, userId, userName });
  return res.data;
};

export const followCreator = async (creatorId, creatorName, myUserId, myName) => {
  const res = await axios.post(\`\${MASTI_BASH_API_URL}/api/v1/social/follow\`, {
    targetUserId: creatorId,
    targetUserName: creatorName,
    followerId: myUserId,
    followerName: myName
  });
  return res.data;
};

/**
 * 6. DIRECT 1-TO-1 CHAT MESSAGES
 */
export const sendChatMessage = async (senderId, senderName, receiverId, receiverName, message) => {
  const res = await axios.post(\`\${MASTI_BASH_API_URL}/api/v1/social/chat/send\`, {
    senderId,
    senderName,
    receiverId,
    receiverName,
    message
  });
  return res.data;
};

/**
 * 7. USER NOTIFICATIONS
 */
export const getUserNotifications = async (userId) => {
  const res = await axios.get(\`\${MASTI_BASH_API_URL}/api/v1/social/notifications/\${userId}\`);
  return res.data.data;
};

/**
 * 8. MONETIZATION EARNINGS & INSTANT UPI WITHDRAWAL (₹)
 */
export const getMonetizationData = async (userEmailOrId) => {
  const res = await axios.get(\`\${MASTI_BASH_API_URL}/api/v1/social/monetization/\${encodeURIComponent(userEmailOrId)}\`);
  return res.data.data; // { walletBalance, totalEarnings, rpm: 28.50, totalViews, payouts }
};

export const requestUpiPayout = async (userId, amount, upiId) => {
  const res = await axios.post(\`\${MASTI_BASH_API_URL}/api/v1/social/monetization/payout\`, {
    userId,
    amount,
    method: 'upi',
    accountInfo: upiId
  });
  return res.data;
};`,

    flutter: `// Flutter (Dart) 360° SDK for Masti Video App
import 'dart:convert';
import 'package:http/http.dart' as http;

class MastiVideo360 {
  static const String baseUrl = '${currentHost}';
  static const String apiKey = '${activeApiKey}';

  static Map<String, String> get headers => {
    'Content-Type': 'application/json',
    'x-api-key': apiKey,
  };

  // 1. Sync User Email
  static Future<Map<String, dynamic>?> loginSync(String email, String name, [String? avatarUrl]) async {
    final res = await http.post(
      Uri.parse('$baseUrl/api/auth/email-sync'),
      headers: headers,
      body: jsonEncode({'email': email, 'name': name, 'avatarUrl': avatarUrl ?? ''}),
    );
    return res.statusCode == 200 ? jsonDecode(res.body)['user'] : null;
  }

  // 2. Fetch 360 Synced Profile
  static Future<Map<String, dynamic>?> get360Profile(String email) async {
    final res = await http.get(
      Uri.parse('$baseUrl/api/v1/social/user/\${Uri.encodeComponent(email)}/synced-profile'),
      headers: headers,
    );
    return res.statusCode == 200 ? jsonDecode(res.body)['data'] : null;
  }

  // 3. Video Feed
  static Future<List<dynamic>> getVideoFeed() async {
    final res = await http.get(Uri.parse('$baseUrl/api/videos/feed'), headers: headers);
    return res.statusCode == 200 ? jsonDecode(res.body)['data'] : [];
  }
}`,

    kotlin: `// Android Kotlin 360° SDK for Masti Video App
package com.mastivideo.sdk

import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody

object MastiVideo360 {
    const val BASE_URL = "${currentHost}"
    const val API_KEY = "${activeApiKey}"
    private val client = OkHttpClient()

    // 1. Sync User Profile (ID, DP, Wallet)
    fun syncUser(email: String, name: String, callback: (String?) -> Unit) {
        val json = """{"email":"$email","name":"$name"}"""
        val req = Request.Builder()
            .url("$BASE_URL/api/auth/email-sync")
            .header("x-api-key", API_KEY)
            .post(json.toRequestBody("application/json".toMediaTypeOrNull()))
            .build()
        client.newCall(req).enqueue(object : Callback {
            override fun onResponse(call: Call, response: Response) {
                callback(response.body?.string())
            }
            override fun onFailure(call: Call, e: java.io.IOException) {
                callback(null)
            }
        })
    }
}`,

    curl: `# 1. User Email Login / Sync
curl -X POST "${currentHost}/api/auth/email-sync" \\
  -H "Content-Type: application/json" \\
  -d '{"email":"rajkalikumar8789@gmail.com","name":"Rajkali Kumar"}'

# 2. Get 360° Synced User Profile (ID, DP, Notifs, Likes, Followers, Wallet)
curl -X GET "${currentHost}/api/v1/social/user/rajkalikumar8789@gmail.com/synced-profile" \\
  -H "x-api-key: ${activeApiKey}"

# 3. Upload Video Linked with User Email
curl -X POST "${currentHost}/api/v1/media/upload" \\
  -H "x-api-key: ${activeApiKey}" \\
  -F "files=@/path/to/video.mp4" \\
  -F "userEmail=rajkalikumar8789@gmail.com" \\
  -F "userName=Rajkali Kumar" \\
  -F "folder=mastivideo_feed"

# 4. Get User Notifications
curl -X GET "${currentHost}/api/v1/social/notifications/usr_rajkali"

# 5. Get Monetization Wallet Balance (₹)
curl -X GET "${currentHost}/api/v1/social/monetization/rajkalikumar8789@gmail.com"

# 6. Request Instant UPI Payout
curl -X POST "${currentHost}/api/v1/social/monetization/payout" \\
  -H "Content-Type: application/json" \\
  -d '{"userId":"usr_rajkali","amount":500,"method":"upi","accountInfo":"rajkali@oksbi"}'`,

    js: `// JavaScript / TypeScript SDK for Masti Video & Masti Base
const API_URL = '${currentHost}';
const API_KEY = '${activeApiKey}';

// 1. Authenticate / Sync user email
async function loginUser(email, name) {
  const res = await fetch(\`\${API_URL}/api/auth/email-sync\`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, name })
  });
  return await res.json();
}

// 2. Fetch full 360 synced data
async function getFullSyncedData(userEmail) {
  const res = await fetch(\`\${API_URL}/api/v1/social/user/\${encodeURIComponent(userEmail)}/synced-profile\`, {
    headers: { 'x-api-key': API_KEY }
  });
  return await res.json();
}

// 3. Fetch media for specific user email
async function getUserVideos(userEmail) {
  const res = await fetch(\`\${API_URL}/api/v1/media?userEmail=\${encodeURIComponent(userEmail)}&mediaType=video\`, {
    headers: { 'x-api-key': API_KEY }
  });
  return (await res.json()).data;
}`,

    python: `# Python SDK for Masti Video -> Masti Base
import requests

API_URL = "${currentHost}"
API_KEY = "${activeApiKey}"
headers = { "x-api-key": API_KEY }

# 1. Authenticate user by email
def authenticate_user(email, name="Masti Creator"):
    res = requests.post(f"{API_URL}/api/auth/email-sync", json={"email": email, "name": name})
    return res.json()

# 2. Get 360 synced profile data
def get_synced_profile(email):
    res = requests.get(f"{API_URL}/api/v1/social/user/{email}/synced-profile", headers=headers)
    return res.json()

# 3. Upload video with user email
def upload_user_video(file_path, user_email, name="Masti Creator"):
    with open(file_path, "rb") as f:
        files = {"files": f}
        data = {
            "userEmail": user_email,
            "userName": name,
            "folder": "mastivideo_feed"
        }
        res = requests.post(f"{API_URL}/api/v1/media/upload", headers=headers, files=files, data=data)
        return res.json()`
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Header */}
      <div>
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-semibold mb-2">
          <Zap className="w-3.5 h-3.5" />
          <span>Masti Video 360° REST API Hub</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
          API Keys & Developer Integrations
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          Directly connect your mobile apps, backend servers, and the <strong>Masti Video</strong> application with full synchronization for User ID, DP, Likes, Comments, Shares, Followers, Chats, Notifications, and Monetization.
        </p>
      </div>

      {/* Server Base URL Card */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-indigo-500/40 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-indigo-600/30 text-indigo-400 border border-indigo-500/30">
              <Server className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                Active Server Base URL (Production Ready)
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-semibold">
                  LIVE READY
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Use this URL in your Masti Video app, Postman, or mobile code.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => handleServerUrlChange('https://masti-base.lovable.app')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                customServerUrl === 'https://masti-base.lovable.app'
                  ? 'bg-indigo-600 text-white border-indigo-500'
                  : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
              }`}
            >
              Masti Base (Production)
            </button>
          </div>
        </div>

        {/* URL Display & One-Click Copy */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {/* Main Base URL */}
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2">
            <div className="min-w-0">
              <span className="text-[10px] uppercase font-bold text-indigo-400 block tracking-wider">
                1. Server Base URL
              </span>
              <span className="font-mono text-xs text-slate-200 truncate block mt-0.5">
                {currentHost}
              </span>
            </div>
            <button
              type="button"
              onClick={() => handleCopy(currentHost, 'base_server_url')}
              className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shrink-0 flex items-center gap-1.5 shadow"
            >
              {copiedKeyId === 'base_server_url' ? <Check className="w-3.5 h-3.5 text-emerald-300" /> : <Copy className="w-3.5 h-3.5" />}
              <span>Copy</span>
            </button>
          </div>

          {/* 360 Synced Profile Endpoint */}
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2">
            <div className="min-w-0">
              <span className="text-[10px] uppercase font-bold text-emerald-400 block tracking-wider">
                2. 360° Synced Profile (GET)
              </span>
              <span className="font-mono text-xs text-slate-200 truncate block mt-0.5">
                {currentHost}/api/v1/social/user/:email/synced-profile
              </span>
            </div>
            <button
              type="button"
              onClick={() => handleCopy(`${currentHost}/api/v1/social/user/rajkalikumar8789@gmail.com/synced-profile`, 'synced_profile_url')}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold shrink-0 flex items-center gap-1.5 border border-slate-700"
            >
              {copiedKeyId === 'synced_profile_url' ? <Check className="w-3.5 h-3.5 text-emerald-300" /> : <Copy className="w-3.5 h-3.5" />}
              <span>Copy</span>
            </button>
          </div>
        </div>
      </div>

      {/* Interactive Email Authentication & 360 Data Sync Tester */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-indigo-500/30 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-indigo-400" />
              Masti Video Email Authentication & 360° Live Sync Tester
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Enter the email of a Masti Video user to authenticate and instantly retrieve their synced profile, notifications, chats, and monetization balance.
            </p>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-[11px] font-semibold text-slate-400 block mb-1">User Email Address</label>
              <input
                type="email"
                placeholder="rajkalikumar8789@gmail.com"
                value={testEmail}
                onChange={(e) => setTestEmail(e.target.value)}
                className="w-full px-3.5 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-100 placeholder:text-slate-500 font-mono focus:outline-none focus:border-indigo-500"
              />
            </div>
            <div>
              <label className="text-[11px] font-semibold text-slate-400 block mb-1">Creator / User Name</label>
              <input
                type="text"
                placeholder="Rajkali Kumar"
                value={testName}
                onChange={(e) => setTestName(e.target.value)}
                className="w-full px-3.5 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>
            <div className="flex items-end">
              <button
                type="button"
                onClick={handleTestEmailSync}
                disabled={isSyncingEmail}
                className="w-full px-4 py-2.5 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white text-xs font-bold rounded-xl shadow transition-all flex items-center justify-center gap-2"
              >
                {isSyncingEmail ? (
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Authenticate & Sync 360° Data</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Sync Result Display */}
          {emailSyncResult && (
            <div className="p-4 rounded-xl bg-slate-900/90 border border-indigo-500/30 text-xs space-y-3 mt-3 animate-in fade-in">
              <div className="flex items-center justify-between">
                <span className="font-bold text-emerald-400 flex items-center gap-1.5 text-xs">
                  <Check className="w-4 h-4" />
                  User Authenticated & Synced Successfully!
                </span>
                <span className="text-[10px] text-slate-400 font-mono">
                  ID: {emailSyncResult.user?.id}
                </span>
              </div>

              {/* 360 Bento Metrics Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 font-mono text-[11px]">
                <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800">
                  <span className="text-[9px] text-slate-500 block uppercase font-bold">User Email</span>
                  <span className="text-slate-200 truncate block font-semibold">{emailSyncResult.user?.email}</span>
                </div>
                <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800">
                  <span className="text-[9px] text-slate-500 block uppercase font-bold">Personal API Key</span>
                  <span className="text-indigo-300 truncate block font-semibold">{emailSyncResult.user?.apiKey}</span>
                </div>
                <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800">
                  <span className="text-[9px] text-emerald-400 block uppercase font-bold">Monetization Balance</span>
                  <span className="text-emerald-300 truncate block font-bold text-xs">
                    ₹{emailSyncResult.user?.monetization?.walletBalance?.toFixed(2) || '245.50'}
                  </span>
                </div>
                <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800">
                  <span className="text-[9px] text-cyan-400 block uppercase font-bold">Social Network</span>
                  <span className="text-cyan-300 truncate block font-semibold">
                    {emailSyncResult.user?.followersCount || 1} Followers • {emailSyncResult.user?.followingCount || 0} Following
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* API Key Management Section */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Key className="w-5 h-5 text-indigo-400" />
              Active API Keys
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Include <code className="text-indigo-300 bg-slate-950 px-1 py-0.5 rounded font-mono">x-api-key: your_key</code> in request headers.
            </p>
          </div>

          {/* New Key Form */}
          <form onSubmit={handleCreateKey} className="flex items-center gap-2">
            <input
              type="text"
              placeholder="e.g. Masti Video Mobile App"
              value={newKeyName}
              onChange={(e) => setNewKeyName(e.target.value)}
              className="px-3.5 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500 w-48 sm:w-60"
            />
            <button
              type="submit"
              className="flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl shadow-lg transition-all"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Generate Key</span>
            </button>
          </form>
        </div>

        {/* Keys List */}
        <div className="space-y-2.5">
          {user && (
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 rounded-xl bg-slate-950 border border-indigo-500/30">
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-white">Default Account Master Key</span>
                  <span className="px-2 py-0.5 rounded bg-indigo-600/30 text-indigo-300 border border-indigo-500/40 text-[10px] font-semibold">
                    Primary
                  </span>
                </div>
                <div className="font-mono text-xs text-slate-300 mt-1 truncate">
                  {user.apiKey}
                </div>
              </div>
              <button
                type="button"
                onClick={() => handleCopy(user.apiKey, 'primary_key')}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 text-xs font-semibold transition-all shrink-0 self-start sm:self-auto"
              >
                {copiedKeyId === 'primary_key' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
                <span>Copy Key</span>
              </button>
            </div>
          )}

          {keys.map(key => (
            <div
              key={key.id}
              className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 rounded-xl bg-slate-950 border border-slate-800"
            >
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-white">{key.keyName}</span>
                  <span className="text-[10px] text-slate-500 font-mono">Created {formatDate(key.createdAt)}</span>
                </div>
                <div className="font-mono text-xs text-slate-300 mt-1 truncate">
                  {key.key}
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0 self-start sm:self-auto">
                <button
                  type="button"
                  onClick={() => handleCopy(key.key, key.id)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 text-xs font-semibold transition-all"
                >
                  {copiedKeyId === key.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
                  <span>Copy</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleDeleteKey(key.id)}
                  className="p-1.5 text-slate-400 hover:text-rose-400 rounded-lg hover:bg-slate-900 transition-colors"
                  title="Revoke API Key"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Interactive Live Playground */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Play className="w-5 h-5 text-emerald-400 fill-current" />
            Live API Playground
          </h3>
          <span className="text-xs text-slate-400">Test real requests directly</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <select
            value={selectedEndpoint}
            onChange={(e) => setSelectedEndpoint(e.target.value)}
            className="px-3.5 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-indigo-500 font-mono"
          >
            <option value="GET /api/v1/social/synced-profile">GET /api/v1/social/user/:email/synced-profile (360° Data)</option>
            <option value="GET /api/v1/social/notifications">GET /api/v1/social/notifications/:userId</option>
            <option value="GET /api/v1/social/monetization">GET /api/v1/social/monetization/:email (Earnings & Wallet)</option>
            <option value="GET /api/v1/social/stats">GET /api/v1/social/stats (Social Totals)</option>
            <option value="GET /api/v1/media">GET /api/v1/media (List Media)</option>
            <option value="GET /api/v1/media/search">GET /api/v1/media/search (Search)</option>
            <option value="GET /api/v1/media/stats/overview">GET /api/v1/media/stats/overview</option>
          </select>

          {(selectedEndpoint.includes('synced-profile') || selectedEndpoint.includes('notifications') || selectedEndpoint.includes('monetization')) && (
            <input
              type="text"
              placeholder="User Email or ID (e.g. rajkalikumar8789@gmail.com)"
              value={testUserId}
              onChange={(e) => setTestUserId(e.target.value)}
              className="px-3.5 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-200 focus:outline-none"
            />
          )}

          {selectedEndpoint === 'GET /api/v1/media/search' && (
            <input
              type="text"
              placeholder="Search query (e.g. video, 4k)"
              value={testSearchQuery}
              onChange={(e) => setTestSearchQuery(e.target.value)}
              className="px-3.5 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-200 focus:outline-none"
            />
          )}

          <button
            onClick={runPlaygroundTest}
            disabled={isRunningPlayground}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl shadow-lg transition-all flex items-center justify-center gap-2"
          >
            {isRunningPlayground ? (
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Execute Request</span>
              </>
            )}
          </button>
        </div>

        {/* Live Response Box */}
        {playgroundResponse && (
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 font-mono text-xs text-emerald-400 overflow-x-auto max-h-80">
            <pre>{playgroundResponse}</pre>
          </div>
        )}
      </div>

      {/* Ready Integration Code Snippets */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Code2 className="w-5 h-5 text-cyan-400" />
            Integration Code Snippets
          </h3>

          {/* Language Selector */}
          <div className="flex p-1 bg-slate-950 rounded-xl border border-slate-800 flex-wrap gap-1">
            <button
              onClick={() => setActiveCodeTab('mastivideo')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                activeCodeTab === 'mastivideo' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Masti Video App (Full 360°)</span>
            </button>
            <button
              onClick={() => setActiveCodeTab('flutter')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                activeCodeTab === 'flutter' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <span>Flutter</span>
            </button>
            <button
              onClick={() => setActiveCodeTab('kotlin')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                activeCodeTab === 'kotlin' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <span>Kotlin</span>
            </button>
            <button
              onClick={() => setActiveCodeTab('curl')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                activeCodeTab === 'curl' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Terminal className="w-3.5 h-3.5" />
              <span>cURL</span>
            </button>
            <button
              onClick={() => setActiveCodeTab('js')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                activeCodeTab === 'js' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <FileCode className="w-3.5 h-3.5" />
              <span>JavaScript</span>
            </button>
            <button
              onClick={() => setActiveCodeTab('python')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                activeCodeTab === 'python' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Server className="w-3.5 h-3.5" />
              <span>Python</span>
            </button>
          </div>
        </div>

        <div className="relative">
          <pre className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono text-slate-200 overflow-x-auto leading-relaxed">
            {codeSnippets[activeCodeTab]}
          </pre>
          <button
            onClick={() => handleCopy(codeSnippets[activeCodeTab], 'snippet')}
            className="absolute top-3 right-3 p-2 bg-slate-800/80 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-medium border border-slate-700 transition-all flex items-center gap-1"
          >
            {copiedKeyId === 'snippet' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>Copy Code</span>
          </button>
        </div>
      </div>
    </div>
  );
};
