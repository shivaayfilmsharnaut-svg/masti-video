import React, { useState, useEffect } from 'react';
import { api } from '../services/api.js';
import { AdMobConfig } from '../types.js';
import { useToast } from './Toast.js';
import {
  DollarSign,
  Smartphone,
  Save,
  RefreshCw,
  Zap,
  CheckCircle2,
  AlertTriangle,
  Layers,
  Code2,
  Copy,
  ExternalLink,
  ShieldCheck,
  ToggleLeft,
  ToggleRight,
  PhoneCall,
  Gift,
  CloudLightning,
  ShieldAlert,
  Sliders,
  Sparkles,
  Download,
  Palette,
  Type,
  Square,
  LayoutGrid,
  Settings2,
  Camera
} from 'lucide-react';

export const AdMobManager: React.FC = () => {
  const [config, setConfig] = useState<AdMobConfig>({
    appId: 'ca-app-pub-3940256099942544~3347511713',
    bannerAdUnitId: 'ca-app-pub-3940256099942544/6300978111',
    interstitialAdUnitId: 'ca-app-pub-3940256099942544/1033173712',
    rewardedAdUnitId: 'ca-app-pub-3940256099942544/5224354917',
    nativeAdUnitId: 'ca-app-pub-3940256099942544/2247696110',
    isAdMobEnabled: true,
    isMonetizationEnabled: true,
    testMode: true,
    adFrequency: 4,
    isVideoCallingEnabled: true,
    isAudioCallingEnabled: true,
    isVirtualGiftingEnabled: false,
    isBadgesEnabled: false,
    isSubscriptionsEnabled: false,
    isStarsEnabled: false,
    isUploadAllowed: true,
    appVersion: '1.0.0',
    forceUpdate: false,
    updateUrl: 'https://play.google.com/store',
    theme: {
      primaryColor: '#6366f1',
      secondaryColor: '#db2777',
      fontFamily: 'modern',
      borderRadius: 16,
      layoutType: 'reels',
      isDarkMode: true,
      cameraEngine: 'expo'
    },
    updatedAt: new Date().toISOString()
  });

  const [activeTab, setActiveTab] = useState<'features' | 'admob' | 'update' | 'styler' | 'advanced'>('features');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const { showToast } = useToast();

  const loadConfig = async () => {
    setLoading(true);
    try {
      const res = await api.getAdMobConfig();
      if (res.success && res.data) {
        // Merge fetched config with fallback keys
        setConfig({
          ...config,
          ...res.data
        });
      }
    } catch (err) {
      console.error('Failed to load AdMob config:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadConfig();
  }, []);

  const handleSave = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setSaving(true);
    try {
      const res = await api.updateAdMobConfig(config);
      if (res.success && res.data) {
        setConfig(res.data);
        showToast(
          'success',
          'App Configuration Saved!',
          'All master settings are now live and synchronised instantly with Masti Video App.'
        );
      } else {
        showToast('error', 'Update Failed', res.error || 'Could not save configurations');
      }
    } catch (err: any) {
      showToast('error', 'Error', err.message || 'Something went wrong');
    } finally {
      setSaving(false);
    }
  };

  const copyToClipboard = (text: string, field: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    showToast('success', 'Copied!', `${field} copied to clipboard`);
    setTimeout(() => setCopiedField(null), 2000);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Banner Header */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-indigo-950/60 via-slate-900 to-purple-950/60 border border-indigo-500/30 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-indigo-500 to-pink-500 flex items-center justify-center text-white shadow-lg shadow-indigo-500/20 font-black">
              <Sliders className="w-6 h-6 stroke-[2.5]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                  Masti App Master Control Center
                </h1>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-extrabold uppercase">
                  Masti Base Config Live 🟢
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                Masti Base se pure mobile app ke features, Google AdMob Ads, aur Updates ko single click me live control karein.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={loadConfig}
              disabled={loading}
              className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-cyan-400 ${loading ? 'animate-spin' : ''}`} />
              <span>Refresh</span>
            </button>
            <button
              type="button"
              onClick={() => handleSave()}
              disabled={saving}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-pink-600 hover:from-indigo-500 hover:to-pink-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-indigo-500/20 transition-all cursor-pointer active:scale-95"
            >
              <Save className="w-3.5 h-3.5" />
              <span>{saving ? 'Saving...' : 'Save & Publish Live'}</span>
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex flex-wrap gap-2 pt-2 border-t border-slate-800">
          <button
            type="button"
            onClick={() => setActiveTab('features')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all ${
              activeTab === 'features'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/20'
                : 'bg-slate-950 hover:bg-slate-900 text-slate-400 hover:text-white'
            }`}
          >
            <PhoneCall className="w-3.5 h-3.5" />
            <span>🛡️ App Features & Calling</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('admob')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all ${
              activeTab === 'admob'
                ? 'bg-amber-600 text-white shadow-lg shadow-amber-600/20'
                : 'bg-slate-950 hover:bg-slate-900 text-slate-400 hover:text-white'
            }`}
          >
            <DollarSign className="w-3.5 h-3.5" />
            <span>💰 Google AdMob Config</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('update')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all ${
              activeTab === 'update'
                ? 'bg-pink-600 text-white shadow-lg shadow-pink-600/20'
                : 'bg-slate-950 hover:bg-slate-900 text-slate-400 hover:text-white'
            }`}
          >
            <Download className="w-3.5 h-3.5" />
            <span>📲 App Update & OTA Lock</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('styler')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all ${
              activeTab === 'styler'
                ? 'bg-gradient-to-r from-violet-600 to-indigo-600 text-white shadow-lg shadow-indigo-600/20'
                : 'bg-slate-950 hover:bg-slate-900 text-slate-400 hover:text-white'
            }`}
          >
            <Palette className="w-3.5 h-3.5" />
            <span>🎨 Visual App Styler</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('advanced')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all ${
              activeTab === 'advanced'
                ? 'bg-gradient-to-r from-slate-600 to-slate-800 text-white shadow-lg'
                : 'bg-slate-950 hover:bg-slate-900 text-slate-400 hover:text-white'
            }`}
          >
            <Settings2 className="w-3.5 h-3.5" />
            <span>⚙️ Advanced Engines</span>
          </button>
        </div>
      </div>

      {/* Main Form Content */}
      <form onSubmit={handleSave} className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Columns: Config Panels */}
        <div className="lg:col-span-2 space-y-6 p-6 rounded-3xl bg-slate-900 border border-slate-800">
          
          {/* TAB 1: App Features & Calling Controls */}
          {activeTab === 'features' && (
            <div className="space-y-5">
              <h2 className="text-base font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-3">
                <PhoneCall className="w-4 h-4 text-indigo-400" />
                <span>App Feature Control & Calling Switches</span>
              </h2>

              {/* Video Calling Switch */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-sm font-bold text-white block">Real-time Video Calling (WebRTC)</span>
                  <span className="text-xs text-slate-400">
                    Masti App ke creators ke beech video call system active ya close karein
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setConfig(prev => ({ ...prev, isVideoCallingEnabled: !prev.isVideoCallingEnabled }))}
                  className={`p-1.5 rounded-xl flex items-center gap-2 text-xs font-bold transition-all ${
                    config.isVideoCallingEnabled
                      ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40'
                      : 'bg-slate-800 text-slate-400 border border-slate-700'
                  }`}
                >
                  {config.isVideoCallingEnabled ? (
                    <>
                      <span>ACTIVE</span>
                      <ToggleRight className="w-6 h-6 text-indigo-400" />
                    </>
                  ) : (
                    <>
                      <span>INACTIVE</span>
                      <ToggleLeft className="w-6 h-6 text-slate-500" />
                    </>
                  )}
                </button>
              </div>

              {/* Audio Calling Switch */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-sm font-bold text-white block">Real-time Audio Calling</span>
                  <span className="text-xs text-slate-400">
                    Voice calling feature ko pure app me block ya allow karein
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setConfig(prev => ({ ...prev, isAudioCallingEnabled: !prev.isAudioCallingEnabled }))}
                  className={`p-1.5 rounded-xl flex items-center gap-2 text-xs font-bold transition-all ${
                    config.isAudioCallingEnabled
                      ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40'
                      : 'bg-slate-800 text-slate-400 border border-slate-700'
                  }`}
                >
                  {config.isAudioCallingEnabled ? (
                    <>
                      <span>ACTIVE</span>
                      <ToggleRight className="w-6 h-6 text-indigo-400" />
                    </>
                  ) : (
                    <>
                      <span>INACTIVE</span>
                      <ToggleLeft className="w-6 h-6 text-slate-500" />
                    </>
                  )}
                </button>
              </div>

              {/* Monetization Switch */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-sm font-bold text-white block">Creator Earnings Wallet</span>
                  <span className="text-xs text-slate-400">
                    Monetization earnings, views count bonus aur payouts list system active karein
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setConfig(prev => ({ ...prev, isMonetizationEnabled: !prev.isMonetizationEnabled }))}
                  className={`p-1.5 rounded-xl flex items-center gap-2 text-xs font-bold transition-all ${
                    config.isMonetizationEnabled
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      : 'bg-slate-800 text-slate-400 border border-slate-700'
                  }`}
                >
                  {config.isMonetizationEnabled ? (
                    <>
                      <span>ACTIVE</span>
                      <ToggleRight className="w-6 h-6 text-emerald-400" />
                    </>
                  ) : (
                    <>
                      <span>INACTIVE</span>
                      <ToggleLeft className="w-6 h-6 text-slate-500" />
                    </>
                  )}
                </button>
              </div>

              {/* Virtual Gifting / Coins Switch */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-sm font-bold text-white block">Virtual Gifting (Coins & Diamonds)</span>
                  <span className="text-xs text-slate-400">
                    Comments ya live stream par virtual gifting portal open karein (User to Creator gifting)
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setConfig(prev => ({ ...prev, isVirtualGiftingEnabled: !prev.isVirtualGiftingEnabled }))}
                  className={`p-1.5 rounded-xl flex items-center gap-2 text-xs font-bold transition-all ${
                    config.isVirtualGiftingEnabled
                      ? 'bg-pink-500/20 text-pink-300 border border-pink-500/40'
                      : 'bg-slate-800 text-slate-400 border border-slate-700'
                  }`}
                >
                  {config.isVirtualGiftingEnabled ? (
                    <>
                      <span>ACTIVE</span>
                      <ToggleRight className="w-6 h-6 text-pink-400" />
                    </>
                  ) : (
                    <>
                      <span>INACTIVE</span>
                      <ToggleLeft className="w-6 h-6 text-slate-500" />
                    </>
                  )}
                </button>
              </div>

              {/* Monetization Category: Badges */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center border border-amber-500/20">
                    <Zap className="w-5 h-5 text-amber-400" />
                  </div>
                  <div>
                    <span className="text-sm font-bold text-white block">Badges (Live Earning)</span>
                    <span className="text-xs text-slate-400">Fans can send badges to creators during live</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setConfig(prev => ({ ...prev, isBadgesEnabled: !prev.isBadgesEnabled }))}
                  className={`p-1.5 rounded-xl flex items-center gap-2 text-xs font-bold transition-all ${
                    config.isBadgesEnabled
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      : 'bg-slate-800 text-slate-400 border border-slate-700'
                  }`}
                >
                  {config.isBadgesEnabled ? <ToggleRight className="w-8 h-8 text-amber-400" /> : <ToggleLeft className="w-8 h-8 text-slate-500" />}
                </button>
              </div>

              {/* Monetization Category: Subscriptions */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-purple-500/10 flex items-center justify-center border border-purple-500/20">
                    <Layers className="w-5 h-5 text-purple-400" />
                  </div>
                  <div>
                    <span className="text-sm font-bold text-white block">Subscriptions (Monthly)</span>
                    <span className="text-xs text-slate-400">Unlock premium monthly creator content</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setConfig(prev => ({ ...prev, isSubscriptionsEnabled: !prev.isSubscriptionsEnabled }))}
                  className={`p-1.5 rounded-xl flex items-center gap-2 text-xs font-bold transition-all ${
                    config.isSubscriptionsEnabled
                      ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40'
                      : 'bg-slate-800 text-slate-400 border border-slate-700'
                  }`}
                >
                  {config.isSubscriptionsEnabled ? <ToggleRight className="w-8 h-8 text-purple-400" /> : <ToggleLeft className="w-8 h-8 text-slate-500" />}
                </button>
              </div>

              {/* Monetization Category: Stars */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-pink-500/10 flex items-center justify-center border border-pink-500/20">
                    <Sparkles className="w-5 h-5 text-pink-400" />
                  </div>
                  <div>
                    <span className="text-sm font-bold text-white block">Stars & Virtual Gifting</span>
                    <span className="text-xs text-slate-400">Direct user-to-creator digital gifting</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setConfig(prev => ({ ...prev, isStarsEnabled: !prev.isStarsEnabled }))}
                  className={`p-1.5 rounded-xl flex items-center gap-2 text-xs font-bold transition-all ${
                    config.isStarsEnabled
                      ? 'bg-pink-500/20 text-pink-300 border border-pink-500/40'
                      : 'bg-slate-800 text-slate-400 border border-slate-700'
                  }`}
                >
                  {config.isStarsEnabled ? <ToggleRight className="w-8 h-8 text-pink-400" /> : <ToggleLeft className="w-8 h-8 text-slate-500" />}
                </button>
              </div>

              {/* Monetization Category: Premium Gold */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-900/40 to-slate-950 border border-amber-500/30 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-400 to-yellow-600 flex items-center justify-center shadow-lg shadow-amber-500/20">
                    <Sparkles className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <span className="text-sm font-black text-amber-100 block">Premium Gold Membership 👑</span>
                    <span className="text-[10px] text-amber-400/80 uppercase font-bold">Exclusive Access Control</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setConfig(prev => ({ ...prev, isPremiumGoldEnabled: !prev.isPremiumGoldEnabled }))}
                  className={`p-1.5 rounded-xl flex items-center gap-2 text-xs font-bold transition-all ${
                    config.isPremiumGoldEnabled
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      : 'bg-slate-800 text-slate-400 border border-slate-700'
                  }`}
                >
                  {config.isPremiumGoldEnabled ? <ToggleRight className="w-8 h-8 text-amber-400" /> : <ToggleLeft className="w-8 h-8 text-slate-500" />}
                </button>
              </div>

              {/* Video Upload Switch */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-sm font-bold text-white block">Allow Reel / Video Uploads</span>
                  <span className="text-xs text-slate-400">
                    Creators ko naye video ya status upload karne ki permission allow karein (Turn off for server maintenance)
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setConfig(prev => ({ ...prev, isUploadAllowed: !prev.isUploadAllowed }))}
                  className={`p-1.5 rounded-xl flex items-center gap-2 text-xs font-bold transition-all ${
                    config.isUploadAllowed
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      : 'bg-slate-800 text-slate-400 border border-slate-700'
                  }`}
                >
                  {config.isUploadAllowed ? (
                    <>
                      <span>ALLOWED</span>
                      <ToggleRight className="w-6 h-6 text-emerald-400" />
                    </>
                  ) : (
                    <>
                      <span>SUSPENDED</span>
                      <ToggleLeft className="w-6 h-6 text-slate-500" />
                    </>
                  )}
                </button>
              </div>
            </div>
          )}

          {/* TAB 2: AdMob Config & Unit IDs */}
          {activeTab === 'admob' && (
            <div className="space-y-5">
              <h2 className="text-base font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-3">
                <Smartphone className="w-4 h-4 text-amber-400" />
                <span>AdMob Placement IDs & Trigger Frequencies</span>
              </h2>

              {/* Master Toggle */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-sm font-bold text-white block">Global Ads Switch</span>
                  <span className="text-xs text-slate-400">
                    Masti Video App mein ads dikhana enable ya disable karein
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setConfig(prev => ({ ...prev, isAdMobEnabled: !prev.isAdMobEnabled }))}
                  className={`p-1.5 rounded-xl flex items-center gap-2 text-xs font-bold transition-all ${
                    config.isAdMobEnabled
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      : 'bg-slate-800 text-slate-400 border border-slate-700'
                  }`}
                >
                  {config.isAdMobEnabled ? (
                    <>
                      <span>ENABLED</span>
                      <ToggleRight className="w-6 h-6 text-emerald-400" />
                    </>
                  ) : (
                    <>
                      <span>DISABLED</span>
                      <ToggleLeft className="w-6 h-6 text-slate-500" />
                    </>
                  )}
                </button>
              </div>

              {/* Test Mode Toggle */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-sm font-bold text-white block">Google AdMob Test Mode</span>
                  <span className="text-xs text-slate-400">
                    Testing ke waqt Google ke official test ads chalayein taaki account ban na ho
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setConfig(prev => ({ ...prev, testMode: !prev.testMode }))}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                    config.testMode
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                      : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                  }`}
                >
                  {config.testMode ? '🧪 TEST ADS (Safe)' : '🚀 LIVE REAL ADS'}
                </button>
              </div>

              {/* AdMob App ID */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
                  <span>Google AdMob App ID</span>
                  <span className="text-[10px] text-slate-500 font-mono">ca-app-pub-xxxxxxxx~xxxxxxxx</span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={config.appId}
                    onChange={e => setConfig({ ...config, appId: e.target.value })}
                    placeholder="ca-app-pub-3940256099942544~3347511713"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white font-mono focus:border-amber-500 focus:outline-none pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => copyToClipboard(config.appId, 'App ID')}
                    className="absolute right-2 top-2 p-1 text-slate-400 hover:text-white rounded animate-pulse"
                  >
                    {copiedField === 'App ID' ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Interstitial Ad Unit */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
                  <span>Interstitial Video Ad Unit ID (Full-screen Video Ad)</span>
                  <span className="text-[10px] text-amber-400">Sabse zyada kamai isse hoti hai ⭐</span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={config.interstitialAdUnitId}
                    onChange={e => setConfig({ ...config, interstitialAdUnitId: e.target.value })}
                    placeholder="ca-app-pub-3940256099942544/1033173712"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white font-mono focus:border-amber-500 focus:outline-none pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => copyToClipboard(config.interstitialAdUnitId, 'Interstitial ID')}
                    className="absolute right-2 top-2 p-1 text-slate-400 hover:text-white rounded"
                  >
                    {copiedField === 'Interstitial ID' ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Banner Ad Unit */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
                  <span>Banner Ad Unit ID (Bottom Strip Ad)</span>
                  <span className="text-[10px] text-slate-500 font-mono">ca-app-pub-.../6300978111</span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={config.bannerAdUnitId}
                    onChange={e => setConfig({ ...config, bannerAdUnitId: e.target.value })}
                    placeholder="ca-app-pub-3940256099942544/6300978111"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white font-mono focus:border-amber-500 focus:outline-none pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => copyToClipboard(config.bannerAdUnitId, 'Banner ID')}
                    className="absolute right-2 top-2 p-1 text-slate-400 hover:text-white rounded"
                  >
                    {copiedField === 'Banner ID' ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Rewarded Ad Unit */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
                  <span>Rewarded Video Ad Unit ID (Bonus Coins Booster)</span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={config.rewardedAdUnitId}
                    onChange={e => setConfig({ ...config, rewardedAdUnitId: e.target.value })}
                    placeholder="ca-app-pub-3940256099942544/5224354917"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white font-mono focus:border-amber-500 focus:outline-none pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => copyToClipboard(config.rewardedAdUnitId, 'Rewarded ID')}
                    className="absolute right-2 top-2 p-1 text-slate-400 hover:text-white rounded"
                  >
                    {copiedField === 'Rewarded ID' ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Ad Frequency Slider */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white">Ad Frequency (Kitni videos ke baad ad aana chahiye?)</span>
                  <span className="px-2.5 py-1 rounded-lg bg-amber-500/20 text-amber-300 font-extrabold text-xs">
                    Har {config.adFrequency} Videos par
                  </span>
                </div>
                <input
                  type="range"
                  min="2"
                  max="10"
                  step="1"
                  value={config.adFrequency}
                  onChange={e => setConfig({ ...config, adFrequency: parseInt(e.target.value, 10) })}
                  className="w-full accent-amber-500 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-500 font-medium">
                  <span>Har 2 videos (Zyada Ads)</span>
                  <span>Har 4 (Recommended)</span>
                  <span>Har 10 (Kam Ads)</span>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: App Update & OTA Control */}
          {activeTab === 'update' && (
            <div className="space-y-5">
              <h2 className="text-base font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-3">
                <Download className="w-4 h-4 text-pink-400" />
                <span>OTA Version Lock & Update Settings</span>
              </h2>

              {/* Force Update Switch */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-sm font-bold text-white block">Force Update Users (MANDATORY)</span>
                  <span className="text-xs text-slate-400">
                    Isse block karke user ko Play Store se update karne par force kiya jata hai
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setConfig(prev => ({ ...prev, forceUpdate: !prev.forceUpdate }))}
                  className={`p-1.5 rounded-xl flex items-center gap-2 text-xs font-bold transition-all ${
                    config.forceUpdate
                      ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                      : 'bg-slate-800 text-slate-400 border border-slate-700'
                  }`}
                >
                  {config.forceUpdate ? (
                    <>
                      <span>LOCKED</span>
                      <ToggleRight className="w-6 h-6 text-rose-400" />
                    </>
                  ) : (
                    <>
                      <span>UNLOCKED</span>
                      <ToggleLeft className="w-6 h-6 text-slate-500" />
                    </>
                  )}
                </button>
              </div>

              {/* App Version Code */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  Target App Version Name (e.g. 1.0.4)
                </label>
                <input
                  type="text"
                  value={config.appVersion}
                  onChange={e => setConfig({ ...config, appVersion: e.target.value })}
                  placeholder="1.0.0"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:border-pink-500 focus:outline-none"
                />
                <p className="text-[10px] text-slate-500">
                  Isse upar ke ya equal versions chalu rahenge, isse purane users lock ho jayenge.
                </p>
              </div>

              {/* Redirect Update Destination URL */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  Play Store Update URL (App Link)
                </label>
                <input
                  type="text"
                  value={config.updateUrl}
                  onChange={e => setConfig({ ...config, updateUrl: e.target.value })}
                  placeholder="https://play.google.com/store/apps/details?id=com.masti.app"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:border-pink-500 focus:outline-none"
                />
              </div>
            </div>
          )}

          {/* TAB 4: Visual App Styler */}
          {activeTab === 'styler' && (
            <div className="space-y-6 animate-in slide-in-from-bottom-2 duration-300">
              <h2 className="text-base font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-3">
                <Palette className="w-4 h-4 text-violet-400" />
                <span>Remote Design & Theme Engine</span>
              </h2>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Primary Color Picker */}
                <div className="space-y-2">
                  <label className="text-xs font-semibold text-slate-300 block">App Primary Color</label>
                  <div className="flex items-center gap-3 p-3 rounded-2xl bg-slate-950 border border-slate-800">
                    <input
                      type="color"
                      value={config.theme?.primaryColor || '#6366f1'}
                      onChange={e => setConfig({
                        ...config,
                        theme: { ...config.theme!, primaryColor: e.target.value }
                      })}
                      className="w-10 h-10 rounded-lg bg-transparent border-none cursor-pointer"
                    />
                    <div className="flex-1">
                      <input
                        type="text"
                        value={config.theme?.primaryColor}
                        onChange={e => setConfig({
                          ...config,
                          theme: { ...config.theme!, primaryColor: e.target.value }
                        })}
                        className="w-full bg-transparent text-xs text-white font-mono focus:outline-none"
                      />
                    </div>
                  </div>
                </div>

                {/* Secondary Color Picker */}
                <div className="space-y-2">
                  <label className="text-xs font-semibold text-slate-300 block">Accent / Secondary Color</label>
                  <div className="flex items-center gap-3 p-3 rounded-2xl bg-slate-950 border border-slate-800">
                    <input
                      type="color"
                      value={config.theme?.secondaryColor || '#db2777'}
                      onChange={e => setConfig({
                        ...config,
                        theme: { ...config.theme!, secondaryColor: e.target.value }
                      })}
                      className="w-10 h-10 rounded-lg bg-transparent border-none cursor-pointer"
                    />
                    <div className="flex-1">
                      <input
                        type="text"
                        value={config.theme?.secondaryColor}
                        onChange={e => setConfig({
                          ...config,
                          theme: { ...config.theme!, secondaryColor: e.target.value }
                        })}
                        className="w-full bg-transparent text-xs text-white font-mono focus:outline-none"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Font Family Selector */}
              <div className="space-y-3">
                <label className="text-xs font-bold text-slate-300 flex items-center gap-2">
                  <Type className="w-3.5 h-3.5 text-indigo-400" />
                  <span>App Typography Style</span>
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {(['modern', 'classic', 'gothic', 'bold'] as const).map((font) => (
                    <button
                      key={font}
                      type="button"
                      onClick={() => setConfig({
                        ...config,
                        theme: { ...config.theme!, fontFamily: font }
                      })}
                      className={`px-3 py-2.5 rounded-xl border text-[11px] font-bold capitalize transition-all ${
                        config.theme?.fontFamily === font
                          ? 'bg-indigo-600 border-indigo-500 text-white shadow-lg'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                      }`}
                    >
                      {font}
                    </button>
                  ))}
                </div>
              </div>

              {/* Layout Type Selector */}
              <div className="space-y-3">
                <label className="text-xs font-bold text-slate-300 flex items-center gap-2">
                  <LayoutGrid className="w-3.5 h-3.5 text-pink-400" />
                  <span>Main Feed Layout Type</span>
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {(['reels', 'grid', 'list'] as const).map((layout) => (
                    <button
                      key={layout}
                      type="button"
                      onClick={() => setConfig({
                        ...config,
                        theme: { ...config.theme!, layoutType: layout }
                      })}
                      className={`flex items-center gap-3 p-3 rounded-2xl border transition-all ${
                        config.theme?.layoutType === layout
                          ? 'bg-pink-600 border-pink-500 text-white shadow-lg shadow-pink-600/20'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                      }`}
                    >
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                        config.theme?.layoutType === layout ? 'bg-white/20' : 'bg-slate-900'
                      }`}>
                        {layout === 'reels' ? <Smartphone className="w-4 h-4" /> : 
                         layout === 'grid' ? <LayoutGrid className="w-4 h-4" /> : 
                         <Layers className="w-4 h-4" />}
                      </div>
                      <span className="text-xs font-bold capitalize">{layout} View</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Border Radius Slider */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-white flex items-center gap-2">
                    <Square className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Button & Card Roundness</span>
                  </label>
                  <span className="text-xs font-mono text-cyan-400 bg-cyan-400/10 px-2 py-0.5 rounded-lg">
                    {config.theme?.borderRadius}px
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="40"
                  step="2"
                  value={config.theme?.borderRadius}
                  onChange={e => setConfig({
                    ...config,
                    theme: { ...config.theme!, borderRadius: parseInt(e.target.value, 10) }
                  })}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-500">
                  <span>Sharp (0px)</span>
                  <span>Modern (16px)</span>
                  <span>Extra Round (40px)</span>
                </div>
              </div>

              {/* Dark Mode Toggle */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-sm font-bold text-white block">Default Dark Mode</span>
                  <span className="text-xs text-slate-400">Mobile app ko dark theme par lock karein</span>
                </div>
                <button
                  type="button"
                  onClick={() => setConfig(prev => ({ 
                    ...prev, 
                    theme: { ...prev.theme!, isDarkMode: !prev.theme?.isDarkMode } 
                  }))}
                  className={`p-1.5 rounded-xl flex items-center gap-2 text-xs font-bold transition-all ${
                    config.theme?.isDarkMode
                      ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40'
                      : 'bg-slate-800 text-slate-400 border border-slate-700'
                  }`}
                >
                  {config.theme?.isDarkMode ? (
                    <>
                      <span>DARK ON</span>
                      <ToggleRight className="w-6 h-6 text-indigo-400" />
                    </>
                  ) : (
                    <>
                      <span>LIGHT ON</span>
                      <ToggleLeft className="w-6 h-6 text-slate-500" />
                    </>
                  )}
                </button>
              </div>

              <div className="p-4 rounded-2xl bg-indigo-500/10 border border-indigo-500/20">
                <p className="text-[10px] text-indigo-300 leading-relaxed italic">
                  * Tip: Yahan badlav karke "Save" karne par aapke mobile app ka pura huliya bina kisi code ke turant live badal jayega.
                </p>
              </div>
            </div>
          )}

          {/* TAB 5: Advanced App Engines */}
          {activeTab === 'advanced' && (
            <div className="space-y-6 animate-in zoom-in-95 duration-200">
              <h2 className="text-base font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-3">
                <Settings2 className="w-4 h-4 text-slate-400" />
                <span>Advanced Mobile App Engine Switcher</span>
              </h2>

              <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex gap-3">
                <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
                <p className="text-xs text-amber-200/80 leading-relaxed">
                  <strong>Caution:</strong> Yahan badlav karne se pehle ye confirm karein ki aapne mobile app (Replit) mein naye libraries install kar li hain. Galat setting se app camera load nahi karega.
                </p>
              </div>

              {/* Camera Engine Selection */}
              <div className="space-y-4">
                <label className="text-xs font-bold text-white flex items-center gap-2">
                  <Camera className="w-4 h-4 text-indigo-400" />
                  <span>Primary Camera Engine (Recording & Live)</span>
                </label>
                
                <div className="grid grid-cols-1 gap-3">
                  {/* Expo Camera Option */}
                  <button
                    type="button"
                    onClick={() => setConfig({
                      ...config,
                      theme: { ...config.theme!, cameraEngine: 'expo' }
                    })}
                    className={`p-4 rounded-2xl border text-left transition-all ${
                      config.theme?.cameraEngine === 'expo'
                        ? 'bg-indigo-600/20 border-indigo-500 text-white shadow-lg'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-bold">Expo Camera (Default)</span>
                      {config.theme?.cameraEngine === 'expo' && <CheckCircle2 className="w-4 h-4 text-indigo-400" />}
                    </div>
                    <p className="text-[11px] opacity-70">Sahi hai standard recording aur normal usage ke liye. Expo Go mein support karta hai.</p>
                  </button>

                  {/* Vision Camera Option */}
                  <button
                    type="button"
                    onClick={() => setConfig({
                      ...config,
                      theme: { ...config.theme!, cameraEngine: 'vision' }
                    })}
                    className={`p-4 rounded-2xl border text-left transition-all ${
                      config.theme?.cameraEngine === 'vision'
                        ? 'bg-pink-600/20 border-pink-500 text-white shadow-lg'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-bold">React Native Vision Camera (Advanced)</span>
                      {config.theme?.cameraEngine === 'vision' && <CheckCircle2 className="w-4 h-4 text-pink-400" />}
                    </div>
                    <p className="text-[11px] opacity-70">Sabse fast camera engine. High FPS aur manual controls (Focus, ISO) ke liye best hai. Development Build chahiye hoga.</p>
                  </button>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800">
                <h3 className="text-xs font-bold text-white mb-2 flex items-center gap-2">
                  <Code2 className="w-3.5 h-3.5 text-cyan-400" />
                  <span>How to apply this in Mobile Code?</span>
                </h3>
                <div className="p-3 rounded-xl bg-black/50 font-mono text-[10px] text-cyan-300">
                  {"if (config.theme.cameraEngine === 'vision') {\n  // Use VisionCamera component\n} else {\n  // Use ExpoCamera component\n}"}
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Right 1 Column: Endpoint Live Preview & Docs */}
        <div className="space-y-5">
          {/* Real-time Config Sync Endpoint Preview */}
          <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Code2 className="w-4 h-4 text-cyan-400" />
              <span>Live App Sync Endpoint</span>
            </h3>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Masti Video App is secure, live REST API route se saare controls fetch karega:
            </p>
            <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-[11px] font-mono text-cyan-300 break-all">
              GET /api/videos/admob
            </div>
            <a
              href="/api/videos/admob"
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1 text-[11px] text-indigo-400 hover:text-indigo-300 font-bold"
            >
              <span>Test Live JSON Output</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>

          {/* Quick Checklist */}
          <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Masti Base Quick Guide</span>
            </h3>
            <ul className="space-y-2 text-xs text-slate-300">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                <span>Yahan toggles change karne par mobile users ko turant live updates dikhenge.</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                <span>Video calling band karne par app calls block kar dega.</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                <span>Maintenance mode par reel upload blocked ho jayegi.</span>
              </li>
            </ul>
          </div>
        </div>
      </form>
    </div>
  );
};
