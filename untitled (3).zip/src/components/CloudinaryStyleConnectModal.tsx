import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext.js';
import { useToast } from './Toast.js';
import { api } from '../services/api.js';
import {
  Cloud,
  Key,
  Copy,
  Check,
  Code2,
  Terminal,
  Smartphone,
  Server,
  Layers,
  ArrowRight,
  ArrowLeftRight,
  Shield,
  FileCode,
  Sparkles,
  ExternalLink,
  Zap,
  Globe,
  Radio,
  FolderSync,
  Heart,
  MessageSquare,
  Users,
  Play,
  Database
} from 'lucide-react';

export const CloudinaryStyleConnectModal: React.FC<{ isOpen: boolean; onClose: () => void }> = ({
  isOpen,
  onClose
}) => {
  const { user } = useAuth();
  const { showToast } = useToast();
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'sync' | 'credentials' | 'sdk'>('sync');
  const [activeSdk, setActiveSdk] = useState<'android' | 'flutter' | 'reactnative' | 'node' | 'curl'>('android');

  // Interactive 2-Way Sync Test State
  const [syncUserId, setSyncUserId] = useState('usr_masti_creator_1');
  const [syncUserName, setSyncUserName] = useState('Rahul Masti Star');
  const [syncFollowers, setSyncFollowers] = useState('12500');
  const [syncBio, setSyncBio] = useState('Masti Video official creator - Dance & Bhojpuri shorts');
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncResult, setSyncResult] = useState<any>(null);

  if (!isOpen) return null;

  const defaultHost = 'https://masti-base.lovable.app';
  const customHost = typeof window !== 'undefined' ? (localStorage.getItem('mb_custom_server_url') || defaultHost) : defaultHost;
  const currentHost = customHost;
  const apiKey = user?.apiKey || 'mb_live_1234567890abcdef';
  const cloudName = 'masti-video-cloud';

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(label);
    showToast(`${label} copied!`, 'success');
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleRunTwoWaySyncTest = async () => {
    setIsSyncing(true);
    try {
      const avatarUrl = `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(syncUserName)}`;
      const res = await api.syncUserFromApp({
        userId: syncUserId.trim(),
        userName: syncUserName.trim(),
        userAvatar: avatarUrl,
        followersCount: parseInt(syncFollowers, 10) || 0,
        followingCount: 15,
        bio: syncBio.trim()
      });

      if (res.success) {
        setSyncResult(res.data);
        showToast('Two-Way Sync Success!', 'success');
      } else {
        showToast(res.error || 'Sync failed', 'error');
      }
    } catch (err: any) {
      showToast(err?.message || 'Sync error', 'error');
    } finally {
      setIsSyncing(false);
    }
  };

  const connectionUrl = `mastibash://${cloudName}:${apiKey}@${currentHost.replace(/^https?:\/\//, '')}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/90 backdrop-blur-xl animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-4xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-indigo-600 flex items-center justify-center text-white shadow-lg">
              <ArrowLeftRight className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                Masti Video App ⇄ Masti Bash Two-Way Live Sync
              </h2>
              <p className="text-xs text-slate-400">
                Live Data Exchange: Likes, Comments, DP, Followers, Videos & Real-time Return Feed
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center border-b border-slate-800 bg-slate-950/40 px-5 gap-2 overflow-x-auto">
          <button
            onClick={() => setActiveTab('sync')}
            className={`flex items-center gap-2 px-4 py-3 text-xs font-bold border-b-2 transition-all ${
              activeTab === 'sync'
                ? 'border-indigo-500 text-indigo-400 bg-indigo-500/5'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <FolderSync className="w-4 h-4 text-indigo-400" />
            <span>Two-Way Live Bridge & Test</span>
          </button>
          <button
            onClick={() => setActiveTab('credentials')}
            className={`flex items-center gap-2 px-4 py-3 text-xs font-bold border-b-2 transition-all ${
              activeTab === 'credentials'
                ? 'border-indigo-500 text-indigo-400 bg-indigo-500/5'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Key className="w-4 h-4 text-amber-400" />
            <span>Cloud Credentials & Endpoints</span>
          </button>
          <button
            onClick={() => setActiveTab('sdk')}
            className={`flex items-center gap-2 px-4 py-3 text-xs font-bold border-b-2 transition-all ${
              activeTab === 'sdk'
                ? 'border-indigo-500 text-indigo-400 bg-indigo-500/5'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Code2 className="w-4 h-4 text-pink-400" />
            <span>App Code & SDK (Android / Flutter / RN)</span>
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6">
          
          {/* TAB 1: TWO-WAY LIVE BRIDGE & TEST */}
          {activeTab === 'sync' && (
            <div className="space-y-6">
              {/* Architecture Explanation Banner */}
              <div className="p-4.5 rounded-2xl bg-gradient-to-r from-indigo-950/60 via-slate-900 to-pink-950/40 border border-indigo-500/30 space-y-3">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-indigo-300">
                    <Sparkles className="w-4 h-4 text-pink-400" />
                    <span>Two-Way Real-time Data Pipeline (2-Way Live Sync)</span>
                  </div>
                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[10px] font-mono flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /> Live Active
                  </span>
                </div>

                {/* 3 Step Visual Pipeline */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2">
                  <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 space-y-1.5">
                    <div className="flex items-center gap-2 text-xs font-bold text-amber-400">
                      <Smartphone className="w-4 h-4" />
                      <span>1. Masti Video App</span>
                    </div>
                    <p className="text-[11px] text-slate-300">
                      User ID, Name, Profile DP, Likes, Comments, Shares, and Video files are sent to Masti Bash Cloud.
                    </p>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 space-y-1.5">
                    <div className="flex items-center gap-2 text-xs font-bold text-indigo-400">
                      <Database className="w-4 h-4" />
                      <span>2. Masti Bash Cloud</span>
                    </div>
                    <p className="text-[11px] text-slate-300">
                      Permanently saved in <code className="text-indigo-300">mastibash_db.json</code> & storage. Indexed with real User IDs and video timestamps.
                    </p>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 space-y-1.5">
                    <div className="flex items-center gap-2 text-xs font-bold text-emerald-400">
                      <Zap className="w-4 h-4" />
                      <span>3. Return Data to App</span>
                    </div>
                    <p className="text-[11px] text-slate-300">
                      Masti Bash returns the live video feed, direct HLS / MP4 stream URLs, updated like counts & follower network back to Masti Video App.
                    </p>
                  </div>
                </div>
              </div>

              {/* Interactive 2-Way Sync Simulator */}
              <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2">
                    <ArrowLeftRight className="w-4 h-4 text-cyan-400" />
                    <span>Live 2-Way Sync Simulator (Test Masti Video App Data ⇄ Masti Bash)</span>
                  </h3>
                  <span className="text-[10px] text-slate-500 font-mono">POST /api/v1/social/user/sync</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                  <div>
                    <label className="text-[11px] font-semibold text-slate-400 block mb-1">User ID</label>
                    <input
                      type="text"
                      value={syncUserId}
                      onChange={(e) => setSyncUserId(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 text-xs text-white rounded-xl px-3 py-2 focus:outline-none focus:border-indigo-500 font-mono"
                      placeholder="e.g. usr_masti_123"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-semibold text-slate-400 block mb-1">User Name</label>
                    <input
                      type="text"
                      value={syncUserName}
                      onChange={(e) => setSyncUserName(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 text-xs text-white rounded-xl px-3 py-2 focus:outline-none focus:border-indigo-500"
                      placeholder="e.g. Anjali Dance Queen"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-semibold text-slate-400 block mb-1">Followers Count</label>
                    <input
                      type="number"
                      value={syncFollowers}
                      onChange={(e) => setSyncFollowers(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 text-xs text-white rounded-xl px-3 py-2 focus:outline-none focus:border-indigo-500"
                      placeholder="e.g. 5000"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-semibold text-slate-400 block mb-1">Bio / Status</label>
                    <input
                      type="text"
                      value={syncBio}
                      onChange={(e) => setSyncBio(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 text-xs text-white rounded-xl px-3 py-2 focus:outline-none focus:border-indigo-500"
                      placeholder="e.g. Official Dance Shorts"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <p className="text-[11px] text-slate-400">
                    Click to send this user data into Masti Bash DB and see the real return data payload.
                  </p>
                  <button
                    onClick={handleRunTwoWaySyncTest}
                    disabled={isSyncing}
                    className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-pink-600 hover:from-indigo-500 hover:to-pink-500 text-white text-xs font-bold flex items-center gap-2 shadow-lg transition-all disabled:opacity-50"
                  >
                    {isSyncing ? (
                      <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <ArrowLeftRight className="w-3.5 h-3.5" />
                    )}
                    <span>{isSyncing ? 'Syncing Live...' : 'Test 2-Way Sync Now'}</span>
                  </button>
                </div>

                {/* Returned Live Data Display */}
                {syncResult && (
                  <div className="mt-4 p-4 rounded-xl bg-slate-900/90 border border-emerald-500/40 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
                        <Check className="w-4 h-4" /> Live Return Data from Masti Bash Cloud:
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        Synced At: {new Date(syncResult.syncedAt).toLocaleTimeString()}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 pb-2">
                      <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800">
                        <span className="text-[9px] uppercase text-slate-500 font-mono">Synced Name</span>
                        <p className="text-xs font-bold text-white mt-0.5 truncate">{syncResult.user?.name}</p>
                      </div>
                      <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800">
                        <span className="text-[9px] uppercase text-slate-500 font-mono">Synced User ID</span>
                        <p className="text-xs font-bold text-indigo-400 mt-0.5 truncate">{syncResult.user?.id}</p>
                      </div>
                      <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800">
                        <span className="text-[9px] uppercase text-slate-500 font-mono">Total Followers</span>
                        <p className="text-xs font-bold text-white mt-0.5">{syncResult.user?.followersCount?.toLocaleString()}</p>
                      </div>
                      <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800">
                        <span className="text-[9px] uppercase text-slate-500 font-mono">API Auth Key</span>
                        <p className="text-xs font-bold text-amber-400 mt-0.5 truncate">{syncResult.user?.apiKey || apiKey}</p>
                      </div>
                    </div>

                    <pre className="p-3 rounded-lg bg-black text-[10px] font-mono text-emerald-300 max-h-48 overflow-y-auto leading-relaxed border border-slate-800">
                      {JSON.stringify(syncResult, null, 2)}
                    </pre>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: CREDENTIALS & ENDPOINTS */}
          {activeTab === 'credentials' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-indigo-400 mb-3 flex items-center gap-1.5">
                  <Key className="w-4 h-4" /> Cloud Credentials & Environment Config
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {/* Cloud Name */}
                  <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                    <span className="text-[11px] text-slate-400">Cloud Name / App ID</span>
                    <div className="flex items-center justify-between font-mono text-xs text-white">
                      <span>{cloudName}</span>
                      <button
                        onClick={() => handleCopy(cloudName, 'Cloud Name')}
                        className="text-slate-400 hover:text-white p-1"
                      >
                        {copiedKey === 'Cloud Name' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>

                  {/* API Key */}
                  <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                    <span className="text-[11px] text-slate-400">API Key</span>
                    <div className="flex items-center justify-between font-mono text-xs text-white">
                      <span className="truncate mr-2">{apiKey}</span>
                      <button
                        onClick={() => handleCopy(apiKey, 'API Key')}
                        className="text-slate-400 hover:text-white p-1"
                      >
                        {copiedKey === 'API Key' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>

                  {/* API Base URL */}
                  <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                    <span className="text-[11px] text-slate-400">API Base URL</span>
                    <div className="flex items-center justify-between font-mono text-xs text-white">
                      <span className="truncate mr-2">{currentHost}</span>
                      <button
                        onClick={() => handleCopy(currentHost, 'Base URL')}
                        className="text-slate-400 hover:text-white p-1"
                      >
                        {copiedKey === 'Base URL' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Cloudinary-style Connection String */}
                <div className="mt-3 p-3.5 rounded-xl bg-slate-950 border border-indigo-500/30 flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <div className="text-[11px] font-semibold text-indigo-400">MASTI_BASH_URL (One-line Connection String)</div>
                    <div className="font-mono text-xs text-slate-300 truncate mt-0.5">{connectionUrl}</div>
                  </div>
                  <button
                    onClick={() => handleCopy(connectionUrl, 'Connection String')}
                    className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold shrink-0 flex items-center gap-1"
                  >
                    {copiedKey === 'Connection String' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>Copy URL</span>
                  </button>
                </div>
              </div>

              {/* Endpoints List */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
                <h4 className="text-xs font-bold uppercase text-slate-300">Live REST & Two-Way Sync Endpoints</h4>
                <div className="space-y-2 text-xs font-mono">
                  <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                    <span className="text-emerald-400 font-bold">POST /api/v1/social/user/sync</span>
                    <span className="text-slate-400 text-[11px]">Syncs User profile & returns complete state</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                    <span className="text-indigo-400 font-bold">POST /api/v1/media/upload</span>
                    <span className="text-slate-400 text-[11px]">Uploads video file with userId, title & DP</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                    <span className="text-pink-400 font-bold">POST /api/v1/social/like</span>
                    <span className="text-slate-400 text-[11px]">Likes/unlikes video and saves user ID</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                    <span className="text-amber-400 font-bold">POST /api/v1/social/comment</span>
                    <span className="text-slate-400 text-[11px]">Posts comment with commenter DP & text</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                    <span className="text-cyan-400 font-bold">GET /api/v1/media?mediaType=video</span>
                    <span className="text-slate-400 text-[11px]">Returns complete video feed with HLS URLs</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: APP CODE & SDK */}
          {activeTab === 'sdk' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold uppercase tracking-wider text-indigo-400 flex items-center gap-1.5">
                  <Code2 className="w-4 h-4" /> Masti Video App Integration SDK Code
                </h3>
                
                {/* SDK Tabs */}
                <div className="flex p-1 bg-slate-950 rounded-xl border border-slate-800 text-xs">
                  {(['android', 'flutter', 'reactnative', 'node', 'curl'] as const).map(tab => (
                    <button
                      key={tab}
                      onClick={() => setActiveSdk(tab)}
                      className={`px-2.5 py-1 rounded-lg capitalize font-medium transition-colors ${
                        activeSdk === tab ? 'bg-indigo-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {tab === 'reactnative' ? 'React Native' : tab}
                    </button>
                  ))}
                </div>
              </div>

              {/* Code Display */}
              <div className="relative">
                <pre className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono text-slate-200 overflow-x-auto leading-relaxed max-h-80">
                  {activeSdk === 'android' && `// === Android Retrofit / Java / Kotlin ===

// 1. Sync User Profile from Masti Video App
JSONObject userPayload = new JSONObject();
userPayload.put("userId", "usr_masti_123");
userPayload.put("userName", "Rahul Verma");
userPayload.put("userAvatar", "https://api.dicebear.com/7.x/bottts/svg?seed=Rahul");
userPayload.put("followersCount", 12500);

RequestBody syncBody = RequestBody.create(
    userPayload.toString(), 
    MediaType.parse("application/json")
);

Request syncRequest = new Request.Builder()
    .url("${currentHost}/api/v1/social/user/sync")
    .addHeader("x-api-key", "${apiKey}")
    .post(syncBody)
    .build();

// 2. Play Video Feed with HLS in ExoPlayer
String streamUrl = "${currentHost}/uploads/sample_video_1.mp4";
MediaItem mediaItem = MediaItem.fromUri(streamUrl);
exoPlayer.setMediaItem(mediaItem);
exoPlayer.prepare();
exoPlayer.play();`}

                  {activeSdk === 'flutter' && `// === Flutter Dart (Masti Video App) ===
import 'package:http/http.dart' as http;
import 'dart:convert';

// 1. Sync User Data
Future<Map<String, dynamic>> syncMastiUser(String userId, String name, int followers) async {
  final res = await http.post(
    Uri.parse('${currentHost}/api/v1/social/user/sync'),
    headers: {'Content-Type': 'application/json', 'x-api-key': '${apiKey}'},
    body: jsonEncode({
      'userId': userId,
      'userName': name,
      'followersCount': followers
    }),
  );
  return jsonDecode(res.body);
}

// 2. Fetch Video Feed
Future<List<dynamic>> fetchMastiVideos() async {
  final res = await http.get(
    Uri.parse('${currentHost}/api/v1/media?mediaType=video'),
    headers: {'x-api-key': '${apiKey}'},
  );
  return jsonDecode(res.body)['data'];
}`}

                  {activeSdk === 'reactnative' && `// === React Native / Expo (Masti Video App) ===
import axios from 'axios';

const MASTI_CONFIG = {
  baseUrl: '${currentHost}',
  apiKey: '${apiKey}'
};

// 1. Two-Way Sync User Profile
export const syncUserProfile = async (userId, userName, followersCount) => {
  const res = await axios.post(\`\${MASTI_CONFIG.baseUrl}/api/v1/social/user/sync\`, {
    userId,
    userName,
    followersCount
  }, {
    headers: { 'x-api-key': MASTI_CONFIG.apiKey }
  });
  return res.data; // Returns synced profile + uploaded videos
};

// 2. Upload video with User metadata
export const uploadMastiVideo = async (uri, title, userId, userName) => {
  const formData = new FormData();
  formData.append('file', { uri, name: 'masti_video.mp4', type: 'video/mp4' });
  formData.append('title', title);
  formData.append('userId', userId);
  formData.append('userName', userName);

  const res = await axios.post(\`\${MASTI_CONFIG.baseUrl}/api/v1/media/upload\`, formData, {
    headers: { 'x-api-key': MASTI_CONFIG.apiKey }
  });
  return res.data;
};`}

                  {activeSdk === 'node' && `// === Node.js Backend / Cloud Function ===
const MASTI_HOST = '${currentHost}';
const MASTI_KEY = '${apiKey}';

// Sync User
const syncRes = await fetch(\`\${MASTI_HOST}/api/v1/social/user/sync\`, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json', 'x-api-key': MASTI_KEY },
  body: JSON.stringify({
    userId: 'usr_masti_star',
    userName: 'DJ Masti',
    followersCount: 50000
  })
});
const syncData = await syncRes.json();
console.log('Returned Data from Masti Bash:', syncData);`}

                  {activeSdk === 'curl' && `# === cURL Two-Way Sync Request ===
curl -X POST "${currentHost}/api/v1/social/user/sync" \\
  -H "Content-Type: application/json" \\
  -H "x-api-key: ${apiKey}" \\
  -d '{
    "userId": "usr_masti_curl",
    "userName": "Live Creator",
    "followersCount": 9800
  }'`}
                </pre>

                <button
                  onClick={() => handleCopy(
                    activeSdk === 'android' ? `${currentHost}/uploads/sample_video_1.mp4` : currentHost,
                    'SDK Snippet'
                  )}
                  className="absolute top-3 right-3 p-1.5 bg-slate-800/90 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold border border-slate-700 transition-all flex items-center gap-1"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/60 flex items-center justify-between flex-wrap gap-2">
          <span className="text-xs text-slate-400 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>Masti Bash provides instant HTTP 206 CDN Video Streaming, auto thumbnails & 2-Way Sync.</span>
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold shadow-md"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};

