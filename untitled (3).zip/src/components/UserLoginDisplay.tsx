import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { 
  User as UserIcon, 
  Mail, 
  Key, 
  ShieldCheck, 
  Smartphone, 
  Globe, 
  Copy, 
  Check, 
  LogOut, 
  LogIn, 
  Sparkles, 
  Database, 
  Flame, 
  Layers, 
  ArrowRight,
  Code,
  DollarSign,
  Heart,
  MessageCircle,
  Video,
  Share2,
  Bookmark,
  Bell
} from 'lucide-react';

export const UserLoginDisplay: React.FC = () => {
  const { user, token, isAuthenticated, loginWithFirebase, loginWithGoogle, logout } = useAuth();
  
  const [activeTab, setActiveTab] = useState<'profile' | 'mapping' | 'mobile_code' | 'api_test'>('profile');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  
  // Custom Login State
  const [customEmail, setCustomEmail] = useState('');
  const [customName, setCustomName] = useState('');
  const [customUid, setCustomUid] = useState('');
  const [firebaseTokenInput, setFirebaseTokenInput] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(label);
    setTimeout(() => setCopiedKey(null), 2500);
  };

  const handleCustomFirebaseLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setStatusMessage(null);

    const tokenOrUid = firebaseTokenInput.trim() || customUid.trim() || `fb_${Date.now()}`;
    const email = customEmail.trim() || undefined;
    const name = customName.trim() || undefined;

    const res = await loginWithFirebase(tokenOrUid, email, name);
    setIsSubmitting(false);

    if (res.success) {
      setStatusMessage({ type: 'success', text: 'Successfully logged in & mapped to MastiBase!' });
    } else {
      setStatusMessage({ type: 'error', text: res.error || 'Login failed' });
    }
  };

  const handleQuickDemoLogin = async (demoEmail: string, demoName: string) => {
    setIsSubmitting(true);
    setStatusMessage(null);
    const res = await loginWithGoogle(demoEmail, demoName);
    setIsSubmitting(false);
    if (res.success) {
      setStatusMessage({ type: 'success', text: `Switched to ${demoName} (${demoEmail})` });
    } else {
      setStatusMessage({ type: 'error', text: res.error || 'Quick login failed' });
    }
  };

  return (
    <div id="user-login-display-container" className="w-full max-w-6xl mx-auto p-4 md:p-6 space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-amber-500/10 via-orange-500/10 to-purple-500/10 border border-amber-500/20 rounded-2xl p-6 relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-600 dark:text-amber-400 text-xs font-semibold mb-2">
              <Flame className="w-3.5 h-3.5" />
              <span>Firebase Auth + MastiBase Single Source of Truth</span>
            </div>
            <h1 className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white tracking-tight">
              User Gmail ID & Authentication Manager
            </h1>
            <p className="text-sm md:text-base text-gray-600 dark:text-gray-300 mt-1 max-w-2xl">
              Manage user Gmail accounts, Firebase authentication tokens, and inspect where the Gmail ID and MastiBase permanent identities appear across the entire application.
            </p>
          </div>

          <div className="flex items-center gap-2">
            {isAuthenticated ? (
              <button
                id="btn-user-logout"
                onClick={logout}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-red-600 dark:text-red-400 font-medium text-sm transition-all border border-red-500/30"
              >
                <LogOut className="w-4 h-4" />
                <span>Logout Session</span>
              </button>
            ) : (
              <div className="flex items-center gap-2 text-xs font-medium text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/50 px-3 py-1.5 rounded-lg border border-amber-200 dark:border-amber-800">
                <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse"></span>
                <span>Not Logged In</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-gray-200 dark:border-gray-800 pb-2">
        <button
          id="tab-btn-profile"
          onClick={() => setActiveTab('profile')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
            activeTab === 'profile'
              ? 'bg-amber-500 text-white shadow-sm'
              : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800'
          }`}
        >
          <Mail className="w-4 h-4" />
          <span>User Gmail ID & Profile</span>
        </button>

        <button
          id="tab-btn-mapping"
          onClick={() => setActiveTab('mapping')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
            activeTab === 'mapping'
              ? 'bg-amber-500 text-white shadow-sm'
              : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Where Gmail ID is Displayed</span>
        </button>

        <button
          id="tab-btn-mobile-code"
          onClick={() => setActiveTab('mobile_code')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
            activeTab === 'mobile_code'
              ? 'bg-amber-500 text-white shadow-sm'
              : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800'
          }`}
        >
          <Code className="w-4 h-4" />
          <span>Mobile App Integration Code</span>
        </button>

        <button
          id="tab-btn-api-test"
          onClick={() => setActiveTab('api_test')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
            activeTab === 'api_test'
              ? 'bg-amber-500 text-white shadow-sm'
              : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800'
          }`}
        >
          <Database className="w-4 h-4" />
          <span>Live API Test & Tokens</span>
        </button>
      </div>

      {statusMessage && (
        <div
          id="auth-status-alert"
          className={`p-4 rounded-xl text-sm font-medium flex items-center justify-between ${
            statusMessage.type === 'success'
              ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800'
              : 'bg-red-50 dark:bg-red-950/40 text-red-700 dark:text-red-300 border border-red-200 dark:border-red-800'
          }`}
        >
          <span>{statusMessage.text}</span>
          <button onClick={() => setStatusMessage(null)} className="text-xs underline opacity-70 hover:opacity-100">
            Dismiss
          </button>
        </div>
      )}

      {/* Tab 1: Profile & Active User Details */}
      {activeTab === 'profile' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main User Card */}
          <div className="lg:col-span-2 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-6 shadow-sm space-y-6">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-4">
                <div className="relative">
                  <img
                    src={user?.avatarUrl || `https://api.dicebear.com/7.x/bottts/svg?seed=${user?.email || 'Masti'}`}
                    alt="User Avatar"
                    className="w-16 h-16 rounded-2xl object-cover border-2 border-amber-500/30 bg-amber-50 dark:bg-gray-800"
                  />
                  {user?.isVerified && (
                    <div className="absolute -bottom-1 -right-1 bg-blue-500 text-white rounded-full p-1 shadow">
                      <ShieldCheck className="w-3.5 h-3.5" />
                    </div>
                  )}
                </div>

                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-xl font-bold text-gray-900 dark:text-white">
                      {user?.name || 'Guest User'}
                    </h2>
                    {user?.role === 'admin' && (
                      <span className="px-2 py-0.5 text-xs font-semibold rounded bg-purple-100 dark:bg-purple-900/50 text-purple-700 dark:text-purple-300">
                        Admin
                      </span>
                    )}
                  </div>

                  {/* PROMINENT GMAIL ID DISPLAY */}
                  <div className="flex items-center gap-2 mt-1">
                    <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-400 border border-red-200 dark:border-red-800/50 text-xs font-semibold">
                      <Mail className="w-3.5 h-3.5" />
                      <span>{user?.email || 'No Gmail ID connected'}</span>
                    </div>

                    {user?.email && (
                      <button
                        onClick={() => copyToClipboard(user.email, 'email')}
                        className="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 transition-all"
                        title="Copy Gmail ID"
                      >
                        {copiedKey === 'email' ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    )}
                  </div>
                </div>
              </div>

              <div className="text-right">
                <span className="text-xs text-gray-400 block">Username</span>
                <span className="text-sm font-semibold text-gray-700 dark:text-gray-300">
                  @{user?.username || (user?.email ? user.email.split('@')[0] : 'guest')}
                </span>
              </div>
            </div>

            {/* Two Identity Architecture Breakdown */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-gray-50 dark:bg-gray-800/60 p-4 rounded-xl border border-gray-200/80 dark:border-gray-700/80">
              <div className="space-y-1">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-orange-600 dark:text-orange-400">
                  <Flame className="w-4 h-4" />
                  <span>Firebase UID (Auth Only)</span>
                </div>
                <div className="flex items-center justify-between font-mono text-xs bg-white dark:bg-gray-900 px-3 py-2 rounded-lg border border-gray-200 dark:border-gray-700">
                  <span className="truncate max-w-[180px]">{user?.firebaseUid || 'Unlinked (Local Auth)'}</span>
                  {user?.firebaseUid && (
                    <button onClick={() => copyToClipboard(user.firebaseUid!, 'uid')} className="text-gray-400 hover:text-gray-600">
                      {copiedKey === 'uid' ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                    </button>
                  )}
                </div>
              </div>

              <div className="space-y-1">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-amber-600 dark:text-amber-400">
                  <Database className="w-4 h-4" />
                  <span>MastiBase Permanent userId</span>
                </div>
                <div className="flex items-center justify-between font-mono text-xs bg-white dark:bg-gray-900 px-3 py-2 rounded-lg border border-gray-200 dark:border-gray-700">
                  <span className="truncate max-w-[180px] text-amber-600 dark:text-amber-400 font-bold">{user?.id || 'Not Assigned'}</span>
                  {user?.id && (
                    <button onClick={() => copyToClipboard(user.id, 'mastibase_id')} className="text-gray-400 hover:text-gray-600">
                      {copiedKey === 'mastibase_id' ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* Real-Time Live Stats directly from MastiBase Single Source of Truth */}
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-3">
                Live Data on MastiBase
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-gray-50 dark:bg-gray-800/40 p-3 rounded-xl border border-gray-200/60 dark:border-gray-800 text-center">
                  <span className="text-xl font-bold text-gray-900 dark:text-white block">
                    {user?.followersCount || 0}
                  </span>
                  <span className="text-xs text-gray-500 flex items-center justify-center gap-1 mt-1">
                    <UserIcon className="w-3 h-3" /> Followers
                  </span>
                </div>

                <div className="bg-gray-50 dark:bg-gray-800/40 p-3 rounded-xl border border-gray-200/60 dark:border-gray-800 text-center">
                  <span className="text-xl font-bold text-gray-900 dark:text-white block">
                    {user?.followingCount || 0}
                  </span>
                  <span className="text-xs text-gray-500 flex items-center justify-center gap-1 mt-1">
                    <UserIcon className="w-3 h-3" /> Following
                  </span>
                </div>

                <div className="bg-gray-50 dark:bg-gray-800/40 p-3 rounded-xl border border-gray-200/60 dark:border-gray-800 text-center">
                  <span className="text-xl font-bold text-pink-600 dark:text-pink-400 block">
                    {user?.totalLikes || 0}
                  </span>
                  <span className="text-xs text-gray-500 flex items-center justify-center gap-1 mt-1">
                    <Heart className="w-3 h-3" /> Total Likes
                  </span>
                </div>

                <div className="bg-gray-50 dark:bg-gray-800/40 p-3 rounded-xl border border-gray-200/60 dark:border-gray-800 text-center">
                  <span className="text-xl font-bold text-amber-600 dark:text-amber-400 block">
                    {user?.totalVideos || 0}
                  </span>
                  <span className="text-xs text-gray-500 flex items-center justify-center gap-1 mt-1">
                    <Video className="w-3 h-3" /> Videos
                  </span>
                </div>
              </div>
            </div>

            {/* Bio & Contact */}
            <div className="space-y-2 pt-2 border-t border-gray-100 dark:border-gray-800 text-sm">
              <div className="flex items-center justify-between text-gray-600 dark:text-gray-400">
                <span className="font-medium text-gray-800 dark:text-gray-200">Bio:</span>
                <span>{(user as any)?.bio || 'Masti Video Creator'}</span>
              </div>
              {user?.phoneNumber && (
                <div className="flex items-center justify-between text-gray-600 dark:text-gray-400">
                  <span className="font-medium text-gray-800 dark:text-gray-200">Phone Number:</span>
                  <span className="font-mono">{user.phoneNumber}</span>
                </div>
              )}
              {user?.apiKey && (
                <div className="flex items-center justify-between text-gray-600 dark:text-gray-400">
                  <span className="font-medium text-gray-800 dark:text-gray-200">MastiBase API Key:</span>
                  <div className="flex items-center gap-1 font-mono text-xs bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded">
                    <span>{user.apiKey.slice(0, 14)}...</span>
                    <button onClick={() => copyToClipboard(user.apiKey!, 'apikey')}>
                      {copiedKey === 'apikey' ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Quick Login & Switch Form */}
          <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-6 shadow-sm space-y-5">
            <div>
              <h3 className="text-lg font-bold text-gray-900 dark:text-white flex items-center gap-2">
                <LogIn className="w-5 h-5 text-amber-500" />
                <span>Login or Sync with Gmail</span>
              </h3>
              <p className="text-xs text-gray-500 mt-1">
                Authenticate with any Gmail address or Firebase UID. MastiBase will automatically link or create your permanent user record.
              </p>
            </div>

            {/* Quick Demo Accounts */}
            <div>
              <div className="mb-3 p-3 bg-amber-500/10 border border-amber-500/30 rounded-2xl flex flex-col gap-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-amber-600 dark:text-amber-400 uppercase tracking-wider block">
                    👑 Admin Account Login
                  </span>
                  <span className="px-1.5 py-0.5 rounded text-[9px] font-extrabold uppercase bg-amber-500 text-slate-950">
                    OWNER
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => handleQuickDemoLogin('rajkalikumar8789@gmail.com', 'Raj Kali Kumar')}
                  disabled={isSubmitting}
                  className="w-full flex items-center justify-between px-3.5 py-3 rounded-xl text-left bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white font-extrabold transition-all text-xs cursor-pointer shadow-lg shadow-amber-500/10"
                >
                  <div>
                    <div className="font-extrabold">Raj Kali Kumar (Admin)</div>
                    <div className="text-[10px] font-mono text-amber-100 opacity-90">rajkalikumar8789@gmail.com</div>
                  </div>
                  <div className="flex items-center gap-1 bg-amber-700/40 px-2 py-1 rounded-lg text-[10px]">
                    <span>Login</span>
                    <ArrowRight className="w-3 h-3" />
                  </div>
                </button>
                <p className="text-[10px] text-amber-700 dark:text-amber-300 leading-tight">
                  Click on this button to instantly log in as the official Admin of Masti Video App and unlock the <strong>Withdrawal Request</strong> console and <strong>Admin Console</strong>.
                </p>
              </div>

              <label className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider block mb-2">
                Quick Select Creator
              </label>
              <div className="space-y-1.5">
                {[
                  { name: 'DJ Rahul Star', email: 'rahul.dj@masti.in' },
                  { name: 'Priya Sharma (Dance)', email: 'priya.dance@masti.in' },
                  { name: 'Kabir Tech Vlogs', email: 'kabir.vlogs@masti.in' },
                  { name: 'Amit Comedy Show', email: 'amit.comedy@masti.in' }
                ].map((demo) => (
                  <button
                    key={demo.email}
                    onClick={() => handleQuickDemoLogin(demo.email, demo.name)}
                    disabled={isSubmitting}
                    className="w-full flex items-center justify-between px-3 py-2 rounded-xl text-left bg-gray-50 hover:bg-amber-50/80 dark:bg-gray-800/40 dark:hover:bg-amber-950/30 border border-gray-200 dark:border-gray-700/60 transition-all text-xs"
                  >
                    <div>
                      <div className="font-semibold text-gray-900 dark:text-white">{demo.name}</div>
                      <div className="text-gray-500 text-[11px] font-mono">{demo.email}</div>
                    </div>
                    <ArrowRight className="w-3.5 h-3.5 text-gray-400" />
                  </button>
                ))}
              </div>
            </div>

            {/* Custom Gmail Form */}
            <form onSubmit={handleCustomFirebaseLogin} className="space-y-3 pt-3 border-t border-gray-100 dark:border-gray-800">
              <label className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider block">
                Or Enter Custom Gmail / Firebase UID
              </label>

              <div>
                <input
                  type="email"
                  placeholder="user@gmail.com"
                  value={customEmail}
                  onChange={(e) => setCustomEmail(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div>
                <input
                  type="text"
                  placeholder="Display Name (optional)"
                  value={customName}
                  onChange={(e) => setCustomName(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div>
                <input
                  type="text"
                  placeholder="Firebase ID Token / UID (optional)"
                  value={firebaseTokenInput}
                  onChange={(e) => setFirebaseTokenInput(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white placeholder-gray-400 font-mono focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting || (!customEmail && !firebaseTokenInput)}
                className="w-full py-2.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-600 disabled:opacity-50 text-white text-xs font-semibold shadow-sm transition-all flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <span>Syncing with MastiBase...</span>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Login & Map to MastiBase</span>
                  </>
                )}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Tab 2: Where Gmail ID is Displayed */}
      {activeTab === 'mapping' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-6 shadow-sm space-y-6">
            <div>
              <h2 className="text-xl font-bold text-gray-900 dark:text-white">
                Where the User Gmail ID Appears in Masti Video App & MastiBase
              </h2>
              <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                Detailed architecture mapping showing where the user's Gmail ID is stored, verified, and displayed across mobile and cloud components.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Screen 1: Mobile App Profile */}
              <div className="border border-gray-200 dark:border-gray-800 rounded-2xl p-5 bg-gray-50/50 dark:bg-gray-800/30 space-y-3">
                <div className="w-10 h-10 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400 flex items-center justify-center font-bold">
                  📱 1
                </div>
                <h3 className="font-bold text-gray-900 dark:text-white text-base">
                  Masti Video App Profile Tab
                </h3>
                <p className="text-xs text-gray-600 dark:text-gray-400">
                  Inside the mobile application, the user's Gmail ID is displayed in:
                </p>
                <ul className="text-xs space-y-1.5 text-gray-700 dark:text-gray-300 list-disc list-inside">
                  <li><strong className="text-blue-500">Settings → Account Info:</strong> Shows the active Gmail ID and linked phone.</li>
                  <li><strong className="text-blue-500">Top Navigation:</strong> User avatar and email badge.</li>
                  <li><strong className="text-blue-500">Creator Monetization:</strong> Payout recipient email for UPI/Bank notifications.</li>
                </ul>
              </div>

              {/* Screen 2: MastiBase Cloud Database */}
              <div className="border border-gray-200 dark:border-gray-800 rounded-2xl p-5 bg-gray-50/50 dark:bg-gray-800/30 space-y-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center font-bold">
                  🗄️ 2
                </div>
                <h3 className="font-bold text-gray-900 dark:text-white text-base">
                  MastiBase Database Records
                </h3>
                <p className="text-xs text-gray-600 dark:text-gray-400">
                  MastiBase stores the Gmail ID in the permanent users table:
                </p>
                <ul className="text-xs space-y-1.5 text-gray-700 dark:text-gray-300 list-disc list-inside">
                  <li><strong className="text-amber-500">users[].email:</strong> Permanent email identity.</li>
                  <li><strong className="text-amber-500">users[].firebaseUid:</strong> Linked Firebase authentication UID.</li>
                  <li><strong className="text-amber-500">users[].apiKey:</strong> Private API access key assigned to the Gmail ID.</li>
                </ul>
              </div>

              {/* Screen 3: Video Attribution & API Responses */}
              <div className="border border-gray-200 dark:border-gray-800 rounded-2xl p-5 bg-gray-50/50 dark:bg-gray-800/30 space-y-3">
                <div className="w-10 h-10 rounded-xl bg-purple-500/10 text-purple-600 dark:text-purple-400 flex items-center justify-center font-bold">
                  ⚡ 3
                </div>
                <h3 className="font-bold text-gray-900 dark:text-white text-base">
                  API Responses & Feeds
                </h3>
                <p className="text-xs text-gray-600 dark:text-gray-400">
                  When videos and profiles are synced:
                </p>
                <ul className="text-xs space-y-1.5 text-gray-700 dark:text-gray-300 list-disc list-inside">
                  <li><strong className="text-purple-500">/api/videos/feed:</strong> Returns creator display name and verified badge.</li>
                  <li><strong className="text-purple-500">/api/v1/user/sync:</strong> Returns the full Gmail profile with video uploads and stats.</li>
                  <li><strong className="text-purple-500">/api/auth/me:</strong> Returns the authenticated user record.</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Mobile App Integration Code */}
      {activeTab === 'mobile_code' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-6 shadow-sm space-y-4">
            <div>
              <h2 className="text-xl font-bold text-gray-900 dark:text-white">
                Masti Video Mobile App Integration Guide
              </h2>
              <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                Follow this exact standard: Mobile app signs in with Firebase Google / Phone Auth, obtains the Firebase ID Token, and sends it to MastiBase.
              </p>
            </div>

            <div className="space-y-4">
              {/* Kotlin / Android */}
              <div className="border border-gray-200 dark:border-gray-800 rounded-xl overflow-hidden">
                <div className="bg-gray-100 dark:bg-gray-800 px-4 py-2 flex items-center justify-between text-xs font-mono font-semibold">
                  <span>Android (Kotlin / Retrofit / OkHttp)</span>
                  <button
                    onClick={() => copyToClipboard(`// Step 1: Get Firebase ID token
val user = FirebaseAuth.getInstance().currentUser
user?.getIdToken(true)?.addOnCompleteListener { task ->
    if (task.isSuccessful) {
        val idToken = task.result?.token
        // Step 2: Send to MastiBase in Bearer Header
        val client = OkHttpClient.Builder()
            .addInterceptor { chain ->
                val request = chain.request().newBuilder()
                    .addHeader("Authorization", "Bearer $idToken")
                    .build()
                chain.proceed(request)
            }.build()

        // Step 3: Fetch MastiBase Video Feed
        // GET https://bfa13a34-5b66-4d87-a7a1-6c09e6e4bd79-00-h78h2s7wr35n.pike.replit.dev/api/videos/feed
    }
}`, 'code_kotlin')}
                    className="flex items-center gap-1 text-amber-500 hover:text-amber-600"
                  >
                    {copiedKey === 'code_kotlin' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>Copy Code</span>
                  </button>
                </div>
                <pre className="p-4 bg-gray-950 text-gray-100 font-mono text-xs overflow-x-auto">
{`// Step 1: Get Firebase ID token
val user = FirebaseAuth.getInstance().currentUser
user?.getIdToken(true)?.addOnCompleteListener { task ->
    if (task.isSuccessful) {
        val idToken = task.result?.token
        
        // Step 2: Set Authorization Header
        val client = OkHttpClient.Builder()
            .addInterceptor { chain ->
                val request = chain.request().newBuilder()
                    .addHeader("Authorization", "Bearer $idToken")
                    .build()
                chain.proceed(request)
            }.build()

        // Step 3: MastiBase Base URL
        val MASTIBASE_URL = "https://bfa13a34-5b66-4d87-a7a1-6c09e6e4bd79-00-h78h2s7wr35n.pike.replit.dev"
        // Feeds: $MASTIBASE_URL/api/videos/feed
        // Upload: $MASTIBASE_URL/api/videos/upload
        // Likes: $MASTIBASE_URL/api/videos/social/videos/{id}/like
    }
}`}
                </pre>
              </div>

              {/* Flutter / Dart */}
              <div className="border border-gray-200 dark:border-gray-800 rounded-xl overflow-hidden">
                <div className="bg-gray-100 dark:bg-gray-800 px-4 py-2 flex items-center justify-between text-xs font-mono font-semibold">
                  <span>Flutter (Dart / Dio / Http)</span>
                  <button
                    onClick={() => copyToClipboard(`// Step 1: Get Firebase ID Token
final User? user = FirebaseAuth.instance.currentUser;
final String? idToken = await user?.getIdToken();

// Step 2: Make request to MastiBase
final response = await http.get(
  Uri.parse('https://bfa13a34-5b66-4d87-a7a1-6c09e6e4bd79-00-h78h2s7wr35n.pike.replit.dev/api/videos/feed'),
  headers: {
    'Authorization': 'Bearer $idToken',
    'Content-Type': 'application/json',
  },
);`, 'code_dart')}
                    className="flex items-center gap-1 text-amber-500 hover:text-amber-600"
                  >
                    {copiedKey === 'code_dart' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>Copy Code</span>
                  </button>
                </div>
                <pre className="p-4 bg-gray-950 text-gray-100 font-mono text-xs overflow-x-auto">
{`// Step 1: Get Firebase ID Token
final User? user = FirebaseAuth.instance.currentUser;
final String? idToken = await user?.getIdToken();

// Step 2: Make request to MastiBase
final response = await http.get(
  Uri.parse('https://bfa13a34-5b66-4d87-a7a1-6c09e6e4bd79-00-h78h2s7wr35n.pike.replit.dev/api/videos/feed'),
  headers: {
    'Authorization': 'Bearer $idToken',
    'Content-Type': 'application/json',
  },
);`}
                </pre>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 4: Live API Test & Tokens */}
      {activeTab === 'api_test' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl p-6 shadow-sm space-y-4">
            <div>
              <h2 className="text-xl font-bold text-gray-900 dark:text-white">
                Active Session Token & API Endpoints
              </h2>
              <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                Inspect the active JWT Bearer token and test MastiBase live endpoints directly.
              </p>
            </div>

            {token ? (
              <div className="space-y-2">
                <label className="text-xs font-semibold text-gray-500 uppercase">Current Bearer Token</label>
                <div className="flex items-center gap-2">
                  <input
                    readOnly
                    value={token}
                    className="w-full px-3 py-2 bg-gray-50 dark:bg-gray-800 font-mono text-xs rounded-xl border border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300"
                  />
                  <button
                    onClick={() => copyToClipboard(token, 'bearer_token')}
                    className="px-4 py-2 bg-amber-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1"
                  >
                    {copiedKey === 'bearer_token' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5 text-white" />}
                    <span>Copy</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="p-4 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/50 rounded-xl text-xs text-amber-700 dark:text-amber-300">
                Log in to generate an active Bearer token.
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              <a
                href="/api/videos/feed"
                target="_blank"
                rel="noreferrer"
                className="p-3 bg-gray-50 dark:bg-gray-800/50 hover:bg-amber-50 dark:hover:bg-amber-950/30 border border-gray-200 dark:border-gray-700 rounded-xl flex items-center justify-between text-xs font-medium"
              >
                <span>GET /api/videos/feed</span>
                <ArrowRight className="w-4 h-4 text-gray-400" />
              </a>

              <a
                href="/api/auth/me"
                target="_blank"
                rel="noreferrer"
                className="p-3 bg-gray-50 dark:bg-gray-800/50 hover:bg-amber-50 dark:hover:bg-amber-950/30 border border-gray-200 dark:border-gray-700 rounded-xl flex items-center justify-between text-xs font-medium"
              >
                <span>GET /api/auth/me</span>
                <ArrowRight className="w-4 h-4 text-gray-400" />
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserLoginDisplay;
