import React, { useState, useEffect } from 'react';
import { api, formatBytes, formatDate } from '../services/api.js';
import { useToast } from './Toast.js';
import {
  Shield,
  Users,
  HardDrive,
  Film,
  Image as ImageIcon,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  IndianRupee,
  Sliders,
  XCircle,
  X,
  Sparkles,
  TrendingUp
} from 'lucide-react';
import { UserMonetizationCard } from './UserMonetizationCard.js';
import { MonetizationData, PromotionRequest } from '../types.js';

interface AdminUserItem {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'user';
  createdAt: string;
  totalUploads: number;
  isVerified?: boolean;
  monetization?: MonetizationData;
}

export const AdminConsole: React.FC = () => {
  const [users, setUsers] = useState<AdminUserItem[]>([]);
  const [promotionRequests, setPromotionRequests] = useState<PromotionRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState<any>(null);
  const [selectedMonetizeUser, setSelectedMonetizeUser] = useState<AdminUserItem | null>(null);
  const { showToast } = useToast();

  const loadAdminData = async () => {
    setLoading(true);
    try {
      const [res, promRes] = await Promise.all([
        api.getAdminOverview(),
        api.getPromotionRequests()
      ]);
      if (res.success && res.data) {
        setUsers(res.data.users || []);
        setStats(res.data.stats || null);
      }
      if (promRes.success && promRes.data) {
        setPromotionRequests(promRes.data || []);
      }
    } catch (err) {
      console.error('Failed to load admin data:', err);
    }
    setLoading(false);
  };

  useEffect(() => {
    loadAdminData();
  }, []);

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-xs font-semibold mb-2">
            <Shield className="w-3.5 h-3.5 text-amber-400" />
            <span>Super Administrator Mode</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
            Masti Bash Admin Console
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            System-wide user accounts, global media audits, and cloud storage engine metrics.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={async () => {
              if (confirm('Kya aap sabhi sample/fake accounts ko delete karna chahte hain? Sirf aapka aur asli users ka data bachega.')) {
                try {
                  const res = await api.purgeFakeUsers();
                  if (res.success) {
                    showToast('success', 'Cleaned!', res.message);
                    loadAdminData();
                  } else {
                    showToast('error', 'Failed', res.error || 'Could not purge fake accounts');
                  }
                } catch (e: any) {
                  showToast('error', 'Error', e.message);
                }
              }
            }}
            className="flex items-center gap-1.5 px-3 py-2 bg-rose-950/60 hover:bg-rose-900/80 text-rose-300 border border-rose-700/50 rounded-xl text-xs font-bold transition-all"
            title="Clean all sample/fake user accounts"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clean Sample Accounts</span>
          </button>

          <button
            onClick={loadAdminData}
            disabled={loading}
            className="flex items-center gap-2 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700 rounded-xl text-xs font-bold transition-all"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>Refresh Data</span>
          </button>
        </div>
      </div>

      {/* Admin Stats Grid */}
      {stats && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center">
              <Users className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xs text-slate-400 font-medium">Registered Accounts</span>
              <h3 className="text-2xl font-bold text-white mt-0.5">{stats.totalUsers}</h3>
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-purple-600/20 text-purple-400 border border-purple-500/30 flex items-center justify-center">
              <Film className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xs text-slate-400 font-medium">Total Video Streams</span>
              <h3 className="text-2xl font-bold text-white mt-0.5">{stats.totalVideos}</h3>
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-cyan-600/20 text-cyan-400 border border-cyan-500/30 flex items-center justify-center">
              <ImageIcon className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xs text-slate-400 font-medium">Total Image Assets</span>
              <h3 className="text-2xl font-bold text-white mt-0.5">{stats.totalImages}</h3>
            </div>
          </div>
        </div>
      )}

      {/* Registered Users Table */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        <h3 className="text-base font-bold text-white flex items-center gap-2">
          <Users className="w-5 h-5 text-indigo-400" />
          Registered Users & Roles
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] font-bold tracking-wider border-b border-slate-800">
              <tr>
                <th className="p-3.5">User</th>
                <th className="p-3.5">Email</th>
                <th className="p-3.5">Role</th>
                <th className="p-3.5">Media Assets</th>
                <th className="p-3.5">Earnings / Wallet</th>
                <th className="p-3.5">Monetize Status</th>
                <th className="p-3.5">Blue Tick</th>
                <th className="p-3.5">Joined Date</th>
                <th className="p-3.5 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {users.map(u => (
                <tr key={u.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="p-3.5 font-bold text-white flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-center text-xs text-indigo-400">
                      {u.name.charAt(0).toUpperCase()}
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span>{u.name}</span>
                      {u.isVerified && (
                        <span className="w-4 h-4 rounded-full bg-blue-500 text-white flex items-center justify-center text-[10px]" title="Verified Blue Tick">✓</span>
                      )}
                    </div>
                  </td>
                  <td className="p-3.5 font-mono text-slate-400">{u.email}</td>
                  <td className="p-3.5">
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                        u.role === 'admin'
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                          : 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40'
                      }`}
                    >
                      {u.role}
                    </span>
                  </td>
                  <td className="p-3.5 font-bold text-white">{u.totalUploads} files</td>
                  <td className="p-3.5 text-[11px] font-mono text-slate-300">
                    <div className="flex flex-col gap-0.5">
                      <span className="flex items-center gap-1 text-emerald-400 font-semibold">
                        <IndianRupee className="w-3 h-3" />
                        Wallet: ₹{(u.monetization?.walletBalance ?? 0).toFixed(2)}
                      </span>
                      <span className="flex items-center gap-1 text-indigo-400">
                        <TrendingUp className="w-3 h-3" />
                        Total: ₹{(u.monetization?.totalEarnings ?? 0).toFixed(2)}
                      </span>
                    </div>
                  </td>
                  <td className="p-3.5">
                    <button
                      type="button"
                      onClick={async () => {
                        const currentVal = u.monetization?.isEnabled !== false;
                        const nextVal = !currentVal;
                        try {
                          const res = await api.updateMonetizationControl(u.id, {
                            isEnabled: nextVal,
                            monetizationStatus: nextVal ? 'active' : 'disabled'
                          });
                          if (res.success && res.data) {
                            setUsers(prev => prev.map(item => item.id === u.id ? { ...item, monetization: res.data } : item));
                            showToast('success', 'Monetization Updated', `${u.name} Monetization is now ${nextVal ? 'ON (Active)' : 'OFF (Disabled)'}`);
                          } else {
                            showToast('error', 'Failed', res.error || 'Could not update monetization');
                          }
                        } catch (err: any) {
                          showToast('error', 'Error', err.message);
                        }
                      }}
                      className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-[11px] font-bold transition-all border shrink-0 ${
                        u.monetization?.isEnabled !== false
                          ? 'bg-emerald-600/20 text-emerald-300 border-emerald-500/50 hover:bg-emerald-600/30'
                          : 'bg-slate-950 text-slate-400 border-slate-800 hover:bg-slate-800 hover:text-slate-200'
                      }`}
                      title="Click to toggle Monetization on/off"
                    >
                      <span className={`w-2 h-2 rounded-full ${u.monetization?.isEnabled !== false ? 'bg-emerald-400 animate-pulse' : 'bg-slate-600'}`}></span>
                      <span>{u.monetization?.isEnabled !== false ? 'ACTIVE (ON)' : 'DISABLED (OFF)'}</span>
                    </button>
                  </td>
                  <td className="p-3.5">
                    <button
                      type="button"
                      onClick={async () => {
                        const nextVal = !u.isVerified;
                        try {
                          const res = await api.updateUserVerification(u.id, nextVal);
                          if (res.success) {
                            setUsers(prev => prev.map(item => item.id === u.id ? { ...item, isVerified: nextVal } : item));
                            showToast('success', 'Verification Updated', `${u.name} Blue Tick is now ${nextVal ? 'ON (Verified)' : 'OFF (Unverified)'}`);
                          } else {
                            showToast('error', 'Failed', res.error || 'Could not update verification');
                          }
                        } catch (err: any) {
                          showToast('error', 'Error', err.message);
                        }
                      }}
                      className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-[11px] font-bold transition-all border ${
                        u.isVerified
                          ? 'bg-blue-600/20 text-blue-300 border-blue-500/50 hover:bg-blue-600/30'
                          : 'bg-slate-950 text-slate-400 border-slate-800 hover:bg-slate-800 hover:text-slate-200'
                      }`}
                      title="Click to toggle Blue Tick badge on/off"
                    >
                      <span className={`w-2 h-2 rounded-full ${u.isVerified ? 'bg-blue-400 animate-pulse' : 'bg-slate-600'}`}></span>
                      <span>{u.isVerified ? 'VERIFIED (ON)' : 'UNVERIFIED (OFF)'}</span>
                    </button>
                  </td>
                  <td className="p-3.5 text-slate-400">{formatDate(u.createdAt)}</td>
                  <td className="p-3.5 text-right">
                    <div className="inline-flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => setSelectedMonetizeUser(u)}
                        className="p-1.5 px-2 rounded-lg bg-emerald-950/40 hover:bg-emerald-900/60 border border-emerald-800/40 text-emerald-300 hover:text-white transition-all inline-flex items-center gap-1 text-[11px]"
                        title="Open monetization controls"
                      >
                        <Sliders className="w-3 h-3" />
                        <span>Monetize</span>
                      </button>

                      <button
                        type="button"
                        onClick={async () => {
                          if (confirm(`Kya aap "${u.name}" (${u.email}) ko permanently delete karna chahte hain?`)) {
                            try {
                              const res = await api.deleteUser(u.id);
                              if (res.success) {
                                showToast('success', 'User Deleted', `${u.name} account has been removed.`);
                                loadAdminData();
                              } else {
                                showToast('error', 'Error', res.error || 'Failed to delete user');
                              }
                            } catch (e: any) {
                              showToast('error', 'Error', e.message);
                            }
                          }
                        }}
                        className="p-1.5 px-2 rounded-lg bg-rose-950/40 hover:bg-rose-900/60 border border-rose-800/40 text-rose-300 hover:text-white transition-all inline-flex items-center gap-1 text-[11px]"
                        title="Delete User"
                      >
                        <Trash2 className="w-3 h-3" />
                        <span>Remove</span>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Promotion Requests Section */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        <h3 className="text-base font-bold text-white flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-purple-400" />
          Video Promotion Requests
        </h3>
        {promotionRequests.length === 0 ? (
          <p className="text-sm text-slate-500">No pending promotion requests.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] font-bold tracking-wider border-b border-slate-800">
                <tr>
                  <th className="p-3.5">User</th>
                  <th className="p-3.5">Media Title</th>
                  <th className="p-3.5">Amount</th>
                  <th className="p-3.5">Duration</th>
                  <th className="p-3.5">Status</th>
                  <th className="p-3.5 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80">
                {promotionRequests.map(p => (
                  <tr key={p.id} className="hover:bg-slate-800/40">
                    <td className="p-3.5">{p.userName}</td>
                    <td className="p-3.5">{p.mediaTitle}</td>
                    <td className="p-3.5 font-mono text-emerald-400">₹{p.amount}</td>
                    <td className="p-3.5">{p.durationDays} days</td>
                    <td className="p-3.5">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                        p.status === 'pending' ? 'bg-amber-500/20 text-amber-300' :
                        p.status === 'approved' ? 'bg-emerald-500/20 text-emerald-300' :
                        'bg-rose-500/20 text-rose-300'
                      }`}>
                        {p.status}
                      </span>
                    </td>
                    <td className="p-3.5 text-right flex gap-2 justify-end">
                      {p.status === 'pending' && (
                        <>
                          <button onClick={async () => {
                             const res = await api.updatePromotionRequest(p.id, 'approved');
                             if (res.success) {
                               loadAdminData();
                               showToast('success', 'Approved', 'Promotion request approved.');
                             } else {
                               showToast('error', 'Error', res.error || 'Failed to approve');
                             }
                          }} className="text-emerald-400 hover:text-emerald-300">Approve</button>
                          <button onClick={async () => {
                             const res = await api.updatePromotionRequest(p.id, 'rejected');
                             if (res.success) {
                               loadAdminData();
                               showToast('success', 'Rejected', 'Promotion request rejected.');
                             } else {
                               showToast('error', 'Error', res.error || 'Failed to reject');
                             }
                          }} className="text-rose-400 hover:text-rose-300">Reject</button>
                        </>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* User Monetization Control Modal */}
      {selectedMonetizeUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="w-full max-w-xl max-h-[92vh] overflow-y-auto rounded-2xl bg-slate-900 border border-emerald-500/30 p-3.5 sm:p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <IndianRupee className="w-5 h-5 text-emerald-400" />
                <h3 className="text-sm sm:text-base font-bold text-white">
                  Masti Video App Monetization Control
                </h3>
              </div>
              <button
                onClick={() => setSelectedMonetizeUser(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-white">{selectedMonetizeUser.name}</span>
                    {selectedMonetizeUser.isVerified && (
                      <span className="w-3.5 h-3.5 rounded-full bg-blue-500 text-white flex items-center justify-center text-[9px]" title="Verified">✓</span>
                    )}
                  </div>
                  <span className="text-[11px] text-slate-400 block">{selectedMonetizeUser.email}</span>
                </div>
                <span className="text-[11px] font-mono text-purple-300 bg-purple-950/50 px-2 py-0.5 rounded border border-purple-800/40">
                  UID: {selectedMonetizeUser.id}
                </span>
              </div>

              {/* Blue Tick Control Switch */}
              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className={`w-4 h-4 ${selectedMonetizeUser.isVerified ? 'text-blue-400' : 'text-slate-500'}`} />
                  <div>
                    <span className="text-xs font-bold text-slate-200 block">Blue Tick (Verified Badge)</span>
                    <span className="text-[10px] text-slate-400">Give verified badge on profile and uploads</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={async () => {
                    const nextVal = !selectedMonetizeUser.isVerified;
                    try {
                      const res = await api.updateUserVerification(selectedMonetizeUser.id, nextVal);
                      if (res.success) {
                        setSelectedMonetizeUser(prev => prev ? { ...prev, isVerified: nextVal } : null);
                        setUsers(prev => prev.map(item => item.id === selectedMonetizeUser.id ? { ...item, isVerified: nextVal } : item));
                        showToast('success', 'Verification Updated', `${selectedMonetizeUser.name} Blue Tick is now ${nextVal ? 'ON (Verified)' : 'OFF (Unverified)'}`);
                      } else {
                        showToast('error', 'Failed', res.error || 'Could not update verification');
                      }
                    } catch (err: any) {
                      showToast('error', 'Error', err.message);
                    }
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all border inline-flex items-center gap-1.5 ${
                    selectedMonetizeUser.isVerified
                      ? 'bg-blue-600 text-white border-blue-500 shadow-lg shadow-blue-600/30'
                      : 'bg-slate-900 text-slate-400 border-slate-800 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <span className={`w-2 h-2 rounded-full ${selectedMonetizeUser.isVerified ? 'bg-white animate-pulse' : 'bg-slate-600'}`}></span>
                  <span>{selectedMonetizeUser.isVerified ? 'VERIFIED (ON)' : 'UNVERIFIED (OFF)'}</span>
                </button>
              </div>
            </div>

            <UserMonetizationCard
              userId={selectedMonetizeUser.id}
              userName={selectedMonetizeUser.name}
              userEmail={selectedMonetizeUser.email}
              initialData={selectedMonetizeUser.monetization}
              onUpdate={(updated) => {
                setUsers(prev => prev.map(u => u.id === selectedMonetizeUser.id ? { ...u, monetization: updated } : u));
              }}
              canControl={true}
            />

            <div className="flex justify-end pt-2">
              <button
                type="button"
                onClick={() => setSelectedMonetizeUser(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition-all"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
