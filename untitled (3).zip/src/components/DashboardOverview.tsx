import React, { useState, useEffect } from 'react';
import { MediaFile, CreatorProfileItem } from '../types.js';
import { formatBytes, formatDate, resolveMediaUrl, api } from '../services/api.js';
import { useToast } from './Toast.js';
import {
  Film,
  Image as ImageIcon,
  Music,
  HardDrive,
  UploadCloud,
  ArrowRight,
  Sparkles,
  Play,
  Copy,
  Check,
  CheckCircle2,
  FolderOpen,
  Radio,
  Zap,
  Globe
} from 'lucide-react';

interface DashboardOverviewProps {
  media: MediaFile[];
  loading: boolean;
  onNavigateToUpload: () => void;
  onNavigateToLibrary: () => void;
  onNavigateToConnect: () => void;
  onSelectVideo: (media: MediaFile) => void;
  onSelectImage: (media: MediaFile) => void;
  onSelectAudio?: (media: MediaFile) => void;
}

const UniqueMastiVerifiedBadge = ({ className = "w-3.5 h-3.5" }: { className?: string }) => (
  <svg 
    aria-label="Verified" 
    className={`shrink-0 drop-shadow-[0_0_3px_rgba(168,85,247,0.6)] ${className}`} 
    viewBox="0 0 100 100" 
    fill="none" 
    xmlns="http://www.w3.org/2000/svg"
  >
    <defs>
      <linearGradient id="mastiPremiumGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#00F0FF" />
        <stop offset="50%" stopColor="#8A2BE2" />
        <stop offset="100%" stopColor="#FF1493" />
      </linearGradient>
    </defs>
    <path d="M50 0L64.4 12.5H82.5V30.6L100 50L82.5 69.4V87.5H64.4L50 100L35.6 87.5H17.5V69.4L0 50L17.5 30.6V12.5H35.6L50 0Z" fill="url(#mastiPremiumGrad)" />
    <path d="M35 50L45 60L65 40" stroke="white" strokeWidth="8" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

export const DashboardOverview: React.FC<DashboardOverviewProps> = ({
  media,
  loading,
  onNavigateToUpload,
  onNavigateToLibrary,
  onNavigateToConnect,
  onSelectVideo,
  onSelectImage,
  onSelectAudio
}) => {
  const { showToast } = useToast();
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [creatorsList, setCreatorsList] = useState<CreatorProfileItem[]>([]);

  useEffect(() => {
    api.getCreators().then(res => {
      if (res.success && Array.isArray(res.data)) {
        setCreatorsList(res.data);
      }
    });
  }, []);

  const currentPublicServerUrl = typeof window !== 'undefined' ? window.location.origin : 'https://ais-dev-vqsmp4cogfojsrm6tre6zu-18143192690.asia-east1.run.app';

  const handleCopyServerUrl = () => {
    navigator.clipboard.writeText(currentPublicServerUrl);
    setCopiedUrl(true);
    showToast('success', 'Public Server URL Copied!', 'Use this as your BASE_URL in Masti Video app.');
    setTimeout(() => setCopiedUrl(false), 2500);
  };

  const totalFiles = media.length;
  const totalVideos = media.filter(m => m.mediaType === 'video').length;
  const totalAudio = media.filter(m => m.mediaType === 'audio').length;
  const totalImages = media.filter(m => m.mediaType === 'image').length;
  const folders = Array.from(new Set(media.map(m => m.folder || 'general'))).filter(Boolean);

  const recentMedia = [...media].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).slice(0, 6);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-indigo-900/60 via-slate-900 to-cyan-950/60 border border-slate-800 p-6 sm:p-8 shadow-2xl">
        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-xs font-semibold mb-3">
            <Radio className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
            <span>Masti Video Cloud Storage Engine Online</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight leading-tight">
            Public Media Cloud for <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-cyan-400">Masti Bash</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-2.5 leading-relaxed">
            Store, stream, and deliver 4K videos, reels, high-fidelity audio tracks, and images directly into your Masti Video app with live CDN streaming and full social synchronization.
          </p>

          {/* 🌟 1-Click Public Server URL Banner */}
          <div className="mt-5 p-3.5 rounded-2xl bg-slate-950/80 border border-cyan-500/30 backdrop-blur-md space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-cyan-300 uppercase tracking-wider flex items-center gap-1.5">
                <Globe className="w-3.5 h-3.5 text-cyan-400 animate-spin-slow" />
                Masti Bash Public Server Base URL
              </span>
              <span className="text-[10px] text-emerald-400 font-semibold px-2 py-0.5 rounded-full bg-emerald-950/60 border border-emerald-800/40">
                Live & Connected
              </span>
            </div>
            
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
              <code className="flex-1 px-3 py-2 rounded-xl bg-slate-900 text-cyan-300 font-mono text-xs border border-slate-800 select-all overflow-x-auto">
                {currentPublicServerUrl}
              </code>
              <button
                onClick={handleCopyServerUrl}
                className="px-4 py-2 bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-1.5 shrink-0"
              >
                {copiedUrl ? <Check className="w-4 h-4 text-emerald-300" /> : <Copy className="w-4 h-4" />}
                <span>{copiedUrl ? 'Copied URL!' : 'Copy Server URL'}</span>
              </button>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3 mt-5">
            <button
              onClick={onNavigateToUpload}
              className="px-5 py-2.5 bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 text-white text-xs font-bold rounded-xl shadow-lg shadow-indigo-600/30 transition-all flex items-center gap-2"
            >
              <UploadCloud className="w-4 h-4" />
              <span>Upload New Media</span>
            </button>

            <button
              onClick={onNavigateToConnect}
              className="px-5 py-2.5 bg-slate-900/80 hover:bg-slate-800 text-slate-200 border border-slate-700 text-xs font-bold rounded-xl transition-all flex items-center gap-2"
            >
              <Zap className="w-4 h-4 text-amber-400" />
              <span>Connect Masti Video</span>
            </button>
          </div>
        </div>

        {/* Ambient Glows */}
        <div className="absolute top-0 right-0 -mt-10 -mr-10 w-80 h-80 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 right-1/4 -mb-10 w-64 h-64 bg-cyan-600/10 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* Metric Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5">
        {/* Total Assets */}
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-sm flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center shrink-0">
            <HardDrive className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] text-slate-400 font-medium">All Files</span>
            <h3 className="text-xl font-bold text-white mt-0.5">{totalFiles}</h3>
          </div>
        </div>

        {/* Total Videos */}
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-sm flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-purple-600/20 text-purple-400 border border-purple-500/30 flex items-center justify-center shrink-0">
            <Film className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] text-slate-400 font-medium">Videos</span>
            <h3 className="text-xl font-bold text-white mt-0.5">{totalVideos}</h3>
          </div>
        </div>

        {/* Total Audio */}
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-sm flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-amber-600/20 text-amber-400 border border-amber-500/30 flex items-center justify-center shrink-0">
            <Music className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] text-slate-400 font-medium">Audio Tracks</span>
            <h3 className="text-xl font-bold text-white mt-0.5">{totalAudio}</h3>
          </div>
        </div>

        {/* Total Images */}
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-sm flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-cyan-600/20 text-cyan-400 border border-cyan-500/30 flex items-center justify-center shrink-0">
            <ImageIcon className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] text-slate-400 font-medium">Images</span>
            <h3 className="text-xl font-bold text-white mt-0.5">{totalImages}</h3>
          </div>
        </div>

        {/* Folders / Categories */}
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-sm flex items-center gap-3.5 col-span-2 sm:col-span-1">
          <div className="w-10 h-10 rounded-xl bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center shrink-0">
            <FolderOpen className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] text-slate-400 font-medium">Folders</span>
            <h3 className="text-xl font-bold text-white mt-0.5">{folders.length || 1}</h3>
          </div>
        </div>
      </div>

      {/* Recent Uploads & Integration Status Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Media Grid */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-400" />
              Recent Uploads
            </h3>
            <button
              onClick={onNavigateToLibrary}
              className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 flex items-center gap-1 transition-colors"
            >
              <span>View All Library</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {recentMedia.length === 0 ? (
            <div className="p-8 rounded-2xl bg-slate-900 border border-slate-800 text-center">
              <p className="text-xs text-slate-400">No media uploaded yet.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3.5">
              {recentMedia.map(item => {
                const isVideo = item.mediaType === 'video';
                const isAudio = item.mediaType === 'audio';
                const creator = creatorsList.find(c => c.id === item.userId);
                
                const handleClick = () => {
                  if (isAudio && onSelectAudio) {
                    onSelectAudio(item);
                  } else if (isVideo) {
                    onSelectVideo(item);
                  } else {
                    onSelectImage(item);
                  }
                };

                return (
                  <div
                    key={item.id}
                    onClick={handleClick}
                    className="group relative rounded-xl bg-slate-900 border border-slate-800 overflow-hidden cursor-pointer hover:border-indigo-500/50 hover:shadow-lg transition-all"
                  >
                    <div className="aspect-video w-full bg-slate-950 overflow-hidden relative flex items-center justify-center">
                      {isAudio ? (
                        item.posterUrl ? (
                          <div className="relative w-full h-full">
                            <img src={resolveMediaUrl(item.posterUrl)} alt={item.originalName} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                            <div className="absolute inset-0 bg-slate-950/40 group-hover:bg-slate-950/20 flex items-center justify-center transition-colors">
                              <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-amber-500 to-rose-600 flex items-center justify-center text-white shadow-md group-hover:scale-110 transition-transform">
                                <Play className="w-4 h-4 ml-0.5 fill-current" />
                              </div>
                            </div>
                          </div>
                        ) : (
                          <div className="w-full h-full bg-gradient-to-tr from-slate-950 via-slate-900 to-slate-800 flex items-center justify-center">
                            <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-amber-500 to-rose-600 flex items-center justify-center text-white shadow-md group-hover:scale-110 transition-transform">
                              <Play className="w-4 h-4 ml-0.5 fill-current" />
                            </div>
                          </div>
                        )
                      ) : isVideo ? (
                        <>
                          <video src={resolveMediaUrl(item.fileUrl)} preload="metadata" className="w-full h-full object-cover" />
                          <div className="absolute inset-0 bg-slate-950/40 group-hover:bg-slate-950/20 flex items-center justify-center transition-colors">
                            <div className="w-8 h-8 rounded-full bg-indigo-600/90 text-white flex items-center justify-center">
                              <Play className="w-4 h-4 ml-0.5 fill-current" />
                            </div>
                          </div>
                        </>
                      ) : (
                        <img src={resolveMediaUrl(item.fileUrl)} alt={item.originalName} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                      )}
                      <span className="absolute bottom-1.5 right-1.5 px-1.5 py-0.5 rounded bg-slate-950/80 text-[9px] font-mono text-slate-300 border border-slate-800 uppercase">
                        {item.mediaType}
                      </span>
                    </div>

                    <div className="p-2.5">
                      <h4 className="text-xs font-semibold text-white truncate" title={item.originalName}>
                        {item.originalName}
                      </h4>
                      <div className="flex items-center justify-between mt-1.5">
                        <div className="flex items-center gap-1 truncate">
                          <img src={creator?.avatarUrl || item.userAvatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${item.userId}`} alt="" className="w-4 h-4 rounded-full"/>
                          <span className="text-[10px] text-slate-300 truncate">{creator?.name || item.userName}</span>
                          {creator?.isVerified && <UniqueMastiVerifiedBadge className="w-3 h-3"/>}
                        </div>
                        <span className="text-[10px] text-slate-500">
                           {formatDate(item.createdAt)}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Integration Status Panel */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Zap className="w-4 h-4 text-amber-400" />
              Masti Video Live API
            </h3>
            <span className="px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800 text-[10px] font-semibold">
              Live & Healthy
            </span>
          </div>

          <div className="space-y-2.5 text-xs">
            <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950 border border-slate-800/80">
              <span className="text-slate-400">API Gateway</span>
              <span className="font-mono text-indigo-400">/api/v1/media</span>
            </div>

            <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950 border border-slate-800/80">
              <span className="text-slate-400">CORS Policy</span>
              <span className="font-semibold text-emerald-400">Permissive (All Mobile Apps)</span>
            </div>

            <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950 border border-slate-800/80">
              <span className="text-slate-400">Streaming Protocol</span>
              <span className="font-semibold text-slate-200">HTTP 206 Range Stream</span>
            </div>

            <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950 border border-slate-800/80">
              <span className="text-slate-400">Authentication</span>
              <span className="font-semibold text-slate-200">API Key & JWT Bearer</span>
            </div>
          </div>

          <button
            onClick={onNavigateToConnect}
            className="w-full py-2.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold border border-slate-700 transition-all flex items-center justify-center gap-1.5"
          >
            <span>Open Connect Hub & API Keys</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
