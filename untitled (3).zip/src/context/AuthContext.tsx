import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, UserRole, AuthResponse } from '../types.js';

interface AuthContextType {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isAdmin: boolean;
  loading: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  register: (name: string, email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  loginWithGoogle: (email: string, name?: string) => Promise<{ success: boolean; error?: string }>;
  loginWithPhone: (phone: string, otp?: string, name?: string) => Promise<{ success: boolean; error?: string }>;
  loginWithFirebase: (firebaseIdTokenOrUid: string, email?: string, name?: string, avatarUrl?: string, phoneNumber?: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(() => localStorage.getItem('mb_token'));
  const [loading, setLoading] = useState(true);

  const fetchCurrentUser = async (authToken: string) => {
    try {
      const res = await fetch('/api/auth/me', {
        headers: {
          Authorization: `Bearer ${authToken}`
        }
      });
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.user) {
          setUser(data.user);
          return true;
        }
      }
    } catch (err) {
      console.error('Error validating session:', err);
    }
    return false;
  };

  useEffect(() => {
    const initAuth = async () => {
      const storedToken = localStorage.getItem('mb_token');
      if (storedToken) {
        setToken(storedToken);
        const valid = await fetchCurrentUser(storedToken);
        if (!valid) {
          localStorage.removeItem('mb_token');
          setToken(null);
          setUser(null);
        }
      }
      setLoading(false);
    };

    initAuth();
  }, []);

  const login = async (email: string, password: string) => {
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
      const data = await res.json();
      if (res.ok && data.success && data.token) {
        localStorage.setItem('mb_token', data.token);
        setToken(data.token);
        setUser(data.user);
        return { success: true };
      }
      return { success: false, error: data.error || 'Login failed' };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error during login' };
    }
  };

  const register = async (name: string, email: string, password: string) => {
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password })
      });
      const data = await res.json();
      if (res.ok && data.success && data.token) {
        localStorage.setItem('mb_token', data.token);
        setToken(data.token);
        setUser(data.user);
        return { success: true };
      }
      return { success: false, error: data.error || 'Registration failed' };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error during registration' };
    }
  };

  const loginWithGoogle = async (email: string, name?: string) => {
    try {
      const res = await fetch('/api/auth/google', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, name })
      });
      const data = await res.json();
      if (res.ok && data.success && data.token) {
        localStorage.setItem('mb_token', data.token);
        setToken(data.token);
        setUser(data.user);
        return { success: true };
      }
      return { success: false, error: data.error || 'Google login failed' };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error during Google login' };
    }
  };

  const loginWithPhone = async (phone: string, otp?: string, name?: string) => {
    try {
      const res = await fetch('/api/auth/phone', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone, otp, name })
      });
      const data = await res.json();
      if (res.ok && data.success && data.token) {
        localStorage.setItem('mb_token', data.token);
        setToken(data.token);
        setUser(data.user);
        return { success: true };
      }
      return { success: false, error: data.error || 'Phone login failed' };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error during Phone login' };
    }
  };

  const loginWithFirebase = async (
    firebaseIdTokenOrUid: string,
    email?: string,
    name?: string,
    avatarUrl?: string,
    phoneNumber?: string
  ) => {
    try {
      const isJwtToken = firebaseIdTokenOrUid.split('.').length === 3;
      const payload = isJwtToken
        ? { firebaseIdToken: firebaseIdTokenOrUid, email, name, avatarUrl, phoneNumber }
        : { firebaseUid: firebaseIdTokenOrUid, email, name, avatarUrl, phoneNumber };

      const res = await fetch('/api/auth/firebase-login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const data = await res.json();
      if (res.ok && data.success && data.token) {
        localStorage.setItem('mb_token', data.token);
        setToken(data.token);
        setUser(data.user);
        return { success: true };
      }
      return { success: false, error: data.error || 'Firebase authentication failed' };
    } catch (err: any) {
      return { success: false, error: err.message || 'Network error during Firebase login' };
    }
  };

  const logout = () => {
    localStorage.removeItem('mb_token');
    setToken(null);
    setUser(null);
  };

  const refreshUser = async () => {
    if (token) {
      await fetchCurrentUser(token);
    }
  };

  const isAdmin = user?.role === 'admin';
  const isAuthenticated = !!user && !!token;

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isAuthenticated,
        isAdmin,
        loading,
        login,
        register,
        loginWithGoogle,
        loginWithPhone,
        loginWithFirebase,
        logout,
        refreshUser
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
