import { MediaFile, ApiKey, MediaType } from '../types.js';

const parseSafeJson = async (res: Response) => {
  const text = await res.text().catch(() => '');
  try {
    return JSON.parse(text);
  } catch {
    return { success: false, error: `Server error (${res.status}): ${text.slice(0, 100)}` };
  }
};

const getAuthHeaders = () => {
  const token = localStorage.getItem('mb_token');
  const headers: Record<string, string> = {
    'Content-Type': 'application/json'
  };
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  return headers;
};

export interface MediaFilterParams {
  mediaType?: MediaType;
  search?: string;
  folder?: string;
  sort?: string;
  page?: number;
  limit?: number;
  allUsers?: boolean;
}

export const api = {
  // Upload files with real progress callback
  uploadFiles: (
    files: File[],
    onProgress?: (progress: number) => void,
    folder: string = 'general',
    tags: string = '',
    metadata?: Record<string, { duration?: number; width?: number; height?: number; posterUrl?: string }>,
    extraFields?: {
      title?: string;
      caption?: string;
      soundtrackTitle?: string;
      audioUrl?: string;
      itemDetails?: Record<string, {
        title?: string;
        caption?: string;
        tags?: string[];
        music?: { title?: string; url?: string; artist?: string };
        soundtrackTitle?: string;
        audioUrl?: string;
      }>;
    }
  ): Promise<{ success: boolean; data?: MediaFile | MediaFile[]; error?: string }> => {
    return new Promise((resolve) => {
      const formData = new FormData();
      for (const file of files) {
        formData.append('files', file);
      }
      formData.append('folder', folder);
      formData.append('tags', tags);
      if (metadata) {
        formData.append('metadata', JSON.stringify(metadata));
      }
      if (extraFields) {
        if (extraFields.title) formData.append('title', extraFields.title);
        if (extraFields.caption) formData.append('caption', extraFields.caption);
        if (extraFields.soundtrackTitle) formData.append('soundtrackTitle', extraFields.soundtrackTitle);
        if (extraFields.audioUrl) formData.append('audioUrl', extraFields.audioUrl);
        if (extraFields.itemDetails) formData.append('itemDetails', JSON.stringify(extraFields.itemDetails));
      }

      const xhr = new XMLHttpRequest();
      const token = localStorage.getItem('mb_token');

      xhr.open('POST', '/api/v1/media/upload');
      if (token) {
        xhr.setRequestHeader('Authorization', `Bearer ${token}`);
      }

      xhr.upload.onprogress = (event) => {
        if (event.lengthComputable && onProgress) {
          const percentComplete = Math.round((event.loaded / event.total) * 100);
          onProgress(percentComplete);
        }
      };

      xhr.onload = () => {
        try {
          const response = JSON.parse(xhr.responseText);
          if (xhr.status >= 200 && xhr.status < 300 && response.success) {
            resolve({ success: true, data: response.data || response.files });
          } else {
            resolve({ success: false, error: response.error || `Upload failed with status ${xhr.status}` });
          }
        } catch (err) {
          resolve({ success: false, error: 'Failed to parse upload server response' });
        }
      };

      xhr.onerror = () => {
        resolve({ success: false, error: 'Network error occurred during upload' });
      };

      xhr.send(formData);
    });
  },

  uploadUrl: async (
    url: string,
    title?: string,
    caption?: string,
    folder: string = 'general',
    tags: string = ''
  ): Promise<{ success: boolean; data?: MediaFile; error?: string }> => {
    try {
      const res = await fetch('/api/v1/media/upload', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders()
        },
        body: JSON.stringify({
          videoUrl: url,
          title: title || 'Sponsored Video Ad',
          caption: caption || '#Sponsored #Ad',
          folder,
          tags
        })
      });
      const data = await res.json();
      return data;
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to upload video link' };
    }
  },

  // Media Endpoints
  getMedia: async (params?: MediaFilterParams) => {
    const query = new URLSearchParams();
    if (params?.mediaType) query.append('mediaType', params.mediaType);
    if (params?.search) query.append('search', params.search);
    if (params?.folder) query.append('folder', params.folder);
    if (params?.sort) query.append('sort', params.sort);
    if (params?.page) query.append('page', String(params.page));
    if (params?.limit) query.append('limit', String(params.limit));
    if (params?.allUsers) query.append('allUsers', 'true');

    const res = await fetch(`/api/v1/media?${query.toString()}`, {
      headers: getAuthHeaders()
    });
    return res.json();
  },

  getFolders: async () => {
    const res = await fetch('/api/v1/media/folders', {
      headers: getAuthHeaders()
    });
    return res.json();
  },

  getMediaById: async (id: string) => {
    const res = await fetch(`/api/v1/media/${id}`, {
      headers: getAuthHeaders()
    });
    return res.json();
  },

  updateMedia: async (id: string, data: Partial<MediaFile>) => {
    const res = await fetch(`/api/v1/media/${id}`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify(data)
    });
    return res.json();
  },

  setMediaPoster: async (id: string, poster: File | string | null) => {
    const token = localStorage.getItem('mb_token') || sessionStorage.getItem('mb_token');
    try {
      if (poster instanceof File) {
        const formData = new FormData();
        formData.append('poster', poster);
        const headers: Record<string, string> = {};
        if (token) {
          headers['Authorization'] = `Bearer ${token}`;
        }
        const res = await fetch(`/api/v1/media/${id}/poster`, {
          method: 'POST',
          headers,
          body: formData
        });
        if (!res.ok) {
          const errData = await res.json().catch(() => ({}));
          return { success: false, error: errData.error || `Server responded with status ${res.status}` };
        }
        return await res.json();
      } else {
        const headers: Record<string, string> = {
          'Content-Type': 'application/json'
        };
        if (token) {
          headers['Authorization'] = `Bearer ${token}`;
        }
        const res = await fetch(`/api/v1/media/${id}/poster`, {
          method: 'POST',
          headers,
          body: JSON.stringify({ posterUrl: poster })
        });
        if (!res.ok) {
          const errData = await res.json().catch(() => ({}));
          return { success: false, error: errData.error || `Server responded with status ${res.status}` };
        }
        return await res.json();
      }
    } catch (e: any) {
      console.error('setMediaPoster error:', e?.message || 'Failed to update poster');
      return { success: false, error: e?.message || 'Failed to connect to server' };
    }
  },

  deleteMedia: async (id: string) => {
    const res = await fetch(`/api/v1/media/${id}`, {
      method: 'DELETE',
      headers: getAuthHeaders()
    });
    return res.json();
  },

  batchDeleteMedia: async (ids: string[]) => {
    const res = await fetch('/api/v1/media/batch-delete', {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({ ids })
    });
    return res.json();
  },

  getStats: async () => {
    const res = await fetch('/api/v1/media/stats/overview', {
      headers: getAuthHeaders()
    });
    return res.json();
  },

  // API Keys
  getApiKeys: async () => {
    const res = await fetch('/api/v1/keys', {
      headers: getAuthHeaders()
    });
    return res.json();
  },

  createApiKey: async (name: string) => {
    const res = await fetch('/api/v1/keys', {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({ name })
    });
    return res.json();
  },

  deleteApiKey: async (id: string) => {
    const res = await fetch(`/api/v1/keys/${id}`, {
      method: 'DELETE',
      headers: getAuthHeaders()
    });
    return res.json();
  },

  // Admin
  getAdminOverview: async () => {
    const res = await fetch('/api/admin/overview', {
      headers: getAuthHeaders()
    });
    if (!res.ok) return parseSafeJson(res);
    return res.json().catch(() => ({ success: false, error: 'Invalid JSON response' }));
  },

  getAdminUsers: async () => {
    const res = await fetch('/api/admin/users', {
      headers: getAuthHeaders()
    });
    if (!res.ok) return parseSafeJson(res);
    return res.json().catch(() => ({ success: false, error: 'Invalid JSON response' }));
  },

  // Social & Community APIs (Likes, Comments, Shares, Follows, Chat)
  toggleLike: async (mediaId: string, userId?: string, userName?: string) => {
    const res = await fetch('/api/v1/social/like', {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({ mediaId, userId, userName })
    });
    return res.json();
  },

  getMediaLikes: async (mediaId: string) => {
    const res = await fetch(`/api/v1/social/like/${mediaId}`, {
      headers: getAuthHeaders()
    });
    return res.json();
  },

  getUserLikedMediaIds: async (userId: string) => {
    const res = await fetch(`/api/v1/social/likes/user/${userId}`, {
      headers: getAuthHeaders()
    });
    return res.json();
  },

  addComment: async (mediaId: string, text: string, userId?: string, userName?: string, userAvatar?: string) => {
    const res = await fetch('/api/v1/social/comment', {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({ mediaId, text, userId, userName, userAvatar })
    });
    return res.json();
  },

  getComments: async (mediaId: string) => {
    const res = await fetch(`/api/v1/social/comment/${mediaId}`, {
      headers: getAuthHeaders()
    });
    return res.json();
  },

  deleteComment: async (commentId: string, userId?: string) => {
    const res = await fetch(`/api/v1/social/comment/${commentId}`, {
      method: 'DELETE',
      headers: getAuthHeaders(),
      body: JSON.stringify({ userId })
    });
    return res.json();
  },

  recordShare: async (mediaId: string, platform?: string, shareUrl?: string, userId?: string) => {
    const res = await fetch('/api/v1/social/share', {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({ mediaId, platform, shareUrl, userId })
    });
    return res.json();
  },

  getShares: async (mediaId: string) => {
    const res = await fetch(`/api/v1/social/share/${mediaId}`, {
      headers: getAuthHeaders()
    });
    return res.json();
  },

  toggleFollow: async (followingId: string, followingName?: string, followerId?: string, followerName?: string) => {
    const res = await fetch('/api/v1/social/follow', {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({ followingId, followingName, followerId, followerName })
    });
    return res.json();
  },

  getFollowers: async (userId: string) => {
    const res = await fetch(`/api/v1/social/followers/${userId}`, {
      headers: getAuthHeaders()
    });
    return res.json();
  },

  getFollowing: async (userId: string) => {
    const res = await fetch(`/api/v1/social/following/${userId}`, {
      headers: getAuthHeaders()
    });
    return res.json();
  },

  sendChatMessage: async (params: { receiverId: string; message: string; senderId?: string; senderName?: string; receiverName?: string; mediaUrl?: string; mediaType?: MediaType }) => {
    const res = await fetch('/api/v1/social/chat', {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(params)
    });
    return res.json();
  },

  getChatConversation: async (user1: string, user2: string) => {
    const res = await fetch(`/api/v1/social/chat/conversation?user1=${encodeURIComponent(user1)}&user2=${encodeURIComponent(user2)}`, {
      headers: getAuthHeaders()
    });
    return res.json();
  },

  getUserChatThreads: async (userId: string) => {
    const res = await fetch(`/api/v1/social/chat/threads/${userId}`, {
      headers: getAuthHeaders()
    });
    return res.json();
  },

  getCreators: async () => {
    const res = await fetch('/api/v1/social/creators', {
      headers: getAuthHeaders()
    });
    return res.json();
  },

  getSocialStats: async () => {
    const res = await fetch('/api/v1/social/stats', {
      headers: getAuthHeaders()
    });
    return res.json();
  },

  syncUserFromApp: async (userData: {
    userId: string;
    userName: string;
    userAvatar?: string;
    email?: string;
    followersCount?: number;
    followingCount?: number;
    bio?: string;
  }) => {
    const res = await fetch('/api/v1/social/user/sync', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeaders()
      },
      body: JSON.stringify(userData)
    });
    return res.json();
  },

  getUserSyncedProfile: async (userId: string) => {
    const res = await fetch(`/api/v1/social/user/${userId}`, {
      headers: getAuthHeaders()
    });
    return res.json();
  },

  syncUserByEmail: async (data: { email: string; name?: string; avatarUrl?: string; bio?: string }) => {
    const res = await fetch('/api/auth/email-sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return res.json();
  },

  getMediaByUserEmail: async (email: string, mediaType?: MediaType) => {
    const query = new URLSearchParams();
    query.append('userEmail', email);
    if (mediaType) query.append('mediaType', mediaType);
    const res = await fetch(`/api/v1/media?${query.toString()}`, {
      headers: getAuthHeaders()
    });
    return res.json();
  },

  // Notifications API
  getNotifications: async (userId: string) => {
    const res = await fetch(`/api/v1/social/notifications/${userId}`, {
      headers: getAuthHeaders()
    });
    return res.json();
  },

  markNotificationRead: async (notificationId: string) => {
    const res = await fetch(`/api/v1/social/notifications/read/${notificationId}`, {
      method: 'POST',
      headers: getAuthHeaders()
    });
    return res.json();
  },

  markAllNotificationsRead: async (userId: string) => {
    const res = await fetch(`/api/v1/social/notifications/read-all/${userId}`, {
      method: 'POST',
      headers: getAuthHeaders()
    });
    return res.json();
  },

  clearNotifications: async (userId: string) => {
    const res = await fetch(`/api/v1/social/notifications/${userId}`, {
      method: 'DELETE',
      headers: getAuthHeaders()
    });
    return res.json();
  },

  // Support & Help Tickets API
  getSupportTickets: async () => {
    const res = await fetch('/api/v1/social/support/tickets', {
      headers: getAuthHeaders()
    });
    return res.json();
  },

  submitSupportTicket: async (data: { subject: string; message: string; userName?: string; userEmail?: string }) => {
    const res = await fetch('/api/v1/social/support/ticket', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeaders()
      },
      body: JSON.stringify(data)
    });
    return res.json();
  },

  resolveSupportTicket: async (ticketId: string, adminReply: string) => {
    const res = await fetch(`/api/v1/social/support/resolve/${ticketId}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeaders()
      },
      body: JSON.stringify({ adminReply })
    });
    return res.json();
  },

  // Monetization API
  getMonetization: async (identifier: string) => {
    const res = await fetch(`/api/v1/social/monetization/${identifier}`, {
      headers: getAuthHeaders()
    });
    return res.json();
  },

  updateMonetizationControl: async (identifier: string, data: {
    isEnabled?: boolean;
    monetizationStatus?: 'active' | 'disabled' | 'in_review' | 'eligible' | 'suspended';
    walletBalance?: number;
    totalEarnings?: number;
    rpm?: number;
    cpm?: number;
    upiId?: string;
    accountHolderName?: string;
    note?: string;
  }) => {
    const res = await fetch(`/api/v1/social/monetization/control/${identifier}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeaders()
      },
      body: JSON.stringify(data)
    });
    return res.json();
  },

  requestPayout: async (data: { userId: string; amount: number; method?: string; accountInfo: string }) => {
    const res = await fetch('/api/v1/social/monetization/payout', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeaders()
      },
      body: JSON.stringify(data)
    });
    return res.json();
  },

  recordView: async (mediaId: string, viewerId?: string) => {
    const res = await fetch('/api/v1/social/view', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeaders()
      },
      body: JSON.stringify({ mediaId, viewerId })
    });
    return res.json();
  },

  deleteUser: async (userId: string) => {
    const res = await fetch(`/api/admin/users/${userId}`, {
      method: 'DELETE',
      headers: getAuthHeaders()
    });
    return res.json();
  },

  purgeFakeUsers: async () => {
    const res = await fetch('/api/admin/purge-fake-users', {
      method: 'POST',
      headers: getAuthHeaders()
    });
    return res.json();
  },

  updateUserVerification: async (userId: string, isVerified: boolean) => {
    const res = await fetch(`/api/admin/users/${userId}/verification`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeaders()
      },
      body: JSON.stringify({ isVerified })
    });
    return res.json();
  },

  updateUserAvatar: async (userId: string, avatarUrl: string) => {
    const res = await fetch(`/api/admin/users/${userId}/avatar`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeaders()
      },
      body: JSON.stringify({ avatarUrl })
    });
    return res.json();
  },

  getAdMobConfig: async () => {
    const res = await fetch('/api/videos/admob');
    return res.json();
  },

  updateAdMobConfig: async (config: Partial<any>) => {
    const res = await fetch('/api/videos/admob', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeaders()
      },
      body: JSON.stringify(config)
    });
    return res.json();
  },

  getPromotionRequests: async () => {
    const res = await fetch('/api/admin/promotions', {
      headers: getAuthHeaders()
    });
    return res.json();
  },

  updatePromotionRequest: async (id: string, status: 'approved' | 'rejected') => {
    const res = await fetch(`/api/admin/promotions/${id}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeaders()
      },
      body: JSON.stringify({ status })
    });
    return res.json();
  },

  getPayoutRequests: async () => {
    const res = await fetch('/api/admin/payouts', {
      headers: getAuthHeaders()
    });
    return res.json();
  },

  updatePayoutStatus: async (id: string, status: 'completed' | 'rejected', transactionRef?: string) => {
    const res = await fetch(`/api/admin/payouts/${id}/status`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeaders()
      },
      body: JSON.stringify({ status, transactionRef })
    });
    return res.json();
  }
};


// Utilities
export const formatBytes = (bytes: number, decimals: number = 2): string => {
  if (!bytes || bytes === 0) return '0 Bytes';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`;
};

export const formatDate = (dateString: string): string => {
  try {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  } catch {
    return dateString;
  }
};

export const formatDuration = (seconds?: number): string => {
  if (!seconds) return '--:--';
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
};

export const resolveMediaUrl = (url?: string): string => {
  if (!url) return '';
  // If url contains /uploads/, always route through relative path for rock-solid iframe & https streaming
  if (url.includes('/uploads/')) {
    const idx = url.indexOf('/uploads/');
    return url.substring(idx);
  }
  return url;
};

