export type UserRole = 'admin' | 'user';
export type MediaType = 'image' | 'video' | 'audio';

export interface UserSocialLinks {
  instagram?: string;
  youtube?: string;
  facebook?: string;
  twitter?: string;
  website?: string;
  whatsapp?: string;
  telegram?: string;
}

export interface PrivacySettings {
  isPrivate?: boolean;
  allowComments?: boolean;
  allowDuet?: boolean;
  allowDirectMessages?: boolean;
}

export interface NotificationSettings {
  likes?: boolean;
  comments?: boolean;
  follows?: boolean;
  directMessages?: boolean;
  monetization?: boolean;
}

export interface User {
  id: string; // Permanent MastiBase User ID (e.g. usr_...)
  firebaseUid?: string; // Mapped Firebase Auth UID
  username?: string;
  name: string;
  email: string;
  phoneNumber?: string;
  authProvider?: 'email' | 'google' | 'phone' | 'firebase';
  avatarUrl?: string;
  bio?: string;
  socialLinks?: UserSocialLinks;
  followersCount?: number;
  followingCount?: number;
  totalLikes?: number;
  totalVideos?: number;
  isVerified?: boolean;
  monetizationStatus?: 'active' | 'disabled' | 'in_review' | 'eligible' | 'suspended';
  privacySettings?: PrivacySettings;
  notificationSettings?: NotificationSettings;
  blockedUsers?: string[];
  mutedUsers?: string[];
  passwordHash: string;
  role: UserRole;
  apiKey: string;
  createdAt: string;
  updatedAt: string;
}

export interface MediaMusic {
  id?: string;
  title?: string;
  artist?: string;
  url?: string;
}

export interface MediaFile {
  id: string; // videoId
  userId: string; // owner MastiBase userId
  userEmail?: string;
  userName?: string;
  userAvatar?: string;
  originalName: string;
  storedName: string;
  mediaType: MediaType;
  mimeType: string;
  fileSize: number;
  fileUrl: string;
  videoUrl?: string;
  thumbnailUrl?: string;
  posterUrl?: string;
  title?: string;
  caption?: string;
  hashtags?: string[];
  mentions?: string[];
  music?: MediaMusic;
  audioUrl?: string;
  soundtrackTitle?: string;
  duration?: number;
  width?: number;
  height?: number;
  visibility?: 'public' | 'private' | 'unlisted';
  commentsEnabled?: boolean;
  duetEnabled?: boolean;
  tags: string[];
  folder: string;
  likesCount?: number;
  commentsCount?: number;
  sharesCount?: number;
  viewsCount?: number;
  savesCount?: number;
  downloadsCount?: number;
  likedBy?: string[];
  savedBy?: string[];
  createdAt: string;
  updatedAt: string;
}

export interface Like {
  id: string;
  mediaId: string;
  userId: string;
  userName?: string;
  createdAt: string;
}

export interface Save {
  id: string;
  mediaId: string;
  userId: string;
  createdAt: string;
}

export interface Comment {
  id: string;
  mediaId: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  text: string;
  replyToCommentId?: string;
  createdAt: string;
}

export interface Share {
  id: string;
  mediaId: string;
  userId?: string;
  platform?: string;
  shareUrl?: string;
  createdAt: string;
}

export interface Follow {
  id: string;
  followerId: string;
  followerName?: string;
  followingId: string;
  followingName?: string;
  createdAt: string;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  receiverId: string;
  receiverName?: string;
  message: string;
  mediaUrl?: string;
  mediaType?: MediaType;
  isRead?: boolean;
  isDeleted?: boolean;
  createdAt: string;
}

export interface Notification {
  id: string;
  userId: string; // recipient MastiBase userId
  actorId: string;
  actorName: string;
  actorAvatar?: string;
  type: 'like' | 'comment' | 'follow' | 'share' | 'chat' | 'monetization' | 'system' | 'save' | 'video_call' | 'audio_call';
  title: string;
  message: string;
  mediaId?: string;
  mediaThumbnail?: string;
  isRead: boolean;
  createdAt: string;
}

export interface SearchHistoryItem {
  id: string;
  userId: string;
  query: string;
  createdAt: string;
}

export interface ReportItem {
  id: string;
  reporterId: string;
  targetType: 'video' | 'user' | 'comment';
  targetId: string;
  reason: string;
  createdAt: string;
}

export interface SupportTicket {
  id: string;
  userId: string;
  userName: string;
  userEmail?: string;
  subject: string;
  message: string;
  status: 'open' | 'in_progress' | 'resolved';
  adminReply?: string;
  createdAt: string;
  updatedAt: string;
}

export interface PayoutTransaction {
  id: string;
  userId: string;
  amount: number;
  currency: string;
  status: 'completed' | 'processing' | 'pending' | 'rejected';
  method: 'upi' | 'bank_transfer' | 'paytm';
  accountInfo: string;
  transactionRef: string;
  createdAt: string;
}

export interface MonetizationData {
  userId: string;
  userName?: string;
  userEmail?: string;
  monetizationStatus: 'eligible' | 'approved' | 'active' | 'in_review' | 'disabled' | 'suspended';
  isEnabled?: boolean;
  statusMessage?: string;
  appSyncStatus?: string;
  totalEarnings: number; // in INR (₹)
  walletBalance: number;
  hasWalletOverride?: boolean;
  hasEarningsOverride?: boolean;
  estimatedMonthlyRevenue: number;
  rpm: number; // Revenue per 1k views (₹15 - ₹45)
  cpm: number;
  totalViews: number;
  monetizedViews: number;
  currency: 'INR' | 'USD';
  bankDetails?: {
    upiId?: string;
    accountNumber?: string;
    ifsc?: string;
    accountHolderName?: string;
  };
  payouts: PayoutTransaction[];
}

export interface CreatorProfileItem {
  id: string;
  name: string;
  username: string;
  email: string;
  role: string;
  avatarUrl: string;
  followersCount: number;
  followingCount: number;
  mediaCount: number;
  likesCount: number;
  isVerified?: boolean;
  badge?: string;
  bio?: string;
  monetization?: any;
  socialLinks?: {
    instagram?: string;
    youtube?: string;
    facebook?: string;
    twitter?: string;
    website?: string;
  };
}

export interface ApiKey {
  id: string;
  userId: string;
  keyName: string;
  key: string;
  createdAt: string;
  lastUsedAt?: string;
}

export interface AuthResponse {
  user: {
    id: string;
    firebaseUid?: string;
    username?: string;
    name: string;
    email: string;
    avatarUrl?: string;
    bio?: string;
    role: UserRole;
    apiKey: string;
    followersCount?: number;
    followingCount?: number;
    totalLikes?: number;
    totalVideos?: number;
  };
  token: string;
}

export interface VideoFeedItem {
  id: string;
  userId: string;
  videoUrl: string;
  thumbnailUrl: string;
  title: string;
  caption: string;
  hashtags?: string[];
  mentions?: string[];
  music?: MediaMusic;
  duration?: number;
  createdAt: string;
  visibility?: 'public' | 'private' | 'unlisted';
  commentsEnabled?: boolean;
  duetEnabled?: boolean;
  profile: {
    id: string;
    firebaseUid?: string;
    name: string;
    username: string;
    avatarUrl: string;
    bio?: string;
    followersCount?: number;
    followingCount?: number;
    isVerified?: boolean;
  };
  social: {
    likes: number;
    comments: number;
    views: number;
    shares: number;
    saves: number;
    isLiked?: boolean;
    isSaved?: boolean;
    isFollowing?: boolean;
  };
}

export interface PromotionRequest {
  id: string;
  userId: string;
  userName: string;
  mediaId: string;
  mediaTitle: string;
  amount: number;
  durationDays: number;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
}

export interface AdMobConfig {
  appId: string;
  bannerAdUnitId: string;
  interstitialAdUnitId: string;
  rewardedAdUnitId: string;
  nativeAdUnitId: string;
  isAdMobEnabled: boolean;
  isMonetizationEnabled: boolean;
  testMode: boolean;
  adFrequency: number; // Show ad every N videos
  updatedAt: string;
  // Dynamic App Features
  isVideoCallingEnabled?: boolean;
  isAudioCallingEnabled?: boolean;
  isVirtualGiftingEnabled?: boolean;
  isBadgesEnabled?: boolean;
  isSubscriptionsEnabled?: boolean;
  isStarsEnabled?: boolean;
  isPremiumGoldEnabled?: boolean;
  isUploadAllowed?: boolean;
  appVersion?: string;
  forceUpdate?: boolean;
  updateUrl?: string;
  // Visual Styling & Theme Engine
  theme?: {
    primaryColor: string;
    secondaryColor: string;
    fontFamily: 'modern' | 'classic' | 'gothic' | 'bold';
    borderRadius: number;
    layoutType: 'reels' | 'grid' | 'list';
    isDarkMode: boolean;
    cameraEngine?: 'expo' | 'vision';
  };
}
