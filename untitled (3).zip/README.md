# MASTI BASH - Cloud Media Storage & Delivery Platform

**Masti Bash** is a high-performance, production-ready cloud media management and storage platform built for video streaming and image hosting. Designed to effortlessly integrate with external clients, mobile applications (such as **Masti Video**), and backend services.

---

## ⚡ Features

1. **Authentication & Role-Based Access Control**
   - Secure user registration, login, and JWT token authentication.
   - Built-in Super Admin role for global file management and user audits.
   - Master and scoped API Keys for programmatic client access.

2. **Media Upload Engine**
   - Drag-and-drop multi-file upload for **videos** (`MP4`, `WebM`, `MOV`, `MKV`, `AVI`, `OGG`) and **images** (`JPG`, `PNG`, `WEBP`, `GIF`, `SVG`, `AVIF`).
   - Real-time upload progress tracking.
   - Collision-proof unique stored filenames and metadata indexing.
   - Custom folder categorization and tagging.

3. **Media Library & Delivery**
   - Grid and List views with instant search and filtering.
   - Filter by media type (Videos / Images), folder, or tags.
   - Sort by Newest, Oldest, Name, or File Size.
   - Built-in HTML5 Video Player with HTTP 206 Partial Content range streaming.
   - Lightbox image preview with zoom controls.
   - 1-click Direct URL copy, HTML5 embed snippets, and Markdown tags.
   - Single and batch delete with modal confirmations.

4. **Masti Video REST API Integration**
   - Full RESTful API with CORS enabled for mobile apps.
   - Support for `x-api-key` header and `Authorization: Bearer <token>` authentication.
   - Interactive Live API Playground with pre-built code snippets for React Native, cURL, JavaScript, and Python.

5. **Durable Storage & Database**
   - Automatic local file persistence in `/uploads` with streaming headers.
   - Persistent metadata store in `/data/mastibash_db.json`.

---

## 🚀 Quick Start

### 1. Installation
```bash
npm install
```

### 2. Environment Variables
Copy `.env.example` to `.env`:
```bash
PORT=3000
NODE_ENV=development
JWT_SECRET=your_secret_key_here
```

### 3. Run in Development Mode
```bash
npm run dev
```
The application will start on `http://localhost:3000`.

### 4. Build for Production
```bash
npm run build
npm start
```

---

## 🔑 Default Demo Accounts

| Role | Email | Password |
|---|---|---|
| **Super Admin** | `admin@mastibash.io` | `admin123` |
| **Demo Creator** | `creator@mastibash.io` | `creator123` |

---

## 📡 REST API Reference (For Masti Video App)

### 1. Upload Media
`POST /api/v1/media/upload`
- **Headers**: `x-api-key: <your_api_key>`
- **Body**: `multipart/form-data` (field: `files`, `folder`, `tags`)
- **Response**:
```json
{
  "success": true,
  "data": {
    "id": "med_a1b2c3d4e5",
    "originalName": "video_highlight.mp4",
    "storedName": "mb_video_highlight_1710000000_abc123.mp4",
    "mediaType": "video",
    "mimeType": "video/mp4",
    "fileSize": 18452090,
    "fileUrl": "http://localhost:3000/uploads/mb_video_highlight_1710000000_abc123.mp4",
    "folder": "promos",
    "tags": ["action", "4k"],
    "createdAt": "2026-08-23T10:00:00.000Z"
  }
}
```

### 2. List All Media
`GET /api/v1/media?mediaType=video&limit=20&sort=newest`
- **Headers**: `x-api-key: <your_api_key>`

### 3. Search Media
`GET /api/v1/media/search?q=promo`
- **Headers**: `x-api-key: <your_api_key>`

### 4. Get Single Item
`GET /api/v1/media/:id`
- **Headers**: `x-api-key: <your_api_key>`

### 5. Delete Media
`DELETE /api/v1/media/:id`
- **Headers**: `x-api-key: <your_api_key>`
