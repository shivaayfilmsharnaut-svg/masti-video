const fs = require('fs');
const dbPath = 'data/mastibash_db.json';
const data = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
const fakeEmailSuffix = '@mastibash.io';
const fakeIds = [
  'usr_admin', 'usr_creator', 'usr_masti_cinema',
  'usr_dj_rohit', 'usr_pawan_music', 'usr_desi_comedy', 'usr_tech_masti'
];

data.users = data.users.filter(u => {
  if (fakeIds.some(id => u.id.startsWith(id))) return false;
  if (u.email && u.email.toLowerCase().endsWith(fakeEmailSuffix)) return false;
  return true;
});

data.media_files = data.media_files.filter(m => 
  data.users.some(u => u.id === m.userId || u.email === m.userEmail)
);

// Clear likes, saves, comments, follows which might be fake or zero them out if you want to wipe all fake activity.
data.likes = [];
data.comments = [];
data.saves = [];
data.shares = [];
data.follows = [];

// Reset all real users and media counts
data.users.forEach(u => {
  u.followersCount = 0;
  u.followingCount = 0;
  u.totalLikes = 0;
});

data.media_files.forEach(m => {
  m.viewsCount = 0;
  m.likesCount = 0;
  m.commentsCount = 0;
  m.sharesCount = 0;
});

fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
console.log('Cleaned db');
